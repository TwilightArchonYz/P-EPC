import os


def print_structure(startpath):
    # 需要忽略的文件夹，保持输出整洁
    ignore_dirs = {'.git', '.idea', '__pycache__', '.vscode', 'wandb', 'logs', 'models'}

    print(f"Project Root: {os.path.abspath(startpath)}")
    print("Structure:")

    for root, dirs, files in os.walk(startpath):
        # 过滤掉不需要的文件夹
        dirs[:] = [d for d in dirs if d not in ignore_dirs]

        level = root.replace(startpath, '').count(os.sep)
        indent = ' ' * 4 * (level)
        print(f'{indent}{os.path.basename(root)}/')
        subindent = ' ' * 4 * (level + 1)

        for f in files:
            # 只显示 python 文件，或者 json/yaml 配置，忽略 .pyc
            if f.endswith('.py') or f.endswith('.json') or f.endswith('.pkl'):
                print(f'{subindent}{f}')


if __name__ == '__main__':
    # 扫描当前脚本所在的目录
    print_structure('.')
import os
import torch
import numpy as np
import random
import json
import datetime
import multiprocessing
import copy

# 导入自定义模块
from evorl.trainning.online import OnlineTrainer
from evorl.trainning.evaluator import Evaluator
from evorl.trainning.offline import OfflineTrainer
from evorl.factory import AlgorithmFactory
from evorl.utils.monitor import Monitor
from evorl.utils.naming import PathManager
from evorl.preprocessing import gen_baselines

# ==============================================================================
# PART 1: 预计算与全局常量 (Pre-calculation & Global Constants)
# ==============================================================================

# 1.1 系统与资源配置
# ------------------------------------------------------------
N_CORES = 12  # [系统] 物理核心数
# [Modified] 统一参数：种子池调整为 10 个
SEED_POOL = list(range(1, 11))

# [New] 重复实验配置
N_REPEATS = 2  # 重复训练次数
# [Modified] 种子列表
BASE_SEEDS = list(range(1, N_REPEATS + 1))  # [1, 2, ..., N]

# 资源列表
TRAIN_PROBLEMS = [1, 2]  # [环境] 参与训练的问题 ID
TARGET_DIMS = [20, 30]  # [环境] 目标维度列表 (移除 50)

# [Modified] 数据集划分逻辑: 统一 5/5/5 分布
# 总集: 1-15
GEN_INSTANCES = list(range(1, 16))

# 自动计算切分点
_n_total = len(GEN_INSTANCES)
_chunk = _n_total // 3

TRAIN_INSTANCES = GEN_INSTANCES[:_chunk]  # [1-5]
VAL_INSTANCES = GEN_INSTANCES[_chunk:2 * _chunk]  # [6-10]
TEST_INSTANCES = GEN_INSTANCES[2 * _chunk:]  # [11-15]

# 1.2 核心算法参数定义 (动作空间驱动)
# ------------------------------------------------------------
ALGO_PARAMS = [
    {
        'name': 'F',  # 缩放因子 (Scaling Factor)
        'options': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    },
    {
        'name': 'CR',  # 交叉概率 (Crossover Rate)
        'options': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
    }
]

# 动态计算网络维度
CALC_STATE_DIM = 4 + len(ALGO_PARAMS)
# DDQN 使用离散动作空间
CALC_ACTION_DIM = 1
for param in ALGO_PARAMS:
    CALC_ACTION_DIM *= len(param['options'])

# ==============================================================================
# PART 2: 主配置字典 (Main Configuration Dictionary)
# ==============================================================================

# 2.1 基础策略配置
# ------------------------------------------------------------
TRAIN_MODE = 'dynamic'
TOTAL_EPOCHS = 100  # [流程] 总训练轮数 (统一为 100)

# 2.2 定义基础配置
# ------------------------------------------------------------
TRAIN_CONFIG = {
    # [1] 系统基础设施
    'n_cores': N_CORES,
    'baseline_path': 'data/precomputed/baselines_shade.pkl',
    'expert_data_path': 'data/precomputed/expert_data.pkl',

    # [2] 全流程与策略控制
    'train_mode': TRAIN_MODE,
    'base_seed': BASE_SEEDS,  # [Modified] 指向种子列表
    'generate_data': True,

    'pretrain_epochs': 50,  # [阶段1] 离线预训练
    'epochs': TOTAL_EPOCHS,  # [阶段2] 在线 RL 训练
    'steps_per_epoch': 50,
    'seeds_per_instance': min(len(SEED_POOL), N_CORES),
    'save_interval': 50,
    'target_update_interval': 10,

    # [3] 问题与数据定义
    'prob_id': 1,
    'train_problems': TRAIN_PROBLEMS,
    'target_dims': TARGET_DIMS,

    # [Corrected] 使用切分后的集合
    'train_instances': TRAIN_INSTANCES,
    'validation_instances': VAL_INSTANCES,
    'test_instances': TEST_INSTANCES,
    'gen_instances': GEN_INSTANCES,

    'seed_pool': SEED_POOL,

    # [4] 智能体 (Agent) 超参数
    'agent_name': 'DuelingDQN',  # [Explicit]
    'state_dim': CALC_STATE_DIM,
    'action_dim': CALC_ACTION_DIM,
    'algo_params': ALGO_PARAMS,

    # Network & Optimization
    'lr': 1e-4,
    'gamma': 0.99,
    # [Modified] 统一参数：提升容量匹配 SAC
    'batch_size': 256,       # 128 -> 256
    'buffer_size': 1000000,  # 100k -> 1M
    'hidden_dim': 256,       # 128 -> 256
    'stream_hidden_dim': 64, # 保持流网络比例 (也可按需提升)

    # State Processing
    'state_bins': [5, 4, 4, 4, 4],
    'dim_norm_factor': 100.0,
    'ucb_beta': 1.0,

    # [5] 环境/求解器设置
    'ea_name': 'SHADE',
    'pop_size_factor': 18,
    'max_fes_factor': 5000,
}

# 2.3 模式绑定与参数注入
# ------------------------------------------------------------
EVAL_N_CYCLES = 1

if TRAIN_MODE == 'dynamic':
    TRAIN_CONFIG['dynamic_review_ratio'] = 0.2
    warmup_ratio = 0.1
    TRAIN_CONFIG['warmup_epochs'] = int(TOTAL_EPOCHS * warmup_ratio)
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)

elif TRAIN_MODE == 'standard':
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)

elif TRAIN_MODE == 'exhaustive':
    n_combos = len(TRAIN_PROBLEMS) * len(TARGET_DIMS)
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * n_combos

else:
    TRAIN_CONFIG['eval_interval'] = 10


def setup_seed(seed):
    """设置全局随机种子"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    print(f"[Main] Global random seed set to: {seed}")


def setup_experiment(config):
    """创建实验目录并保存配置"""
    tag = PathManager.get_naming_tag(config)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # [Modified] 加入 Mode 和 Seed 信息
    mode = config.get('train_mode', 'unknown')
    seed_val = config['base_seed']

    dir_name = f"{timestamp}_{mode}_{tag}_seed{seed_val}"

    exp_dir = os.path.join('../experiments', dir_name)
    os.makedirs(exp_dir, exist_ok=True)
    print(f"[Main] Experiment Directory Created: {exp_dir}")

    config_path = os.path.join(exp_dir, f"{tag}_config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    print(f"[Main] Configuration saved to {config_path}")
    return exp_dir


def _run_single_execution(config):
    """执行单次完整的训练流程"""
    current_seed = config['base_seed']
    setup_seed(current_seed)

    print("=" * 60)
    print(f"[Run] Starting Single Execution | Seed: {current_seed}")
    print(f"[Config] Agent: {config['agent_name']} (Discrete Off-Policy)")
    print("=" * 60)

    # 1. 实验目录初始化
    experiment_dir = setup_experiment(config)

    # 2. 自动数据生成
    if config.get('generate_data', True):
        gen_baselines.generate_dataset(config, experiment_dir=experiment_dir, check_consistency=True)

    # 3. 监控器与基准报告
    monitor = Monitor(config, experiment_dir=experiment_dir)
    monitor.report_baseline()

    # 4. 初始化 RL Agent
    print(f"[Main] Initializing Master Agent ({config['agent_name']})...")
    agent = AlgorithmFactory.create_agent(
        config['agent_name'],
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config['lr'],
        gamma=config['gamma'],
        batch_size=config['batch_size'],
        buffer_size=config['buffer_size'],
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config['stream_hidden_dim'],
        state_bins=config['state_bins'],
        algo_params=config['algo_params'],
        dim_norm_factor=config['dim_norm_factor'],
        device='cuda' if torch.cuda.is_available() else 'cpu',
        target_dims=config['target_dims']
    )

    # 5. 阶段 1: 离线预训练 (Offline Phase)
    pretrain_epochs = config.get('pretrain_epochs', 0)
    if pretrain_epochs > 0:
        print(f"[Run] Starting Offline Pre-training...")
        offline_trainer = OfflineTrainer(config, agent, monitor, experiment_dir=experiment_dir)
        offline_trainer.train()
    else:
        print(f"[Run] Skipping Offline Pre-training.")

    # 6. 阶段 2: 在线微调 (Online Phase)
    evaluator = Evaluator(config, monitor)
    online_trainer = OnlineTrainer(config, agent, evaluator, monitor, experiment_dir=experiment_dir)
    online_trainer.train()

    print(f"\n[Run] Execution Finished for Seed {current_seed}.\n")


def run_pipeline():
    """主训练管道 (Loop wrapper)"""
    seeds = TRAIN_CONFIG['base_seed']
    if not isinstance(seeds, list):
        seeds = [seeds]

    total_runs = len(seeds)
    print(f"\n>>> [Main] Planned Executions: {total_runs} runs (Seeds: {seeds})")

    for i, seed in enumerate(seeds):
        print("\n" + "#" * 80)
        print(f"### EXECUTION {i + 1}/{total_runs} | SEED {seed}")
        print("#" * 80 + "\n")

        current_config = copy.deepcopy(TRAIN_CONFIG)
        current_config['base_seed'] = seed

        try:
            _run_single_execution(current_config)
        except Exception as e:
            print(f"[Main] ERROR in execution {i + 1} (Seed {seed}): {e}")
            import traceback
            traceback.print_exc()
            print("[Main] Continuing to next seed...")

    print("\n>>> [Main] All executions completed.")


if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    run_pipeline()
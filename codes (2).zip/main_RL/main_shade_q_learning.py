import os
import torch
import numpy as np
import random
import json
import datetime
import multiprocessing
import copy

# 导入自定义模块
from evorl.trainning.online import OnlineTrainer
from evorl.trainning.evaluator import Evaluator
from evorl.trainning.offline import OfflineTrainer
from evorl.factory import AlgorithmFactory
from evorl.utils.monitor import Monitor
from evorl.utils.naming import PathManager
from evorl.preprocessing import gen_baselines

# ==============================================================================
# PART 1: 预计算与全局常量 (Pre-calculation & Global Constants)
# ==============================================================================

# 1.1 系统与资源配置
# ------------------------------------------------------------
N_CORES = 12  # [系统] 并行计算使用的 CPU 核心数
# [Modified] 统一参数：种子池调整为 10 个，与 SAC 保持一致
SEED_POOL = list(range(1, 11))

# [New] 重复实验配置 (保持与 SAC 一致的测试设置)
N_REPEATS = 2  # 重复训练次数
# [Modified] 种子列表
BASE_SEEDS = list(range(1, N_REPEATS + 1))  # [1, 2, ..., N]

# 资源列表
TRAIN_PROBLEMS = [1, 2]  # [环境] 参与训练的问题 ID
TARGET_DIMS = [20, 30]  # [环境] 目标维度列表 (移除 50)

# [Modified] 数据集划分逻辑: 先定义总集，再均分 (5/5/5)
# 总集: 1-15 (共15个实例)
GEN_INSTANCES = list(range(1, 16))

# 自动计算切分点
_n_total = len(GEN_INSTANCES)
_chunk = _n_total // 3

TRAIN_INSTANCES = GEN_INSTANCES[:_chunk]  # [1-5]
VAL_INSTANCES = GEN_INSTANCES[_chunk:2 * _chunk]  # [6-10]
TEST_INSTANCES = GEN_INSTANCES[2 * _chunk:]  # [11-15]

# 1.2 核心算法参数定义 (动作空间定义)
# ------------------------------------------------------------
# 定义 RL Agent 可控制的底层演化算法 (EA) 参数
ALGO_PARAMS = [
    {
        'name': 'F',  # 差分进化算法的缩放因子 (Scaling Factor)
        'options': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]  # F 的离散动作空间
    },
    {
        'name': 'CR',  # 差分进化算法的交叉概率 (Crossover Rate)
        'options': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]  # CR 的离散动作空间
    }
]

# 动态计算网络维度 (自动推导)
CALC_STATE_DIM = 4 + len(ALGO_PARAMS)  # 状态维数
CALC_ACTION_DIM = 1
for param in ALGO_PARAMS:
    CALC_ACTION_DIM *= len(param['options'])  # 动作维数: 离散组合 (72)

# ==============================================================================
# PART 2: 主配置字典 (Main Configuration Dictionary)
# ==============================================================================

# 2.1 基础策略配置 (Base Strategy)
# ------------------------------------------------------------
TRAIN_MODE = 'dynamic'  # [调度] 训练模式
TOTAL_EPOCHS = 100  # [流程] 总训练轮数 (Epochs)

# 2.2 定义基础配置 (Common Configuration)
# ------------------------------------------------------------
TRAIN_CONFIG = {
    # [1] 系统基础设施
    'n_cores': N_CORES,
    'baseline_path': 'data/precomputed/baselines_shade.pkl',
    'expert_data_path': 'data/precomputed/expert_data.pkl',

    # [2] 全流程与策略控制 (通用部分)
    'train_mode': TRAIN_MODE,
    'base_seed': BASE_SEEDS,  # [Modified] 指向种子列表
    'generate_data': True,  # 默认 True，通过一致性检查决定是否跳过

    'pretrain_epochs': 50,  # [阶段1] 离线预训练
    'epochs': TOTAL_EPOCHS,  # [阶段2] 在线 RL 训练
    'steps_per_epoch': 50,
    'seeds_per_instance': min(len(SEED_POOL), N_CORES),
    'save_interval': 50,
    'target_update_interval': 10,  # DQN 特有参数

    # [3] 问题与数据定义
    'prob_id': 1,
    'train_problems': TRAIN_PROBLEMS,
    'target_dims': TARGET_DIMS,

    # [Corrected] 使用切分后的集合
    'train_instances': TRAIN_INSTANCES,
    'validation_instances': VAL_INSTANCES,  # [New] 验证集
    'test_instances': TEST_INSTANCES,
    'gen_instances': GEN_INSTANCES,  # 数据生成范围 (1-15)

    'seed_pool': SEED_POOL,

    # [4] 智能体 (Agent) 超参数
    'agent_name': 'Q_Learning',  # 算法名称
    'state_dim': CALC_STATE_DIM,
    'action_dim': CALC_ACTION_DIM,
    'algo_params': ALGO_PARAMS,

    # DQN Specific
    # [Modified] 统一参数：提升网络容量与 Buffer 大小以匹配 SAC
    'lr': 1e-4,
    'gamma': 0.99,
    'batch_size': 256,       # [Unified] 128 -> 256
    'buffer_size': 1000000,  # [Unified] 100000 -> 1000000
    'hidden_dim': 256,       # [Unified] 128 -> 256
    'stream_hidden_dim': 64, # 保持原比例或可选择同步提升，此处暂保持原逻辑
    'state_bins': [5, 4, 4, 4, 4],
    'dim_norm_factor': 100.0,
    'ucb_beta': 1.0,

    # [5] 环境/求解器 (Solver) 设置
    'ea_name': 'SHADE',
    'pop_size_factor': 18,
    'max_fes_factor': 5000,
}

# 2.3 模式绑定与参数注入 (Mode Binding & Injection)
# ------------------------------------------------------------
EVAL_N_CYCLES = 1  # 辅助常量

if TRAIN_MODE == 'dynamic':
    # [Dynamic Mode]
    TRAIN_CONFIG['dynamic_review_ratio'] = 0.2
    warmup_ratio = 0.1
    TRAIN_CONFIG['warmup_epochs'] = int(TOTAL_EPOCHS * warmup_ratio)
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)

elif TRAIN_MODE == 'standard':
    # [Standard Mode]
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)

elif TRAIN_MODE == 'exhaustive':
    # [Exhaustive Mode]
    n_combos = len(TRAIN_PROBLEMS) * len(TARGET_DIMS)
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * n_combos

else:
    TRAIN_CONFIG['eval_interval'] = 10


def setup_seed(seed):
    """设置全局随机种子"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    print(f"[Main] Global random seed set to: {seed}")


def setup_experiment(config):
    """
    [Modified] 创建实验目录并保存配置
    命名格式: timestamp_mode_tag_seed
    """
    tag = PathManager.get_naming_tag(config)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    mode = config.get('train_mode', 'unknown')
    seed_val = config['base_seed']

    # 独立的顶层目录
    dir_name = f"{timestamp}_{mode}_{tag}_seed{seed_val}"

    exp_dir = os.path.join('../experiments', dir_name)
    os.makedirs(exp_dir, exist_ok=True)
    print(f"[Main] Experiment Directory Created: {exp_dir}")

    config_path = os.path.join(exp_dir, f"{tag}_config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    print(f"[Main] Configuration saved to {config_path}")
    return exp_dir


def _run_single_execution(config):
    """
    [Internal] 执行单次完整的训练流程。
    接收特定种子的 config 对象。
    """
    # 1. 设置种子
    current_seed = config['base_seed']
    setup_seed(current_seed)

    print("=" * 60)
    print(f"[Run] Starting Single Execution | Seed: {current_seed}")
    print(
        f"[Config] Mode: {config['train_mode']} | Train: {config['train_instances']} | Val: {config['validation_instances']}")
    print("=" * 60)

    # 2. 实验目录初始化 (Single Seed Dir)
    experiment_dir = setup_experiment(config)

    # 3. [Modified] 自动数据生成
    # 委托给 gen_baselines 进行一致性检查 (check_consistency=True)
    if config.get('generate_data', True):
        print("[Main] Invoking data generator with consistency check...")
        gen_baselines.generate_dataset(config, experiment_dir=experiment_dir, check_consistency=True)

    # 4. 初始化模块
    monitor = Monitor(config, experiment_dir=experiment_dir)
    monitor.report_baseline()

    # 5. 初始化 RL Agent
    print(f"[Main] Initializing Agent ({config['agent_name']})...")
    agent = AlgorithmFactory.create_agent(
        config['agent_name'],
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config['lr'],
        gamma=config['gamma'],
        batch_size=config['batch_size'],
        buffer_size=config['buffer_size'],
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config['stream_hidden_dim'],
        state_bins=config['state_bins'],
        algo_params=config['algo_params'],
        dim_norm_factor=config['dim_norm_factor'],
        device='cuda' if torch.cuda.is_available() else 'cpu',
        target_dims=config['target_dims']
    )

    # 6. 阶段 1: 离线预训练 (Offline Phase)
    pretrain_epochs = config.get('pretrain_epochs', 0)
    if pretrain_epochs > 0:
        print(f"[Run] Starting Offline Pre-training...")
        offline_trainer = OfflineTrainer(config, agent, monitor, experiment_dir=experiment_dir)
        offline_trainer.train()
    else:
        print(f"[Run] Skipping Offline Pre-training.")

    # 7. 阶段 2: 在线微调 (Online Phase)
    evaluator = Evaluator(config, monitor)
    online_trainer = OnlineTrainer(config, agent, evaluator, monitor, experiment_dir=experiment_dir)
    online_trainer.train()

    print(f"\n[Run] Execution Finished for Seed {current_seed}.\n")


def run_pipeline():
    """
    主训练管道 (Loop wrapper)
    按顺序遍历所有定义的种子，重复执行训练。
    """
    seeds = TRAIN_CONFIG['base_seed']
    if not isinstance(seeds, list):
        seeds = [seeds]

    total_runs = len(seeds)
    print(f"\n>>> [Main] Planned Executions: {total_runs} runs (Seeds: {seeds})")

    for i, seed in enumerate(seeds):
        print("\n" + "#" * 80)
        print(f"### EXECUTION {i + 1}/{total_runs} | SEED {seed}")
        print("#" * 80 + "\n")

        # 构造当前运行的配置副本
        current_config = copy.deepcopy(TRAIN_CONFIG)
        current_config['base_seed'] = seed  # 覆盖为单个整数种子

        try:
            _run_single_execution(current_config)
        except Exception as e:
            print(f"[Main] ERROR in execution {i + 1} (Seed {seed}): {e}")
            import traceback
            traceback.print_exc()
            print("[Main] Continuing to next seed...")

    print("\n>>> [Main] All executions completed.")


if __name__ == "__main__":
    # Windows/Multiprocessing 兼容性设置
    multiprocessing.set_start_method('spawn', force=True)
    run_pipeline()
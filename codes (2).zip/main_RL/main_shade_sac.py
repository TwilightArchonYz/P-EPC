import os
import torch
import numpy as np
import random
import json
import datetime
import multiprocessing
import copy

# 导入自定义模块
from evorl.trainning.online import OnlineTrainer
from evorl.trainning.evaluator import Evaluator
from evorl.trainning.offline import OfflineTrainer
from evorl.factory import AlgorithmFactory
from evorl.utils.monitor import Monitor
from evorl.utils.naming import PathManager
from evorl.preprocessing import gen_baselines

# ==============================================================================
# PART 1: 预计算与全局常量 (Pre-calculation & Global Constants)
# ==============================================================================

# 1.1 系统与资源配置 (System & Resources)
# ------------------------------------------------------------
N_CORES = 12  # [系统] 物理核心数 / 并行进程数
SEED_POOL = list(range(1, 11))  # [环境] 随机种子池 (20个种子)

# [New] 重复实验配置
N_REPEATS = 2 # 重复训练次数
# [Modified] 种子从 1 到 10
BASE_SEEDS = list(range(1, N_REPEATS + 1))  # [1, 2, ..., 10]

# 资源列表
TRAIN_PROBLEMS = [1, 2]  # [环境] 参与训练的真实问题 ID
TARGET_DIMS = [20, 30]  # [环境] 目标维度列表

# [Modified] 数据集划分逻辑: 先定义总集，再均分
# 总集: 1-15 (共15个实例)
GEN_INSTANCES = list(range(1, 16))

# 自动计算切分点 (5/5/5)
_n_total = len(GEN_INSTANCES)
_chunk = _n_total // 3

TRAIN_INSTANCES = GEN_INSTANCES[:_chunk]  # [1, 2, 3, 4, 5]
VAL_INSTANCES = GEN_INSTANCES[_chunk:2 * _chunk]  # [6, 7, 8, 9, 10]
TEST_INSTANCES = GEN_INSTANCES[2 * _chunk:]  # [11, 12, 13, 14, 15]

# 1.2 核心算法参数定义 (动作空间驱动)
# ------------------------------------------------------------
ALGO_PARAMS = [
    {
        'name': 'F',  # 缩放因子 (Scaling Factor)
        'options': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    },
    {
        'name': 'CR',  # 交叉概率 (Crossover Rate)
        'options': [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
    }
]

# 动态计算网络维度
CALC_STATE_DIM = 4 + len(ALGO_PARAMS)

# [Modified] SAC 使用连续动作空间
# 动作维度 = 参数个数 (例如 F, CR 共 2 个参数，输出 dim=2 的向量)
CALC_ACTION_DIM = len(ALGO_PARAMS)

# ==============================================================================
# PART 2: 主配置字典 (Main Configuration Dictionary)
# ==============================================================================

# 2.1 基础策略配置
# ------------------------------------------------------------
# 'standard':   纯标准模式 (广度巡逻)
# 'exhaustive': 纯穷尽模式 (深度轮转)
# 'dynamic':    动态自适应 (巡逻 -> 发现弱项 -> 攻坚)
TRAIN_MODE = 'dynamic'
TOTAL_EPOCHS = 100  # [流程] 总训练轮数

# 2.2 定义基础配置 (Common Configuration)
# ------------------------------------------------------------
TRAIN_CONFIG = {
    # ==========================================================================
    # [1] 系统基础设施
    # ==========================================================================
    'n_cores': N_CORES,  # 并行进程数

    # 路径配置 (由 PathManager 管理，此处可覆盖)
    'baseline_path': 'data/precomputed/baselines_shade.pkl',
    'expert_data_path': 'data/precomputed/expert_data.pkl',

    # ==========================================================================
    # [2] 全流程与策略控制 (通用部分)
    # ==========================================================================
    'train_mode': TRAIN_MODE,

    # [Modified] 这里存储的是种子列表，会在运行时动态替换为单个整数
    'base_seed': BASE_SEEDS,

    'generate_data': True,  # 默认 True，会在运行时检查文件是否存在

    # --- 阶段 1: 离线预训练 (Offline Phase) ---
    # 若设为 0，则完全跳过离线阶段
    'pretrain_epochs': 50,

    # --- 阶段 2: 在线微调 (Online Timeline) ---
    'epochs': TOTAL_EPOCHS,  # 总训练轮数
    'steps_per_epoch': 50,  # 每轮梯度下降步数

    # --- 阶段 2: 动态特性 (Online Dynamics) ---
    # [Modified] 此处仅定义通用参数，review_ratio 和 warmup_epochs 在下方动态注入
    'seeds_per_instance': min(len(SEED_POOL), N_CORES),  # 攻坚模式下的并发种子数

    # --- 事件触发器 (Event Triggers) ---
    # eval_interval 也在下方根据模式动态计算
    'save_interval': 50,  # 保存间隔
    'target_update_interval': 10,  # 目标网络同步间隔 (for SAC soft update logic)

    # ==========================================================================
    # [4] 智能体超参数 (RL Agent Hyperparameters)
    # ==========================================================================
    'agent_name': 'SAC',  # [Modified] 显式指定 SAC
    'state_dim': CALC_STATE_DIM,
    'action_dim': CALC_ACTION_DIM,  # 连续动作维度 (e.g., 2)
    'algo_params': ALGO_PARAMS,

    # Network & Optimization
    'lr': 3e-4,  # SAC 常用学习率
    'gamma': 0.99,  # 折扣因子
    'batch_size': 256,  # SAC 通常使用较大的 Batch 以稳定训练
    'buffer_size': 1000000,  # Off-Policy 需要较大的 Replay Buffer
    'hidden_dim': 256,  # SAC 网络通常较宽
    'stream_hidden_dim': 128,

    # [SAC Specific Params]
    'alpha': 0.2,  # 初始温度系数
    'tau': 0.005,  # 软更新系数
    'auto_entropy_tuning': True,  # 是否自动调整 Alpha

    # State Processing
    'state_bins': [5, 4, 4, 4, 4],
    'dim_norm_factor': 100.0,
    'ucb_beta': 1.0,

    # ==========================================================================
    # [3] 问题与数据定义 (Problem & Data Configuration)
    # ==========================================================================
    'prob_id': 1,  # (旧兼容字段)
    'train_problems': TRAIN_PROBLEMS,  # 训练问题集
    'target_dims': TARGET_DIMS,  # 训练维度集

    # [Corrected] 使用切分后的集合
    'train_instances': TRAIN_INSTANCES,
    'validation_instances': VAL_INSTANCES,  # [New] 验证集
    'test_instances': TEST_INSTANCES,
    'gen_instances': GEN_INSTANCES,  # 数据生成范围 (1-15)

    'seed_pool': SEED_POOL,  # 种子池

    # ==========================================================================
    # [5] 环境/求解器设置 (EA Environment Settings)
    # ==========================================================================
    'ea_name': 'SHADE',
    'pop_size_factor': 18,
    'max_fes_factor': 5000,
}

# 2.3 模式绑定与参数注入 (Mode Binding & Injection)
# ------------------------------------------------------------
EVAL_N_CYCLES = 1  # 辅助常量

if TRAIN_MODE == 'dynamic':
    # [Dynamic Mode] 自适应调度配置
    TRAIN_CONFIG['dynamic_review_ratio'] = 0.2
    warmup_ratio = 0.1
    TRAIN_CONFIG['warmup_epochs'] = int(TOTAL_EPOCHS * warmup_ratio)
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)

elif TRAIN_MODE == 'standard':
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)

elif TRAIN_MODE == 'exhaustive':
    n_combos = len(TRAIN_PROBLEMS) * len(TARGET_DIMS)
    TRAIN_CONFIG['eval_interval'] = EVAL_N_CYCLES * n_combos

else:
    TRAIN_CONFIG['eval_interval'] = 10


def setup_seed(seed):
    """设置全局随机种子"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    print(f"[Main] Global random seed set to: {seed}")


def setup_experiment(config):
    """创建实验目录并保存配置"""
    tag = PathManager.get_naming_tag(config)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # [Modified] 显式加入 Mode 和 Seed 信息，便于直观区分
    mode = config.get('train_mode', 'unknown')
    seed_val = config['base_seed']

    # 新的目录命名格式: 时间_模式_标签_种子
    dir_name = f"{timestamp}_{mode}_{tag}_seed{seed_val}"

    exp_dir = os.path.join('../experiments', dir_name)
    os.makedirs(exp_dir, exist_ok=True)
    print(f"[Main] Experiment Directory Created: {exp_dir}")

    config_path = os.path.join(exp_dir, f"{tag}_config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    print(f"[Main] Configuration saved to {config_path}")
    return exp_dir


def _run_single_execution(config):
    """
    [Internal] 执行单次完整的训练流程。
    接收特定种子的 config 对象。
    """
    # 1. 设置种子
    current_seed = config['base_seed']
    setup_seed(current_seed)

    print("=" * 60)
    print(f"[Run] Starting Single Execution | Seed: {current_seed}")
    print(
        f"[Config] Mode: {config['train_mode']} | Train: {config['train_instances']} | Val: {config['validation_instances']}")
    print("=" * 60)

    # 2. 实验目录初始化
    experiment_dir = setup_experiment(config)

    # 3. [Modified] 自动数据生成
    # 删除了原有的手动 os.path.exists 检查
    # 将一致性检查委托给 generate_dataset (check_consistency=True)
    if config.get('generate_data', True):
        print("[Main] Invoking data generator with consistency check...")
        gen_baselines.generate_dataset(config, experiment_dir=experiment_dir, check_consistency=True)

    # 4. 监控器与基准报告
    monitor = Monitor(config, experiment_dir=experiment_dir)
    monitor.report_baseline()

    # 5. 初始化 RL Agent (Master)
    print(f"[Main] Initializing Master Agent ({config['agent_name']})...")
    agent = AlgorithmFactory.create_agent(
        config['agent_name'],
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config['lr'],
        gamma=config['gamma'],
        batch_size=config['batch_size'],
        buffer_size=config['buffer_size'],
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config['stream_hidden_dim'],
        state_bins=config['state_bins'],
        algo_params=config['algo_params'],
        dim_norm_factor=config['dim_norm_factor'],
        alpha=config['alpha'],
        tau=config['tau'],
        auto_entropy_tuning=config.get('auto_entropy_tuning', True),
        device='cuda' if torch.cuda.is_available() else 'cpu',
        target_dims=config['target_dims']
    )

    # 6. 阶段 1: 离线预训练 (Offline Phase)
    pretrain_epochs = config.get('pretrain_epochs', 0)
    if pretrain_epochs > 0:
        print(f"[Main] Starting Offline Pre-training for {pretrain_epochs} epochs...")
        offline_trainer = OfflineTrainer(config, agent, monitor, experiment_dir=experiment_dir)
        offline_trainer.train()
    else:
        print(f"[Main] Skipping Offline Pre-training.")

    # 7. 阶段 2: 在线微调 (Online Phase)
    evaluator = Evaluator(config, monitor)
    online_trainer = OnlineTrainer(config, agent, evaluator, monitor, experiment_dir=experiment_dir)
    online_trainer.train()

    print(f"\n[Run] Execution Finished for Seed {current_seed}.\n")


def run_pipeline():
    """
    主训练管道 (Loop wrapper)
    按顺序遍历所有定义的种子，重复执行训练。
    """
    seeds = TRAIN_CONFIG['base_seed']
    if not isinstance(seeds, list):
        seeds = [seeds]

    total_runs = len(seeds)
    print(f"\n>>> [Main] Planned Executions: {total_runs} runs (Seeds: {seeds})")

    for i, seed in enumerate(seeds):
        print("\n" + "#" * 80)
        print(f"### EXECUTION {i + 1}/{total_runs} | SEED {seed}")
        print("#" * 80 + "\n")

        # 构造当前运行的配置副本
        current_config = copy.deepcopy(TRAIN_CONFIG)
        current_config['base_seed'] = seed  # 覆盖为单个整数种子

        try:
            _run_single_execution(current_config)
        except Exception as e:
            print(f"[Main] ERROR in execution {i + 1} (Seed {seed}): {e}")
            import traceback
            traceback.print_exc()
            print("[Main] Continuing to next seed...")

    print("\n>>> [Main] All executions completed.")


if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    run_pipeline()
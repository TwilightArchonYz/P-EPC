import os
import re
import glob
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import matplotlib.ticker as ticker
import matplotlib.lines as mlines
import warnings

warnings.filterwarnings('ignore')  # 忽略作图或统计检验中的除零警告

# ==============================================================================
# 1. 配置与映射 (Configuration & Mappings)
# ==============================================================================

PATH_BASELINES = 'experiments/benchmarks/benchmark_results_5000D_30_40_50.pkl'
PATH_RL_SPECIALIST = 'experiments/benchmarks/rl_specialist_results.pkl'
ROOT_EXP_SINGLE = 'experiments_single'  # 用于动态读取训练时间的日志根目录
OUTPUT_DIR = 'experiments/benchmarks/analysis_final_paper'

DIMS = [30, 40, 50]
PROBLEMS = list(range(1, 21))
MAX_FES_FACTOR = 5000

SPLITS_INFO = {
    'Train': {1, 2, 3},
    'Val': {4, 5, 6},
    'Test': {7, 8, 9}
}

# 1v1 对比配置 (底层物理数据键名)
PAIRS_1V1_RAW = [
    ('Q_Learning_JADE-Specialist', 'JADE'),
    ('Q_Learning_LJADE-Specialist', 'L-SHADE'),
    ('Q_Learning_PSO-Specialist', 'IPSO')
]

# 论文标准命名映射 (LaTeX Safe)
PAPER_NAMES_MAP = {
    'Q_Learning_JADE-Specialist': 'QL-JADE',
    'Q_Learning_LJADE-Specialist': 'QL-IJADE',
    'Q_Learning_PSO-Specialist': 'QL-PSO',
    'JADE': 'JADE', 'IPSO': 'IPSO', 'L-SHADE': 'L-SHADE',
    'jSO': 'jSO', 'IMODE': 'IMODE', 'SHADE': 'SHADE'
}

SOTA_ALGOS_RAW = ['L-SHADE', 'jSO', 'IMODE']

ALGO_COLORS = {
    'QL-JADE': '#d62728', 'QL-IJADE': '#ff7f0e', 'QL-PSO': '#1f77b4',
    'JADE': '#ff9896', 'IPSO': '#aec7e8',
    'L-SHADE': '#2ca02c', 'jSO': '#9467bd', 'IMODE': '#8c564b', 'SHADE': '#7f7f7f'
}

ALGO_ORDER = ['QL-JADE', 'QL-IJADE', 'QL-PSO', 'JADE', 'IPSO', 'L-SHADE', 'jSO', 'IMODE', 'SHADE']


def get_line_style(algo_name):
    if 'QL-' in algo_name:
        return '-', 2.0  # RL算法：实线，加粗
    elif algo_name in ['L-SHADE', 'jSO', 'IMODE', 'SHADE']:
        return '--', 1.5  # SOTA算法：虚线
    else:
        return ':', 1.5  # 基准算法：点线


FIG_SIZE_SINGLE = (3.5, 3.2)

plt.rcParams.update({
    'font.size': 10, 'axes.labelsize': 11, 'axes.titlesize': 11,
    'xtick.labelsize': 9, 'ytick.labelsize': 9, 'legend.fontsize': 8,
})


# ==============================================================================
# 2. 数据加载机制 (Data Loading)
# ==============================================================================

def load_training_times():
    print("=" * 80)
    print("[1/6] Parsing Pre-training Times from Logs...")
    train_time_map = {}

    if not os.path.exists(ROOT_EXP_SINGLE):
        print(f"   > Warning: {ROOT_EXP_SINGLE} not found. Training times will be N/A.")
        return train_time_map

    for root, dirs, files in os.walk(ROOT_EXP_SINGLE):
        for file in files:
            if file.endswith('_train_steps.csv'):
                log_path = os.path.join(root, file).replace('\\', '/')

                pid_match = re.search(r'_P(\d+)_', file)
                if not pid_match: pid_match = re.search(r'_P(\d+)', root)
                if not pid_match: continue
                pid = int(pid_match.group(1))

                algo_clean = None
                log_path_upper = log_path.upper()
                if 'LJADE' in log_path_upper or 'IJADE' in log_path_upper or 'LSHADE' in log_path_upper:
                    algo_clean = 'QL-IJADE'
                elif 'JADE' in log_path_upper:
                    algo_clean = 'QL-JADE'
                elif 'PSO' in log_path_upper:
                    algo_clean = 'QL-PSO'

                if not algo_clean: continue

                try:
                    df = pd.read_csv(log_path)
                    if 'Timestamp' in df.columns and len(df) > 1:
                        start_t = pd.to_datetime(df['Timestamp'].iloc[0])
                        end_t = pd.to_datetime(df['Timestamp'].iloc[-1])
                        total_sec = (end_t - start_t).total_seconds()

                        if algo_clean not in train_time_map: train_time_map[algo_clean] = {}
                        train_time_map[algo_clean][pid] = total_sec / 3.0
                except Exception:
                    pass

    print(f"   > Parsed pre-training times for {len(train_time_map)} RL algorithm groups.")
    return train_time_map


def load_and_merge_data():
    print("\n[2/6] Loading and Merging Pickle Data...")
    structured_data = {dim: {pid: {} for pid in PROBLEMS} for dim in DIMS}

    def _merge(raw_dict, tag):
        count = 0
        for key, val in raw_dict.items():
            try:
                algo, pid, dim, inst = key[0], key[1], key[2], key[3]
            except Exception:
                continue
            if dim not in DIMS or pid not in PROBLEMS: continue

            if algo not in structured_data[dim][pid]:
                structured_data[dim][pid][algo] = {'histories': [], 'instances': [], 'runtimes': []}

            if val.get('history') is not None:
                structured_data[dim][pid][algo]['histories'].append(val['history'])
                structured_data[dim][pid][algo]['instances'].append(inst)
                structured_data[dim][pid][algo]['runtimes'].append(val.get('runtime', np.nan))
                count += 1
        print(f"   > Merged {count} instances from {tag}.")

    if os.path.exists(PATH_BASELINES):
        with open(PATH_BASELINES, 'rb') as f: _merge(pickle.load(f), "Baselines")
    if os.path.exists(PATH_RL_SPECIALIST):
        with open(PATH_RL_SPECIALIST, 'rb') as f: _merge(pickle.load(f), "RL-Specialist")

    return structured_data


def get_aligned_fitness(histories, instances, target_instances, max_fes):
    fit_list = []
    for hist, inst in zip(histories, instances):
        if inst in target_instances:
            hist = np.array(hist)
            if hist.ndim == 2 and hist.shape[1] == 2:
                valid_idx = np.where(hist[:, 0] <= max_fes)[0]
                if len(valid_idx) > 0:
                    fit_list.append(hist[valid_idx[-1], 1])
    return np.array(fit_list)


# ==============================================================================
# 3. 核心统计计算与 CSV 导出 (Stats & CSV Export)
# ==============================================================================

def analyze_and_export_stats(data, train_time_map):
    print("\n[3/6] Calculating W/T/L, RPD, Ranks, and Runtimes...")
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    plot_data_pack = {'Test': {'runtime_stats': {d: {} for d in DIMS}}}

    for split_name, inst_set in SPLITS_INFO.items():
        wtl_rows = []
        rank_rows = []
        runtime_rows = []

        if split_name == 'Test':
            plot_data_pack['Test']['dim_stats'] = {dim: {} for dim in DIMS}

        for dim in DIMS:
            max_fes = MAX_FES_FACTOR * dim

            all_algos_raw = [p[0] for p in PAIRS_1V1_RAW] + SOTA_ALGOS_RAW + [p[1] for p in PAIRS_1V1_RAW]
            all_algos_raw = list(dict.fromkeys(all_algos_raw))
            all_algos_raw = [a for a in all_algos_raw if any(a in data[dim][pid] for pid in PROBLEMS)]

            # --- A. 时间统计与 FES 公平归一化 ---
            if split_name == 'Test':
                for algo_raw in all_algos_raw:
                    algo_clean = PAPER_NAMES_MAP.get(algo_raw, algo_raw)
                    time_list = []
                    for pid in PROBLEMS:
                        insts = data[dim][pid].get(algo_raw, {}).get('instances', [])
                        runtimes = data[dim][pid].get(algo_raw, {}).get('runtimes', [])
                        for rt, inst in zip(runtimes, insts):
                            if inst in inst_set and not np.isnan(rt):
                                time_list.append(rt)

                    avg_solve_time = np.mean(time_list) if time_list else np.nan

                    # [核心归一化逻辑]: 原生 EA 跑了 10000D FES，强制除以 2 统一至 5000D 标尺
                    if algo_clean in ['JADE', 'IPSO', 'L-SHADE', 'jSO', 'IMODE', 'SHADE']:
                        if not np.isnan(avg_solve_time):
                            avg_solve_time = avg_solve_time / 2.0

                    plot_data_pack['Test']['runtime_stats'][dim][algo_clean] = avg_solve_time

                    if 'QL-' in algo_clean:
                        t_times = [train_time_map.get(algo_clean, {}).get(p, np.nan) for p in PROBLEMS]
                        avg_train_time = np.nanmean(t_times) if not np.isnan(t_times).all() else np.nan
                        train_time_str = f"{avg_train_time:.2f}" if not np.isnan(avg_train_time) else "N/A"
                    else:
                        train_time_str = "0.00"

                    runtime_rows.append({
                        'Dimension': f"{dim}D", 'Algorithm': algo_clean,
                        'Avg Pre-training Time (s)': train_time_str,
                        'Norm Solving Time (s)': f"{avg_solve_time:.2f}" if not np.isnan(avg_solve_time) else "N/A"
                    })

            # --- B. 1v1 W/T/L & RPD 分析 ---
            for rl_raw, base_raw in PAIRS_1V1_RAW:
                rl_clean = PAPER_NAMES_MAP.get(rl_raw, rl_raw)
                base_clean = PAPER_NAMES_MAP.get(base_raw, base_raw)
                wins, ties, losses = 0, 0, 0
                rpd_list = []

                if split_name == 'Test':
                    if rl_clean not in plot_data_pack['Test']['dim_stats'][dim]:
                        plot_data_pack['Test']['dim_stats'][dim][rl_clean] = {'scatter': {'rl': [], 'base': []},
                                                                              'rpd': [], 'base_target': base_clean}

                for pid in PROBLEMS:
                    rl_fit = get_aligned_fitness(data[dim][pid].get(rl_raw, {}).get('histories', []),
                                                 data[dim][pid].get(rl_raw, {}).get('instances', []), inst_set, max_fes)
                    base_fit = get_aligned_fitness(data[dim][pid].get(base_raw, {}).get('histories', []),
                                                   data[dim][pid].get(base_raw, {}).get('instances', []), inst_set,
                                                   max_fes)

                    if len(rl_fit) >= 3 and len(base_fit) >= 3:
                        mean_rl, mean_base = np.mean(rl_fit), np.mean(base_fit)

                        if split_name == 'Test':
                            plot_data_pack['Test']['dim_stats'][dim][rl_clean]['scatter']['rl'].append(mean_rl)
                            plot_data_pack['Test']['dim_stats'][dim][rl_clean]['scatter']['base'].append(mean_base)

                        denominator = max(abs(mean_base), abs(mean_rl), 1e-8)
                        rpd = ((mean_base - mean_rl) / denominator) * 100
                        rpd_list.append(rpd)

                        if split_name == 'Test':
                            plot_data_pack['Test']['dim_stats'][dim][rl_clean]['rpd'].append(rpd)

                        stat, p_val = stats.mannwhitneyu(rl_fit, base_fit, alternative='two-sided')
                        if p_val < 0.05:
                            if mean_rl < mean_base:
                                wins += 1
                            else:
                                losses += 1
                        else:
                            ties += 1
                    else:
                        ties += 1

                avg_rpd = np.mean(rpd_list) if rpd_list else 0
                wtl_rows.append({'Dimension': f"{dim}D", 'Pair': f"{rl_clean} vs {base_clean}",
                                 'W/T/L': f"{wins}W / {ties}T / {losses}L", 'RPD(%)': f"{avg_rpd:+.1f}%"})

            # --- C. 排名与热力图 ---
            problem_ranks = {PAPER_NAMES_MAP.get(a, a): [] for a in all_algos_raw}
            heatmap_matrix = {PAPER_NAMES_MAP.get(p[0], p[0]): {PAPER_NAMES_MAP.get(s, s): [] for s in SOTA_ALGOS_RAW}
                              for p in PAIRS_1V1_RAW}

            for pid in PROBLEMS:
                pid_means = {}
                for algo_raw in all_algos_raw:
                    fit = get_aligned_fitness(data[dim][pid].get(algo_raw, {}).get('histories', []),
                                              data[dim][pid].get(algo_raw, {}).get('instances', []), inst_set, max_fes)
                    if len(fit) > 0: pid_means[PAPER_NAMES_MAP.get(algo_raw, algo_raw)] = np.mean(fit)

                valid_algos_clean = list(pid_means.keys())
                if valid_algos_clean:
                    vals = [pid_means[a] for a in valid_algos_clean]
                    ranks = stats.rankdata(vals)
                    for a, r in zip(valid_algos_clean, ranks):
                        problem_ranks[a].append(r)

                if split_name == 'Test':
                    for rl_raw in [p[0] for p in PAIRS_1V1_RAW]:
                        rl_clean = PAPER_NAMES_MAP.get(rl_raw, rl_raw)
                        rl_fit = get_aligned_fitness(data[dim][pid].get(rl_raw, {}).get('histories', []),
                                                     data[dim][pid].get(rl_raw, {}).get('instances', []), inst_set,
                                                     max_fes)
                        for sota_raw in SOTA_ALGOS_RAW:
                            sota_clean = PAPER_NAMES_MAP.get(sota_raw, sota_raw)
                            sota_fit = get_aligned_fitness(data[dim][pid].get(sota_raw, {}).get('histories', []),
                                                           data[dim][pid].get(sota_raw, {}).get('instances', []),
                                                           inst_set, max_fes)

                            if len(rl_fit) >= 3 and len(sota_fit) >= 3:
                                _, p_val = stats.mannwhitneyu(rl_fit, sota_fit, alternative='two-sided')
                                if p_val < 0.05:
                                    score = 1 if np.mean(rl_fit) < np.mean(sota_fit) else -1
                                else:
                                    score = 0
                            else:
                                score = 0
                            heatmap_matrix[rl_clean][sota_clean].append(score)

            for algo_clean, r_list in problem_ranks.items():
                avg_r = np.mean(r_list) if r_list else np.nan
                rank_rows.append({'Dimension': f"{dim}D", 'Algorithm': algo_clean, 'Avg_Rank': avg_r})

            if split_name == 'Test':
                plot_data_pack['Test']['dim_stats'][dim]['ranks_raw'] = problem_ranks
                plot_data_pack['Test']['dim_stats'][dim]['heatmap_raw'] = heatmap_matrix

        pd.DataFrame(wtl_rows).to_csv(os.path.join(OUTPUT_DIR, f'WTL_RPD_{split_name}.csv'), index=False)
        pd.DataFrame(rank_rows).pivot(index='Algorithm', columns='Dimension', values='Avg_Rank').to_csv(
            os.path.join(OUTPUT_DIR, f'Avg_Rank_{split_name}.csv'))
        if split_name == 'Test' and runtime_rows:
            pd.DataFrame(runtime_rows).to_csv(os.path.join(OUTPUT_DIR, f'Runtime_Comparison_Test.csv'), index=False)

    return plot_data_pack


# ==============================================================================
# 4. 图表绘制: 解耦单文件生成，配套数据导出
# ==============================================================================

def draw_plots_for_test_set(plot_pack):
    print("\n[4/6] Generating Independent Figures & CSVs (Scatter, RPD, Rank, Heatmap)...")

    for dim in DIMS:
        pack_dim = plot_pack['Test']['dim_stats'][dim]

        # --- 图 A: 对角线散点图 ---
        for rl_clean in [PAPER_NAMES_MAP.get(p[0]) for p in PAIRS_1V1_RAW]:
            if rl_clean not in pack_dim: continue
            base_clean = pack_dim[rl_clean]['base_target']
            rl_vals = np.array(pack_dim[rl_clean]['scatter']['rl'])
            base_vals = np.array(pack_dim[rl_clean]['scatter']['base'])

            if len(rl_vals) == 0: continue

            # [导出伴生数据]
            df_scatter = pd.DataFrame({
                'Problem': PROBLEMS[:len(rl_vals)],
                f'{base_clean}_Fitness': base_vals,
                f'{rl_clean}_Fitness': rl_vals
            })
            df_scatter.to_csv(os.path.join(OUTPUT_DIR, f'Data_Scatter_{rl_clean}_vs_{base_clean}_{dim}D.csv'),
                              index=False)

            rl_vals_clip = np.clip(rl_vals, 1e-12, None)
            base_vals_clip = np.clip(base_vals, 1e-12, None)

            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
            ax.scatter(base_vals_clip, rl_vals_clip, alpha=0.8, c=ALGO_COLORS.get(rl_clean, 'red'), edgecolors='white',
                       s=40)

            min_val = min(np.min(rl_vals_clip), np.min(base_vals_clip)) * 0.1
            max_val = max(np.max(rl_vals_clip), np.max(base_vals_clip)) * 10
            ax.plot([min_val, max_val], [min_val, max_val], 'k--', alpha=0.5)

            ax.set_aspect('equal')
            ax.set_xscale('log')
            ax.set_yscale('log')
            ax.set_xlim(min_val, max_val)
            ax.set_ylim(min_val, max_val)
            ax.set_xlabel(f'{base_clean}')
            ax.set_ylabel(f'{rl_clean}')
            ax.set_title(f'{rl_clean} vs {base_clean} ({dim}D)')
            ax.grid(True, which="both", ls="--", alpha=0.2)
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Scatter_{rl_clean}_vs_{base_clean}_{dim}D.pdf'), dpi=300)
            plt.close()

        # --- 图 B: 逐算例相对提升率 (全解耦为单图) ---
        x_pos = np.arange(len(PROBLEMS))
        for rl_raw in [p[0] for p in PAIRS_1V1_RAW]:
            rl_clean = PAPER_NAMES_MAP.get(rl_raw)
            rpds = pack_dim.get(rl_clean, {}).get('rpd', [])
            if len(rpds) == 0: continue
            base_clean = pack_dim[rl_clean]["base_target"]

            # [导出伴生数据]
            df_rpd = pd.DataFrame({'Problem': [f"P{i}" for i in PROBLEMS[:len(rpds)]], 'RPD(%)': rpds})
            df_rpd.to_csv(os.path.join(OUTPUT_DIR, f'Data_RPD_{rl_clean}_{dim}D.csv'), index=False)

            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
            colors = ['#2ca02c' if v > 0 else '#d62728' for v in rpds]
            ax.bar(x_pos[:len(rpds)], rpds, color=colors, alpha=0.8, width=0.6)
            ax.axhline(0, color='k', linewidth=0.8)
            ax.set_ylabel('RPD (%)')
            ax.set_title(f'{rl_clean} over {base_clean} ({dim}D)')
            ax.set_xticks(x_pos[:len(rpds)])
            ax.set_xticklabels([f"P{i}" for i in PROBLEMS[:len(rpds)]], rotation=45, ha='right', fontsize=7)
            ax.grid(axis='y', alpha=0.3)
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_RPD_{rl_clean}_{dim}D.pdf'), dpi=300)
            plt.close()

        # --- 图 C: 排名的箱型图 ---
        box_df = pd.DataFrame(pack_dim['ranks_raw'])
        order_clean = [o for o in ALGO_ORDER if o in box_df.columns and not box_df[o].isnull().all()]

        if not box_df.empty and order_clean:
            # [导出伴生数据]
            box_df[order_clean].to_csv(os.path.join(OUTPUT_DIR, f'Data_Rank_Boxplot_{dim}D.csv'),
                                       index_label='Problem_Idx')

            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
            sns.boxplot(data=box_df[order_clean], ax=ax, palette=[ALGO_COLORS.get(x, '#cccccc') for x in order_clean],
                        width=0.5)
            ax.invert_yaxis()
            ax.set_ylabel('Rank (Lower is Better)')
            ax.set_title(f'Rank Distribution ({dim}D)')
            ax.set_xticklabels(order_clean, rotation=45, ha='right')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Rank_Boxplot_{dim}D.pdf'), dpi=300)
            plt.close()

        # --- 图 D: 优势热力图 ---
        for rl_clean in [PAPER_NAMES_MAP.get(p[0]) for p in PAIRS_1V1_RAW]:
            sota_heat = pack_dim['heatmap_raw'].get(rl_clean, {})
            if not sota_heat or all(len(v) == 0 for v in sota_heat.values()): continue

            df_heat = pd.DataFrame(sota_heat, index=[f"P{i}" for i in PROBLEMS])
            # [导出伴生数据]
            df_heat.to_csv(os.path.join(OUTPUT_DIR, f'Data_Heatmap_{rl_clean}_{dim}D.csv'), index_label='Problem')

            fig, ax = plt.subplots(figsize=(3.5, 4.0))
            cmap = sns.color_palette("vlag", as_cmap=True)
            sns.heatmap(df_heat, cmap=cmap, center=0, cbar=False, annot=False, linewidths=.5, ax=ax)
            ax.set_title(f'{rl_clean} vs SOTA ({dim}D)')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Heatmap_{rl_clean}_{dim}D.pdf'), dpi=300)
            plt.close()


def draw_runtime_analysis(plot_pack):
    print("\n[5/6] Generating Runtime Figures (Paired Absolute & Overhead Scalability)...")
    runtime_stats = plot_pack['Test'].get('runtime_stats', {})
    if not runtime_stats: return

    target_pairs = [
        ('QL-JADE', 'JADE'),
        ('QL-IJADE', 'L-SHADE'),
        ('QL-PSO', 'IPSO')
    ]

    # --- 图 E1: 按维度的绝对求解时间分组图 (Paired Bar Chart) ---
    for dim in DIMS:
        df_list_dim = []
        for rl_algo, base_algo in target_pairs:
            t_rl = runtime_stats[dim].get(rl_algo, np.nan)
            t_base = runtime_stats[dim].get(base_algo, np.nan)
            if not np.isnan(t_rl) and not np.isnan(t_base):
                df_list_dim.append({'Pair_Group': f"{rl_algo} vs {base_algo}", 'Algorithm': base_algo,
                                    'Norm Solving Time (s)': t_base})
                df_list_dim.append(
                    {'Pair_Group': f"{rl_algo} vs {base_algo}", 'Algorithm': rl_algo, 'Norm Solving Time (s)': t_rl})

        df_dim = pd.DataFrame(df_list_dim)
        if not df_dim.empty:
            # [导出伴生数据]
            df_dim.to_csv(os.path.join(OUTPUT_DIR, f'Data_Runtime_Absolute_{dim}D.csv'), index=False)

            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
            sns.barplot(data=df_dim, x='Pair_Group', y='Norm Solving Time (s)', hue='Algorithm', palette=ALGO_COLORS,
                        ax=ax, edgecolor='black', linewidth=0.5)

            ax.set_title(f"Solving Time ({dim}D, Norm to 5000D FES)", fontsize=10)
            ax.set_ylabel("Time (Seconds)")
            ax.set_xlabel("")
            ax.legend(loc='upper left', fontsize=7, framealpha=0.7)
            plt.xticks(rotation=15, fontsize=8)
            plt.grid(axis='y', alpha=0.3, linestyle='--')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Runtime_Absolute_Pairs_{dim}D.pdf'), dpi=300)
            plt.close()

    # --- 图 E2: 各 RL 算法的开销扩展性折线图 (Scalability Line Chart) ---
    for rl_algo, base_algo in target_pairs:
        scale_data = []
        for dim in DIMS:
            t_rl = runtime_stats[dim].get(rl_algo, np.nan)
            t_base = runtime_stats[dim].get(base_algo, np.nan)
            if not np.isnan(t_rl) and not np.isnan(t_base) and t_base > 0:
                scale_data.append({
                    'Dimension': f"{dim}D",
                    f'{base_algo}_Time': t_base,
                    f'{rl_algo}_Time': t_rl,
                    'Overhead_Ratio': t_rl / t_base
                })

        df_scale = pd.DataFrame(scale_data)
        if not df_scale.empty:
            # [导出伴生数据]
            df_scale.to_csv(os.path.join(OUTPUT_DIR, f'Data_Runtime_Scalability_{rl_algo}.csv'), index=False)

            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
            ax.plot(df_scale['Dimension'], df_scale['Overhead_Ratio'], marker='o', markersize=8,
                    linestyle='-', color=ALGO_COLORS.get(rl_algo, 'red'), linewidth=2, label=f"{rl_algo} / {base_algo}")

            # 画一条 1.0 的基准参考线
            ax.axhline(1.0, color='gray', linestyle='--', linewidth=1.2, label='Baseline EA (1.0x)')

            # 标注数值
            for i, row in df_scale.iterrows():
                ax.text(i, row['Overhead_Ratio'] + 0.02, f"{row['Overhead_Ratio']:.2f}x", ha='center', va='bottom',
                        fontsize=9, fontweight='bold')

            ax.set_title(f"Time Overhead Scalability: {rl_algo}")
            ax.set_ylabel("Relative Overhead Ratio")
            ax.set_xlabel("Problem Dimension")

            # 留足顶部空间给文字
            y_max = max(df_scale['Overhead_Ratio'].max(), 1.0)
            ax.set_ylim(min(df_scale['Overhead_Ratio'].min(), 1.0) - 0.1, y_max + 0.15)

            ax.legend(loc='lower left', fontsize=8)
            plt.grid(True, alpha=0.3, linestyle='--')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Runtime_Scalability_{rl_algo}.pdf'), dpi=300)
            plt.close()


def draw_convergence_all_algos(raw_data):
    print("\n[6/6] Generating All-Algorithms Convergence Figures with Compact Legend...")
    test_insts = SPLITS_INFO['Test']

    SELECTED_PROBS = PROBLEMS
    dim = 50
    max_fes = MAX_FES_FACTOR * dim

    all_raw = [p[0] for p in PAIRS_1V1_RAW] + SOTA_ALGOS_RAW + [p[1] for p in PAIRS_1V1_RAW]
    all_raw = list(dict.fromkeys(all_raw))
    algos_raw_sorted = sorted(all_raw,
                              key=lambda x: ALGO_ORDER.index(PAPER_NAMES_MAP.get(x, x)) if PAPER_NAMES_MAP.get(x,
                                                                                                               x) in ALGO_ORDER else 999)

    for pid in SELECTED_PROBS:
        fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)

        for algo_raw in algos_raw_sorted:
            histories = raw_data[dim][pid].get(algo_raw, {}).get('histories', [])
            instances = raw_data[dim][pid].get(algo_raw, {}).get('instances', [])

            interp_ys = []
            common_x = np.linspace(0, max_fes, 200)
            for hist, inst in zip(histories, instances):
                if inst in test_insts:
                    h = np.array(hist)
                    if h.ndim == 2:
                        valid = h[:, 0] <= max_fes
                        if np.sum(valid) > 2:
                            x, y = h[valid, 0], h[valid, 1]
                            y_interp = np.interp(common_x, x, y)
                            interp_ys.append(y_interp)

            if interp_ys:
                mean_y = np.mean(interp_ys, axis=0)
                algo_clean = PAPER_NAMES_MAP.get(algo_raw, algo_raw)
                color = ALGO_COLORS.get(algo_clean, 'black')
                l_style, l_width = get_line_style(algo_clean)
                ax.plot(common_x, mean_y, label=algo_clean, color=color, linestyle=l_style, lw=l_width, alpha=0.85)

        ax.set_title(f'P{pid} Convergence ({dim}D)')
        ax.set_xlabel('FES')
        ax.set_ylabel('Fitness')
        ax.set_yscale('symlog', linthresh=1e-2)
        ax.xaxis.set_major_formatter(
            ticker.FuncFormatter(lambda x, pos: f'{int(x / 1000)}k' if x >= 1000 else f'{int(x)}'))

        ax.legend(loc='upper right', ncol=2, fontsize=7, framealpha=0.5, edgecolor='none', labelspacing=0.2,
                  columnspacing=0.8)

        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Convergence_All_P{pid}_{dim}D.pdf'), dpi=300)
        plt.close()

    # 生成独立图例
    try:
        fig_leg = plt.figure(figsize=(7.5, 0.5))
        handles = []
        labels = []
        for algo in ALGO_ORDER:
            c = ALGO_COLORS.get(algo, 'black')
            ls, lw = get_line_style(algo)
            line = mlines.Line2D([], [], color=c, linestyle=ls, linewidth=lw, label=algo)
            handles.append(line)
            labels.append(algo)
        fig_leg.legend(handles, labels, loc='center', ncol=len(ALGO_ORDER), fontsize=9, frameon=False)
        fig_leg.gca().set_axis_off()
        fig_leg.savefig(os.path.join(OUTPUT_DIR, 'Fig_Convergence_Shared_Legend.pdf'), dpi=300, bbox_inches='tight')
        plt.close(fig_leg)
    except Exception:
        pass


# ==============================================================================
# Main
# ==============================================================================
if __name__ == "__main__":
    train_time_map = load_training_times()
    data = load_and_merge_data()
    if data:
        plot_pack = analyze_and_export_stats(data, train_time_map)
        draw_plots_for_test_set(plot_pack)
        draw_runtime_analysis(plot_pack)
        draw_convergence_all_algos(data)

        print("\n[Success] All tasks completed! LaTeX-ready files are in:")
        print(f"      -> {OUTPUT_DIR}")
    else:
        print("[Error] Initialization failed.")
import numpy as np
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def
from evorl.algorithms.ea.lshade import SolverLSHADE

# ==============================================================================
# 1. 实验控制变量 (严格对齐训练期环境)
# ==============================================================================
PID = 1
DIM = 30
INSTANCES = [1, 2, 3, 4]
SEEDS = list(range(1, 21))
TARGET_FES = 5000 * DIM  # 两组都只看 5000D 时刻的成绩

# ==============================================================================
# 2. 核心对照逻辑
# ==============================================================================
def run_ab_test():
    results_group_a = []  # 模拟训练期基准：设置 10000D，截取 5000D
    results_group_b = []  # 模拟最终汇总：设置 5000D，跑完 5000D

    total_tasks = len(INSTANCES) * len(SEEDS)
    print("-" * 60)
    print(f"[验证] 启动 A/B 对照测试: 共 {total_tasks} 组严格对齐的底层环境")
    print("-" * 60)

    for inst in INSTANCES:
        # 保证两组面对的地形偏移完全一致
        param_dict, pf1, pf2 = params_def.generate_instance_config(PID, DIM, inst)
        problem = ScalableProblem(PID, DIM, param_dict, pf1=pf1, pf2=pf2)

        for seed in SEEDS:
            # ---------------------------------------------------------
            # [组 A] 模拟基准生成 (对应 -18.3 的逻辑)
            # max_nfes 被强行翻倍，但只采集跑到一半时的成绩
            # ---------------------------------------------------------
            max_nfes_A = 10000 * DIM
            pop_size_A = 18 * DIM
            solver_A = SolverLSHADE(problem=problem, pop_size=pop_size_A, max_nfes=max_nfes_A, seed=seed)
            solver_A.initialize()

            # 跑到目标 FES 强行截断
            while solver_A.fes < TARGET_FES:
                solver_A.evolve()
            results_group_a.append(solver_A.gbest_val)

            # ---------------------------------------------------------
            # [组 B] 模拟最终汇总 (对应 -24.4 的逻辑)
            # max_nfes 正常设置，正常跑完生命周期
            # ---------------------------------------------------------
            max_nfes_B = 5000 * DIM
            pop_size_B = 18 * DIM
            solver_B = SolverLSHADE(problem=problem, pop_size=pop_size_B, max_nfes=max_nfes_B, seed=seed)
            solver_B.initialize()

            # 正常跑完设定的生命周期
            while solver_B.fes < max_nfes_B:
                solver_B.evolve()
            results_group_b.append(solver_B.gbest_val)

    # ==============================================================================
    # 3. 数据统计与输出
    # ==============================================================================
    mean_A = np.mean(results_group_a)
    mean_B = np.mean(results_group_b)

    print("\n" + "=" * 60)
    print("A/B 测试最终结果 (环境: Problem 1, Dim 30, Instances 1-4)")
    print("=" * 60)
    print(f"[组 A] 基准截断模式 (设置 10000D, 取 5000D 成绩) : {mean_A:.2e}")
    print(f"[组 B] 最终汇总模式 (设置  5000D, 取 5000D 成绩) : {mean_B:.2e}")
    print("=" * 60)

if __name__ == "__main__":
    run_ab_test()
import os
import sys
import json
import torch
import pickle
import numpy as np
import time
from tqdm import tqdm
import glob
import traceback

# [System] 导入核心模块
try:
    from evorl.factory import AlgorithmFactory
    from evorl.problems import ScalableProblem
    import evorl.problems.params_def as params_def
    from evorl.utils.agent_adapter import AgentAdapter
except ImportError as e:
    print(f"[Error] Failed to import evorl modules: {e}")
    sys.exit(1)

# ==============================================================================
# 配置区域 (Configuration)
# ==============================================================================

# [Config] 输入：通才模型通常保存在 experiments 根目录下
INPUT_ROOT = 'experiments'

# [Config] 输出：结果保存路径
OUTPUT_DIR = 'experiments/benchmarks'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'rl_generalist_results.pkl')

# [Config] 忽略的非模型目录 (黑名单)
IGNORE_DIRS = [
    'baselines_results',
    'benchmarks',
    '__pycache__',
    'plots',
    'logs'
]

# [Config] 推理范围
TARGET_DIMS = [30, 40, 50]  # 测试维度
EVAL_PROBLEMS = list(range(1, 21))  # [Critical] 通才模型必须测试所有 20 个问题
MAX_FES_FACTOR = 5000
TEST_INSTANCES_FORCE = list(range(1, 10))  # 强制覆盖测试实例 ID


# ==============================================================================
# 核心逻辑 (Core Logic)
# ==============================================================================

def load_generalist_agent(folder_path, device):
    """
    加载 Agent 和 Config。
    专为 Generalist 设计：允许并校验多问题训练配置。
    """
    # 1. 定位 Config 文件
    config_files = glob.glob(os.path.join(folder_path, '*_config.json'))

    if config_files:
        config_path = config_files[0]
    elif os.path.exists(os.path.join(folder_path, 'config.json')):
        config_path = os.path.join(folder_path, 'config.json')
    else:
        raise FileNotFoundError(f"No *_config.json found in {folder_path}")

    # 2. 定位模型权重
    best_models = glob.glob(os.path.join(folder_path, '**', '*_best.pth'), recursive=True)
    pretrained_models = glob.glob(os.path.join(folder_path, '**', '*_pretrained.pth'), recursive=True)

    if best_models:
        model_path = best_models[0]
    elif pretrained_models:
        model_path = pretrained_models[0]
    else:
        raise FileNotFoundError(f"No checkpoint found in {folder_path}")

    # 3. 加载配置
    with open(config_path, 'r') as f:
        config = json.load(f)

    # [Logic Audit] 过滤逻辑
    train_probs = config.get('train_problems', [])
    if len(train_probs) <= 1:
        if isinstance(config.get('prob_id'), list) and len(config['prob_id']) > 1:
            pass
        else:
            raise ValueError(f"Detected Specialist Model (Training on {train_probs}). Skipping.")

    # 4. 重建 Agent
    agent_name = config['agent_name']
    algo_params = config.get('algo_params', [])
    spec_params = config.get('special_params', {})
    context_spec = config.get('context_spec', None)

    agent = AlgorithmFactory.create_agent(
        agent_name,
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config.get('lr', 3e-4),
        gamma=config.get('gamma', 0.99),
        batch_size=config.get('batch_size', 256),
        buffer_size=config.get('buffer_size', 1000000),
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config.get('stream_hidden_dim', 64),
        state_spec=config.get('state_spec'),
        context_spec=context_spec,
        state_bins=config.get('state_bins', []),
        algo_params=algo_params,
        dim_norm_factor=config.get('dim_norm_factor', 50),
        device=device,
        target_dims=config.get('target_dims', [30]),
        inference_only=True,
        **spec_params
    )

    # 5. 加载权重
    if hasattr(agent, 'load') and agent_name == "Q_Learning":
        try:
            agent.load(model_path)
        except Exception as e:
            raise RuntimeError(f"Q-Learning agent failed to load {model_path}: {e}")
    else:
        try:
            # 加载原始 checkpoint 字典
            checkpoint = torch.load(model_path, map_location=device, weights_only=False)

            state_to_load = checkpoint

            # [Critical Fix] 智能剥离：从全量 Checkpoint 中提取推理网络权重
            if isinstance(checkpoint, dict):
                # 优先级 1: 如果是标准的 model_state_dict (PPO常见)
                if 'model_state_dict' in checkpoint:
                    state_to_load = checkpoint['model_state_dict']

                # 优先级 2: 如果包含 actor (SAC/DDPG/TD3常见) -> 这是我们需要的 eval_net
                elif 'actor' in checkpoint:
                    state_to_load = checkpoint['actor']

                # 优先级 3: 如果包含 q_net (DQN常见)
                elif 'q_net' in checkpoint:
                    state_to_load = checkpoint['q_net']

                # 优先级 4: 如果包含 eval_net (部分自定义实现)
                elif 'eval_net' in checkpoint:
                    state_to_load = checkpoint['eval_net']

            # 使用 AgentAdapter 加载提取后的纯净权重
            AgentAdapter.load_state(agent, state_to_load)

        except Exception as e:
            keys = checkpoint.keys() if isinstance(checkpoint, dict) else "Not a dict"
            raise RuntimeError(f"Failed to load weights from {model_path}. \nKeys found: {keys}. \nError: {e}")

    # 6. 切换评估模式
    if hasattr(agent, 'eval'):
        agent.eval()

    return agent, config


def run_solver_inference(agent, config, target_prob_id, dim, instance_id, device):
    """
    通用推理函数
    """
    try:
        param_dict, pf1, pf2 = params_def.generate_instance_config(target_prob_id, dim, instance_id)
        problem = ScalableProblem(target_prob_id, dim, param_dict, pf1=pf1, pf2=pf2)
    except Exception as e:
        return None, None, None

    ea_name = config.get('ea_name', 'JADE')
    max_nfes = MAX_FES_FACTOR * dim
    pop_size = config.get('pop_size_factor', 20) * dim

    try:
        solver = AlgorithmFactory.create_solver(
            problem=problem,
            ea_name=ea_name,
            agent=agent,
            pop_size=pop_size,
            max_nfes=max_nfes,
            seed=config.get('base_seed', 2024),
            mode='test'
        )
    except Exception as e:
        return None, None, None

    start_time = time.time()
    history = []

    try:
        solver.initialize()
        if hasattr(solver, '_rl_init_params'):
            solver.setup_rl(**solver._rl_init_params)
            del solver._rl_init_params

        history.append([float(solver.fes), float(solver.gbest_val)])

        while solver.fes < solver.max_nfes:
            solver.evolve()
            history.append([float(solver.fes), float(solver.gbest_val)])

    except Exception as e:
        return None, None, None

    runtime = time.time() - start_time
    return np.array(history), float(solver.gbest_val), runtime


def main_generalist_export():
    print("=" * 80)
    print(f"[Pipeline] Starting RL Generalist Export (Multi-Problem Evaluation)")
    print(f"   > Input: {INPUT_ROOT}")
    print(f"   > Output: {OUTPUT_FILE}")
    print("=" * 80)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    combined_results = {}

    if not os.path.exists(INPUT_ROOT):
        print(f"[Error] Input root not found: {INPUT_ROOT}")
        return

    # 获取所有子目录
    subdirs = [d for d in os.listdir(INPUT_ROOT) if os.path.isdir(os.path.join(INPUT_ROOT, d))]

    # [Fix] 过滤掉已知的非模型目录 (结果目录、缓存目录等)
    candidate_folders = [d for d in subdirs if d not in IGNORE_DIRS]

    print(
        f"[System] Found {len(candidate_folders)} potential model folders (Filtered {len(subdirs) - len(candidate_folders)} ignored dirs).")

    valid_models_count = 0

    for folder_name in tqdm(candidate_folders, desc="Scanning Models"):
        folder_path = os.path.join(INPUT_ROOT, folder_name)

        try:
            agent, config = load_generalist_agent(folder_path, device)
        except ValueError as ve:
            # print(f"[DEBUG] Skipped {folder_name}: {ve}")
            continue
        except Exception as e:
            # 只有真正的加载错误才打印，跳过那些可能不相关的文件
            print(f"[DEBUG] Error loading {folder_name}: {e}")
            # traceback.print_exc()
            continue

        valid_models_count += 1

        rl_algo = config.get('agent_name', 'UnknownRL')
        ea_algo = config.get('ea_name', 'JADE')
        seed = config.get('base_seed')

        algo_name_key = f"{rl_algo}_{ea_algo}-Generalist"

        print(f"\n>>> Processing Model: {rl_algo} + {ea_algo} (Seed {seed})")

        for target_prob_id in EVAL_PROBLEMS:
            # print(f"    -> [Running] RL: {rl_algo} | EA: {ea_algo} | Problem: P{target_prob_id}")

            test_instances = TEST_INSTANCES_FORCE if TEST_INSTANCES_FORCE else config.get('test_instances', [])

            for dim in TARGET_DIMS:
                for inst_id in test_instances:
                    key = (algo_name_key, target_prob_id, dim, inst_id, seed)

                    history, final_fit, runtime = run_solver_inference(
                        agent, config, target_prob_id, dim, inst_id, device
                    )

                    if history is not None:
                        combined_results[key] = {
                            'history': history,
                            'final_fitness': final_fit,
                            'runtime': runtime
                        }

    print("-" * 80)
    print(f"[Summary] Valid Generalist Models: {valid_models_count}")
    print(f"[System] Saving {len(combined_results)} entries to {OUTPUT_FILE}...")

    with open(OUTPUT_FILE, 'wb') as f:
        pickle.dump(combined_results, f)

    print("[System] Done.")


if __name__ == "__main__":
    main_generalist_export()
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from evorl.core.reward_def import TrajectoryRewardCalculator


def _calc_absolute_lead(baseline: np.ndarray, agent_fits: np.ndarray) -> np.ndarray:
    """
    [Independent Logic] 使用双指针算法计算绝对领先度。
    用于验证 TrajectoryRewardCalculator 的正确性，并提供可视化的绝对值。
    """
    n = len(agent_fits)
    m = len(baseline)
    leads = np.zeros(n, dtype=np.float64)
    ptr = 0

    # 线性扫描 (假设 Baseline 是单调非增的，最小化问题)
    for t in range(n):
        fit = agent_fits[t]

        # 只要 Baseline 当前位置比 Agent 差 (数值更大)，就继续往后找
        while ptr < m and baseline[ptr] > fit:
            ptr += 1

        # Lead = 等效索引 - 当前步数
        leads[t] = ptr - t

    return leads


def verify_reward_mechanics(
        agent_fits: np.ndarray,
        matched_seed_fits: np.ndarray,
        mean_base_fits: np.ndarray,
        all_raw_baselines: list,
        raw_mean_baseline: np.ndarray,
        save_dir: str,
        case_identifier: str
) -> dict:
    """
    验证单次轨迹的奖励计算机制 (Inspector Tool).

    功能:
    1. 执行 TrajectoryRewardCalculator 获取增量奖励。
    2. 执行本地独立双指针算法获取绝对领先度。
    3. 双重校验：验证 (Diff(Abs_Lead) == Calculator_Output).
    4. 绘制四联图 (Symlog 坐标, 绝对 Lead).

    Args:
        agent_fits: Agent 适应度历史 (1D).
        matched_seed_fits: 对应种子的基准 (含 Padding).
        mean_base_fits: 均值基准 (含 Padding).
        all_raw_baselines: 原始基准列表 (无 Padding, 用于背景).
        raw_mean_baseline: 原始均值 (无 Padding).
        save_dir: 保存目录.
        case_identifier: 案例标识.
    """

    # 0. 目录准备
    log_dir = os.path.join(save_dir, 'logs')
    plot_dir = os.path.join(save_dir, 'plots')
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(plot_dir, exist_ok=True)

    # 1. 数据预处理
    try:
        ag_data = np.array(agent_fits, dtype=np.float64).flatten()
        sd_data = np.array(matched_seed_fits, dtype=np.float64).flatten()
        mn_data = np.array(mean_base_fits, dtype=np.float64).flatten()
    except Exception as e:
        return {'Status': 'ERROR', 'Error': f"Data Conversion Failed: {str(e)}", 'Stats': {}}

    # 2. 执行计算
    sanity_errors = []

    # --- A. Calculator (Black Box) ---
    try:
        calculator = TrajectoryRewardCalculator(
            seed_baseline=sd_data,
            mean_baseline=mn_data,
            weight_seed=1.0,
            weight_mean=1.0
        )
        rewards = calculator.compute_rewards(ag_data)
        # 获取 Calculator 内部计算的"增量"
        delta_lead_seed_calc = calculator._calc_track_reward_linear(sd_data, ag_data)
        delta_lead_mean_calc = calculator._calc_track_reward_linear(mn_data, ag_data)
    except Exception as e:
        return {'Status': 'ERROR', 'Error': f"Calculator Runtime Error: {str(e)}", 'Stats': {}}

    # --- B. Independent Logic (White Box) ---
    try:
        # 计算绝对领先 (Absolute Lead)
        abs_lead_seed = _calc_absolute_lead(sd_data, ag_data)
        abs_lead_mean = _calc_absolute_lead(mn_data, ag_data)

        # 计算增量 (用于校验)
        # 逻辑需与 Calculator 一致: np.diff(leads, prepend=leads[0])
        delta_lead_seed_indep = np.diff(abs_lead_seed, prepend=abs_lead_seed[0])
        delta_lead_mean_indep = np.diff(abs_lead_mean, prepend=abs_lead_mean[0])

    except Exception as e:
        return {'Status': 'ERROR', 'Error': f"Independent Calc Error: {str(e)}", 'Stats': {}}

    # --- C. 双重校验 (Cross Validation) ---
    # 允许微小浮点误差
    if not np.allclose(delta_lead_seed_calc, delta_lead_seed_indep, atol=1e-5):
        sanity_errors.append("Mismatch in Seed Lead Delta (Calculator vs Independent)")

    if not np.allclose(delta_lead_mean_calc, delta_lead_mean_indep, atol=1e-5):
        sanity_errors.append("Mismatch in Mean Lead Delta (Calculator vs Independent)")

    # --- D. 常规检查 ---
    if len(rewards) != len(ag_data):
        sanity_errors.append(f"Length Mismatch: Agent({len(ag_data)}) vs Reward({len(rewards)})")

    if np.isnan(rewards).any() or np.isinf(rewards).any():
        sanity_errors.append("NaN/Inf detected in Rewards")

    if sanity_errors:
        return {'Status': 'FAIL', 'Error': "; ".join(sanity_errors), 'Stats': {}}

    # 4. 日志记录 (CSV)
    steps = np.arange(len(ag_data))

    # 获取参考值 (仅用于显示)
    ref_seed_vals = []
    ref_mean_vals = []
    for t in steps:
        ref_s = sd_data[t] if t < len(sd_data) else np.nan
        ref_m = mn_data[t] if t < len(mn_data) else np.nan
        ref_seed_vals.append(ref_s)
        ref_mean_vals.append(ref_m)

    df_log = pd.DataFrame({
        'Iter': steps,
        'Agent_Fit': ag_data,
        'Ref_Seed_Fit_Padded': ref_seed_vals,
        'Ref_Mean_Fit_Padded': ref_mean_vals,
        'Abs_Lead_Seed': abs_lead_seed,  # [Corrected] Log Absolute Lead
        'Abs_Lead_Mean': abs_lead_mean,  # [Corrected] Log Absolute Lead
        'Delta_Lead_Seed': delta_lead_seed_indep,
        'Reward': rewards
    })

    log_path = os.path.join(log_dir, f"{case_identifier}.csv")
    df_log.to_csv(log_path, index=False)

    # 5. 可视化 (Plotting - 4 Subplots with Symlog)
    fig, (ax1, ax2, ax3, ax4) = plt.subplots(4, 1, figsize=(10, 20), sharex=True)

    # --- Panel 1: Raw Context (Symlog) ---
    if all_raw_baselines:
        for raw_bl in all_raw_baselines:
            rb = np.array(raw_bl).flatten()
            ax1.plot(np.arange(len(rb)), rb, color='grey', alpha=0.15, linewidth=0.8)

    if raw_mean_baseline is not None:
        rm = np.array(raw_mean_baseline).flatten()
        ax1.plot(np.arange(len(rm)), rm, 'k:', linewidth=1.5, alpha=0.8, label='Raw Mean')

    ax1.plot(steps, ag_data, 'r-', linewidth=1.5, label='Agent (Raw)')
    ax1.set_yscale('symlog')  # [Fix] Use Symlog
    ax1.set_ylabel('Fitness (SymLog)')
    ax1.set_title(f'Raw Context (No Padding): {case_identifier}')
    ax1.legend(loc='upper right')
    ax1.grid(True, alpha=0.3)

    # --- Panel 2: Calculation Context (Symlog) ---
    ax2.plot(np.arange(len(sd_data)), sd_data, 'g-', alpha=0.4, label='Matched Seed (Padded)')
    ax2.plot(np.arange(len(mn_data)), mn_data, 'b--', alpha=0.4, label='Mean Baseline (Padded)')
    ax2.plot(steps, ag_data, 'r-', linewidth=1.5, label='Agent')
    ax2.set_yscale('symlog')  # [Fix] Use Symlog
    ax2.set_ylabel('Fitness (SymLog)')
    ax2.set_title('Calculation Context (With Padding)')
    ax2.legend(loc='upper right')
    ax2.grid(True, alpha=0.3)

    # --- Panel 3: Absolute Lead (No CumSum, Real Values) ---
    ax3.plot(steps, abs_lead_seed, 'g-', label='vs Matched Seed')
    ax3.plot(steps, abs_lead_mean, 'b-', label='vs Mean')
    ax3.axhline(0, color='k', linestyle=':', alpha=0.5)
    ax3.set_ylabel('Absolute Lead (Index)')
    ax3.set_title('Lead Evolution (Absolute Index Advantage)')
    ax3.legend(loc='upper right')
    ax3.grid(True, alpha=0.3)

    # --- Panel 4: Reward ---
    ax4.plot(steps, rewards, 'm-', linewidth=0.8)
    ax4.set_ylabel('Reward')
    ax4.set_xlabel('Iteration')
    ax4.set_title('Instantaneous Reward')
    ax4.grid(True, alpha=0.3)

    plt.tight_layout()
    plot_path = os.path.join(plot_dir, f"{case_identifier}.png")
    plt.savefig(plot_path)
    plt.close()

    # 6. 返回统计信息
    stats = {
        'Min_Reward': float(np.min(rewards)),
        'Max_Reward': float(np.max(rewards)),
        'Mean_Reward': float(np.mean(rewards)),
        'Final_Abs_Lead': float(abs_lead_seed[-1]),
        'Total_Steps': len(ag_data)
    }

    return {'Status': 'PASS', 'Error': None, 'Stats': stats}
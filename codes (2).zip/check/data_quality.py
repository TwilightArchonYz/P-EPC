import os
import numpy as np
import matplotlib.pyplot as plt


def diagnose_rewards(agent, save_dir, tag="Offline_Pretrain"):
    """
    诊断 Agent 经验池中的奖励分布，确保专家数据被正确加载且数值正常。

    Args:
        agent: RL Agent 对象，需包含 memory 或 reward_memory。
        save_dir: 图像保存路径。
        tag: 文件命名前缀。
    """
    print("=" * 60)
    print(f"[Check] 正在执行数据质量诊断 ({tag})...")

    # 1. 提取 Reward 数据 (兼容 Matrix 和 Deque 两种 Buffer)
    rewards = None
    buffer_size = 0

    try:
        if hasattr(agent, 'mem_cntr') and hasattr(agent, 'reward_memory'):
            # [Case A] 矩阵式 Buffer (如 DDPG, TD3, SAC 等)
            # 注意：只取已存储的部分，mem_cntr 可能会超过 buffer_capacity (循环覆盖)
            buffer_capacity = agent.buffer_capacity
            current_size = min(agent.mem_cntr, buffer_capacity)

            if current_size > 0:
                # 仅切片有效数据
                rewards = agent.reward_memory[:current_size]
                buffer_size = current_size
            else:
                print("[Check] 警告: 矩阵式 Buffer 为空 (mem_cntr=0)。")
                return

        elif hasattr(agent, 'memory'):
            # [Case B] 链表式 Buffer (如 DQN 的 deque)
            buffer_size = len(agent.memory)
            if buffer_size > 0:
                # 假设结构为 (state, action, reward, next_state, ...)
                # 取索引 2 作为 reward
                rewards = np.array([sample[2] for sample in agent.memory])
            else:
                print("[Check] 警告: 链表式 Buffer 为空 (len=0)。")
                return
        else:
            print("[Check] 错误: 无法识别 Agent 的 Buffer 结构，跳过诊断。")
            return

    except Exception as e:
        print(f"[Check] 提取数据时发生异常: {e}")
        return

    # 2. 基础统计分析
    if rewards is None or len(rewards) == 0:
        print("[Check] 未提取到任何奖励数据。")
        return

    # 转换为 float 以防类型问题
    rewards = np.array(rewards, dtype=np.float32)

    r_min = np.min(rewards)
    r_max = np.max(rewards)
    r_mean = np.mean(rewards)
    r_std = np.std(rewards)
    nan_count = np.isnan(rewards).sum()
    inf_count = np.isinf(rewards).sum()

    print(f"   > 样本数量: {buffer_size}")
    print(f"   > Reward Min:  {r_min:.6f}")
    print(f"   > Reward Max:  {r_max:.6f}")
    print(f"   > Reward Mean: {r_mean:.6f}")
    print(f"   > Reward Std:  {r_std:.6f}")

    if nan_count > 0 or inf_count > 0:
        print(f"   [CRITICAL] 发现异常值! NaN: {nan_count}, Inf: {inf_count}")
    else:
        print(f"   > 数据完整性检查通过 (无 NaN/Inf)。")

    # 3. 可视化绘制
    # 设置非交互式后端，防止在无头服务器上报错
    try:
        import matplotlib
        matplotlib.use('Agg')

        plt.figure(figsize=(10, 6))
        plt.hist(rewards, bins=50, color='skyblue', edgecolor='black', alpha=0.7)
        plt.title(f'Reward Distribution Check - {tag}\n(N={buffer_size}, Mean={r_mean:.2f})')
        plt.xlabel('Reward Value')
        plt.ylabel('Frequency')
        plt.grid(True, linestyle='--', alpha=0.5)

        # 构建保存路径
        plot_filename = f"{tag}_reward_dist.png"
        plot_path = os.path.join(save_dir, plot_filename)

        # 确保目录存在
        os.makedirs(save_dir, exist_ok=True)

        plt.savefig(plot_path)
        plt.close()
        print(f"   > 诊断图表已保存至: {plot_path}")

    except Exception as e:
        print(f"[Check] 绘图失败: {e}")
        # 绘图不是核心逻辑，失败不中断程序

    print("=" * 60)
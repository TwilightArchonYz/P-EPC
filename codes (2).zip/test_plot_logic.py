import matplotlib

# [CRITICAL] Force backend to 'Agg' immediately.
# This must happen before importing pyplot.
matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np
import os
import time


def test_continuous_plotting():
    print("[Test] Starting Continuous Headless Plotting Test (10 Steps)...")

    output_file = 'test_chart_continuous.png'
    if os.path.exists(output_file):
        os.remove(output_file)

    # 1. Initialize Figure ONCE (Mimicking Monitor.__init__)
    # We do NOT create a new figure every step. We reuse this one.
    try:
        fig = plt.figure(figsize=(10, 6))
        ax = fig.add_subplot(111)
        print("[Test] Figure initialized.")
    except Exception as e:
        print(f"[Test] Fatal: Failed to initialize figure: {e}")
        return

    # Data History
    epochs = []
    train_fits = []
    test_fits = []

    # 2. Simulate Training Loop
    for step in range(1, 11):  # Run 10 steps
        print(f"[Test] Step {step:02d}: Generating data...", end=" ")

        # A. Simulate Data Update
        epochs.append(step)
        # Random walking negative value
        new_train = -10.0 - (step * 0.5) + np.random.normal(0, 0.5)
        new_test = -10.0 - (step * 0.4) + np.random.normal(0, 0.8)

        train_fits.append(new_train)
        test_fits.append(new_test)

        # B. Plotting Cycle
        try:
            # 1. Clear previous frame (Crucial!)
            ax.clear()

            # 2. Re-plot all data
            ax.plot(epochs, train_fits, 'b-o', label='Train Fit')
            ax.plot(epochs, test_fits, 'r--x', label='Test Fit')

            # 3. Re-apply Styles (clear() wipes these too)
            ax.set_title(f'Continuous Test: Step {step}/10')
            ax.set_xlabel('Epoch')
            ax.set_ylabel('Fitness (SymLog)')
            ax.grid(True, which="both", ls="-", alpha=0.5)
            ax.legend()
            ax.set_yscale('symlog')  # Verify scale handling works repeatedly

            # 4. Save to Disk
            fig.savefig(output_file)
            print(f"-> Plot Updated ({output_file})")

            # Simulate short training delay
            time.sleep(0.2)

        except Exception as e:
            print(f"\n[Test] FAILED at step {step}: {e}")
            import traceback
            traceback.print_exc()
            break

    # 3. Cleanup
    plt.close(fig)
    print("[Test] Test Complete. Please check if 'test_chart_continuous.png' shows 10 points.")


if __name__ == "__main__":
    test_continuous_plotting()
import os

# [Architecture - Step 1] 移除全局环境钳制
import torch
import numpy as np
import random
import json
import datetime
import multiprocessing
import copy
import time
import sys

# 导入自定义模块
from evorl.trainning.online import OnlineTrainer
from evorl.trainning.evaluator import Evaluator
from evorl.trainning.offline import OfflineTrainer
from evorl.factory import AlgorithmFactory
from evorl.utils.monitor import Monitor
from evorl.utils.naming import PathManager
from evorl.preprocessing import gen_baselines

# ==============================================================================
# PART 1: 用户全局配置 (User Global Configuration)
# ==============================================================================

# ------------------------------------------------------------------------------
# Group 1: 基础设施与复现 (Infrastructure & Reproducibility)
# ------------------------------------------------------------------------------
N_CORES = 30
N_REPEATS = 1                               #使用不同的种子重复训练不同RL模型
SEED_START = 1
SEED_POOL = list(range(SEED_START, 11))     #EA算法求解不同算例时使用不同的随机数种子池
BASE_SEEDS = list(range(1, N_REPEATS + 1))  #使用不同的种子重复训练不同RL模型的种子池

# ------------------------------------------------------------------------------
# Group 2: 问题定义与数据 (Problem & Data)
# ------------------------------------------------------------------------------
TRAIN_PROBLEMS = list(range(20, 21)) #问题集合
TARGET_DIMS = [30, 40, 50]          #维度集合
GEN_INSTANCES = list(range(1, 10))  #算例集合

# ------------------------------------------------------------------------------
# Group 3: 特征工程与动作空间 (Feature & Action Space)
# ------------------------------------------------------------------------------
options_list = [round(x * 0.02, 2) for x in range(1, 51)] #动作空间0-1离散化

ALGO_PARAMS = [                                #控制参数
    {'name': 'F', 'options': options_list},
    {'name': 'CR', 'options': options_list}
]


# 输入特征
FEATURE_REGISTRY = {
    'Progress': {'bins': 5, 'min': 0.0, 'max': 1.0},
    'Diversity': {'bins': 5, 'min': 0.0, 'max': 1.0},
    'Stagnation': {'bins': 5, 'min': 0.0, 'max': 1.0},
    'FitDist': {'bins': 5, 'min': 0.0, 'max': 1.0},
    'EvoRate': {'bins': 5, 'min': 0.0, 'max': 1.0},
    'NormDim': {'bins': 5, 'min': 0.0, 'max': 1.0},
}
# 输入特征集合
SELECTED_FEATURES = [
    'Progress', 'Diversity', 'Stagnation', 'FitDist', 'EvoRate', 'NormDim', 'F', 'CR'
]

# ------------------------------------------------------------------------------
# Group 4: 神经网络与强化学习核心 (Network & RL Core)
# ------------------------------------------------------------------------------
HIDDEN_DIM = 256
STREAM_HIDDEN_DIM = 64
RL_LR = 3e-4
RL_GAMMA = 0.99
UCB_BETA = 1.0

# ------------------------------------------------------------------------------
# Group 5: 训练流程与动态调整 (Training Flow & Dynamics)
# ------------------------------------------------------------------------------
TRAIN_MODE = 'dynamic'
TOTAL_EPOCHS = 100
PRETRAIN_EPOCHS = 200
STEPS_PER_EPOCH = 10
EVAL_N_CYCLES = 1
# 特征计算参数
HEAD_PADDING_RATIO = 0.2
EVO_LONG_RATIO = 0.1
EVO_SHORT_RATIO = 0.05
# 奖励计算参数
REWARD_WINDOW_LONG_RATIO = 0.5
REWARD_WINDOW_SHORT_RATIO = 0.2
REWARD_WEIGHT_SEED = 1.0
REWARD_WEIGHT_MEAN = 1.0

# ------------------------------------------------------------------------------
# Group 6: 路径与存储 (Paths & Storage)
# ------------------------------------------------------------------------------
# 强调: 纯 EA 基准数据
PATH_BASELINE = 'data/precomputed/baselines_ljade.pkl'  #namming 函数应该会自动生成，这里有冗余
PATH_EXPERT = 'data/precomputed/expert_data_ljade.pkl'

## RL模型保存
SAVE_INTERVAL = 1000            #模型保存间隔（每次评估后，如果有更好的模型，会直接保存（验证集的评估结果）
TARGET_UPDATE_INTERVAL = 10     #价值网络更新价格？？？

# ==============================================================================
# PART 2: 衍生配置与逻辑处理 (Derived Configuration & Logic)
# ==============================================================================
# 划分训练集，验证集和测试集
_n_total = len(GEN_INSTANCES)
_chunk = _n_total // 3
TRAIN_INSTANCES = GEN_INSTANCES[:_chunk]
VAL_INSTANCES = GEN_INSTANCES[_chunk:2 * _chunk]
TEST_INSTANCES = GEN_INSTANCES[2 * _chunk:]



# 处理特征
RL_STATE_SPEC = []
_idx_counter = 0

for feat_name in SELECTED_FEATURES:
    spec = {}
    if feat_name in FEATURE_REGISTRY:
        spec = FEATURE_REGISTRY[feat_name].copy()
        spec['name'] = feat_name
        spec['idx'] = _idx_counter
        RL_STATE_SPEC.append(spec)
        _idx_counter += 1
    elif feat_name in [p['name'] for p in ALGO_PARAMS]:
        spec = {'idx': _idx_counter, 'bins': 5, 'min': 0.0, 'max': 1.0, 'name': feat_name}
        RL_STATE_SPEC.append(spec)
        _idx_counter += 1

CALC_STATE_DIM = len(RL_STATE_SPEC)

norm_dim_idx = -1
for spec in RL_STATE_SPEC:
    if spec['name'] == 'NormDim':
        norm_dim_idx = spec['idx']
        break

RL_CONTEXT_SPEC = {
    'idx': norm_dim_idx,
    'norm_factor': 50.0,
    'name': 'NormDim'
}

#配置参数汇总
COMMON_CONFIG = {
    'n_cores': N_CORES,
    'baseline_path': PATH_BASELINE,
    'expert_data_path': PATH_EXPERT,
    'enable_perf_log': False,
    'train_mode': TRAIN_MODE,
    'generate_data': True,
    'pretrain_epochs': PRETRAIN_EPOCHS,
    'epochs': TOTAL_EPOCHS,
    'steps_per_epoch': STEPS_PER_EPOCH,
    'save_interval': SAVE_INTERVAL,
    'target_update_interval': TARGET_UPDATE_INTERVAL,
    'seeds_per_instance': min(len(SEED_POOL), N_CORES),
    'prob_id': 1,
    'train_problems': TRAIN_PROBLEMS,
    'target_dims': TARGET_DIMS,
    'train_instances': TRAIN_INSTANCES,
    'validation_instances': VAL_INSTANCES,
    'test_instances': TEST_INSTANCES,
    'gen_instances': GEN_INSTANCES,
    'seed_pool': SEED_POOL,
    'hidden_dim': HIDDEN_DIM,
    'stream_hidden_dim': STREAM_HIDDEN_DIM,
    'lr': RL_LR,
    'gamma': RL_GAMMA,
    'ucb_beta': UCB_BETA,
    'state_spec': RL_STATE_SPEC,
    'context_spec': RL_CONTEXT_SPEC,
    'use_features': SELECTED_FEATURES,
    'state_bins': [spec['bins'] for spec in RL_STATE_SPEC],
    'dim_norm_factor': RL_CONTEXT_SPEC['norm_factor'],


    # 下面这几个参数不应该在这里设置。
    # --- EA 环境参数 [核心修改区] ---
    'ea_name': 'LJADE',  # 环境映射符: 触发工厂类实例化 LJADE_RL
    'pop_size_factor': 18,  # [修改] 初始种群规模设为 18 * D
    'max_fes_factor': 5000,

    # LJADE / LSHADE 专属超参数
    'memory_size': 5,   # 记忆库大小（RL_LJADE中没有这个记忆库）
    'min_pop_size': 4,  # LPSR 最低截断限制

    # --- 动态窗口参数 ---
    'head_padding_ratio': HEAD_PADDING_RATIO,
    'evo_long_ratio': EVO_LONG_RATIO,
    'evo_short_ratio': EVO_SHORT_RATIO,
    'reward_window_long_ratio': REWARD_WINDOW_LONG_RATIO,
    'reward_window_short_ratio': REWARD_WINDOW_SHORT_RATIO,
    'reward_weight_seed': REWARD_WEIGHT_SEED,
    'reward_weight_mean': REWARD_WEIGHT_MEAN
}

if TRAIN_MODE == 'dynamic':
    COMMON_CONFIG['dynamic_review_ratio'] = 0.2
    COMMON_CONFIG['warmup_epochs'] = int(TOTAL_EPOCHS * 0.1)
    COMMON_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)
elif TRAIN_MODE == 'standard':
    COMMON_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)
else:
    COMMON_CONFIG['eval_interval'] = 10

# ==============================================================================
# PART 3: 算法注册表 (Algorithm Registry)
# ==============================================================================
# RL算法的基本参数
ALGO_REGISTRY = {
    'SAC': {'type': 'continuous', 'batch_size': 256, 'buffer_size': 1000000, 'lr': 1e-4,
            'special_params': {'alpha': 0.2, 'tau': 0.005, 'auto_entropy_tuning': True}},
    'DDPG': {'type': 'continuous', 'batch_size': 256, 'buffer_size': 1000000, 'lr': 1e-4, 'special_params': {}},
    'PPO': {'type': 'continuous', 'batch_size': 256, 'buffer_size': 2048, 'lr': 1e-4,
            'special_params': {'clip_param': 0.2, 'ppo_epoch': 10, 'value_coef': 0.5, 'entropy_coef': 0.01,
                               'grad_clip': 0.5}},
    'DQN': {'type': 'discrete', 'batch_size': 256, 'buffer_size': 1000000, 'lr': 1e-4, 'special_params': {}},
    'DuelingDQN': {'type': 'discrete', 'batch_size': 256, 'buffer_size': 1000000, 'lr': 1e-4, 'special_params': {}},
    'Q_Learning': {'type': 'discrete', 'batch_size': 4096, 'buffer_size': 1000000, 'lr': 1e-4,
                   'special_params': {'diffusion_decay': 0.5}}
}

# ==============================================================================
# PART 4: RL算法执行序列控制 (Execution Sequence)
# ==============================================================================
# 选择使用的RL算法，多个RL算法依次训练
ALGO_SEQUENCE = [
    'Q_Learning'
]


# ==============================================================================
# PART 5: 核心工具函数 (Core Utilities)
# ==============================================================================
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def setup_experiment(config):
    algo_map = {
        'Q_Learning': 'QL', 'DuelingDQN': 'DDQN', 'DQN': 'DQN',
        'PPO': 'PPO', 'SAC': 'SAC', 'DDPG': 'DDPG'
    }

    algo_full = config['agent_name']
    algo_short = algo_map.get(algo_full, algo_full[:4])
    ea_name = config.get('ea_name', 'EA')
    prob_id = config.get('prob_id', 'All')
    seed_val = config.get('base_seed', 0)

    timestamp = datetime.datetime.now().strftime("%m%d_%H%M")
    dir_name = f"{algo_short}_{ea_name}_P{prob_id}_S{seed_val}_{timestamp}"

    current_file_dir = os.path.dirname(os.path.abspath(__file__))
    exp_root = os.path.join(current_file_dir, 'experiments_single')
    exp_dir = os.path.join(exp_root, dir_name)

    os.makedirs(exp_dir, exist_ok=True)

    config_path = os.path.join(exp_dir, "config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)

    return exp_dir


def _run_single_execution(config):
    current_seed = config['base_seed']
    setup_seed(current_seed)

    print("-" * 60)
    print(f"[Run] Agent: {config['agent_name']} | Seed: {current_seed}")
    print(f"[Run] Problem: {config.get('prob_id', 'All')} (Single Mode)")
    print(f"[Run] Type: {ALGO_REGISTRY[config['agent_name']]['type']} | Action Dim: {config['action_dim']}")
    print("-" * 60)

    experiment_dir = setup_experiment(config)

    # 自动生成 Baseline 数据
    if config.get('generate_data', True):
        gen_config = copy.deepcopy(config)

        gen_config['ea_name'] = 'LJADE'
        gen_config['max_fes_factor'] = gen_config.get('max_fes_factor', 5000)

        print(f"[System] Generating Extended Baseline Data using {gen_config['ea_name']} (18D)...")
        gen_baselines.generate_dataset(gen_config, experiment_dir=experiment_dir, check_consistency=True)

    monitor = Monitor(config, experiment_dir=experiment_dir)
    monitor.report_baseline()

    spec_params = ALGO_REGISTRY[config['agent_name']].get('special_params', {})

    agent = AlgorithmFactory.create_agent(
        config['agent_name'],
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config['lr'],
        gamma=config['gamma'],
        batch_size=config['batch_size'],
        buffer_size=config['buffer_size'],
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config['stream_hidden_dim'],
        state_spec=config['state_spec'],
        context_spec=config['context_spec'],
        state_bins=config['state_bins'],
        algo_params=ALGO_PARAMS,
        dim_norm_factor=config['dim_norm_factor'],
        device='cuda' if torch.cuda.is_available() else 'cpu',
        target_dims=config['target_dims'],
        **spec_params
    )

    pretrain_epochs = config.get('pretrain_epochs', 0)
    if pretrain_epochs > 0:
        print(f"[Run] Starting Offline Pre-training ({pretrain_epochs} epochs)...")
        offline_trainer = OfflineTrainer(config, agent, monitor, experiment_dir=experiment_dir)
        offline_trainer.train()

    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"

    evaluator = Evaluator(config, monitor)
    online_trainer = OnlineTrainer(config, agent, evaluator, monitor, experiment_dir=experiment_dir)
    online_trainer.train()

    print(f"[Run] Finished: {config['agent_name']} (Prob {config.get('prob_id', 'Unknown')} Seed {current_seed})\n")


def run_pipeline():
    total_algos = len(ALGO_SEQUENCE)
    seeds = BASE_SEEDS
    problem_list = TRAIN_PROBLEMS

    print("=" * 80)
    print(f"MAIN BENCHMARK PIPELINE STARTED (SINGLE PROBLEM MODE)")
    print(f"Algorithms: {ALGO_SEQUENCE}")
    print(f"Problems: {problem_list}")
    print(f"Seeds: {seeds}")
    print(f"Output Root: experiments_single/")
    print("=" * 80 + "\n")

    for i, algo_name in enumerate(ALGO_SEQUENCE):
        print(">" * 80)
        print(f">>> STARTING ALGORITHM {i + 1}/{total_algos}: {algo_name}")
        print(">" * 80 + "\n")

        algo_spec = ALGO_REGISTRY.get(algo_name)
        if not algo_spec:
            continue

        current_config = copy.deepcopy(COMMON_CONFIG)
        current_config['agent_name'] = algo_name
        current_config['batch_size'] = algo_spec['batch_size']
        current_config['buffer_size'] = algo_spec['buffer_size']
        current_config['lr'] = algo_spec.get('lr', 3e-4)
        current_config['algo_params'] = ALGO_PARAMS
        current_config['state_dim'] = CALC_STATE_DIM

        if algo_spec['type'] == 'continuous':
            current_config['action_dim'] = len(ALGO_PARAMS)
        else:
            dim = 1
            for p in ALGO_PARAMS:
                dim *= len(p['options'])
            current_config['action_dim'] = dim

        for prob_id in problem_list:
            print("*" * 60)
            print(f"*** Processing Problem ID: {prob_id} ***")
            print("*" * 60)

            for seed in seeds:
                seed_config = copy.deepcopy(current_config)
                seed_config['base_seed'] = seed
                seed_config['prob_id'] = prob_id
                seed_config['train_problems'] = [prob_id]

                try:
                    _run_single_execution(seed_config)
                except Exception as e:
                    print(f"[Error] Failed execution for {algo_name} (Prob {prob_id}, Seed {seed}): {e}")
                    import traceback
                    traceback.print_exc()

        print(f"\n<<< COMPLETED ALGORITHM: {algo_name}\n")
        time.sleep(2)

    print("=" * 80)
    print("ALL BENCHMARKS COMPLETED.")
    print("=" * 80)


if __name__ == "__main__":
    print("=" * 80)
    print(f"[System] Parallel Architecture Check")
    print(f"   > Detected CPUs: {multiprocessing.cpu_count()}")
    print(f"   > Configured N_CORES: {N_CORES}")
    print("-" * 40)
    print(f"   > Env: OMP_NUM_THREADS = {os.environ.get('OMP_NUM_THREADS', 'Not Set (Correct)')}")
    print(f"   > Torch: Initial Num Threads = {torch.get_num_threads()} (Should be > 1 for Main Process)")
    print("-" * 40)

    if torch.get_num_threads() == 1:
        print("[Warning] Torch threads are 1! Main process might be slow.")
    else:
        print("[OK] Main Process is Unclamped (Full Speed).")
    print("=" * 80)

    run_pipeline()
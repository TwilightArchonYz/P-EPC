import os
import glob
import json
import pickle
import numpy as np
import pandas as pd

# ==============================================================================
# 1. 全局配置 (Configuration)
# ==============================================================================
INPUT_ROOT = 'experiments'
PKL_PATH = 'experiments/benchmarks/rl_generalist_results.pkl'
OUTPUT_DIR = 'experiments/benchmarks/analysis_generalist_paper'

IGNORE_DIRS = ['baselines_results', 'benchmarks', '__pycache__', 'plots', 'logs']
DIMS = [30, 40, 50]


# ==============================================================================
# 2. 核心管线 (The Profiling Pipeline)
# ==============================================================================

def extract_generalist_physical_stats():
    """
    扫描实验目录，提取通才模型的【存储空间 (MB)】和【预训练总耗时 (Hours)】
    零防御性编程：暴露最直接的物理读取路径，崩溃前强制输出目标状态。
    """
    print("[1/3] Scanning Experiments Directory for Storage and Training Time...\n")

    physical_stats = {}
    subdirs = [d for d in os.listdir(INPUT_ROOT) if os.path.isdir(os.path.join(INPUT_ROOT, d)) and d not in IGNORE_DIRS]

    for folder_name in subdirs:
        folder_path = os.path.join(INPUT_ROOT, folder_name)

        config_files = glob.glob(os.path.join(folder_path, '*_config.json'))
        config_path = config_files[0] if config_files else os.path.join(folder_path, 'config.json')

        if not os.path.exists(config_path):
            continue

        with open(config_path, 'r') as f:
            config = json.load(f)

        train_probs = config.get('train_problems', [])
        if len(train_probs) <= 1:
            continue

        agent_name = config['agent_name']
        ea_name = config.get('ea_name', 'JADE')
        algo_key = f"{agent_name}_{ea_name}-Generalist"

        # --- 扫描权重文件 ---
        best_models = glob.glob(os.path.join(folder_path, '**', '*_best.pth'), recursive=True)
        pretrained_models = glob.glob(os.path.join(folder_path, '**', '*_pretrained.pth'), recursive=True)

        # [精准排查点 1]：崩溃前输出当前正在审查的文件夹，及寻址结果
        print(f"   [Debug] Inspecting Folder: {folder_name}")
        print(f"           -> Found '*_best.pth': {len(best_models)}")
        print(f"           -> Found '*_pretrained.pth': {len(pretrained_models)}")

        # 如果为0，在此行必定触发 IndexError
        model_path = best_models[0] if best_models else pretrained_models[0]

        size_bytes = os.path.getsize(model_path)
        size_mb = size_bytes / (1024 * 1024)

        # --- 扫描日志文件 ---
        log_files = glob.glob(os.path.join(folder_path, '**', '*train_steps.csv'), recursive=True)

        # [精准排查点 2]：输出日志寻址结果
        print(f"           -> Found '*train_steps.csv': {len(log_files)}")

        log_path = log_files[0]

        df = pd.read_csv(log_path)
        start_t = pd.to_datetime(df['Timestamp'].iloc[0])
        end_t = pd.to_datetime(df['Timestamp'].iloc[-1])
        train_hours = (end_t - start_t).total_seconds() / 3600.0

        physical_stats[algo_key] = {
            'Storage_Size_MB': size_mb,
            'Train_Time_Hours': train_hours
        }
        print(f"   [Success] Parsed {algo_key}: {size_mb:.2f} MB | {train_hours:.2f} Hours\n")

    return physical_stats


def extract_inference_runtimes():
    """
    解析 .pkl 文件，提取并计算平均【推理耗时 (Seconds)】
    """
    print("\n[2/3] Parsing Pickle for Inference Runtimes...")

    with open(PKL_PATH, 'rb') as f:
        raw_data = pickle.load(f)

    runtime_dict = {}
    for key, val in raw_data.items():
        algo, pid, dim = key[0], key[1], key[2]

        if dim not in DIMS:
            continue

        if algo not in runtime_dict:
            runtime_dict[algo] = {d: [] for d in DIMS}

        runtime_dict[algo][dim].append(val['runtime'])

    inference_stats = {}
    for algo, dims_data in runtime_dict.items():
        inference_stats[algo] = {}
        for dim in DIMS:
            inference_stats[algo][f'Infer_Time_{dim}D_Sec'] = np.mean(dims_data[dim])

    print(f"   > Extracted runtimes for {len(inference_stats)} Generalist algorithms.")
    return inference_stats


def merge_and_export(physical_stats, inference_stats):
    """
    拼装数据并导出
    """
    print("\n[3/3] Merging Data and Exporting...")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    merged_rows = []

    for algo, infer_data in inference_stats.items():
        phys_data = physical_stats.get(algo, {})

        row = {
            'Algorithm': algo.replace('-Generalist', '(Gen)'),
            'Storage_Size (MB)': phys_data.get('Storage_Size_MB', np.nan),
            'Total_Train_Time (Hours)': phys_data.get('Train_Time_Hours', np.nan),
        }

        for dim in DIMS:
            row[f'Avg_Infer_Time_{dim}D (s)'] = infer_data.get(f'Infer_Time_{dim}D_Sec', np.nan)

        merged_rows.append(row)

    df = pd.DataFrame(merged_rows)
    df = df.sort_values(by='Algorithm').reset_index(drop=True)

    output_csv = os.path.join(OUTPUT_DIR, 'RL_EA_Generalist_Overhead_Summary.csv')
    df.to_csv(output_csv, index=False)

    print("\n" + "=" * 80)
    print("✅ OVERHEAD SUMMARY GENERATED SUCCESSFULLY")
    print("=" * 80)
    print(df.to_string(index=False, float_format="%.2f", na_rep="N/A"))
    print(f"\nSaved to: {output_csv}")


if __name__ == "__main__":
    phys_stats = extract_generalist_physical_stats()
    infer_stats = extract_inference_runtimes()
    merge_and_export(phys_stats, infer_stats)
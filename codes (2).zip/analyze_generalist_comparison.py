import os
import re
import glob
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import matplotlib.ticker as ticker
import matplotlib.lines as mlines
from math import pi

# ==============================================================================
# 1. 通才专属配置 (Generalist Configuration)
# ==============================================================================

PATH_BASELINES = 'experiments/benchmarks/benchmark_results_5000D_30_40_50.pkl'
PATH_RL_GENERALIST = 'experiments/benchmarks/rl_generalist_results.pkl'
ROOT_EXP_SINGLE = 'experiments'  # 用于扫描模型文件和日志的根目录
OUTPUT_DIR = 'experiments/benchmarks/analysis_generalist_paper'

DIMS = [30, 40, 50]
PROBLEMS = list(range(1, 21))
MAX_FES_FACTOR = 5000

# 全量数据集切分
SPLITS_INFO = {
    'Train': {1, 2, 3},
    'Val': {4, 5, 6},
    'Test': {7, 8, 9}
}

# 核心映射：不同 RL 算法结合 JADE (通才模型) vs 纯 JADE
PAIRS_1V1_RAW = [
    ('PPO_JADE-Generalist', 'JADE'),
    ('DDPG_JADE-Generalist', 'JADE'),
    ('DQN_JADE-Generalist', 'JADE'),
    ('DuelingDQN_JADE-Generalist', 'JADE'),
    ('SAC_JADE-Generalist', 'JADE'),
    ('Q_Learning_JADE-Generalist', 'JADE')
]

PAPER_NAMES_MAP = {
    'PPO_JADE-Generalist': 'PPO-JADE(Gen)',
    'DDPG_JADE-Generalist': 'DDPG-JADE(Gen)',
    'DQN_JADE-Generalist': 'DQN-JADE(Gen)',
    'DuelingDQN_JADE-Generalist': 'DDQN-JADE(Gen)',
    'SAC_JADE-Generalist': 'SAC-JADE(Gen)',
    'Q_Learning_JADE-Generalist': 'QL-JADE(Gen)',
    'JADE': 'JADE', 'L-SHADE': 'L-SHADE', 'jSO': 'jSO', 'IMODE': 'IMODE', 'SHADE': 'SHADE'
}

SOTA_ALGOS_RAW = ['L-SHADE', 'jSO', 'IMODE']

ALGO_COLORS = {
    'PPO-JADE(Gen)': '#d62728',  # 红
    'DDPG-JADE(Gen)': '#ff7f0e',  # 橙
    'DQN-JADE(Gen)': '#1f77b4',  # 蓝
    'DDQN-JADE(Gen)': '#9467bd',  # 紫
    'SAC-JADE(Gen)': '#e377c2',  # 粉
    'QL-JADE(Gen)': '#8c564b',  # 棕
    'JADE': '#7f7f7f', 'L-SHADE': '#2ca02c', 'jSO': '#bcbd22', 'IMODE': '#17becf', 'SHADE': '#8c564b'
}

ALGO_ORDER = [
    'PPO-JADE(Gen)', 'DDPG-JADE(Gen)', 'DQN-JADE(Gen)', 'DDQN-JADE(Gen)', 'SAC-JADE(Gen)', 'QL-JADE(Gen)',
    'JADE', 'L-SHADE', 'jSO', 'IMODE', 'SHADE'
]


def get_line_style(algo_name):
    if '(Gen)' in algo_name:
        return '-', 2.0
    elif algo_name in ['L-SHADE', 'jSO', 'IMODE', 'SHADE']:
        return '--', 1.5
    else:
        return ':', 1.5


FIG_SIZE_SINGLE = (3.5, 3.2)
plt.rcParams.update({
    'font.size': 10, 'axes.labelsize': 11, 'axes.titlesize': 11,
    'xtick.labelsize': 9, 'ytick.labelsize': 9, 'legend.fontsize': 8,
})


# ==============================================================================
# 2. 数据与资源加载 (零防御)
# ==============================================================================

def load_training_times():
    print("\n[1/7] Parsing Pre-training Times from Logs...")
    train_time_map = {PAPER_NAMES_MAP[p[0]]: {} for p in PAIRS_1V1_RAW}

    if not os.path.exists(ROOT_EXP_SINGLE):
        return train_time_map

    for root, dirs, files in os.walk(ROOT_EXP_SINGLE):
        for file in files:
            if file.endswith('_train_steps.csv'):
                log_path = os.path.join(root, file).replace('\\', '/')
                pid_match = re.search(r'_P(\d+)_', file)
                if not pid_match: pid_match = re.search(r'_P(\d+)', root)
                if not pid_match: continue
                pid = int(pid_match.group(1))

                algo_clean = None
                for raw_name, clean_name in PAPER_NAMES_MAP.items():
                    if raw_name.split('_')[0] in log_path:
                        algo_clean = clean_name
                        break

                if not algo_clean or algo_clean not in train_time_map:
                    continue

                df = pd.read_csv(log_path)
                start_t = pd.to_datetime(df['Timestamp'].iloc[0])
                end_t = pd.to_datetime(df['Timestamp'].iloc[-1])
                total_sec = (end_t - start_t).total_seconds()
                train_time_map[algo_clean][pid] = total_sec / 3.0

    return train_time_map


def load_and_merge_data():
    print("[2/7] Loading and Merging Generalist Pickle Data...")
    structured_data = {dim: {pid: {} for pid in PROBLEMS} for dim in DIMS}

    def _merge(raw_dict, tag):
        count = 0
        for key, val in raw_dict.items():
            algo, pid, dim, inst, _ = key[:5] if len(key) >= 5 else (*key, None)
            if len(key) == 4:
                algo, pid, dim, inst = key
            elif len(key) == 5:
                algo, pid, dim, inst, seed = key
            else:
                raise ValueError(f"Unexpected key format in pickle: {key}")

            if dim not in DIMS or pid not in PROBLEMS:
                continue

            if algo not in structured_data[dim][pid]:
                structured_data[dim][pid][algo] = {'histories': [], 'instances': [], 'runtimes': []}

            structured_data[dim][pid][algo]['histories'].append(val['history'])
            structured_data[dim][pid][algo]['instances'].append(inst)
            structured_data[dim][pid][algo]['runtimes'].append(val['runtime'])
            count += 1
        print(f"   > Merged {count} instances from {tag}.")

    with open(PATH_BASELINES, 'rb') as f:
        _merge(pickle.load(f), "Baselines")
    with open(PATH_RL_GENERALIST, 'rb') as f:
        _merge(pickle.load(f), "RL-Generalist")

    return structured_data


def get_aligned_fitness(histories, instances, target_instances, max_fes):
    fit_list = []
    for hist, inst in zip(histories, instances):
        if inst in target_instances:
            hist = np.array(hist)
            valid_idx = np.where(hist[:, 0] <= max_fes)[0]
            if len(valid_idx) > 0:
                fit_list.append(hist[valid_idx[-1], 1])
    return np.array(fit_list)


# ==============================================================================
# 3. 资源消耗分析 (Storage, Train Time, Inference Time)
# ==============================================================================
def analyze_computational_resources(data, train_time_map):
    print("\n[3/7] Calculating Storage and Time Overheads...")
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    resource_rows = []

    model_sizes = {}
    if os.path.exists(ROOT_EXP_SINGLE):
        for algo_raw, _ in PAIRS_1V1_RAW:
            algo_prefix = algo_raw.split('_')[0]
            checkpoints = glob.glob(os.path.join(ROOT_EXP_SINGLE, f'*{algo_prefix}*', '**', '*.pth'), recursive=True)
            if checkpoints:
                model_sizes[PAPER_NAMES_MAP[algo_raw]] = os.path.getsize(checkpoints[0]) / (1024 * 1024)

    for dim in DIMS:
        for algo_raw, base_raw in PAIRS_1V1_RAW:
            rl_clean = PAPER_NAMES_MAP[algo_raw]
            base_clean = PAPER_NAMES_MAP[base_raw]

            rl_runtimes, base_runtimes = [], []
            for pid in PROBLEMS:
                if algo_raw in data[dim][pid]:
                    rl_runtimes.extend(data[dim][pid][algo_raw]['runtimes'])
                if base_raw in data[dim][pid]:
                    base_runtimes.extend(data[dim][pid][base_raw]['runtimes'])

            avg_rl_runtime = np.nanmean(rl_runtimes) if rl_runtimes else np.nan
            avg_base_runtime = (np.nanmean(base_runtimes) / 2.0) if base_runtimes else np.nan

            t_times = [train_time_map.get(rl_clean, {}).get(p, np.nan) for p in PROBLEMS]
            avg_train_time = np.nanmean(t_times)

            resource_rows.append({
                'Dimension': f"{dim}D",
                'Algorithm': rl_clean,
                'Storage Size (MB)': f"{model_sizes.get(rl_clean, np.nan):.2f}",
                'Avg Train Time (s)': f"{avg_train_time:.2f}",
                'Avg Inference Time (s)': f"{avg_rl_runtime:.2f}",
                f'Baseline {base_clean} Inference (s)': f"{avg_base_runtime:.2f}"
            })

    df_resources = pd.DataFrame(resource_rows)
    df_resources.to_csv(os.path.join(OUTPUT_DIR, 'Computational_Resources_Summary.csv'), index=False)


# ==============================================================================
# 4. 全集统计计算 (W/T/L & RPD)
# ==============================================================================
def analyze_and_export_stats(data):
    print("\n[4/7] Calculating W/T/L and RPD for Train/Val/Test...")
    plot_data_pack = {split: {'dim_stats': {dim: {} for dim in DIMS}} for split in SPLITS_INFO.keys()}

    for split_name, inst_set in SPLITS_INFO.items():
        wtl_rows = []
        for dim in DIMS:
            max_fes = MAX_FES_FACTOR * dim
            for rl_raw, base_raw in PAIRS_1V1_RAW:
                rl_clean = PAPER_NAMES_MAP[rl_raw]
                base_clean = PAPER_NAMES_MAP[base_raw]
                wins, ties, losses = 0, 0, 0
                rpd_list = []

                plot_data_pack[split_name]['dim_stats'][dim][rl_clean] = {'rpd': [], 'base_target': base_clean}

                for pid in PROBLEMS:
                    rl_fit = []
                    if rl_raw in data[dim][pid]:
                        rl_fit = get_aligned_fitness(data[dim][pid][rl_raw]['histories'],
                                                     data[dim][pid][rl_raw]['instances'], inst_set, max_fes)
                    base_fit = []
                    if base_raw in data[dim][pid]:
                        base_fit = get_aligned_fitness(data[dim][pid][base_raw]['histories'],
                                                       data[dim][pid][base_raw]['instances'], inst_set, max_fes)

                    if len(rl_fit) > 0 and len(base_fit) > 0:
                        mean_rl = np.mean(rl_fit)
                        mean_base = np.mean(base_fit)

                        denominator = max(abs(mean_base), abs(mean_rl), 1e-8)
                        rpd = ((mean_base - mean_rl) / denominator) * 100
                        rpd_list.append(rpd)
                        plot_data_pack[split_name]['dim_stats'][dim][rl_clean]['rpd'].append(rpd)

                        stat, p_val = stats.mannwhitneyu(rl_fit, base_fit, alternative='two-sided')
                        if p_val < 0.05:
                            if mean_rl < mean_base:
                                wins += 1
                            else:
                                losses += 1
                        else:
                            ties += 1

                avg_rpd = np.mean(rpd_list) if rpd_list else 0
                wtl_rows.append({'Dimension': f"{dim}D", 'Pair': f"{rl_clean} vs {base_clean}",
                                 'W/T/L': f"{wins}W / {ties}T / {losses}L", 'Avg_RPD(%)': f"{avg_rpd:+.1f}%"})

        pd.DataFrame(wtl_rows).to_csv(os.path.join(OUTPUT_DIR, f'WTL_RPD_Generalist_{split_name}.csv'), index=False)

    return plot_data_pack


# ==============================================================================
# 5. 排名分析 (Global Ranking & RL-Only Ranking)
# ==============================================================================
def analyze_and_plot_rankings(data):
    print("\n[5/7] Generating Global and RL-Only Rankings (Train/Val/Test)...")

    # 集合 1: 所有人参与排名 (Global)
    all_raw = [p[0] for p in PAIRS_1V1_RAW] + SOTA_ALGOS_RAW + [p[1] for p in PAIRS_1V1_RAW]
    all_raw = list(dict.fromkeys(all_raw))

    # 集合 2: 仅 RL_EA 内部排名 (RL-Only)
    rl_only_raw = [p[0] for p in PAIRS_1V1_RAW]
    rl_only_display_order = [PAPER_NAMES_MAP[r] for r in rl_only_raw]

    for split_name, inst_set in SPLITS_INFO.items():
        for dim in DIMS:
            max_fes = MAX_FES_FACTOR * dim
            rank_matrix_global = []
            rank_matrix_rl_only = []

            for pid in PROBLEMS:
                # --- A. 计算全局排名 ---
                pid_means_global = {}
                for algo_raw in all_raw:
                    if algo_raw in data[dim][pid]:
                        fit = get_aligned_fitness(data[dim][pid][algo_raw]['histories'],
                                                  data[dim][pid][algo_raw]['instances'], inst_set, max_fes)
                        if len(fit) > 0:
                            pid_means_global[PAPER_NAMES_MAP[algo_raw]] = np.mean(fit)

                valid_algos_glb = list(pid_means_global.keys())
                vals_glb = [pid_means_global[a] for a in valid_algos_glb]
                ranks_glb = stats.rankdata(vals_glb)

                row_data_glb = {'Problem': f"P{pid}"}
                for a, r in zip(valid_algos_glb, ranks_glb):
                    row_data_glb[a] = r
                rank_matrix_global.append(row_data_glb)

                # --- B. 计算 RL 内部排名 ---
                pid_means_rl = {}
                for algo_raw in rl_only_raw:
                    if algo_raw in data[dim][pid]:
                        fit = get_aligned_fitness(data[dim][pid][algo_raw]['histories'],
                                                  data[dim][pid][algo_raw]['instances'], inst_set, max_fes)
                        if len(fit) > 0:
                            pid_means_rl[PAPER_NAMES_MAP[algo_raw]] = np.mean(fit)

                valid_algos_rl = list(pid_means_rl.keys())
                vals_rl = [pid_means_rl[a] for a in valid_algos_rl]
                ranks_rl = stats.rankdata(vals_rl)

                row_data_rl = {'Problem': f"P{pid}"}
                for a, r in zip(valid_algos_rl, ranks_rl):
                    row_data_rl[a] = r
                rank_matrix_rl_only.append(row_data_rl)

            # ======================== 导出 Global 图表 ========================
            df_ranks_glb = pd.DataFrame(rank_matrix_global).set_index('Problem')
            display_cols_glb = [col for col in ALGO_ORDER if col in df_ranks_glb.columns]
            df_ranks_glb = df_ranks_glb[display_cols_glb]

            df_ranks_glb.loc['Average_Rank'] = df_ranks_glb.mean()
            df_ranks_glb.to_csv(os.path.join(OUTPUT_DIR, f'Algorithm_Rankings_Global_{dim}D_{split_name}.csv'))
            df_ranks_glb = df_ranks_glb.drop('Average_Rank')

            fig, ax = plt.subplots(figsize=(6, 4))
            sns.boxplot(data=df_ranks_glb, ax=ax, palette=[ALGO_COLORS[x] for x in df_ranks_glb.columns], width=0.6,
                        linewidth=1.2)
            ax.set_ylabel('Rank (Lower is Better)')
            ax.set_title(f'Global Rank Distribution ({dim}D - {split_name})')
            ax.set_xticklabels(df_ranks_glb.columns, rotation=45, ha='right')
            ax.invert_yaxis()
            ax.grid(axis='y', alpha=0.3, linestyle='--')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Rank_Boxplot_Global_{dim}D_{split_name}.pdf'), dpi=300)
            plt.close()

            fig, ax = plt.subplots(figsize=(8, 6))
            cmap_glb = sns.color_palette("YlGnBu_r", as_cmap=True)
            sns.heatmap(df_ranks_glb.T, cmap=cmap_glb, annot=True, fmt=".1f", annot_kws={"size": 7}, linewidths=.5,
                        cbar_kws={'label': 'Rank'})
            ax.set_title(f'Global Ranking Heatmap ({dim}D - {split_name})')
            ax.set_xlabel('Problem ID')
            ax.set_ylabel('Algorithm')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Rank_Heatmap_Global_{dim}D_{split_name}.pdf'), dpi=300)
            plt.close()

            # ======================== 导出 RL-Only 图表 ========================
            df_ranks_rl = pd.DataFrame(rank_matrix_rl_only).set_index('Problem')
            display_cols_rl = [col for col in rl_only_display_order if col in df_ranks_rl.columns]
            df_ranks_rl = df_ranks_rl[display_cols_rl]

            df_ranks_rl.loc['Average_Rank'] = df_ranks_rl.mean()
            df_ranks_rl.to_csv(os.path.join(OUTPUT_DIR, f'Algorithm_Rankings_RL_Only_{dim}D_{split_name}.csv'))
            df_ranks_rl = df_ranks_rl.drop('Average_Rank')

            # RL专属箱型图
            fig, ax = plt.subplots(figsize=(5, 4))
            sns.boxplot(data=df_ranks_rl, ax=ax, palette=[ALGO_COLORS[x] for x in df_ranks_rl.columns], width=0.6,
                        linewidth=1.2)
            ax.set_ylabel('Rank (1 to 6, Lower is Better)')
            ax.set_title(f'RL-Only Rank Distribution ({dim}D - {split_name})')
            ax.set_xticklabels(df_ranks_rl.columns, rotation=45, ha='right')
            ax.invert_yaxis()
            ax.grid(axis='y', alpha=0.3, linestyle='--')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Rank_Boxplot_RL_Only_{dim}D_{split_name}.pdf'), dpi=300)
            plt.close()

            # RL专属热力图
            fig, ax = plt.subplots(figsize=(7, 4))
            cmap_rl = sns.color_palette("RdYlGn_r", as_cmap=True)  # 使用红黄绿配色，绿色代表排名靠前 (强)
            sns.heatmap(df_ranks_rl.T, cmap=cmap_rl, annot=True, fmt=".1f", annot_kws={"size": 8}, linewidths=.5,
                        cbar_kws={'label': 'Rank'})
            ax.set_title(f'RL-Only Internal Ranking Heatmap ({dim}D - {split_name})')
            ax.set_xlabel('Problem ID')
            ax.set_ylabel('RL Algorithm')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Rank_Heatmap_RL_Only_{dim}D_{split_name}.pdf'), dpi=300)
            plt.close()


# ==============================================================================
# 6. 雷达图分析
# ==============================================================================
def draw_radar_charts(plot_pack):
    print("\n[6/7] Generating Single & Combined Radar Charts...")
    categories = [f"P{i}" for i in PROBLEMS]
    N = len(categories)
    angles = [n / float(N) * 2 * pi for n in range(N)]
    angles += angles[:1]

    for split_name in SPLITS_INFO.keys():
        for dim in DIMS:
            pack_dim = plot_pack[split_name]['dim_stats'][dim]
            df_radar_combined = pd.DataFrame({'Problem': categories, 'Baseline (JADE)': [0.0] * N})

            for rl_raw, base_raw in PAIRS_1V1_RAW:
                rl_clean = PAPER_NAMES_MAP[rl_raw]
                base_clean = pack_dim[rl_clean]['base_target']
                rpds = pack_dim[rl_clean]['rpd']

                df_radar_combined[f'{rl_clean}_RPD'] = rpds
                values = np.append(np.array(rpds), rpds[0])

                fig, ax = plt.subplots(figsize=(5, 5), subplot_kw={'projection': 'polar'})
                ax.plot(angles, [0] * len(angles), color='gray', linestyle='--', linewidth=1.5,
                        label=f'{base_clean} Baseline')
                ax.fill(angles, [0] * len(angles), color='gray', alpha=0.1)

                color = ALGO_COLORS[rl_clean]
                ax.plot(angles, values, color=color, linewidth=2, linestyle='solid', label=rl_clean)
                ax.fill(angles, values, color=color, alpha=0.25)

                ax.set_xticks(angles[:-1])
                ax.set_xticklabels(categories, fontsize=9)

                min_v = -10 if not list(values) else min(-10, np.min(values) - 10)
                max_v = 10 if not list(values) else max(10, np.max(values) + 10)
                ax.set_ylim(min_v, max_v)

                plt.title(f"Zero-Shot Footprint ({dim}D - {split_name})\n{rl_clean}", size=11, y=1.1)
                ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=8)
                plt.tight_layout()
                plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Radar_Single_{rl_clean}_{dim}D_{split_name}.pdf'), dpi=300)
                plt.close()

            df_radar_combined.to_csv(os.path.join(OUTPUT_DIR, f'Data_Radar_Combined_{dim}D_{split_name}.csv'),
                                     index=False)

            fig, ax = plt.subplots(figsize=(6, 6), subplot_kw={'projection': 'polar'})
            ax.plot(angles, [0] * len(angles), color='gray', linestyle='--', linewidth=1.5, label=f'JADE Baseline (0%)')

            global_min, global_max = -10, 10
            for rl_raw, _ in PAIRS_1V1_RAW:
                rl_clean = PAPER_NAMES_MAP[rl_raw]
                if not pack_dim[rl_clean]['rpd']: continue
                values = np.append(np.array(pack_dim[rl_clean]['rpd']), pack_dim[rl_clean]['rpd'][0])
                global_min = min(global_min, np.min(values) - 5)
                global_max = max(global_max, np.max(values) + 5)

                ax.plot(angles, values, color=ALGO_COLORS[rl_clean], linewidth=1.8, linestyle='solid', alpha=0.9,
                        label=rl_clean)

            ax.set_xticks(angles[:-1])
            ax.set_xticklabels(categories, fontsize=9)
            ax.set_ylim(global_min, global_max)

            plt.title(f"Combined Algorithms Footprint ({dim}D - {split_name})", size=12, y=1.15)
            ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.1), ncol=3, fontsize=9, frameon=False)
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Radar_Combined_All_{dim}D_{split_name}.pdf'), dpi=300)
            plt.close()


# ==============================================================================
# 7. 收敛图分析
# ==============================================================================
def draw_convergence_all_algos(raw_data):
    print("\n[7/7] Generating Convergence Figures (All Splits)...")
    dim = 50
    max_fes = MAX_FES_FACTOR * dim

    all_raw = [p[0] for p in PAIRS_1V1_RAW] + SOTA_ALGOS_RAW + [p[1] for p in PAIRS_1V1_RAW]
    all_raw = list(dict.fromkeys(all_raw))
    algos_raw_sorted = sorted(all_raw,
                              key=lambda x: ALGO_ORDER.index(PAPER_NAMES_MAP.get(x, x)) if PAPER_NAMES_MAP.get(x,
                                                                                                               x) in ALGO_ORDER else 999)

    for split_name, target_insts in SPLITS_INFO.items():
        for pid in PROBLEMS:
            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)

            for algo_raw in algos_raw_sorted:
                if algo_raw not in raw_data[dim][pid]: continue
                histories = raw_data[dim][pid][algo_raw]['histories']
                instances = raw_data[dim][pid][algo_raw]['instances']

                interp_ys = []
                common_x = np.linspace(0, max_fes, 200)
                for hist, inst in zip(histories, instances):
                    if inst in target_insts:
                        h = np.array(hist)
                        valid = h[:, 0] <= max_fes
                        x, y = h[valid, 0], h[valid, 1]
                        y_interp = np.interp(common_x, x, y)
                        interp_ys.append(y_interp)

                if interp_ys:
                    mean_y = np.mean(interp_ys, axis=0)
                    algo_clean = PAPER_NAMES_MAP[algo_raw]
                    ax.plot(common_x, mean_y, label=algo_clean, color=ALGO_COLORS[algo_clean],
                            linestyle=get_line_style(algo_clean)[0], lw=get_line_style(algo_clean)[1], alpha=0.85)

            ax.set_title(f'P{pid} Convergence ({dim}D - {split_name})')
            ax.set_xlabel('FES')
            ax.set_ylabel('Fitness')
            ax.set_yscale('symlog', linthresh=1e-2)
            ax.xaxis.set_major_formatter(
                ticker.FuncFormatter(lambda x, pos: f'{int(x / 1000)}k' if x >= 1000 else f'{int(x)}'))
            ax.legend(loc='upper right', ncol=2, fontsize=7, framealpha=0.5, edgecolor='none', labelspacing=0.2,
                      columnspacing=0.8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Fig_Convergence_All_P{pid}_{dim}D_{split_name}.pdf'), dpi=300)
            plt.close()

    fig_leg = plt.figure(figsize=(7.5, 0.5))
    handles = [mlines.Line2D([], [], color=ALGO_COLORS[algo], linestyle=get_line_style(algo)[0],
                             linewidth=get_line_style(algo)[1], label=algo) for algo in ALGO_ORDER]
    fig_leg.legend(handles, ALGO_ORDER, loc='center', ncol=len(ALGO_ORDER), fontsize=9, frameon=False)
    fig_leg.gca().set_axis_off()
    fig_leg.savefig(os.path.join(OUTPUT_DIR, 'Fig_Convergence_Shared_Legend.pdf'), dpi=300, bbox_inches='tight')
    plt.close(fig_leg)


# ==============================================================================
# Main
# ==============================================================================
if __name__ == "__main__":
    train_time_map = load_training_times()
    data = load_and_merge_data()

    analyze_computational_resources(data, train_time_map)
    plot_pack = analyze_and_export_stats(data)
    analyze_and_plot_rankings(data)
    draw_radar_charts(plot_pack)
    draw_convergence_all_algos(data)

    print("\n[Success] Generalist Analysis Completed! Files saved to:")
    print(f"      -> {OUTPUT_DIR}")
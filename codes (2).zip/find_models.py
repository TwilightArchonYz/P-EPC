import os
import glob

# 设置目标搜索目录
target_dir = 'R1'

print(f"{'='*60}")
print(f"Scanning '{target_dir}' for any .pt (PyTorch Model) files...")
print(f"{'='*60}")

# 递归搜索所有 .pt 文件
pt_files = glob.glob(os.path.join(target_dir, '**', '*.pt'), recursive=True)

if not pt_files:
    print(f"[Error] No .pt files found in {target_dir} or its subdirectories.")
    print("Please check if your training script actually saved the models.")
else:
    print(f"Found {len(pt_files)} model files:\n")
    for f in pt_files:
        # 打印相对路径，方便查看结构
        print(f"  -> {f}")

print(f"\n{'='*60}")
print("Please copy the output above and send it back.")
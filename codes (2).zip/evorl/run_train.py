import multiprocessing
import os
import torch
from evorl.factory import AlgorithmFactory
from evorl.utils.monitor import Monitor
from evorl.training.offline import OfflineTrainer
from evorl.training.online import OnlineTrainer
from evorl.training.evaluator import Evaluator

# ==============================================================================
# Configuration
# ==============================================================================
TRAIN_CONFIG = {
    # --- Problem Settings ---
    "prob_id": 1,
    "target_dims": [10, 30],         # Dims to rotate during training
    "train_instances": [1, 2, 3, 4, 5],
    "test_instances": [6, 7, 8, 9, 10],
    
    # --- Algorithm Selection ---
    "ea_name": "SHADE",              # "SHADE" or "DE"
    "agent_name": "DQN",             # "DQN" or "Q_Learning"
    
    # --- Training Hyperparameters ---
    "epochs": 5000,
    "n_cores": 12,                   # Parallel workers
    "batch_size": 128,
    "lr": 1e-4,
    "gamma": 0.99,
    
    # --- Phase 1: Pre-training ---
    "pretrain_enabled": True,
    "pretrain_epochs": 100,
    "expert_data_path": "data/precomputed/baselines_shade.pkl",
    
    # --- Phase 2: Online Training ---
    "online_repeats": 5,             # Repeats per instance per epoch
    "train_steps_per_epoch": 50,
    "target_update_interval": 10,
    
    # --- Evaluation & Logging ---
    "eval_interval": 10,             # Run full test every N epochs
    "eval_seeds": [42, 43, 44],      # Fixed seeds for fair comparison
    "model_save_path": "models/dqn_shade_final.pth",
    "history_save_path": "logs/training_history.json",
    
    # --- Agent Specific ---
    "state_dim": 6,
    "action_dim": 72,                # 6 continuous levels * 12 discrete levels (example)
}

# ==============================================================================
# Main Execution
# ==============================================================================

def main():
    # 1. Setup Environment
    # 'spawn' is safer for PyTorch with Multiprocessing, especially on CUDA
    multiprocessing.set_start_method('spawn', force=True)
    
    # Ensure directories exist
    os.makedirs(os.path.dirname(TRAIN_CONFIG['model_save_path']), exist_ok=True)
    os.makedirs(os.path.dirname(TRAIN_CONFIG['history_save_path']), exist_ok=True)

    print(f"=== EvoRL Training Pipeline ===")
    print(f"Problem: F{TRAIN_CONFIG['prob_id']} | Dims: {TRAIN_CONFIG['target_dims']}")
    print(f"Algorithm: {TRAIN_CONFIG['ea_name']} + {TRAIN_CONFIG['agent_name']}")
    
    # 2. Initialize Monitor (Visualization)
    # Enable plot only if running in a GUI environment
    monitor = Monitor(enable_plot=True)
    
    # 3. Create Agent (via Factory)
    # We create the master agent here
    agent = AlgorithmFactory.create_agent(
        TRAIN_CONFIG['agent_name'],
        state_dim=TRAIN_CONFIG['state_dim'],
        action_dim=TRAIN_CONFIG['action_dim'],
        lr=TRAIN_CONFIG['lr'],
        gamma=TRAIN_CONFIG['gamma'],
        batch_size=TRAIN_CONFIG['batch_size'],
        target_dims=TRAIN_CONFIG['target_dims'], # Passed for specific logic like DQN-SHADE
        device='cuda' if torch.cuda.is_available() else 'cpu'
    )
    print(f"[Main] Agent {TRAIN_CONFIG['agent_name']} initialized on {agent.device}")

    # 4. Phase 1: Offline Pre-training
    if TRAIN_CONFIG['pretrain_enabled']:
        offline_trainer = OfflineTrainer(TRAIN_CONFIG, agent, monitor)
        offline_trainer.train()
    
    # 5. Initialize Evaluator (for Phase 2)
    evaluator = Evaluator(TRAIN_CONFIG, monitor)
    
    # 6. Phase 2: Online Training
    online_trainer = OnlineTrainer(TRAIN_CONFIG, agent, evaluator, monitor)
    online_trainer.train()
    
    # 7. Final Save
    agent.save(TRAIN_CONFIG['model_save_path'])
    monitor.save_history(TRAIN_CONFIG['history_save_path'])
    print("[Main] Pipeline Finished Successfully.")

if __name__ == "__main__":
    main()
import os


class PathManager:
    """
    PathManager: Centralized utility for generating standardized filenames and paths.
    Enforces the naming convention: {EA}_{RL}_P{Probs}_D{Dims}_I{Insts}_{Suffix}
    """

    @staticmethod
    def _format_seq(seq):
        """
        Helper: Formats a list of numbers into a compact string.
        e.g., [1, 2, 3, 4, 5] -> "1-5"
        e.g., [1, 3, 5] -> "1_3_5"
        """
        if not seq:
            return "None"

        # Ensure distinct and sorted
        seq = sorted(list(set(seq)))
        if len(seq) == 1:
            return str(seq[0])

        # Check if continuous
        is_continuous = True
        for i in range(len(seq) - 1):
            if seq[i + 1] != seq[i] + 1:
                is_continuous = False
                break

        if is_continuous:
            return f"{seq[0]}-{seq[-1]}"
        else:
            return "_".join(map(str, seq))

    @staticmethod
    def get_naming_tag(cfg, specific_instances=None):
        """
        Generates the standard file tag based on configuration.
        Format: {EA}_{RL}_P{Probs}_D{Dims}_I{Insts}
        """
        ea = cfg.get('ea_name', 'UnknownEA')
        rl = cfg.get('agent_name', 'UnknownRL')

        # Problems
        probs = cfg.get('train_problems', [cfg.get('prob_id', 1)])
        p_str = PathManager._format_seq(probs)

        # Dimensions
        dims = cfg.get('target_dims', [])
        d_str = PathManager._format_seq(dims)

        # Instances
        # If specific_instances provided (e.g. for a specific subset), use it.
        # Otherwise, default to 'train_instances' for generic naming.
        # Note: Ideally, for global files, we might want to represent the union of instances.
        if specific_instances:
            insts = specific_instances
        else:
            insts = cfg.get('train_instances', [])
        i_str = PathManager._format_seq(insts)

        return f"{ea}_{rl}_P{p_str}_D{d_str}_I{i_str}"

    @staticmethod
    def get_paths(cfg, experiment_dir=None, data_root='data/precomputed'):
        """
        Returns a dictionary containing paths for ALL data artifacts.

        Args:
            cfg (dict): The configuration dictionary.
            experiment_dir (str): Root directory for the current experiment run (e.g., experiments/Time_...).
            data_root (str): Root directory for shared precomputed data.

        Returns:
            dict: Key-Value pairs of file identifiers and their full paths.
        """
        paths = {}

        # 1. Determine Instance Set for Naming
        # For precomputed data, we usually cover ALL instances (Train + Test)
        # For experiment logs, we usually tag with the Training instances

        # Tag for Shared Data (Covering Gen Instances)
        gen_insts = cfg.get('gen_instances', cfg.get('train_instances', []) + cfg.get('test_instances', []))
        data_tag = PathManager.get_naming_tag(cfg, specific_instances=gen_insts)

        # Tag for Experiment Artifacts (Covering Train Instances)
        # (Or we can use the same tag if we want strict consistency)
        exp_tag = PathManager.get_naming_tag(cfg)

        # --- Section 1: Precomputed Data (Shared) ---
        # Stored in data_root
        # [Fix] Naming now strictly binds to EA name to prevent overwriting by different algorithms
        ea_name = cfg.get('ea_name', 'UnknownEA').lower()

        paths['baseline_pkl'] = os.path.join(data_root, f"baselines_{ea_name}.pkl")
        paths['expert_pkl'] = os.path.join(data_root, f"expert_data_{ea_name}.pkl")

        # --- Section 2: Experiment Artifacts (Specific Run) ---
        if experiment_dir:
            log_dir = os.path.join(experiment_dir, 'logs')
            model_dir = os.path.join(experiment_dir, 'models')
            plot_dir = os.path.join(experiment_dir, 'plots')

            # Ensure subdirs exist (Helper side-effect)
            os.makedirs(log_dir, exist_ok=True)
            os.makedirs(model_dir, exist_ok=True)
            os.makedirs(plot_dir, exist_ok=True)

            # A. Logs (CSV Reports)
            # The Baseline Report (Pure EA)
            paths['baseline_report_csv'] = os.path.join(log_dir, f"{exp_tag}_baseline_report.csv")

            # Training & Eval Logs
            paths['eval_detailed'] = os.path.join(log_dir, f"{exp_tag}_eval_detailed.csv")
            paths['eval_summary'] = os.path.join(log_dir, f"{exp_tag}_eval_summary.csv")
            paths['train_steps'] = os.path.join(log_dir, f"{exp_tag}_train_steps.csv")

            # B. Models
            paths['model_pretrained'] = os.path.join(model_dir, f"{exp_tag}_pretrained.pth")
            paths['model_best'] = os.path.join(model_dir, f"{exp_tag}_best.pth")
            paths['model_latest'] = os.path.join(model_dir, f"{exp_tag}_latest.pth")

            # C. Plots
            paths['plot_curves'] = os.path.join(plot_dir, f"{exp_tag}_curves.png")

            # D. Config Backup
            paths['config_json'] = os.path.join(experiment_dir, f"{exp_tag}_config.json")

        return paths
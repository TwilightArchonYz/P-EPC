import numpy as np
import random


class TaskScheduler:
    """
    任务调度器 (TaskScheduler)
    --------------------------------------------------
    实现三种核心训练策略，支持基于配额（Budget）的双指针轮询机制，
    确保任何模式下每个 Epoch 的求解次数（Rollout）恒定。

    核心机制:
    1. Budget (基准预算): 恒等于 N_prob * N_dim * N_inst。
    2. Universal Queue (全量队列): 标准任务池，用于巡逻和复习。
    3. Focus Queue (攻坚队列): 穷尽任务池，用于深度攻坚。
    4. Cursors (游标): 维护队列读取进度，保证跨 Epoch 的全覆盖。

    策略模式 (Modes):
    1. 'standard' (纯标准): 100% Budget -> Universal Queue (1 Seed/Task)。
    2. 'exhaustive' (纯穷尽): 100% Budget -> Focus Queue (N Seeds/Task)。
    3. 'dynamic' (动态混合): Budget 按比例分配给 Focus Queue 和 Universal Queue。
    """

    def __init__(self, config):
        self.cfg = config
        self.mode = config.get('train_mode', 'standard')

        # 记录初始配置模式
        self.initial_mode = self.mode

        # 资源配置
        self.problems = config.get('train_problems', [1])
        self.dims = config.get('target_dims', [10, 30])
        self.instances = config.get('train_instances', list(range(1, 11)))
        self.seed_pool = config.get('seed_pool', list(range(1, 21)))

        # Exhaustive 模式设置
        self.seeds_per_inst = config.get('seeds_per_instance', 5)

        # Dynamic 模式设置
        # 复习任务在攻坚状态下的占比 (默认 20%)
        self.review_ratio = config.get('dynamic_review_ratio', 0.2)

        # 聚焦列表 (用于存储表现不佳的任务)
        self.focus_tasks = []

        # ======================================================================
        # [New] 定额双指针轮询机制初始化
        # ======================================================================

        # 1. 计算基准预算 (Budget)
        # 任何模式下，单 Epoch 生成的任务数严格等于此数值
        self.budget = len(self.problems) * len(self.dims) * len(self.instances)
        print(f"[Scheduler] 任务基准预算 (Budget) 已设定: {self.budget} tasks/epoch")

        # 2. 构建全量队列 (Universal Queue) - 仅包含 (Prob, Dim, Inst)
        # 这是一个静态有序列表，用于 Standard 模式和 Dynamic 复习
        self.universal_queue = []
        for pid in self.problems:
            for dim in self.dims:
                for inst in self.instances:
                    self.universal_queue.append((pid, dim, inst))

        # 3. 初始化攻坚队列 (Focus Queue) - 包含 (Prob, Dim, Inst, Seed)
        # 这是一个动态列表，根据 focus_tasks 变化
        self.focus_queue = []

        # 4. 初始化游标 (Cursors)
        self.review_cursor = 0  # 指向 Universal Queue
        self.focus_cursor = 0  # 指向 Focus Queue

        # 若初始为 exhaustive 且无 focus，预填充全量穷尽池
        if self.mode == 'exhaustive':
            self._rebuild_focus_queue(None)  # None 表示全量填充

    def set_focus_tasks(self, task_list):
        """
        设置聚焦任务列表，并重组攻坚队列。
        """
        self.focus_tasks = task_list
        if task_list:
            print(f"[Scheduler] 聚焦生效! 目标组合数: {len(task_list)}")
            # 仅针对弱项构建队列
            self._rebuild_focus_queue(task_list)
        else:
            print(f"[Scheduler] 聚焦解除。")
            # 若解除聚焦且处于 Exhaustive 模式，回退到全量穷尽池
            if self.mode == 'exhaustive':
                self._rebuild_focus_queue(None)
            else:
                self.focus_queue = []

        # 重置攻坚游标，确保从头开始攻坚
        self.focus_cursor = 0

    def _rebuild_focus_queue(self, target_pd_list):
        """
        内部方法：重建攻坚队列 (Focus Queue)。
        Queue 内容为 (pid, dim, inst, seed) 的四元组。

        参数:
            target_pd_list: [(pid, dim), ...] 列表。若为 None，则包含所有 (P, D)。
        """
        self.focus_queue = []

        # 确定目标范围
        if target_pd_list is None:
            # 全量范围 (用于 Exhaustive 无聚焦时的轮询)
            targets = [(p, d) for p in self.problems for d in self.dims]
        else:
            targets = target_pd_list

        # 展开: Target -> Instances -> Seeds
        for (pid, dim) in targets:
            for inst in self.instances:
                # 获取指定数量的种子
                seeds = self.seed_pool[:self.seeds_per_inst]
                for seed in seeds:
                    self.focus_queue.append((pid, dim, inst, seed))

        # 乱序以避免数据相关性?
        # 为了保证轮询的确定性，这里保持有序，或者使用固定种子的随机打乱。
        # 这里选择保持有序，依靠 Scheduler 的切片逻辑来遍历。
        # print(f"   [Debug] Focus Queue 重建完成，长度: {len(self.focus_queue)}")

    def _get_circular_slice(self, queue, cursor, n_needed):
        """
        环形切片方法：从队列中提取指定数量的任务，并更新游标。
        """
        if not queue:
            return [], cursor

        q_len = len(queue)
        batch = []

        for i in range(n_needed):
            idx = (cursor + i) % q_len
            batch.append(queue[idx])

        new_cursor = (cursor + n_needed) % q_len
        return batch, new_cursor

    def generate_tasks(self, epoch, agent_state_dict, baselines_dict):
        """
        生成最终任务列表。
        严格遵循 self.budget 数量限制。
        """
        agent_name = self.cfg['agent_name']
        ea_name = self.cfg['ea_name']

        # 获取当前 Epoch 的标准种子 (用于 Standard/Review 任务)
        current_std_seed = self.seed_pool[(epoch - 1) % len(self.seed_pool)]

        raw_specs = []  # 存储 (pid, dim, inst, seed)

        # ======================================================================
        # 策略 1: Standard (纯标准)
        # ======================================================================
        if self.mode == 'standard':
            # 直接使用全量队列 (长度 = Budget)
            # 注意: Universal Queue 只存了 (P, D, I)，需要补上 Seed
            batch = self.universal_queue
            raw_specs = [(*item, current_std_seed) for item in batch]

        # ======================================================================
        # 策略 2: Exhaustive (纯穷尽)
        # ======================================================================
        elif self.mode == 'exhaustive':
            # 100% 算力从 Focus Queue 中获取
            # 如果 Focus Queue 为空 (理论上 _rebuild_focus_queue 保证了不为空除非配置错误)，则回退到 Standard
            if not self.focus_queue:
                print("[Scheduler] Warning: Focus Queue empty in Exhaustive mode. Fallback to Standard.")
                batch = self.universal_queue
                raw_specs = [(*item, current_std_seed) for item in batch]
            else:
                batch, self.focus_cursor = self._get_circular_slice(
                    self.focus_queue, self.focus_cursor, self.budget
                )
                raw_specs = batch  # Focus Queue 已经包含 Seed

        # ======================================================================
        # 策略 3: Dynamic (动态自适应)
        # ======================================================================
        elif self.mode == 'dynamic':
            if not self.focus_tasks:
                # [状态 A] 巡逻: 无弱项 -> 100% 标准任务 (同 Standard)
                batch = self.universal_queue
                raw_specs = [(*item, current_std_seed) for item in batch]
            else:
                # [状态 B] 攻坚: 有弱项 -> 混合模式

                # 1. 计算配额
                n_review = int(self.budget * self.review_ratio)
                n_focus = self.budget - n_review

                # 2. 提取复习任务 (从 Universal Queue 切片)
                review_batch_raw, self.review_cursor = self._get_circular_slice(
                    self.universal_queue, self.review_cursor, n_review
                )
                # 补上种子
                review_specs = [(*item, current_std_seed) for item in review_batch_raw]

                # 3. 提取攻坚任务 (从 Focus Queue 切片)
                focus_specs, self.focus_cursor = self._get_circular_slice(
                    self.focus_queue, self.focus_cursor, n_focus
                )

                raw_specs = focus_specs + review_specs

                # 调试打印 (可选)
                # print(f"   [Scheduler] Dynamic: {len(focus_specs)} Focus + {len(review_specs)} Review")

        # ======================================================================
        # 组装最终任务元组
        # ======================================================================
        final_tasks = []
        for spec in raw_specs:
            (pid, dim, inst, seed) = spec
            baseline = baselines_dict.get((pid, dim, inst, seed))
            task = (pid, dim, inst, seed,
                    agent_name, agent_state_dict, ea_name, self.cfg, baseline)
            final_tasks.append(task)

        return final_tasks
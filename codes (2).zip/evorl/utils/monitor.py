import matplotlib

# [CRITICAL] 强制使用非交互式后端 'Agg'，避免在无头服务器上报错
matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np
import json
import os
import csv
import time
from evorl.utils.naming import PathManager


class Monitor:
    """
    监控器 (Monitor)
    --------------------------------------------------
    功能：数据日志中心、报告生成与可视化。
    [更新] 支持记录训练模式 (Mode) 和弱项统计 (Weak Count)，以便分析自适应调度的行为。
    [Modified] 将 Test 相关指标重命名为 Val (Validation)，以匹配新的训练集/验证集划分逻辑。
    [Modified] 新增 Test 集数据记录及拆分 WeakCount 统计。
    """

    def __init__(self, config, experiment_dir, enable_plot=True):
        self.config = config
        self.exp_dir = experiment_dir
        self.enable_plot = enable_plot

        # 1. 设置路径
        self.paths = PathManager.get_paths(config, experiment_dir)

        self.train_log_file = self.paths['train_steps']
        self.eval_log_file = self.paths['eval_summary']
        self.plot_file = self.paths['plot_curves']

        # 2. 初始化 CSV 文件
        self._init_csv_logs()

        # 3. 内存历史数据
        self.eval_epochs = []

        # Train
        self.eval_train_fit = []
        self.eval_train_imp = []
        self.eval_weak_train = []  # [新增]

        # Val
        self.eval_val_fit = []
        self.eval_val_imp = []
        self.eval_weak_val = []  # [新增]

        # Test [新增]
        self.eval_test_fit = []
        self.eval_test_imp = []
        self.eval_weak_test = []  # [新增]

        self.train_history = []

        # [Modified] 跟踪最佳验证集提升率
        self.best_val_imp = -float('inf')

        # 4. 绘图设置
        if self.enable_plot:
            self.fig = plt.figure(figsize=(12, 6))  # 稍微加宽一点
            self.ax = self.fig.add_subplot(111)
            self.ax2 = self.ax.twinx()
        else:
            self.fig = None
            self.ax = None
            self.ax2 = None

    def _init_csv_logs(self):
        """初始化 CSV 文件并写入表头。"""
        # 训练日志 (Train Log)
        if not os.path.exists(self.train_log_file):
            with open(self.train_log_file, 'w', newline='') as f:
                writer = csv.writer(f)
                # [新增] 增加 'Mode' 列
                writer.writerow(['Timestamp', 'Epoch', 'Mode', 'Seed', 'MeanFitness', 'MeanLoss', 'Transitions'])

        # 评估日志 (Eval Log)
        if not os.path.exists(self.eval_log_file):
            with open(self.eval_log_file, 'w', newline='') as f:
                writer = csv.writer(f)
                # [Modified] 扩充表头: Train, Val, Test 及分别的 Weak Count
                writer.writerow(['Timestamp', 'Epoch',
                                 'TrainFit', 'TrainImp',
                                 'ValFit', 'ValImp',
                                 'TestFit', 'TestImp',  # [New]
                                 'WeakTrain', 'WeakVal', 'WeakTest'])  # [New]

    def report_baseline(self):
        """
        读取并打印基准数据摘要。
        """
        csv_path = self.paths.get('baseline_report_csv')

        if not csv_path or not os.path.exists(csv_path):
            print(f"[Monitor] Warning: Baseline CSV not found at {csv_path}")
            return

        print(f"[Monitor] Reading baseline metrics from {csv_path}")

        # 获取各类实例集合
        train_insts = set(self.config.get('train_instances', []))
        val_insts = set(self.config.get('validation_instances', []))
        test_insts = set(self.config.get('test_instances', []))

        train_fits = []
        val_fits = []
        test_fits = []

        try:
            with open(csv_path, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    inst_id = int(row['InstID'])
                    fit = float(row['BestFitness'])

                    if inst_id in train_insts:
                        train_fits.append(fit)
                    elif inst_id in val_insts:
                        val_fits.append(fit)
                    elif inst_id in test_insts:
                        test_fits.append(fit)

            mean_train = np.mean(train_fits) if train_fits else float('inf')
            mean_val = np.mean(val_fits) if val_fits else float('inf')
            mean_test = np.mean(test_fits) if test_fits else float('inf')

            ea_name = self.config.get('ea_name', 'EA')
            print("=" * 60)
            print(f"[Monitor] Baseline Algorithm ({ea_name}) Performance Summary:")
            print(f"       >>> Train Set Mean Fitness: {mean_train:.2e} (Count: {len(train_fits)})")
            print(f"       >>> Val   Set Mean Fitness: {mean_val:.2e}   (Count: {len(val_fits)})")
            print(f"       >>> Test  Set Mean Fitness: {mean_test:.2e}  (Count: {len(test_fits)})")
            print("=" * 60)

        except Exception as e:
            print(f"[Monitor] Error analyzing baseline CSV: {e}")
            raise e

    def log_eval(self, epoch,
                 train_fit, train_imp,
                 val_fit, val_imp,
                 test_fit, test_imp,  # [New]
                 weak_train=0, weak_val=0, weak_test=0):  # [New]
        """
        记录评估结果 (区分训练集/验证集/测试集)。
        """
        # 1. 更新内存
        self.eval_epochs.append(epoch)

        self.eval_train_fit.append(train_fit)
        self.eval_train_imp.append(train_imp)
        self.eval_weak_train.append(weak_train)

        self.eval_val_fit.append(val_fit)
        self.eval_val_imp.append(val_imp)
        self.eval_weak_val.append(weak_val)

        self.eval_test_fit.append(test_fit)
        self.eval_test_imp.append(test_imp)
        self.eval_weak_test.append(weak_test)

        # 2. 写入 CSV
        with open(self.eval_log_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                time.strftime("%Y-%m-%d %H:%M:%S"), epoch,
                train_fit, train_imp,
                val_fit, val_imp,
                test_fit, test_imp,
                weak_train, weak_val, weak_test
            ])

        # 3. 检查是否最佳模型 (基于验证集提升率)
        is_best = False
        if val_imp > self.best_val_imp:
            self.best_val_imp = val_imp
            is_best = True
            print(f"     [Monitor] New Best Model! Val Imp: {val_imp * 100:.2f}% | Val Fit: {val_fit:.2e}")

        # 4. 保存绘图
        if self.enable_plot:
            self._save_plot()

        return is_best

    def _save_plot(self):
        """
        重绘图表。
        左轴: Fitness (Train vs Val)
        右轴: Val Improvement
        (暂不绘制 Test 曲线以保持清晰)
        """
        if not self.ax or not self.ax2:
            return

        # 1. 清除旧内容
        self.ax.clear()
        self.ax2.clear()

        # 2. 绘制 Fitness (左轴)
        l1 = self.ax.plot(self.eval_epochs, self.eval_train_fit, 'b-o', label='Train Fit', markersize=4, alpha=0.7)
        l2 = self.ax.plot(self.eval_epochs, self.eval_val_fit, 'r--s', label='Val Fit', markersize=4, alpha=0.7)

        self.ax.set_ylabel('Mean Fitness (SymLog)', color='k')
        self.ax.set_yscale('symlog')

        # 3. 绘制 Improvement (右轴)
        l3 = self.ax2.plot(self.eval_epochs, self.eval_val_imp, 'g:^', label='Val Imp', markersize=4)

        self.ax2.set_ylabel('Val Improvement', color='g')
        self.ax2.tick_params(axis='y', labelcolor='g')

        # 4. 图例
        lines = l1 + l2 + l3
        labels = [l.get_label() for l in lines]
        self.ax.legend(lines, labels, loc='upper left')

        # 5. 样式
        ea = self.config.get('ea_name', 'EA')
        rl = self.config.get('agent_name', 'RL')
        self.ax.set_title(f"Training Progress ({ea} + {rl})")
        self.ax.set_xlabel('Epoch')
        self.ax.grid(True, which="major", ls="-", alpha=0.5)

        # 6. 保存
        self.fig.savefig(self.plot_file)

    def log_train(self, epoch, mode, seed, mean_fit, mean_loss, transitions):
        """
        记录训练步详情。
        """
        record = {
            'epoch': epoch,
            'mode': mode,
            'seed': seed,
            'fitness': float(mean_fit),
            'loss': float(mean_loss),
            'transitions': transitions
        }
        self.train_history.append(record)

        with open(self.train_log_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                time.strftime("%Y-%m-%d %H:%M:%S"),
                epoch,
                mode,
                seed,
                f"{mean_fit:.4e}",
                f"{mean_loss:.6f}",
                transitions
            ])

    def save_history(self, filepath=None):
        """
        将完整历史转储为 JSON (备份)。
        """
        if filepath is None:
            filepath = os.path.join(self.exp_dir, 'history_dump.json')

        data = {
            'eval_epochs': self.eval_epochs,

            'eval_train_fit': self.eval_train_fit,
            'eval_weak_train': self.eval_weak_train,

            'eval_val_fit': self.eval_val_fit,
            'eval_weak_val': self.eval_weak_val,

            'eval_test_fit': self.eval_test_fit,
            'eval_test_imp': self.eval_test_imp,
            'eval_weak_test': self.eval_weak_test,

            'train_history': self.train_history
        }

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)
import numpy as np
import torch
import sys
import pickle


class AgentAdapter:
    """
    Agent 适配器 (Agent Adapter)
    --------------------------------------------------
    功能：作为统一接口，处理不同类型 Agent (Deep RL vs Tabular RL) 的差异。
    负责状态提取、权重加载、设备转移等底层逻辑，使上层业务代码（如 Evaluator）保持清洁。
    """

    @staticmethod
    def extract_state(agent, device='cpu'):
        """
        从 Agent 中提取可序列化的状态数据（用于多进程传递或保存）。

        参数:
            agent: 智能体实例
            device: 目标设备 (通常为 'cpu')

        返回:
            state_data: 可序列化的状态对象 (dict 或 ndarray)，若无法提取则返回 None
        """
        # Case A: Deep RL (拥有神经网络 eval_net)
        if hasattr(agent, 'eval_net'):
            if hasattr(agent.eval_net, 'state_dict'):
                # 提取 state_dict 并转到指定设备
                return {k: v.to(device) for k, v in agent.eval_net.state_dict().items()}

        # Case B: Tabular RL (拥有 Q-Table)
        elif hasattr(agent, 'q_table'):
            # [Modified] 全量状态捕获
            # 不再只返回 Q 表数组，而是返回整个对象的属性字典，以包含元数据 (如 obs_min, spec_logic 等)
            # 浅拷贝 __dict__ 是安全的，因为我们将在 prepare_step 中剥离重型引用
            return agent.__dict__.copy()

        # Case C: 未知类型或无状态 Agent
        return None

    @staticmethod
    def prepare_state_for_worker(agent, use_shared_q=False):
        """
        [New] 专为多进程 Worker 准备的轻量级状态。
        集中了提取、共享内存判断和外科手术式瘦身逻辑。
        此方法应在循环外部调用一次，然后将结果广播给所有任务。

        参数:
            agent: 智能体实例
            use_shared_q: 是否启用了共享内存 Q 表模式

        返回:
            clean_state: 已清洗、可安全 Pickle 的轻量级状态 (或 None)
        """
        # 1. 提取完整状态
        raw_state = AgentAdapter.extract_state(agent, device='cpu')

        if raw_state is None:
            return None

        # 2. 外科手术式瘦身 (Surgical Stripping)
        # 仅针对字典类型的状态进行清洗
        if isinstance(raw_state, dict):
            # 浅拷贝：我们需要修改字典结构 (删除 Key)，但不希望影响 Agent 自身
            clean_state = raw_state.copy()

            # [黑名单机制] 定义需要移除的大型对象
            blacklist = [
                'memory',  # Replay Buffer (DQN standard)
                'buffer',  # Replay Buffer (Generic)
                'replay_buffer',  # Replay Buffer (Common)
                'optimizer',  # Optimizer Object
                'optimizer_state',  # Optimizer State
                'optimizer_state_dict',
                'state_memory',  # Matrix Buffer parts...
                'action_memory',
                'reward_memory',
                'next_state_memory',
                'terminal_memory',

                # [FIX] Target Network 相关大数组 (解决 PicklingError)
                'q_table_target',
                'q_table_target_tensor',

                # PyTorch Tensors (Worker 通常使用 NumPy 推断，且 Tensor 不能跨进程 Pickle)
                'q_table_tensor',
                'visits_tensor',
                'target_dims_tensor',
                'spec_idxs_t', 'spec_mins_t', 'spec_maxs_t', 'spec_bins_t', 'spec_strides_t'
            ]

            # [Key Logic] 如果启用了共享内存，必须剥离 Q 表和 Visit 表本身
            # 因为 Worker 将通过共享内存直接访问它们，不需要通过 Pickle 传输
            if use_shared_q:
                blacklist.extend(['q_table', 'visits'])

            # 批量删除
            for k in blacklist:
                if k in clean_state:
                    del clean_state[k]

            return clean_state

        # 如果 use_shared_q 为 True，但 raw_state 不是字典 (例如旧代码只返回了 Array)，
        # 这属于异常情况，因为新版 extract_state 应该返回字典。
        # 为了兼容性/安全性，如果是 Array 且启用共享内存，则返回 None (回退到默认初始化)
        if use_shared_q and isinstance(raw_state, np.ndarray):
            return None

        return raw_state

    @staticmethod
    def load_state(agent, state_data):
        """
        将状态数据加载回 Agent。
        [Upgrade] 支持混合加载：元数据覆盖 + 共享内存保留。

        参数:
            agent: 智能体实例
            state_data: 状态数据 (dict 或 ndarray)
        """
        if state_data is None:
            return

        # Case A: Deep RL (字典类型的 state_dict)
        if hasattr(agent, 'eval_net') and isinstance(state_data, dict):
            # 这里假设 DeepRL 的 state_data 仅包含网络权重
            # 如果包含其他元数据，可能需要更复杂的处理，但目前保持原样
            if hasattr(agent.eval_net, 'load_state_dict'):
                agent.eval_net.load_state_dict(state_data)

        # Case B: Tabular RL (字典类型的混合状态 - New Standard)
        elif hasattr(agent, 'q_table') and isinstance(state_data, dict):
            # 遍历字典，恢复属性
            for k, v in state_data.items():
                # [Protection] 不要覆盖 Q 表和 Visits，除非明确需要 (例如 Legacy Load)
                # 在 prepare_state_for_worker(use_shared_q=True) 后，state_data 中不应包含 'q_table'
                if k == 'q_table':
                    if isinstance(agent.q_table, np.ndarray) and isinstance(v, np.ndarray):
                        if agent.q_table.shape == v.shape:
                            agent.q_table[:] = v[:]
                    continue

                if k == 'visits':
                    if hasattr(agent, 'visits') and isinstance(agent.visits, np.ndarray) and isinstance(v, np.ndarray):
                        if agent.visits.shape == v.shape:
                            agent.visits[:] = v[:]
                    continue

                # 恢复其他元数据 (如 use_spec_logic, spec_bins_arr, epsilon 等)
                setattr(agent, k, v)

        # Case C: Tabular RL (旧版 Numpy 数组 - Legacy Backup)
        elif isinstance(state_data, np.ndarray) and hasattr(agent, 'q_table'):
            if agent.q_table.shape != state_data.shape:
                raise ValueError(f"[AgentAdapter] Q-Table shape mismatch. "
                                 f"Agent: {agent.q_table.shape}, Data: {state_data.shape}")
            agent.q_table[:] = state_data[:]

    @staticmethod
    def get_shared_visits(agent):
        """
        提取共享访问计数缓冲区的基地址 (用于多进程初始化)。
        统一处理不同 Agent 实现中属性名的差异。
        """
        # 优先检查 flat visits (DQN style, 通常用于多维状态映射)
        if hasattr(agent, 'visits_flat') and hasattr(agent.visits_flat, 'base'):
            return agent.visits_flat.base

        # 其次检查 standard visits (Q-Learning style, 直接的一维数组)
        if hasattr(agent, 'visits') and hasattr(agent.visits, 'base'):
            return agent.visits.base

        return None
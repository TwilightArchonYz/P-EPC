# ==============================================================================
# 1. 演化算法导入 (Evolutionary Algorithms Imports)
# ==============================================================================
from evorl.algorithms.ea.de import SolverDE
from evorl.algorithms.ea.pso import SolverPSO
from evorl.algorithms.ea.shade import SolverSHADE
from evorl.algorithms.ea.lshade import SolverLSHADE
from evorl.algorithms.ea.jade import SolverJADE
from evorl.algorithms.ea.ljade import SolverLJADE
from evorl.algorithms.ea.spso import SolverSPSO
from evorl.algorithms.ea.lpso import SolverLPSO

# ==============================================================================
# 2. 混合算法容器导入 (Hybrid Containers Imports)
# ==============================================================================
from evorl.algorithms.hybrid.de_rl import DE_RL
from evorl.algorithms.hybrid.shade_rl import SHADE_RL
from evorl.algorithms.hybrid.jade_rl import JADE_RL
from evorl.algorithms.hybrid.ljade_rl import LJADE_RL
from evorl.algorithms.hybrid.pso_rl import PSO_RL  # [新增] 导入 PSO_RL

# ==============================================================================
# 3. 强化学习智能体导入 (RL Agents Imports)
# ==============================================================================
# DuelingDQNAgent 已重构以支持通用参数配置 (algo_params)
from evorl.algorithms.rl.dueling_dqn import DuelingDQNAgent
from evorl.algorithms.rl.q_learning import QLearningAgent

# [Modified] 解锁 DQN 导入 (dqn.py 现已存在)
from evorl.algorithms.rl.dqn import DQNAgent

# [Modified] 解锁 DDPG 导入 (ddpg.py 现已存在)
from evorl.algorithms.rl.ddpg import DDPGAgent

# [Modified] 解锁 PPO 导入 (ppo.py 现已存在)
from evorl.algorithms.rl.ppo import PPOAgent

# [Modified] 解锁 SAC 导入
from evorl.algorithms.rl.sac import SACAgent

# [Temporary] 暂时注释掉尚未创建的文件导入，防止 ImportError
# from evorl.algorithms.rl.td3 import TD3Agent


class AlgorithmFactory:
    """
    算法工厂类 (AlgorithmFactory)
    --------------------------------------------------
    功能：作为创建 Solver（演化算法求解器）和 Agent（强化学习智能体）的中央注册表。
    提供统一的接口来实例化基础 EA、RL Agent 以及混合算法容器。
    """

    # 1. 基础演化算法注册表
    # 映射关系: 字符串名称 -> Solver 类
    EA_REGISTRY = {
        'DE': SolverDE,
        'PSO': SolverPSO,
        'SHADE': SolverSHADE,
        'LSHADE': SolverLSHADE,
        'JADE': SolverJADE,
        'LJADE': SolverLJADE,
        'SPSO': SolverSPSO,
        'LPSO': SolverLPSO
    }

    # 2. 混合算法容器注册表 (EA + RL)
    # 仅包含支持 RL 指导的算法变体
    HYBRID_REGISTRY = {
        'DE': DE_RL,
        'SHADE': SHADE_RL,
        'JADE': JADE_RL,
        'LJADE': LJADE_RL,
        'PSO': PSO_RL  # [新增] 注册 PSO 混合算法
    }

    # 3. 强化学习智能体注册表
    AGENT_REGISTRY = {
        'Q_Learning': QLearningAgent,   # Q表
        'DQN': DQNAgent,                # Standard DQN
        'DuelingDQN': DuelingDQNAgent,  # Dueling DQN
        'DDPG': DDPGAgent,              # DDPG
        'PPO': PPOAgent,                # PPO
        'SAC': SACAgent,                # SAC
        # 'TD3': TD3Agent,              # TD3 (待文件创建)
    }

    @staticmethod
    def get_agent_class(agent_name):
        """
        根据名称检索 Agent 类。
        """
        if agent_name not in AlgorithmFactory.AGENT_REGISTRY:
            available = list(AlgorithmFactory.AGENT_REGISTRY.keys())
            raise ValueError(f"未知的 Agent: {agent_name}。可用列表: {available}")
        return AlgorithmFactory.AGENT_REGISTRY[agent_name]

    @staticmethod
    def create_agent(agent_name, state_dim, action_dim, **kwargs):
        """
        实例化一个强化学习智能体 (RL Agent)。

        参数:
            agent_name (str): 智能体名称 (如 'DQN')。
            state_dim (int): 状态向量的维度。
            action_dim (int): 动作空间的维度。
                              - 对于 DQN/Q-Learning: 离散动作的 Flat Index 数量。
                              - 对于 DDPG/PPO/SAC: 连续动作向量的维度 (参数个数)。
            **kwargs: 传递给 Agent 构造函数的额外参数。
                      关键点：对于支持通用动作空间的 Agent (如 DuelingDQNAgent)，
                      必须包含 'algo_params' 以便正确计算参数网格和步长。

        返回:
            一个 RL Agent 实例。
        """
        agent_cls = AlgorithmFactory.get_agent_class(agent_name)
        # 将所有动态配置 (包括 algo_params) 透传给 Agent
        return agent_cls(state_dim=state_dim, action_dim=action_dim, **kwargs)

    @staticmethod
    def create_solver(problem, ea_name, agent=None, **kwargs):
        """
        实例化一个求解器 (Evolutionary Algorithm)。

        参数:
            problem: 优化问题实例 (包含 eval 方法)。
            ea_name (str): 演化算法名称 (如 'SHADE', 'PSO')。
            agent (object, optional): RL 智能体实例。如果提供，则创建混合算法容器。
            **kwargs: 算法特定的超参数 (如 pop_size, max_nfes 等)。
                      [New] 支持传递给 RL-EA 的扩展参数 (通过 kwargs 透传):
                      - baseline_seed_curve: (np.array) 精确种子基准曲线
                      - baseline_mean_curve: (np.array) 均值基准曲线
                      - reward_window_long: (float) 长期奖励窗口比例
                      - reward_window_short: (float) 短期奖励窗口比例
                      - use_features: (list) 特征选择列表

        返回:
            一个 Solver 实例。
        """
        # 情况 A: 混合求解器 (EA + RL)
        # 如果传入了 agent，说明是 RL 指导模式
        if agent is not None:
            if ea_name not in AlgorithmFactory.HYBRID_REGISTRY:
                available = list(AlgorithmFactory.HYBRID_REGISTRY.keys())
                raise ValueError(f"该 EA 尚未实现混合模式 (RL): {ea_name}。"
                                 f"可用混合算法: {available}")

            solver_cls = AlgorithmFactory.HYBRID_REGISTRY[ea_name]
            # 混合求解器需要在 __init__ 中接收 agent
            # kwargs 会自动包含 baseline_curve, reward_window, use_features 等参数
            return solver_cls(problem, agent=agent, **kwargs)

        # 情况 B: 基础求解器 (纯 EA)
        else:
            if ea_name not in AlgorithmFactory.EA_REGISTRY:
                available = list(AlgorithmFactory.EA_REGISTRY.keys())
                raise ValueError(f"未知的 EA: {ea_name}。可用列表: {available}")

            solver_cls = AlgorithmFactory.EA_REGISTRY[ea_name]
            # 基础 EA 通常不接受 extra args，如果 kwargs 包含无关参数可能会报错
            # 但在 gen_baselines 中调用时通常只传基础参数，所以这里直接透传也是安全的
            return solver_cls(problem, **kwargs)
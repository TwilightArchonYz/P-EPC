import numpy as np
from evorl.algorithms.ea.shade import SolverSHADE


class SolverLJADE(SolverSHADE):
    """
    LJADE (L-SHADE 换名版)
    --------------------------------------------------
    本质上是正统的 L-SHADE (Linear Population Size Reduction SHADE)。
    为了与混合算法 LJADE_RL 在日志、基准数据文件命名上保持一致，特此重命名为 SolverLJADE。
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 memory_size=5, min_pop_size=4, **kwargs):
        """
        初始化 LJADE (L-SHADE) 求解器。
        """
        super().__init__(problem, pop_size, max_nfes, seed, memory_size=memory_size)

        self.min_pop_size = min_pop_size
        self.NP_init = pop_size  # 记录初始种群大小
        self.arc_rate = 1.0  # 存档比例，参考代码为 1.0

    def _apply_bound_constraint(self, U, X):
        """
        应用边界约束：中点修复策略。
        """
        lb = self.problem.lb
        ub = self.problem.ub

        # 处理下界
        mask_l = U < lb
        if np.any(mask_l):
            U[mask_l] = ((X + lb) / 2.0)[mask_l]

        # 处理上界
        mask_u = U > ub
        if np.any(mask_u):
            U[mask_u] = ((X + ub) / 2.0)[mask_u]

        return U

    def evolve(self):
        """执行一代进化 (原汁原味的 L-SHADE 逻辑)"""
        # --- A. LPSR: 线性种群缩减 ---
        new_pop_size = int(round(((self.min_pop_size - self.NP_init) / self.max_nfes) * self.fes + self.NP_init))
        new_pop_size = max(self.min_pop_size, new_pop_size)

        if new_pop_size < self.pop_size:
            # 缩减种群: 保留 Fitness 最好的前 new_pop_size 个
            sorted_idx = np.argsort(self.fitness)
            keep_idx = sorted_idx[:new_pop_size]

            self.X = self.X[keep_idx]
            self.fitness = self.fitness[keep_idx]
            self.cv = self.cv[keep_idx]
            if hasattr(self, 'raw_f'):
                self.raw_f = self.raw_f[keep_idx]

            self.pop_size = new_pop_size

            # 缩减存档: Archive size = arc_rate * NP
            current_archive_cap = int(self.arc_rate * self.pop_size)
            if len(self.archive_X) > current_archive_cap:
                # 随机删除
                n_remove = len(self.archive_X) - current_archive_cap
                for _ in range(n_remove):
                    self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

        # --- B. 记录演化前的状态 (For RL Trajectory) ---
        progress = self.fes / self.max_nfes
        diversity = self.get_diversity()
        max_gens = self.max_nfes / self.NP_init
        stag_ratio = min(1.0, self.stagnation_counter / (max_gens + 1e-9))
        current_state = (progress, diversity, stag_ratio)

        # --- C. SHADE 参数生成 ---
        pop_size = self.pop_size
        dim = self.dim
        X = self.X
        fitness = self.fitness

        r_idx = self.rng.randint(0, self.memory_size, pop_size)
        m_cr = self.M_cr[r_idx]
        m_f = self.M_f[r_idx]

        # Generate CR: Normal(m_cr, 0.1)
        cr = self.rng.normal(m_cr, 0.1, pop_size)
        cr = np.where(m_cr == -1, 0.0, cr)
        cr = np.clip(cr, 0.0, 1.0)

        # Generate F: Cauchy(m_f, 0.1)
        f_param = m_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))

        # F Regeneration
        while np.any(f_param <= 0):
            mask = f_param <= 0
            n_regen = np.sum(mask)
            f_param[mask] = m_f[mask] + 0.1 * np.tan(np.pi * (self.rng.rand(n_regen) - 0.5))

        f_param = np.minimum(f_param, 1.0)

        # 记录平均动作
        mean_f = np.mean(f_param)
        mean_cr = np.mean(cr)

        # --- D. 变异与交叉 (current-to-pbest/1) ---
        sorted_idx = np.argsort(fitness)
        num_pbest = max(1, int(pop_size * self.p_best_rate))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        r1 = self.rng.randint(0, pop_size, pop_size)
        Union_X = np.vstack([X, np.array(self.archive_X)]) if self.archive_X else X
        r2 = self.rng.randint(0, len(Union_X), pop_size)

        V = X + f_param.reshape(-1, 1) * (X_pbest - X) + f_param.reshape(-1, 1) * (X[r1] - Union_X[r2])

        # 边界处理: 使用中点修复策略
        V = self._apply_bound_constraint(V, X)

        mask_cross = self.rng.rand(pop_size, dim) < cr.reshape(-1, 1)
        j_rand = self.rng.randint(0, dim, pop_size)
        mask_cross[np.arange(pop_size), j_rand] = True
        U = np.where(mask_cross, V, X)

        # --- E. 评估 ---
        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        # --- F. 选择与更新 ---
        improved_mask = fit_U < fitness

        if np.any(improved_mask):
            success_f = f_param[improved_mask]
            success_cr = cr[improved_mask]
            diff_fit = np.abs(fitness[improved_mask] - fit_U[improved_mask])

            # 更新存档
            for p_vec in X[improved_mask]:
                self.archive_X.append(p_vec.copy())

            # 缩减存档
            current_archive_cap = int(self.arc_rate * self.pop_size)
            while len(self.archive_X) > current_archive_cap:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

            # 更新种群
            self.X[improved_mask] = U[improved_mask]
            self.fitness[improved_mask] = fit_U[improved_mask]
            self.cv[improved_mask] = cv_U[improved_mask]
            if hasattr(self, 'raw_f'):
                self.raw_f[improved_mask] = raw_U[improved_mask]

            # 更新记忆库
            weights = diff_fit / (np.sum(diff_fit) + 1e-15)

            # Update M_f (Lehmer Mean)
            self.M_f[self.k_mem] = np.sum(weights * (success_f ** 2)) / (np.sum(weights * success_f) + 1e-15)

            # Update M_cr (Lehmer Mean)
            if np.max(success_cr) == 0 or self.M_cr[self.k_mem] == -1:
                self.M_cr[self.k_mem] = -1
            else:
                self.M_cr[self.k_mem] = np.sum(weights * (success_cr ** 2)) / (np.sum(weights * success_cr) + 1e-15)

            self.k_mem = (self.k_mem + 1) % self.memory_size

        # --- G. 更新全局最优与奖励 ---
        prev_best = self.gbest_val
        self._update_gbest()
        current_best_fit = self.gbest_val

        if current_best_fit < prev_best:
            rel_imp = (prev_best - current_best_fit) / (abs(prev_best) + 1e-9)
            step_reward = 1.0 + min(10.0, 100.0 * rel_imp)
        else:
            step_reward = -0.1

        # 记录轨迹
        self.trajectory.append({
            'state': current_state,
            'action': (mean_f, mean_cr),
            'reward': step_reward
        })

    def solve(self):
        """主循环：返回结果及专家经验轨迹"""
        self.initialize()
        self.NP_init = self.pop_size
        self.last_best_fit = self.gbest_val

        while self.fes < self.max_nfes:
            self.evolve()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'trajectory': self.trajectory
        }
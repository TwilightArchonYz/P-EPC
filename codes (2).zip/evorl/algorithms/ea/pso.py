import numpy as np
from evorl.core.base_solver import BaseSolver


class SolverPSO(BaseSolver):
    """
    标准粒子群优化算法 (Standard PSO)
    策略: Inertia Weight Model (w-PSO)
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 w=0.729, c1=1.494, c2=1.494):
        # 接口对齐: 将 seed 透传给 BaseSolver，由其统一处理 RNG (支持 int 或 RandomState)
        super().__init__(problem, pop_size, max_nfes, seed)

        # PSO 参数
        self.w = w
        self.c1 = c1
        self.c2 = c2

        # 速度限制 (通常设为搜索范围的 20%)
        self.v_max = 0.2 * (self.ub - self.lb)
        self.v_min = -self.v_max

        # 状态变量
        self.V = None
        self.pbest_X = None
        self.pbest_fit = None

    def initialize(self):
        """覆盖初始化，增加速度和 Pbest 初始化"""
        super().initialize()

        # 初始化速度 (0)
        self.V = np.zeros((self.pop_size, self.dim))

        # 初始化 Pbest
        self.pbest_X = self.X.copy()
        self.pbest_fit = self.fitness.copy()

    def evolve(self):
        """执行一代进化"""
        # 使用统一接口管理的 self.rng
        r1 = self.rng.rand(self.pop_size, self.dim)
        r2 = self.rng.rand(self.pop_size, self.dim)

        # 1. 更新速度
        # V = w*V + c1*r1*(pbest - X) + c2*r2*(gbest - X)
        self.V = (self.w * self.V +
                  self.c1 * r1 * (self.pbest_X - self.X) +
                  self.c2 * r2 * (self.gbest_X - self.X))

        # 速度钳制
        self.V = np.clip(self.V, self.v_min, self.v_max)

        # 2. 更新位置
        self.X = self.X + self.V

        # 位置边界处理
        self.X = np.clip(self.X, self.lb, self.ub)

        # 3. 评估
        fitness, raw_f, cv = self.problem.evaluate(self.X)
        self.fitness = fitness
        self.raw_f = raw_f
        self.cv = cv
        self.fes += self.pop_size

        # 4. 更新 Pbest
        mask = fitness < self.pbest_fit
        self.pbest_X[mask] = self.X[mask]
        self.pbest_fit[mask] = fitness[mask]

        # 5. 更新 Gbest (调用基类方法)
        self._update_gbest()

    def update_params(self, action):
        """
        [DRL 接口] 更新参数
        action: expected [w, c1, c2]
        """
        if action is not None and len(action) >= 3:
            self.w = np.clip(action[0], 0.1, 1.0)
            self.c1 = np.clip(action[1], 0.1, 4.0)
            self.c2 = np.clip(action[2], 0.1, 4.0)
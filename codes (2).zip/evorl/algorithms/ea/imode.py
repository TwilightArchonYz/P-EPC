import numpy as np
from scipy.optimize import minimize
from evorl.core.base_solver import BaseSolver


class SolverIMODE(BaseSolver):
    """
    IMODE: Improved Multi-Operator Differential Evolution
    Reference: func_IMODE.m
    Includes:
        - EBO (DE with LPSR and 4-slot Memory)
        - Scout (CMA-ES with Competition)
        - LS2 (SQP Local Search)
    """

    def __init__(self, problem, pop_size=None, max_nfes=100000, seed=None,
                 min_pop_size=4, **kwargs):
        """
        初始化 IMODE 求解器。
        注意: IMODE 会根据问题维度自动调整种群大小分配 (PS1, PS2)。
        """
        # IMODE 默认总种群大小建议为 18 * D，如果用户未指定，则自动计算
        if pop_size is None:
            pop_size = 18 * problem.dim

        super().__init__(problem, pop_size, max_nfes, seed)

        self.min_pop_size = min_pop_size
        self.dim = problem.dim

        # --- 1. 参数设置 & 种群分配 ---
        # PS2 (CMA Pop) = 4 + floor(3 * log(n))
        self.ps2 = 4 + int(np.floor(3 * np.log(self.dim)))
        # PS1 (DE Pop) = Total - PS2
        self.ps1 = self.pop_size - self.ps2

        if self.ps1 < self.min_pop_size:
            # 保护机制：若总种群太小，优先保证 DE
            self.ps1 = self.pop_size
            self.ps2 = 0  # 这种情况下 CMA 不会运行

        self.init_ps1 = self.ps1  # 记录初始 DE 种群大小 (用于 LPSR)

        # Cycle Parameters
        if self.dim == 10:
            self.cs = 50
        elif self.dim == 30:
            self.cs = 100
        elif self.dim == 50:
            self.cs = 150
        else:
            self.cs = self.dim * 5

        self.cy = 0  # Cycle counter
        self.probs = np.array([0.5, 0.5])  # [Prob_DE, Prob_CMA]
        self.prob_ls = 0.1  # Local Search Probability

        # --- 2. 初始化种群 ---
        # 为了方便，我们在 initialize 中具体填充数值
        self.ea_1 = None  # DE Population
        self.fit_1 = None
        self.ea_2 = None  # CMA Population
        self.fit_2 = None

        # --- 3. Memory Initialization (EBO) ---
        self.memory_size = 6
        self.hist_pos = 0
        self.mem_f = np.full(self.memory_size, 0.7)
        self.mem_cr = np.full(self.memory_size, 0.5)
        self.mem_t = np.full(self.memory_size, 0.1)
        self.mem_freq = np.full(self.memory_size, 0.5)

        # Archive for DE
        self.arc_rate = 2.6
        self.archive_x = []
        self.archive_f = []  # Fitness of archive

        # --- 4. CMA Parameters ---
        self.cma_state = {}  # Dict to store B, D, C, sigma, etc.

        # RL Trajectory
        self.trajectory = []
        self.last_best_fit = float('inf')

    def initialize(self):
        """初始化种群及 CMA 参数"""
        super().initialize()  # Base Initialize (creates self.X, self.fitness)

        # 分割 BaseSolver 生成的初始种群
        self.ea_1 = self.X[:self.ps1].copy()
        self.fit_1 = self.fitness[:self.ps1].copy()

        if self.ps2 > 0:
            self.ea_2 = self.X[self.ps1:].copy()
            self.fit_2 = self.fitness[self.ps1:].copy()
            self._init_cma_params()
        else:
            self.ea_2 = None
            self.fit_2 = None

        # [FIX] 显式初始化 last_best_fit，防止 Benchmark 循环中第一代计算奖励出错
        self.last_best_fit = self.gbest_val

    def _init_cma_params(self):
        """初始化/重置 CMA-ES 参数"""
        n = self.dim
        # xmean = mean(EA_2)
        xmean = np.mean(self.ea_2, axis=0)

        sigma = 0.3
        # Weights
        mu = int(np.ceil(self.ps2 / 2))
        weights = np.log(max(mu, n / 2) + 0.5) - np.log(np.arange(1, mu + 1))
        weights = weights / np.sum(weights)
        mueff = np.sum(weights) ** 2 / np.sum(weights ** 2)

        # Adaptation constants
        cc = (4 + mueff / n) / (n + 4 + 2 * mueff / n)
        cs = (mueff + 2) / (n + mueff + 3)
        ccov1 = 2 / ((n + 1.3) ** 2 + mueff)
        ccovmu = 2 * (mueff - 2 + 1 / mueff) / ((n + 2) ** 2 + mueff)
        damps = 1 + 2 * max(0, np.sqrt((mueff - 1) / (n + 1)) - 1) + cs

        # Matrices
        pc = np.zeros(n)
        ps = np.zeros(n)
        B = np.eye(n)
        D = np.ones(n)
        C = np.eye(n)  # B * D * (B * D)'
        chiN = n ** 0.5 * (1 - 1 / (4 * n) + 1 / (21 * n ** 2))

        self.cma_state = {
            'xmean': xmean,
            'sigma': sigma,
            'pc': pc,
            'ps': ps,
            'B': B,
            'D': D,
            'C': C,
            'chiN': chiN,
            'weights': weights,
            'mu': mu,
            'mueff': mueff,
            'cc': cc,
            'cs': cs,
            'ccov1': ccov1,
            'ccovmu': ccovmu,
            'damps': damps,
            'xold': xmean.copy()
        }

    def _han_boun(self, X_new, X_old, mode=1):
        """
        边界处理 logic.
        mode 1 (DE): Midpoint repair.
        mode 2 (CMA): Reflection with truncation.
        """
        lb = self.problem.lb
        ub = self.problem.ub

        # [Safety Check] 确保输入是至少 2D 的
        if X_new.ndim == 1:
            X_new = X_new.reshape(1, -1)

        if X_old is not None and X_old.ndim == 1:
            X_old = X_old.reshape(1, -1)

        if mode == 1:
            # DE Mode: (x + bound) / 2
            if X_old is not None:
                mask_l = X_new < lb
                if np.any(mask_l):
                    X_new[mask_l] = ((X_old + lb) / 2.0)[mask_l]  # Broadcasting fix

                mask_u = X_new > ub
                if np.any(mask_u):
                    X_new[mask_u] = ((X_old + ub) / 2.0)[mask_u]
            else:
                X_new = np.clip(X_new, lb, ub)

        elif mode == 2:
            # CMA Mode: Reflection
            mask_l = X_new < lb
            if np.any(mask_l):
                X_new[mask_l] = (2.0 * lb - X_new)[mask_l]  # Broadcasting fix

            mask_u = X_new > ub
            if np.any(mask_u):
                X_new[mask_u] = (2.0 * ub - X_new)[mask_u]

        # [Final Safety] 统一强制截断
        X_new = np.clip(X_new, lb, ub)

        return X_new

    def _step_ebo(self):
        """
        Phase 1: EBO (DE with LPSR & 4-slot Memory)
        """
        if self.ps1 <= 0: return

        # --- 1. LPSR (Linear Population Size Reduction) ---
        current_target = int(round(((self.min_pop_size - self.init_ps1) / self.max_nfes) * self.fes + self.init_ps1))

        if self.ps1 > current_target:
            reduce_num = self.ps1 - current_target
            if self.ps1 - reduce_num < self.min_pop_size:
                reduce_num = self.ps1 - self.min_pop_size

            if reduce_num > 0:
                sort_idx = np.argsort(self.fit_1)  # Ascending (best first)
                keep_idx = sort_idx[:-reduce_num]  # Keep top

                self.ea_1 = self.ea_1[keep_idx]
                self.fit_1 = self.fit_1[keep_idx]
                self.ps1 = len(self.ea_1)

                # Update Archive size
                arc_target = int(round(self.arc_rate * self.ps1))
                if len(self.archive_x) > arc_target:
                    keep_arc = self.rng.choice(len(self.archive_x), arc_target, replace=False)
                    self.archive_x = [self.archive_x[i] for i in keep_arc]
                    self.archive_f = [self.archive_f[i] for i in keep_arc]

        # --- 2. Generate Parameters (F, CR, T, Freq) ---
        r_idx = self.rng.randint(0, self.memory_size, self.ps1)
        mu_f = self.mem_f[r_idx]
        mu_cr = self.mem_cr[r_idx]
        mu_t = self.mem_t[r_idx]
        mu_freq = self.mem_freq[r_idx]

        # Generate CR
        rnd1 = self.rng.rand(self.ps1)
        rnd2 = self.rng.rand(self.ps1)
        cr = mu_cr + 0.1 * np.sqrt(np.pi) * (np.arcsin(-rnd1) + np.arcsin(rnd2))
        cr = np.where(mu_cr == -1, 0.0, cr)
        cr = np.clip(cr, 0.0, 1.0)

        # Generate F
        f_params = mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(self.ps1) - 0.5))
        while np.any(f_params <= 0):
            mask = f_params <= 0
            f_params[mask] = mu_f[mask] + 0.1 * np.tan(np.pi * (self.rng.rand(np.sum(mask)) - 0.5))
        f_params = np.minimum(f_params, 1.0)

        # Generate T
        t_params = mu_t + 0.05 * (
                np.sqrt(np.pi) * (np.arcsin(-self.rng.rand(self.ps1)) + np.arcsin(self.rng.rand(self.ps1))))
        t_params = np.clip(t_params, 0.0, 0.5)

        # Generate Freq
        freq_params = mu_freq + 0.1 * np.tan(np.pi * (self.rng.rand(self.ps1) - 0.5))
        while np.any(freq_params <= 0):
            mask = freq_params <= 0
            freq_params[mask] = mu_freq[mask] + 0.1 * np.tan(np.pi * (self.rng.rand(np.sum(mask)) - 0.5))
        freq_params = np.minimum(freq_params, 1.0)

        # --- 3. Mutation & Crossover ---
        mask_cross = np.zeros((self.ps1, self.dim), dtype=bool)
        if self.dim == 1:
            mask_cross[:, 0] = (self.rng.rand(self.ps1) < cr)
        else:
            l_start = np.floor(self.dim * self.rng.rand(self.ps1)).astype(int)
            for i in range(self.ps1):
                half_n = self.dim // 2
                decay = np.exp(-t_params[i] / self.dim * np.arange(half_n))

                if self.dim % 2 == 0:
                    ll = cr[i] * np.concatenate([decay, decay[::-1]])
                else:
                    mid = np.exp(-t_params[i] / self.dim * half_n)
                    ll = cr[i] * np.concatenate([decay, [mid], decay[::-1]])

                indices = np.roll(np.arange(self.dim), -l_start[i])
                mask_cross[i, indices] = (self.rng.rand(self.dim) < ll)

        j_rand = self.rng.randint(0, self.dim, self.ps1)
        mask_cross[np.arange(self.ps1), j_rand] = True

        # Mutation Vectors
        sort_idx = np.argsort(self.fit_1)
        p_np = max(int(0.1 * self.ps1), 2)
        pbest_indices = sort_idx[self.rng.randint(0, p_np, self.ps1)]
        x_pbest = self.ea_1[pbest_indices]

        idxs = np.arange(self.ps1)
        r1 = self.rng.randint(0, self.ps1, self.ps1)

        pop_all = self.ea_1
        if len(self.archive_x) > 0:
            pop_all = np.vstack([self.ea_1, np.array(self.archive_x)])

        r2 = self.rng.randint(0, len(pop_all), self.ps1)
        r3 = self.rng.randint(0, self.ps1, self.ps1)

        if not hasattr(self, 'de_strat_probs'):
            self.de_strat_probs = np.array([0.5, 0.5])

        bb = self.rng.rand(self.ps1)
        mask_s1 = bb <= self.de_strat_probs[0]
        mask_s2 = ~mask_s1

        # Oscillation for F
        if self.fes <= self.max_nfes / 2:
            c = self.rng.rand()
            gg = self.fes / self.ps1
            if c < 0.5:
                osc = 0.5 * (np.tan(2 * np.pi * 0.5 * gg + np.pi) * ((self.max_nfes - self.fes) / self.max_nfes) + 1)
                f_params[:] = osc
            else:
                osc = 0.5 * (np.tan(2 * np.pi * freq_params * gg) * (gg / self.max_nfes) + 1)
                f_params[:] = osc

        V = np.zeros_like(self.ea_1)

        if np.any(mask_s1):
            V[mask_s1] = self.ea_1[mask_s1] + f_params[mask_s1, None] * (
                    self.ea_1[r1[mask_s1]] - self.ea_1[mask_s1] +
                    self.ea_1[r3[mask_s1]] - pop_all[r2[mask_s1]]
            )

        if np.any(mask_s2):
            V[mask_s2] = self.ea_1[mask_s2] + f_params[mask_s2, None] * (
                    x_pbest[mask_s2] - self.ea_1[mask_s2] +
                    self.ea_1[r1[mask_s2]] - self.ea_1[r3[mask_s2]]
            )

        V = self._han_boun(V, self.ea_1, mode=1)
        U = np.where(mask_cross, V, self.ea_1)

        fit_new, _, _ = self.problem.evaluate(U)
        self.fes += self.ps1

        improved = fit_new < self.fit_1

        if np.any(improved):
            for i in np.where(improved)[0]:
                self.archive_x.append(self.ea_1[i].copy())
                self.archive_f.append(self.fit_1[i])

            arc_target = int(self.arc_rate * self.ps1)
            while len(self.archive_x) > arc_target:
                idx = self.rng.randint(0, len(self.archive_x))
                self.archive_x.pop(idx)
                self.archive_f.pop(idx)

        diff2 = np.maximum(0, (self.fit_1 - fit_new) / (np.abs(self.fit_1) + 1e-9))
        count_s = np.zeros(2)
        if np.any(mask_s1 & improved):
            count_s[0] = np.mean(diff2[mask_s1 & improved])
        if np.any(mask_s2 & improved):
            count_s[1] = np.mean(diff2[mask_s2 & improved])

        if np.sum(count_s) > 0:
            self.de_strat_probs = np.clip(count_s / np.sum(count_s), 0.1, 0.9)
        else:
            self.de_strat_probs = np.array([0.5, 0.5])

        if np.any(improved):
            diff_val = np.abs(self.fit_1[improved] - fit_new[improved])
            weights = diff_val / (np.sum(diff_val) + 1e-15)

            succ_f = f_params[improved]
            succ_cr = cr[improved]
            succ_t = t_params[improved]
            succ_freq = freq_params[improved]

            self.mem_f[self.hist_pos] = np.sum(weights * succ_f ** 2) / (np.sum(weights * succ_f) + 1e-15)

            if np.max(succ_cr) == 0 or self.mem_cr[self.hist_pos] == -1:
                self.mem_cr[self.hist_pos] = -1
            else:
                self.mem_cr[self.hist_pos] = np.sum(weights * succ_cr ** 2) / (np.sum(weights * succ_cr) + 1e-15)

            self.mem_t[self.hist_pos] = np.sum(weights * succ_t ** 2) / (np.sum(weights * succ_t) + 1e-15)

            if np.max(succ_freq) == 0 or self.mem_freq[self.hist_pos] == -1:
                self.mem_freq[self.hist_pos] = -1
            else:
                self.mem_freq[self.hist_pos] = np.sum(weights * succ_freq ** 2) / (np.sum(weights * succ_freq) + 1e-15)

            self.mem_f[self.hist_pos] = np.clip(self.mem_f[self.hist_pos], 0, 1)
            self.hist_pos = (self.hist_pos + 1) % self.memory_size

        self.ea_1[improved] = U[improved]
        self.fit_1[improved] = fit_new[improved]

    def _step_scout(self):
        """
        Phase 2: Scout (CMA-ES)
        """
        if self.ps2 <= 0: return

        st = self.cma_state
        n = self.dim
        lambda_ = self.ps2

        if self.rng.rand() < self.probs[0]:
            arz = np.sqrt(np.pi) * (np.arcsin(self.rng.rand(n, lambda_)) + np.arcsin(-self.rng.rand(n, lambda_)))
        else:
            arz = np.sqrt(np.pi) * np.arcsin(2 * self.rng.rand(n, lambda_) - 1)

        arx = st['xmean'][:, None] + st['sigma'] * (st['B'] @ (st['D'][:, None] * arz))
        arx = arx.T

        if self.fes >= 0.5 * self.max_nfes:
            arx = self._han_boun(arx, None, mode=2)

        fit_new, _, _ = self.problem.evaluate(arx)
        self.fes += lambda_

        sort_idx = np.argsort(fit_new)
        arx = arx[sort_idx]
        fit_new = fit_new[sort_idx]
        arz = arz[:, sort_idx]

        self.ea_2 = arx.copy()
        self.fit_2 = fit_new.copy()

        mu = st['mu']
        weights = st['weights']

        xold = st['xmean']
        cmean = 1.0
        xmean = (1 - cmean) * xold + cmean * (arx[:mu].T @ weights)

        if self.fes >= 0.5 * self.max_nfes:
            xmean = self._han_boun(xmean[None, :], None, mode=2)[0]

        st['xmean'] = xmean
        st['xold'] = xold

        zmean = arz[:, :mu] @ weights
        st['ps'] = (1 - st['cs']) * st['ps'] + \
                   np.sqrt(st['cs'] * (2 - st['cs']) * st['mueff']) * (st['B'] @ zmean)

        hsig = np.linalg.norm(st['ps']) / np.sqrt(1 - (1 - st['cs']) ** (2 * (self.fes / lambda_))) / st[
            'chiN'] < 1.4 + 2 / (n + 1)

        st['pc'] = (1 - st['cc']) * st['pc'] + \
                   hsig * np.sqrt(st['cc'] * (2 - st['cc']) * st['mueff']) / st['sigma'] * (xmean - xold)

        artmp = (arx[:mu].T - xold[:, None]) / st['sigma']
        st['C'] = (1 - st['ccov1'] - st['ccovmu']) * st['C'] + \
                  st['ccov1'] * np.outer(st['pc'], st['pc']) + \
                  st['ccovmu'] * (artmp @ np.diag(weights) @ artmp.T)

        st['sigma'] *= np.exp(min(1, (np.linalg.norm(st['ps']) / st['chiN'] - 1) * st['cs'] / st['damps']))

        if (self.fes // lambda_) % max(1, int(1 / (st['ccov1'] + st['ccovmu']) / n / 10)) == 0:
            st['C'] = np.triu(st['C']) + np.triu(st['C'], 1).T
            vals, vecs = np.linalg.eigh(st['C'])
            st['D'] = np.sqrt(np.maximum(vals, 0))
            st['B'] = vecs

    def _step_ls(self):
        """Phase 3: Local Search (SQP)"""
        best_idx = np.argmin(self.fit_1)
        best_x = self.ea_1[best_idx]
        best_f = self.fit_1[best_idx]

        ls_fe = int(np.ceil(0.02 * self.max_nfes))

        def obj_func(x):
            f, _, _ = self.problem.evaluate(x.reshape(1, -1))
            return f[0]

        bounds = list(zip(self.problem.lb, self.problem.ub))

        res = minimize(obj_func, best_x, method='SLSQP', bounds=bounds,
                       options={'maxiter': ls_fe, 'ftol': 1e-8})

        self.fes += res.nfev

        if res.fun < best_f:
            self.ea_1[best_idx] = res.x
            self.fit_1[best_idx] = res.fun

            sort_idx = np.argsort(self.fit_1)
            self.ea_1 = self.ea_1[sort_idx]
            self.fit_1 = self.fit_1[sort_idx]

            if self.ea_2 is not None:
                self.ea_2[:] = self.ea_1[0]
                self._init_cma_params()
                self.cma_state['sigma'] = 1e-5
                self.fit_2[:] = self.fit_1[0]

            self.prob_ls = 0.1
        else:
            self.prob_ls = 0.01

    def evolve(self):
        """IMODE Evolution Cycle"""
        self.cy += 1

        if self.cy == self.cs + 1:
            q1 = self.fit_1[0]
            # [FIX] 安全获取 q2
            q2 = self.fit_2[0] if (self.fit_2 is not None and len(self.fit_2) > 0) else float('inf')

            if np.isinf(q2):
                norm_q = np.array([1.0, 0.0])  # DE Wins
            else:
                qs = np.array([q1, q2])
                norm_q = 1.0 - (qs / (np.sum(qs) + 1e-15))

            d1 = np.mean(np.linalg.norm(self.ea_1[1:] - self.ea_1[0], axis=1)) if len(self.ea_1) > 1 else 0
            if self.ea_2 is not None and len(self.ea_2) > 1:
                d2 = np.mean(np.linalg.norm(self.ea_2[1:] - self.ea_2[0], axis=1))
            else:
                d2 = 0

            ds = np.array([d1, d2])
            norm_d = ds / (np.sum(ds) + 1e-15)

            new_probs = norm_q + norm_d
            new_probs = new_probs / (np.sum(new_probs) + 1e-15)
            self.probs = np.clip(new_probs, 0.1, 0.9)

        elif self.cy >= 2 * self.cs:
            if self.probs[0] > self.probs[1]:
                if self.ea_2 is not None:
                    n_share = min(self.ps1, self.ps2)
                    indices = self.rng.choice(self.ps1, n_share, replace=False)
                    self.ea_2[:n_share] = self.ea_1[indices]
                    self.fit_2[:n_share] = self.fit_1[indices]
                    self._init_cma_params()
                    self.cma_state['sigma'] *= (1 - self.fes / self.max_nfes)
            else:
                if self.ea_2 is not None and self.fit_2[0] < self.fit_1[-1]:
                    self.ea_1[-1] = self.ea_2[0]
                    self.fit_1[-1] = self.fit_2[0]
                    sort_idx = np.argsort(self.fit_1)
                    self.ea_1 = self.ea_1[sort_idx]
                    self.fit_1 = self.fit_1[sort_idx]

            self.cy = 0
            self.probs = np.array([0.5, 0.5])

        if self.rng.rand() < self.probs[0]:
            self._step_ebo()
        else:
            self._step_scout()

        if self.fes > 0.75 * self.max_nfes:
            if self.rng.rand() < self.prob_ls:
                self._step_ls()

        # --- 5. Global Best Update ---
        # [FIX] 更加鲁棒的 Best 更新逻辑
        best_1_idx = np.argmin(self.fit_1)
        current_best = self.fit_1[best_1_idx]
        current_best_X = self.ea_1[best_1_idx]

        if self.fit_2 is not None and len(self.fit_2) > 0:
            best_2_idx = np.argmin(self.fit_2)
            if self.fit_2[best_2_idx] < current_best:
                current_best = self.fit_2[best_2_idx]
                current_best_X = self.ea_2[best_2_idx]

        # [FIX] 强制单调递减更新 gbest_val
        if current_best < self.gbest_val:
            self.gbest_val = current_best
            self.gbest_X = current_best_X.copy()
            # Reset stagnation? BaseSolver does it in _update_gbest,
            # but IMODE manages manually. Let's keep manual for now.

        # Record Trajectory
        progress = self.fes / self.max_nfes

        if self.gbest_val < self.last_best_fit:
            if np.isinf(self.last_best_fit):
                step_reward = 1.0
            else:
                step_reward = 1.0  # Simplified reward
            self.last_best_fit = self.gbest_val
        else:
            step_reward = 0.0

        self.trajectory.append({
            'state': (progress, 0.0, 0.0),
            'action': tuple(self.probs),
            'reward': step_reward
        })

    def update_params(self, action):
        pass

    def solve(self):
        self.initialize()
        while self.fes < self.max_nfes:
            self.evolve()

        return {
            'best_fitness': self.gbest_val,
            'trajectory': self.trajectory
        }
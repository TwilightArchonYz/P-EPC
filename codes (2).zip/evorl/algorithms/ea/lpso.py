import numpy as np
from evorl.core.base_solver import BaseSolver

# ✅ [新增] 必须导入父类 SolverSPSO，否则 NameError
from evorl.algorithms.ea.spso import SolverSPSO

class SolverLPSO(SolverSPSO):
    """
    L-PSO: S-PSO with Linear Population Size Reduction
    特点:
    1. 继承 SolverSPSO 的自适应参数机制
    2. 随着 FES 增加，线性减少粒子数量
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 memory_size=5, min_pop_size=4):
        super().__init__(problem, pop_size, max_nfes, seed, memory_size)

        self.initial_pop_size = pop_size
        self.min_pop_size = min_pop_size

    def evolve(self):
        """覆盖父类进化，增加 LPSR 逻辑"""
        # 1. 执行标准 S-PSO 进化一代
        super().evolve()

        # 2. 执行线性种群缩减
        self.reduce_population()

    def reduce_population(self):
        """
        LPSR Logic for PSO
        """
        fes_ratio = self.fes / self.max_nfes
        n_next = int(self.initial_pop_size + (self.min_pop_size - self.initial_pop_size) * fes_ratio)

        if n_next < self.min_pop_size:
            n_next = self.min_pop_size

        curr_size = self.pop_size

        if curr_size > n_next:
            num_to_delete = curr_size - n_next

            # 策略: 删除 Pbest 最差的粒子
            sorted_idx = np.argsort(self.pbest_fit)
            # 取最后 (fitness 大 = 差)
            worst_indices = sorted_idx[-num_to_delete:]

            keep_mask = np.ones(curr_size, dtype=bool)
            keep_mask[worst_indices] = False

            # 同步删除所有状态矩阵
            self.X = self.X[keep_mask]
            self.V = self.V[keep_mask]
            self.pbest_X = self.pbest_X[keep_mask]
            self.pbest_fit = self.pbest_fit[keep_mask]

            self.fitness = self.fitness[keep_mask]
            self.raw_f = self.raw_f[keep_mask]
            self.cv = self.cv[keep_mask]

            # 更新种群大小
            self.pop_size = n_next

import numpy as np
from evorl.core.base_solver import BaseSolver


class SolverIPSO(BaseSolver):
    """
    IPSO: Improved PSO with Linear Decreasing Inertia Weight (LDIW)
    特点:
    1. 惯性权重 w 随进化过程从 w_max 线性递减至 w_min。
    2. 初期 w 较大 (0.9) 增强全局探索，后期 w 较小 (0.4) 增强局部精细开发。
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 c1=2.0, c2=2.0, w_max=0.9, w_min=0.4):
        super().__init__(problem, pop_size, max_nfes, seed)

        # 学习因子 (通常配合 LDIW 设为 2.0)
        self.c1 = c1
        self.c2 = c2

        # 惯性权重范围
        self.w_max = w_max
        self.w_min = w_min

        # 速度限制
        self.v_max = 0.2 * (self.ub - self.lb)
        self.v_min = -self.v_max

        # 状态变量
        self.V = None
        self.pbest_X = None
        self.pbest_fit = None

    def initialize(self):
        """初始化速度和 Pbest"""
        super().initialize()

        # 初始化速度 (0)
        self.V = np.zeros((self.pop_size, self.dim))

        # 初始化 Pbest
        self.pbest_X = self.X.copy()
        self.pbest_fit = self.fitness.copy()

    def update_params(self, action):
        """
        [BaseSolver 接口要求]
        IPSO 是纯自适应算法（LDIW），不需要外部 RL 控制参数，因此留空。
        """
        pass

    def evolve(self):
        """执行一代进化"""
        # 1. 计算当前的自适应权重 w
        # w = w_max - (w_max - w_min) * (current_fes / max_fes)
        progress = self.fes / self.max_nfes
        w = self.w_max - (self.w_max - self.w_min) * progress

        # 2. 更新速度
        r1 = self.rng.rand(self.pop_size, self.dim)
        r2 = self.rng.rand(self.pop_size, self.dim)

        self.V = (w * self.V +
                  self.c1 * r1 * (self.pbest_X - self.X) +
                  self.c2 * r2 * (self.gbest_X - self.X))

        # 速度钳制
        self.V = np.clip(self.V, self.v_min, self.v_max)

        # 3. 更新位置
        self.X = self.X + self.V

        # 位置边界处理
        self.X = np.clip(self.X, self.lb, self.ub)

        # 4. 评估
        fitness, raw_f, cv = self.problem.evaluate(self.X)
        self.fes += self.pop_size

        # 更新当前状态
        self.fitness = fitness
        self.raw_f = raw_f
        self.cv = cv

        # 5. 更新 Pbest
        # 注意: 这里的 fitness 已经是新的了
        mask = fitness < self.pbest_fit
        self.pbest_X[mask] = self.X[mask]
        self.pbest_fit[mask] = fitness[mask]

        # 6. 更新 Gbest
        self._update_gbest()


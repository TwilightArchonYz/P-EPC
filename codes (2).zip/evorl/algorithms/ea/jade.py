import numpy as np
from evorl.core.base_solver import BaseSolver


class SolverJADE(BaseSolver):
    """
    JADE: Adaptive Differential Evolution with Optional External Archive
    [Enhanced] 增加轨迹记录功能，用于加速 RL 训练
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 c=0.1, p_best_rate=0.05):
        super().__init__(problem, pop_size, max_nfes, seed)

        self.c = c  # 参数适应学习率
        self.p_best_rate = p_best_rate
        self.arc_rate = 1.0

        # JADE 参数初始化
        self.mu_cr = 0.5
        self.mu_f = 0.5

        # 外部存档
        self.archive_X = []

        # [Expert Feature] 轨迹记录：用于存储 (s, a, r)
        self.trajectory = []
        self.last_best_fit = float('inf')
        # stagnation_counter 已在 BaseSolver 定义，此处直接使用

    def get_diversity(self):
        """计算归一化多样性 (逻辑与 SolverRLDE 对齐)"""
        std_per_dim = np.std(self.X, axis=0)
        mean_std = np.mean(std_per_dim)
        bounds = self.problem.ub - self.problem.lb
        mean_bound = np.mean(bounds)
        return mean_std / (mean_bound + 1e-9)

    def update_params(self, action):
        """
        [接口实现] 满足 BaseSolver 抽象要求。
        JADE 使用基于成功历史的自适应机制，而非外部 DRL 控制，
        因此此处保持为空逻辑。
        """
        pass

    def evolve(self):
        """执行一代进化并记录专家轨迹"""
        # --- A. 记录演化前的状态 ---
        progress = self.fes / self.max_nfes
        diversity = self.get_diversity()
        # 停滞比例 (基于 BaseSolver 中的 stagnation_counter)
        max_gens = self.max_nfes / self.pop_size
        stag_ratio = min(1.0, self.stagnation_counter / max_gens) if max_gens > 0 else 0.0

        current_state = (progress, diversity, stag_ratio)

        # --- B. JADE 标准演化逻辑 ---
        pop_size = self.pop_size
        dim = self.dim
        X = self.X
        fitness = self.fitness

        # 生成 CR: N(mu_cr, 0.1)
        # [FIXED] 使用 self.rng 而非 np.random，确保种子(Seed)生效
        cr = self.rng.normal(self.mu_cr, 0.1, pop_size)
        cr = np.clip(cr, 0.0, 1.0)

        # 生成 F: Cauchy(mu_f, 0.1)
        # 使用 tan 分布模拟柯西分布: C(loc, scale) = loc + scale * tan(pi * (rand - 0.5))
        f_param = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))

        # JADE F 截断与重生成逻辑
        # 1. F > 1 截断为 1
        f_param = np.where(f_param > 1.0, 1.0, f_param)

        # 2. F <= 0 重生成 (向量化处理)
        while np.any(f_param <= 0):
            mask = f_param <= 0
            n_regen = np.sum(mask)
            f_param[mask] = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(n_regen) - 0.5))
            f_param[mask] = np.where(f_param[mask] > 1.0, 1.0, f_param[mask])

        # 记录本次迭代的平均动作 (用于 RL 模仿)
        mean_f = np.mean(f_param)
        mean_cr = np.mean(cr)

        sorted_idx = np.argsort(fitness)
        num_pbest = max(1, int(pop_size * self.p_best_rate))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        r1 = self.rng.randint(0, pop_size, pop_size)
        Union_X = np.vstack([X, np.array(self.archive_X)]) if self.archive_X else X
        r2 = self.rng.randint(0, len(Union_X), pop_size)

        # DE/current-to-pbest/1
        # V = X + F*(Xpbest - X) + F*(Xr1 - Xr2)
        V = X + f_param.reshape(-1, 1) * (X_pbest - X) + f_param.reshape(-1, 1) * (X[r1] - Union_X[r2])

        # 边界处理: Clip
        # 注意: JADE 原始论文通常不做特殊 Reflection，Clip 是安全的
        V = np.clip(V, self.problem.lb, self.problem.ub)

        mask_cross = self.rng.rand(pop_size, dim) < cr.reshape(-1, 1)
        j_rand = self.rng.randint(0, dim, pop_size)
        mask_cross[np.arange(pop_size), j_rand] = True
        U = np.where(mask_cross, V, X)

        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        improved_mask = fit_U < fitness

        # --- JADE 参数自适应更新 ---
        if np.any(improved_mask):
            success_f = f_param[improved_mask]
            success_cr = cr[improved_mask]

            # 更新 mu_cr (Arithmetic Mean)
            self.mu_cr = (1 - self.c) * self.mu_cr + self.c * np.mean(success_cr)

            # 更新 mu_f (Lehmer Mean: sum(F^2) / sum(F))
            mean_lehmer = np.sum(success_f ** 2) / (np.sum(success_f) + 1e-15)
            self.mu_f = (1 - self.c) * self.mu_f + self.c * mean_lehmer

            # 存储父代到存档
            for p_vec in X[improved_mask]:
                self.archive_X.append(p_vec.copy())
            while len(self.archive_X) > pop_size:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

            # 更新种群
            self.X[improved_mask] = U[improved_mask]
            self.fitness[improved_mask] = fit_U[improved_mask]
            self.cv[improved_mask] = cv_U[improved_mask]
            self.raw_f[improved_mask] = raw_U[improved_mask]  # 对齐 BaseSolver 字段

        # --- C. 更新全局最优与奖励计算 ---
        prev_best = self.gbest_val
        self._update_gbest()  # 调用基类方法统一更新 gbest_val 和 stagnation_counter
        current_best_fit = self.gbest_val

        if current_best_fit < prev_best:
            rel_imp = (prev_best - current_best_fit) / (abs(prev_best) + 1e-9)
            step_reward = 1.0 + min(10.0, 100.0 * rel_imp)
        else:
            step_reward = -0.1

        # --- D. 记录轨迹数据 ---
        self.trajectory.append({
            'state': current_state,
            'action': (mean_f, mean_cr),
            'reward': step_reward
        })

    def solve(self):
        """主循环：返回结果及专家经验轨迹"""
        self.initialize()
        self.last_best_fit = self.gbest_val

        while self.fes < self.max_nfes:
            self.evolve()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'trajectory': self.trajectory
        }
import numpy as np
from evorl.core.base_solver import BaseSolver


class SolverSHADE(BaseSolver):
    """
    SHADE: Success-History based Adaptive Differential Evolution
    [Enhanced] 增加轨迹记录功能，用于加速 RL 训练
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 memory_size=100):
        super().__init__(problem, pop_size, max_nfes, seed)

        self.memory_size = memory_size
        self.p_best_rate = 0.11
        self.arc_rate = 1.0

        # 记忆库初始化
        self.M_cr = np.full(memory_size, 0.5)
        self.M_f = np.full(memory_size, 0.5)
        self.k_mem = 0

        # 外部存档
        self.archive_X = []

        # [Expert Feature] 轨迹记录：用于存储 (s, a, r)
        self.trajectory = []
        self.last_best_fit = float('inf')
        # stagnation_counter 已在 BaseSolver 定义，此处直接使用

    def get_diversity(self):
        """计算归一化多样性 (逻辑与 SolverRLDE 对齐)"""
        std_per_dim = np.std(self.X, axis=0)
        mean_std = np.mean(std_per_dim)
        bounds = self.problem.ub - self.problem.lb
        mean_bound = np.mean(bounds)
        return mean_std / (mean_bound + 1e-9)

    def update_params(self, action):
        """
        [接口实现] 满足 BaseSolver 抽象要求。
        """
        pass

    def evolve(self):
        """执行一代进化并记录专家轨迹"""
        # --- A. 记录演化前的状态 ---
        progress = self.fes / self.max_nfes
        diversity = self.get_diversity()
        # 停滞比例
        max_gens = self.max_nfes / self.pop_size
        stag_ratio = min(1.0, self.stagnation_counter / max_gens) if max_gens > 0 else 0.0

        current_state = (progress, diversity, stag_ratio)

        # --- B. SHADE 标准演化逻辑 ---
        pop_size = self.pop_size
        dim = self.dim
        X = self.X
        fitness = self.fitness

        r_idx = self.rng.randint(0, self.memory_size, pop_size)
        m_cr = self.M_cr[r_idx]
        m_f = self.M_f[r_idx]

        # 1. 生成 CR [修正: 使用 self.rng.normal 替代 randn 以兼容 Generator]
        cr = np.clip(self.rng.normal(m_cr, 0.1, pop_size), 0.0, 1.0)

        # 2. 生成 F [修正: 标准 SHADE 要求 F<=0 时重采样，而非设为 0.5]
        f_param = m_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))

        # 向量化重采样逻辑：只要有 <= 0 的就一直循环重生成
        while np.any(f_param <= 0):
            mask = f_param <= 0
            n_regen = np.sum(mask)
            f_param[mask] = m_f[mask] + 0.1 * np.tan(np.pi * (self.rng.rand(n_regen) - 0.5))

        f_param = np.minimum(f_param, 1.0)  # F > 1 时截断为 1.0

        # 记录本次迭代的平均动作
        mean_f = np.mean(f_param)
        mean_cr = np.mean(cr)

        sorted_idx = np.argsort(fitness)
        num_pbest = max(1, int(pop_size * self.p_best_rate))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        r1 = self.rng.randint(0, pop_size, pop_size)

        # [修正: 存档处理的健壮性]
        if len(self.archive_X) > 0:
            Union_X = np.vstack([X, np.array(self.archive_X)])
        else:
            Union_X = X

        r2 = self.rng.randint(0, len(Union_X), pop_size)

        # Mutation: current-to-pbest/1
        # 注意：严格实现应保证 i != r1 != r2，此处保持简化实现
        V = X + f_param.reshape(-1, 1) * (X_pbest - X) + f_param.reshape(-1, 1) * (X[r1] - Union_X[r2])
        V = np.clip(V, self.problem.lb, self.problem.ub)

        mask_cross = self.rng.rand(pop_size, dim) < cr.reshape(-1, 1)
        j_rand = self.rng.randint(0, dim, pop_size)
        mask_cross[np.arange(pop_size), j_rand] = True
        U = np.where(mask_cross, V, X)

        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        # 贪婪选择逻辑
        improved_mask = fit_U < fitness

        # 收集成功参数更新记忆库
        if np.any(improved_mask):
            success_f = f_param[improved_mask]
            success_cr = cr[improved_mask]
            diff_fit = np.abs(fitness[improved_mask] - fit_U[improved_mask])

            # 存储父代到存档
            for p_vec in X[improved_mask]:
                self.archive_X.append(p_vec.copy())

            # 随机移除多余存档
            current_archive_cap = int(self.arc_rate * pop_size)
            while len(self.archive_X) > current_archive_cap:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

            # 更新种群
            self.X[improved_mask] = U[improved_mask]
            self.fitness[improved_mask] = fit_U[improved_mask]
            self.cv[improved_mask] = cv_U[improved_mask]
            self.raw_f[improved_mask] = raw_U[improved_mask]

            # 更新记忆库 (Weighted Lehmer Mean)
            # 增加分母极小值保护，防止全 0 除错
            total_diff = np.sum(diff_fit)
            if total_diff == 0: total_diff = 1e-15
            weights = diff_fit / total_diff

            # Update M_f
            denom_f = np.sum(weights * success_f)
            if denom_f == 0: denom_f = 1e-15
            self.M_f[self.k_mem] = np.sum(weights * (success_f ** 2)) / denom_f

            # Update M_cr (Weighted Arithmetic Mean)
            # SHADE 规定: 如果 max(success_cr) == 0 或 M_cr[k] == -1, 需特殊处理，此处保留简化逻辑
            self.M_cr[self.k_mem] = np.sum(weights * success_cr)

            self.k_mem = (self.k_mem + 1) % self.memory_size

        # --- C. 更新全局最优与奖励计算 ---
        prev_best = self.gbest_val
        self._update_gbest()
        current_best_fit = self.gbest_val

        if current_best_fit < prev_best:
            rel_imp = (prev_best - current_best_fit) / (abs(prev_best) + 1e-9)
            step_reward = 1.0 + min(10.0, 100.0 * rel_imp)
        else:
            step_reward = -0.1

        # --- D. 记录轨迹数据 ---
        self.trajectory.append({
            'state': current_state,
            'action': (mean_f, mean_cr),
            'reward': step_reward
        })

    def solve(self):
        """主循环：返回结果及专家经验轨迹"""
        self.initialize()
        self.last_best_fit = self.gbest_val

        while self.fes < self.max_nfes:
            self.evolve()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'trajectory': self.trajectory
        }
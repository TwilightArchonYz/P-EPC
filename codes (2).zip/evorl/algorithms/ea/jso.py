import numpy as np
from evorl.algorithms.ea.shade import SolverSHADE


class SolverjSO(SolverSHADE):
    """
    jSO: iL-SHADE (Improved L-SHADE)
    Reference: func_jSO.m
    """

    def __init__(self, problem, pop_size=None, max_nfes=100000, seed=None,
                 memory_size=5, min_pop_size=4, arc_rate=1.4, **kwargs):
        """
        初始化 jSO 求解器。

        参数:
            pop_size: 初始种群大小。如果为 None，按照 jSO 标准设为 18 * dim。
            memory_size: 记忆库大小，默认 5。
            min_pop_size: 最小种群大小，默认 4。
            arc_rate: 外部存档大小比例，默认 1.4。
        """
        # jSO 标准初始种群大小为 18 * D
        if pop_size is None:
            pop_size = 18 * problem.dim

        super().__init__(problem, pop_size, max_nfes, seed, memory_size=memory_size)

        self.min_pop_size = min_pop_size
        self.NP_init = pop_size
        self.arc_rate = arc_rate

        # jSO 记忆库初始化为: M_f = 0.5, M_cr = 0.8
        self.M_f = np.full(self.memory_size, 0.5)
        self.M_cr = np.full(self.memory_size, 0.8)

    def initialize(self):
        """初始化种群并同步状态"""
        super().initialize()

        # [FIX] 关键修复：
        # 在 Benchmark 手动循环模式下，solve() 不会被调用。
        # 因此必须在此处将 last_best_fit 初始化为当前种群的最优值。
        # 否则第一代 evolve 计算奖励时会出现 Inf / Inf = NaN 的错误。
        self.last_best_fit = self.gbest_val

    def _apply_bound_constraint(self, V, X):
        """
        应用边界约束：jSO 风格的反射 (Reflection) 策略。
        [Fixed] 修复了 2D 掩码索引 1D 边界数组导致的 'too many indices' 报错。
        """
        lb = self.problem.lb
        ub = self.problem.ub

        # --- Lower Bound Check ---
        mask_l = V < lb
        if np.any(mask_l):
            # Reflection: 2 * lb - V
            # [FIXED] 利用广播机制: (2*lb - V) 先计算完整矩阵，再取掩码
            V[mask_l] = (2.0 * lb - V)[mask_l]

            # Secondary Check: If reflection shoots over upper bound
            mask_l_u = (V > ub) & mask_l
            if np.any(mask_l_u):
                # [FIXED] 利用广播机制赋值 ub
                V[mask_l_u] = (np.ones_like(V) * ub)[mask_l_u]

        # --- Upper Bound Check ---
        mask_u = V > ub
        if np.any(mask_u):
            # Reflection: 2 * ub - V
            # [FIXED] 利用广播机制
            V[mask_u] = (2.0 * ub - V)[mask_u]

            # Secondary Check: If reflection shoots under lower bound
            mask_u_l = (V < lb) & mask_u
            if np.any(mask_u_l):
                # [FIXED] 利用广播机制赋值 lb
                V[mask_u_l] = (np.ones_like(V) * lb)[mask_u_l]

        return V

    def evolve(self):
        """执行一代 jSO 进化"""
        pop_size = self.pop_size
        dim = self.dim
        X = self.X
        fitness = self.fitness

        # --- A. 计算动态 p 值 (for p-best) ---
        p_max = 0.25
        p_min = 0.125
        progress = self.fes / self.max_nfes
        p_best_rate = (p_max - p_min) * progress + p_min

        # --- B. 参数生成 (jSO Special Logic) ---
        r_idx = self.rng.randint(0, self.memory_size, pop_size)
        m_cr = self.M_cr[r_idx]
        m_f = self.M_f[r_idx]

        # 特殊逻辑: memory_size - 1 强制为 0.9
        mask_special = (r_idx == self.memory_size - 1)
        if np.any(mask_special):
            m_cr[mask_special] = 0.9
            m_f[mask_special] = 0.9

        # 1. Generate CR
        # [FIXED] 使用 self.rng 确保一致性
        cr = self.rng.normal(m_cr, 0.1, pop_size)
        cr = np.where(m_cr == -1, 0.0, cr)
        cr = np.clip(cr, 0.0, 1.0)

        # CR Constraints based on FES
        if self.fes < 0.25 * self.max_nfes:
            cr = np.maximum(cr, 0.7)
        elif self.fes < 0.5 * self.max_nfes:
            cr = np.maximum(cr, 0.6)

        # 2. Generate F
        f_param = m_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))
        while np.any(f_param <= 0):
            mask_regen = f_param <= 0
            n_regen = np.sum(mask_regen)
            f_param[mask_regen] = m_f[mask_regen] + 0.1 * np.tan(np.pi * (self.rng.rand(n_regen) - 0.5))

        f_param = np.minimum(f_param, 1.0)

        # F Constraints & Modifiers
        if self.fes < 0.6 * self.max_nfes:
            f_param = np.where(f_param > 0.7, 0.7, f_param)

        if self.fes < 0.2 * self.max_nfes:
            f_param = 0.7 * f_param
        elif self.fes < 0.4 * self.max_nfes:
            f_param = 0.8 * f_param
        else:
            f_param = 1.2 * f_param

        # 记录平均动作
        mean_f = np.mean(f_param)
        mean_cr = np.mean(cr)

        # --- C. 变异与交叉 ---
        sorted_idx = np.argsort(fitness)
        num_pbest = max(1, int(pop_size * p_best_rate))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        r1 = self.rng.randint(0, pop_size, pop_size)
        Union_X = np.vstack([X, np.array(self.archive_X)]) if self.archive_X else X
        r2 = self.rng.randint(0, len(Union_X), pop_size)

        V = X + f_param.reshape(-1, 1) * (X_pbest - X) + f_param.reshape(-1, 1) * (X[r1] - Union_X[r2])

        # 边界处理 (Broadcasting Fixed)
        V = self._apply_bound_constraint(V, X)

        mask_cross = self.rng.rand(pop_size, dim) < cr.reshape(-1, 1)
        j_rand = self.rng.randint(0, dim, pop_size)
        mask_cross[np.arange(pop_size), j_rand] = True
        U = np.where(mask_cross, V, X)

        # --- D. 评估 ---
        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        # --- E. 选择与更新 ---
        improved_mask = fit_U < fitness

        if np.any(improved_mask):
            success_f = f_param[improved_mask]
            success_cr = cr[improved_mask]
            diff_fit = np.abs(fitness[improved_mask] - fit_U[improved_mask])

            # Update Archive
            for p_vec in X[improved_mask]:
                self.archive_X.append(p_vec.copy())

            # Archive Maintenance
            current_archive_cap = int(self.arc_rate * self.pop_size)
            while len(self.archive_X) > current_archive_cap:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

            # Update Population
            self.X[improved_mask] = U[improved_mask]
            self.fitness[improved_mask] = fit_U[improved_mask]
            self.cv[improved_mask] = cv_U[improved_mask]
            self.raw_f[improved_mask] = raw_U[improved_mask]

            # Update Memory
            weights = diff_fit / (np.sum(diff_fit) + 1e-15)

            # 1. Lehmer Mean for F
            mean_lehmer_f = np.sum(weights * (success_f ** 2)) / (np.sum(weights * success_f) + 1e-15)
            self.M_f[self.k_mem] = (mean_lehmer_f + self.M_f[self.k_mem]) / 2.0

            # 2. Lehmer Mean for CR
            if np.max(success_cr) == 0 or self.M_cr[self.k_mem] == -1:
                self.M_cr[self.k_mem] = 0.0
            else:
                mean_lehmer_cr = np.sum(weights * (success_cr ** 2)) / (np.sum(weights * success_cr) + 1e-15)
                self.M_cr[self.k_mem] = (mean_lehmer_cr + self.M_cr[self.k_mem]) / 2.0

            self.k_mem = (self.k_mem + 1) % self.memory_size

        # --- F. LPSR ---
        new_pop_size = int(round(((self.min_pop_size - self.NP_init) / self.max_nfes) * self.fes + self.NP_init))
        new_pop_size = max(self.min_pop_size, new_pop_size)

        if new_pop_size < self.pop_size:
            sorted_idx = np.argsort(self.fitness)
            keep_idx = sorted_idx[:new_pop_size]

            self.X = self.X[keep_idx]
            self.fitness = self.fitness[keep_idx]
            self.cv = self.cv[keep_idx]
            if hasattr(self, 'raw_f'):
                self.raw_f = self.raw_f[keep_idx]

            self.pop_size = new_pop_size

            current_archive_cap = int(self.arc_rate * self.pop_size)
            if len(self.archive_X) > current_archive_cap:
                n_remove = len(self.archive_X) - current_archive_cap
                for _ in range(n_remove):
                    self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

        # --- G. 记录轨迹与更新 Gbest ---
        self._update_gbest()

        progress_val = self.fes / self.max_nfes
        diversity = self.get_diversity()
        max_gens = self.max_nfes / self.NP_init
        stag_ratio = min(1.0, self.stagnation_counter / (max_gens + 1e-9))

        if self.gbest_val < self.last_best_fit:
            # [FIX] 双重保险：检查 last_best_fit 是否为 Inf
            if np.isinf(self.last_best_fit):
                rel_imp = 1.0  # 视为有效改进
            else:
                rel_imp = (self.last_best_fit - self.gbest_val) / (abs(self.last_best_fit) + 1e-9)

            step_reward = 1.0 + min(10.0, 100.0 * rel_imp)
        else:
            step_reward = -0.1

        # 更新 last_best_fit 供下一代使用
        self.last_best_fit = self.gbest_val

        self.trajectory.append({
            'state': (progress_val, diversity, stag_ratio),
            'action': (mean_f, mean_cr),
            'reward': step_reward
        })

    def update_params(self, action):
        """[BaseSolver 接口] jSO 无需外部参数控制"""
        pass

    def solve(self):
        """主循环"""
        self.initialize()
        self.NP_init = self.pop_size
        self.last_best_fit = self.gbest_val

        while self.fes < self.max_nfes:
            self.evolve()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'trajectory': self.trajectory
        }
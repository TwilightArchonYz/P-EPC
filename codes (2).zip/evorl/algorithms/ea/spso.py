import numpy as np
from evorl.core.base_solver import BaseSolver


class SolverSPSO(BaseSolver):
    """
    S-PSO: SHADE-inspired Particle Swarm Optimization
    特点:
    1. 引入 SHADE 的成功历史记忆机制 (Success History Memory)
    2. 自适应调整 PSO 的三个关键参数: w, c1, c2
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 memory_size=5):
        super().__init__(problem, pop_size, max_nfes, seed)

        self.memory_size = memory_size

        # 初始化记忆库 (w, c1, c2)
        # 经验值: w~0.7, c1~1.5, c2~1.5
        self.M_w = np.full(memory_size, 0.7)
        self.M_c1 = np.full(memory_size, 1.5)
        self.M_c2 = np.full(memory_size, 1.5)
        self.k_mem = 0

        # 速度与 Pbest
        self.V = None
        self.pbest_X = None
        self.pbest_fit = None

    def initialize(self):
        super().initialize()
        self.V = np.zeros((self.pop_size, self.dim))
        self.pbest_X = self.X.copy()
        self.pbest_fit = self.fitness.copy()

        # 速度限制
        self.v_max = 0.2 * (self.ub - self.lb)
        self.v_min = -self.v_max

    def evolve(self):
        """执行一代进化"""
        pop_size = self.pop_size

        # -------------------------
        # 1. 参数自适应生成
        # -------------------------
        r_idx = self.rng.randint(0, self.memory_size, pop_size)
        mu_w = self.M_w[r_idx]
        mu_c1 = self.M_c1[r_idx]
        mu_c2 = self.M_c2[r_idx]

        # 生成 w (Cauchy)
        w = mu_w + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))
        w = np.clip(w, 0.1, 0.95)

        # 生成 c1, c2 (Normal)
        c1 = mu_c1 + 0.1 * self.rng.randn(pop_size)
        c1 = np.clip(c1, 0.1, 3.5)

        c2 = mu_c2 + 0.1 * self.rng.randn(pop_size)
        c2 = np.clip(c2, 0.1, 3.5)

        # -------------------------
        # 2. 粒子更新
        # -------------------------
        r1 = self.rng.rand(pop_size, self.dim)
        r2 = self.rng.rand(pop_size, self.dim)

        W_mat = w.reshape(-1, 1)
        C1_mat = c1.reshape(-1, 1)
        C2_mat = c2.reshape(-1, 1)

        # 速度更新
        self.V = (W_mat * self.V +
                  C1_mat * r1 * (self.pbest_X - self.X) +
                  C2_mat * r2 * (self.gbest_X - self.X))

        self.V = np.clip(self.V, self.v_min, self.v_max)

        # 位置更新
        self.X = self.X + self.V
        self.X = np.clip(self.X, self.lb, self.ub)

        # -------------------------
        # 3. 评估
        # -------------------------
        fit_new, raw_new, cv_new = self.problem.evaluate(self.X)
        self.fes += pop_size

        # 改进判定
        mask_improve = fit_new < self.pbest_fit

        # -------------------------
        # 4. 更新记忆库 (必须在更新 Pbest 之前计算 Diff)
        # -------------------------
        num_success = np.sum(mask_improve)
        if num_success > 0:
            success_w = w[mask_improve]
            success_c1 = c1[mask_improve]
            success_c2 = c2[mask_improve]

            # 计算提升量 (Diff)
            diff_fit = np.abs(self.pbest_fit[mask_improve] - fit_new[mask_improve])

            # Weighted Lehmer Mean
            total_diff = np.sum(diff_fit)
            if total_diff == 0: total_diff = 1e-15
            weights = diff_fit / total_diff

            def lehmer_mean(S, w_vec):
                denom = np.sum(w_vec * S)
                if np.abs(denom) < 1e-15: return np.mean(S)
                return np.sum(w_vec * (S ** 2)) / denom

            mean_w = lehmer_mean(success_w, weights)
            mean_c1 = lehmer_mean(success_c1, weights)
            mean_c2 = lehmer_mean(success_c2, weights)

            # 渐进更新
            self.M_w[self.k_mem] = 0.5 * self.M_w[self.k_mem] + 0.5 * mean_w
            self.M_c1[self.k_mem] = 0.5 * self.M_c1[self.k_mem] + 0.5 * mean_c1
            self.M_c2[self.k_mem] = 0.5 * self.M_c2[self.k_mem] + 0.5 * mean_c2

            self.k_mem = (self.k_mem + 1) % self.memory_size

        # -------------------------
        # 5. 更新状态 (CRITICAL FIX)
        # -------------------------
        # 更新 Pbest
        self.pbest_X[mask_improve] = self.X[mask_improve]
        self.pbest_fit[mask_improve] = fit_new[mask_improve]

        # 更新当前代状态 (这是之前漏掉的!)
        self.fitness = fit_new
        self.raw_f = raw_new
        self.cv = cv_new

        # 更新 Gbest (依赖 self.fitness)
        self._update_gbest()

    def update_params(self, action):
        pass
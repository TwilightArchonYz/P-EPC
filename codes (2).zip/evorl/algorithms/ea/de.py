import numpy as np
from evorl.core.base_solver import BaseSolver


class SolverDE(BaseSolver):
    """
    标准差分进化算法 (Standard DE)
    策略: DE/rand/1/bin
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None,
                 F=0.5, CR=0.9):
        # 接口对齐: 透传 seed 支持统一 RNG
        super().__init__(problem, pop_size, max_nfes, seed)

        # DE 参数
        self.F = F
        self.CR = CR

    def evolve(self):
        """执行一代进化"""
        X = self.X
        pop_size = self.pop_size
        dim = self.dim

        # 1. 变异 (Mutation): DE/rand/1
        # V = X_r1 + F * (X_r2 - X_r3)
        # 生成随机索引 r1, r2, r3 != i

        # 使用统一接口管理的 self.rng
        r1 = self.rng.randint(0, pop_size, pop_size)
        r2 = self.rng.randint(0, pop_size, pop_size)
        r3 = self.rng.randint(0, pop_size, pop_size)

        # 简单防重
        mask_dup = (r1 == r2) | (r1 == r3) | (r2 == r3)
        if np.any(mask_dup):
            r1[mask_dup] = self.rng.randint(0, pop_size, np.sum(mask_dup))
            r2[mask_dup] = self.rng.randint(0, pop_size, np.sum(mask_dup))
            r3[mask_dup] = self.rng.randint(0, pop_size, np.sum(mask_dup))

        V = X[r1] + self.F * (X[r2] - X[r3])

        # 变异向量边界处理 (截断)
        V = np.clip(V, self.lb, self.ub)

        # 2. 交叉 (Crossover): Binomial
        # Mask: rand < CR or j == j_rand
        mask_cross = self.rng.rand(pop_size, dim) < self.CR
        j_rand = self.rng.randint(0, dim, pop_size)
        # 强制至少这一维交叉
        mask_cross[np.arange(pop_size), j_rand] = True

        U = np.where(mask_cross, V, X)

        # 3. 选择 (Selection)
        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        # 贪婪选择: 如果 U 更好，则替换 X
        mask_better = fit_U < self.fitness

        self.X[mask_better] = U[mask_better]
        self.fitness[mask_better] = fit_U[mask_better]
        self.raw_f[mask_better] = raw_U[mask_better]
        self.cv[mask_better] = cv_U[mask_better]

        # 4. 更新 Gbest
        self._update_gbest()

    def update_params(self, action):
        """
        [DRL 接口] 更新参数
        action: expected [F, CR]
        """
        if action is not None and len(action) >= 2:
            self.F = np.clip(action[0], 0.1, 2.0)
            self.CR = np.clip(action[1], 0.0, 1.0)
import numpy as np
import torch
import pickle
import os
import random

# ==============================================================================
# 默认配置常量
# ==============================================================================
DEFAULT_STATE_BINS = [5, 4, 4, 4, 4, 4, 4]
DEFAULT_DIM_NORM_FACTOR = 100.0
DEFAULT_DIFFUSION_DECAY = 0.5  # 初始扩散衰减率


class QLearningAgent:
    """
    通用 Q-Learning 智能体 (Dual-Engine Hybrid Version)
    --------------------------------------------------
    架构设计：
    1. 双引擎架构：
       - 推断引擎 (Inference): 纯 NumPy 实现，针对单样本低延迟优化 (消除 Python 循环)。
       - 训练引擎 (Training): PyTorch CPU 实现，针对大批量高吞吐优化 (多线程并行累加)。
    2. 零拷贝内存：
       - 底层数据存储在 NumPy (共享) 内存中。
       - PyTorch 通过 torch.from_numpy 创建视图，修改 Tensor 即修改 NumPy 数组。
    3. 深度向量化：
       - 无论是单步推断还是批量训练，索引计算均完全向量化。
    """

    def __init__(self, state_dim, action_dim,
                 lr=0.1,
                 gamma=0.99,
                 eps_c=1.0,
                 eps_min=0.05,
                 buffer_size=100000,
                 batch_size=128,
                 shared_memory=None,
                 shared_visits=None,
                 target_dims=None,
                 state_spec=None,
                 context_spec=None,
                 inference_only=False,  # [New] 新增参数：推断模式标志
                 # 保持向后兼容的参数
                 state_bins=None,
                 dim_norm_factor=None,
                 algo_params=None,
                 **kwargs):

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.lr = lr
        self.gamma = gamma
        self.eps_c = eps_c
        self.eps_min = eps_min
        self.inference_only = inference_only

        # 经验回放配置
        self.batch_size = batch_size
        self.buffer_capacity = buffer_size

        # [Buffer] 始终保持为 NumPy (与环境交互最快)
        self.mem_cntr = 0
        self.train_step_cnt = 0  # [Diag] 内部训练步数计数器

        # [Modified] 如果是推断模式，跳过大内存分配
        if not self.inference_only:
            self.state_memory = np.zeros((self.buffer_capacity, self.state_dim), dtype=np.float32)
            self.next_state_memory = np.zeros((self.buffer_capacity, self.state_dim), dtype=np.float32)
            self.action_memory = np.zeros((self.buffer_capacity,), dtype=np.int32)
            self.reward_memory = np.zeros((self.buffer_capacity,), dtype=np.float32)
        else:
            self.state_memory = None
            self.next_state_memory = None
            self.action_memory = None
            self.reward_memory = None

        # 1. 保存配置规格说明书
        self.state_spec = state_spec
        self.context_spec = context_spec
        self.target_dims = target_dims

        # 检查是否启用 Spec 逻辑
        self.use_spec_logic = (self.state_spec is not None)

        # [Debug Info] 打印初始化模式
        if not self.use_spec_logic:
            self.state_bins = state_bins if state_bins is not None else DEFAULT_STATE_BINS
            self.dim_norm_factor = dim_norm_factor if dim_norm_factor is not None else DEFAULT_DIM_NORM_FACTOR
        else:
            self.state_bins = [spec['bins'] for spec in self.state_spec]
            if self.context_spec:
                self.dim_norm_factor = self.context_spec.get('norm_factor', 100.0)
            else:
                self.dim_norm_factor = dim_norm_factor if dim_norm_factor is not None else DEFAULT_DIM_NORM_FACTOR

        # 2. 构建参数网格 (动作解码用)
        self.param_grids = []
        self.param_names = []  # [New] 保存参数名称以进行状态匹配

        # [Helper] 计算默认均值参数 (Fallback)
        self.default_mean_params = []  # [Modified] 改为 self 属性，供 BC 使用

        if algo_params is not None:
            for param in algo_params:
                if 'options' in param:
                    grid = param['options']
                    self.param_grids.append(grid)
                    self.param_names.append(param.get('name', 'Unknown'))

                    # 计算该参数的几何中心 (均值)
                    mid_idx = len(grid) // 2
                    self.default_mean_params.append(grid[mid_idx])

        if not self.param_grids:
            print("[Agent] Warning: 未提供 'algo_params'。动作空间可能未定义。")
            self.param_grids = [[0.5]]
            self.param_names = ['Unknown']
            self.default_mean_params = [0.5]

        # 3. 预计算动作步长
        self.action_strides = []
        curr_act_stride = 1
        for grid in reversed(self.param_grids[1:]):
            curr_act_stride *= len(grid)
            self.action_strides.insert(0, curr_act_stride)
        self.action_strides.append(1)

        # 4. 预计算状态步长
        self.state_strides = []
        curr_state_stride = 1
        for b in reversed(self.state_bins[1:]):
            curr_state_stride *= b
            self.state_strides.insert(0, curr_state_stride)
        self.state_strides.append(1)

        # 计算总状态数
        self.total_states_per_dim = int(np.prod(self.state_bins))
        self.num_dims = len(target_dims) if target_dims else 1
        self.total_states_global = self.total_states_per_dim * self.num_dims

        # [Pre-computation] 预编译 Spec 为 NumPy (推断用) 和 Tensor (训练用)
        if self.use_spec_logic:
            self._compile_spec_dual_engine()

        # 预编译 Target Dims
        if self.target_dims:
            self.target_dims_arr = np.array(self.target_dims, dtype=np.int32)
            self.target_dims_tensor = torch.tensor(self.target_dims, dtype=torch.int32)
        else:
            self.target_dims_arr = None
            self.target_dims_tensor = None

        # 5. 初始化或挂载 Q-Table (Dual View)
        expected_q_size = self.total_states_global * self.action_dim

        # A. NumPy View (Primary)
        if shared_memory is not None:
            self.q_table = np.frombuffer(shared_memory, dtype=np.float32, count=expected_q_size)
            self.q_table = self.q_table.reshape((self.total_states_global, self.action_dim))
        else:
            # [Standard Init] 默认全零
            self.q_table = np.zeros((self.total_states_global, self.action_dim), dtype=np.float32)

            # [Init Strategy] 移除 "恒等初始化" 逻辑，迁移至 learn_behavior_cloning
            # 保持 Q 表纯净，由外部调用显式初始化

        # B. PyTorch View (Zero-Copy Shadow)
        # 仅当内存可写时（主进程）才创建 Tensor 视图。
        if self.q_table.flags.writeable:
            self.q_table_tensor = torch.from_numpy(self.q_table)

            # [Modified] 仅非推理模式且内存可写时，才创建 Target Network
            # 解决多进程评估时的内存溢出问题 (OOM Fix)
            if not self.inference_only:
                # [FIX] 初始化 Target Network (独立内存，不共享)
                # 仅主进程需要维护 Target Network，Worker 进程只需要读取 Main Q
                # 使用 np.array(copy=True) 确保它是独立的物理内存
                self.q_table_target = np.array(self.q_table, copy=True)
                self.q_table_target_tensor = torch.from_numpy(self.q_table_target)
            else:
                self.q_table_target = None
                self.q_table_target_tensor = None
        else:
            self.q_table_tensor = None
            # Worker 进程不需要 Target Network
            self.q_table_target = None
            self.q_table_target_tensor = None

        # 6. 初始化或挂载 Visits Table (Dual View)
        expected_v_size = self.total_states_global
        if shared_visits is not None:
            self.visits = np.frombuffer(shared_visits, dtype=np.float32, count=expected_v_size)
        else:
            self.visits = np.zeros((self.total_states_global,), dtype=np.float32)

        # 同理处理 visits_tensor
        if self.visits.flags.writeable:
            self.visits_tensor = torch.from_numpy(self.visits)
        else:
            self.visits_tensor = None

    def __getstate__(self):
        state = self.__dict__.copy()

        # 移除大内存对象
        keys_to_remove = [
            'q_table', 'q_table_tensor',
            'q_table_target', 'q_table_target_tensor',
            'visits', 'visits_tensor',
            'state_memory', 'next_state_memory',
            'action_memory', 'reward_memory'
        ]

        for key in keys_to_remove:
            if key in state:
                del state[key]

        return state

    def __setstate__(self, state):
        self.__dict__.update(state)

        # 将被移除的属性设为 None，避免 AttributeError
        self.q_table = None
        self.q_table_tensor = None
        self.q_table_target = None
        self.q_table_target_tensor = None
        self.visits = None
        self.visits_tensor = None
        self.state_memory = None
        self.next_state_memory = None
        self.action_memory = None
        self.reward_memory = None

    def _compile_spec_dual_engine(self):
        idxs = []
        mins = []
        maxs = []
        bins = []

        for spec in self.state_spec:
            idxs.append(spec['idx'])
            mins.append(spec.get('min', 0.0))
            maxs.append(spec.get('max', 1.0))
            bins.append(spec['bins'])

        # 1. NumPy Arrays (For Inference Engine)
        self.spec_idxs_arr = np.array(idxs, dtype=np.int32)
        self.spec_mins_arr = np.array(mins, dtype=np.float32)
        self.spec_maxs_arr = np.array(maxs, dtype=np.float32)
        self.spec_bins_arr = np.array(bins, dtype=np.float32)
        self.spec_strides_arr = np.array(self.state_strides, dtype=np.int32)

        # 2. PyTorch Tensors (For Training Engine)
        # 注意：strides 需要 float 类型以匹配 matmul 输入，或者在计算时转换
        self.spec_idxs_t = torch.tensor(idxs, dtype=torch.long)
        self.spec_mins_t = torch.tensor(mins, dtype=torch.float32)
        self.spec_maxs_t = torch.tensor(maxs, dtype=torch.float32)
        self.spec_bins_t = torch.tensor(bins, dtype=torch.float32)
        self.spec_strides_t = torch.tensor(self.state_strides, dtype=torch.float32)

    def get_state_idx(self, state):
        """
        [Inference Engine - Pure NumPy]
        单样本状态离散化。极致优化延迟。
        移除所有 Python 循环，使用 NumPy 向量运算。
        """
        # 1. 预处理输入
        if not isinstance(state, np.ndarray):
            state_arr = np.array(state, dtype=np.float32)
        else:
            state_arr = state

        # [DEBUG LOG] 检查状态是否包含 NaN
        if np.isnan(state_arr).any():
            print(f"[FATAL ERROR] State contains NaN! State: {state_arr}")
            return 0

        # 兼容性回退
        if not self.use_spec_logic:
            # Fallback Legacy Logic (Manual)
            return self._get_state_idx_legacy(state_arr)

        # --- Vectorized Calculation ---

        # A. Local Index
        # 提取特征: (NumFeatures,)
        feats = state_arr[self.spec_idxs_arr]

        # 归一化: (val - min) / (max - min)
        spans = self.spec_maxs_arr - self.spec_mins_arr
        spans[spans < 1e-9] = 1e-9
        norm_vals = (feats - self.spec_mins_arr) / spans

        # 分箱: floor(norm * bins)
        idx_vals = np.floor(norm_vals * self.spec_bins_arr).astype(np.int32)

        # 截断: clip(0, bins-1)
        # 注意: 这里的 bins-1 需要是 int
        idx_vals = np.clip(idx_vals, 0, self.spec_bins_arr.astype(np.int32) - 1)

        # 局部索引: dot product
        local_idx = np.dot(idx_vals, self.spec_strides_arr)

        # B. Context Index (Updated: Nearest Neighbor)
        dim_idx = 0
        if self.target_dims_arr is not None and self.context_spec:
            c_idx = self.context_spec['idx']
            if c_idx < len(state_arr):
                current_dim_val = state_arr[c_idx]
                current_dim = int(round(current_dim_val * self.dim_norm_factor))

                # [Modified] 最近邻匹配 (Nearest Neighbor)
                # 解决维度值微小偏差导致 np.where 匹配失败的问题 (如 48 vs 50)
                diffs = np.abs(self.target_dims_arr - current_dim)
                dim_idx = np.argmin(diffs)

        # C. Global Index
        final_idx = dim_idx * self.total_states_per_dim + local_idx
        return min(final_idx, self.total_states_global - 1)

    def _get_state_idx_legacy(self, state):
        """[Legacy] 旧版硬编码逻辑，仅作备份"""
        current_dim_val = 0
        if len(state) > 5:
            current_dim_val = state[5]
        elif len(state) > 3:
            current_dim_val = state[3]
        current_dim = int(round(current_dim_val * self.dim_norm_factor))

        meta_feats = []
        if len(state) > 4: meta_feats = [state[0], state[1], state[2], state[3], state[4]]
        param_feats = []
        if len(state) > 6: param_feats = list(state[6:])
        feats_to_bin = meta_feats + param_feats

        local_idx = 0
        for i, val in enumerate(feats_to_bin):
            if i >= len(self.state_bins): break
            bins = self.state_bins[i]
            stride = self.state_strides[i]
            if i == 4: val = (val + 1.0) / 2.0
            idx_val = int(val * bins)
            idx_val = min(idx_val, bins - 1)
            idx_val = max(idx_val, 0)
            local_idx += idx_val * stride

        dim_idx = 0
        if self.target_dims:
            try:
                dim_idx = self.target_dims.index(current_dim)
            except ValueError:
                dim_idx = 0

        final_idx = dim_idx * self.total_states_per_dim + local_idx
        return min(final_idx, self.total_states_global - 1)

    def _get_state_idx_batch_tensor(self, states_batch_tensor):
        """
        [Training Engine - PyTorch]
        批量状态离散化。
        """
        if not self.use_spec_logic:
            np_states = states_batch_tensor.numpy()
            return torch.tensor([self._get_state_idx_legacy(s) for s in np_states], dtype=torch.long)

        # 1. Local Index
        feats = states_batch_tensor[:, self.spec_idxs_t]

        spans = self.spec_maxs_t - self.spec_mins_t
        spans[spans < 1e-9] = 1e-9
        norm_vals = (feats - self.spec_mins_t) / spans

        idx_vals = torch.floor(norm_vals * self.spec_bins_t)
        idx_vals = torch.clamp(idx_vals, min=torch.tensor(0.0), max=self.spec_bins_t - 1)

        local_idxs = torch.matmul(idx_vals, self.spec_strides_t).long()

        # 2. Context Index (Updated: Nearest Neighbor)
        dim_idxs = torch.zeros(len(states_batch_tensor), dtype=torch.long)
        if self.target_dims_tensor is not None and self.context_spec:
            c_idx = self.context_spec['idx']
            if c_idx < states_batch_tensor.shape[1]:
                ctx_vals = states_batch_tensor[:, c_idx]

                # [Modified] 向量化最近邻匹配
                # current_dims: (Batch,) - 这里保留 float 用于更精确的距离计算
                current_dims = ctx_vals * self.dim_norm_factor

                # 计算与所有 target_dims 的距离矩阵: (Batch, NumTargets)
                # 使用 float 进行减法
                dists = torch.abs(current_dims.unsqueeze(1) - self.target_dims_tensor.float().unsqueeze(0))

                # 取最小距离的索引
                dim_idxs = torch.argmin(dists, dim=1)

        # 3. Global Index
        final_idxs = dim_idxs * self.total_states_per_dim + local_idxs
        final_idxs = torch.clamp(final_idxs, max=self.total_states_global - 1)
        return final_idxs

    def get_action_params(self, action_idx):
        params = []
        rem = int(action_idx)
        for i, stride in enumerate(self.action_strides):
            grid = self.param_grids[i]
            idx = rem // stride
            idx = min(idx, len(grid) - 1)
            params.append(grid[idx])
            rem = rem % stride
        return tuple(params)

    def get_closest_action(self, action_params):
        flat_idx = 0
        for i, val in enumerate(action_params):
            if i >= len(self.param_grids): break
            grid = self.param_grids[i]
            stride = self.action_strides[i]
            best_val = min(grid, key=lambda x: abs(x - val))
            idx = grid.index(best_val)
            flat_idx += idx * stride
        return flat_idx

    def store_transition(self, s, a, r, s_next):
        """存储经验到 NumPy Buffer (极速)"""
        index = self.mem_cntr % self.buffer_capacity
        self.state_memory[index] = s
        self.action_memory[index] = a
        self.reward_memory[index] = r
        self.next_state_memory[index] = s_next
        self.mem_cntr += 1

    def choose_action(self, state, mode='train', beta=1.0):
        """
        [Inference Engine]
        完全基于 NumPy 运行，无 PyTorch overhead。
        """
        # 1. 极速索引计算
        if hasattr(state, '__len__') and not isinstance(state, (str, bytes)):
            state_idx = self.get_state_idx(state)
        else:
            state_idx = int(state)

        # 2. 查表 (NumPy View)
        if mode != 'train':
            return np.argmax(self.q_table[state_idx])

        # Train mode
        n_visits = self.visits[state_idx]

        numerator = beta if beta is not None else self.eps_c
        term = numerator / np.sqrt(n_visits + 1e-6)
        epsilon = max(self.eps_min, min(1.0, term))

        if np.random.rand() < epsilon:
            return np.random.randint(self.action_dim)
        else:
            return np.argmax(self.q_table[state_idx])

    def learn(self, current_step=None, max_steps=None):
        """
        [Training Engine]
        支持动态邻域扩散 (Dynamic Neighbor Diffusion) 的 Q-Learning 更新。
        [Diag] 包含异常触发诊断系统
        """
        current_size = min(self.mem_cntr, self.buffer_capacity)
        if current_size < self.batch_size:
            return None

        self.train_step_cnt += 1  # 内部计数

        # 1. 计算进度与扩散参数
        progress = 0.0
        if current_step is not None and max_steps is not None and max_steps > 0:
            progress = min(1.0, current_step / max_steps)

        if progress < 0.2:
            diffusion_layers = 2
        elif progress < 0.5:
            diffusion_layers = 1
        else:
            diffusion_layers = 0

        diffusion_rate = DEFAULT_DIFFUSION_DECAY * (1.0 - progress)

        # 2. 采样
        batch_indices = np.random.randint(0, current_size, size=self.batch_size)
        states = torch.as_tensor(self.state_memory[batch_indices])
        actions = torch.as_tensor(self.action_memory[batch_indices], dtype=torch.long)
        rewards = torch.as_tensor(self.reward_memory[batch_indices])
        next_states = torch.as_tensor(self.next_state_memory[batch_indices])

        # 3. 索引计算
        state_indices = self._get_state_idx_batch_tensor(states)
        next_state_indices = self._get_state_idx_batch_tensor(next_states)

        # 4. Bellman Error
        # Visits update
        self.visits_tensor.index_add_(0, state_indices, torch.ones(len(state_indices), dtype=torch.float32))

        q_predict = self.q_table_tensor[state_indices, actions]

        # [FIX] 使用 Target Network 计算目标 Q 值
        # 如果 Target Network 未初始化（例如 Worker 进程），回退到 Main Q (Double Q-Learning style)
        if self.q_table_target_tensor is not None:
            q_next_max = torch.max(self.q_table_target_tensor[next_state_indices], dim=1)[0]
        else:
            q_next_max = torch.max(self.q_table_tensor[next_state_indices], dim=1)[0]

        q_target = rewards + self.gamma * q_next_max
        td_error = q_target - q_predict

        # [FIX] TD Error Clipping (防御性截断)
        td_error = torch.clamp(td_error, min=-10.0, max=10.0)

        # === [DIAGNOSTIC SYSTEM START] ===
        # 基于规则的异常检测与分量拆解日志
        with torch.no_grad():
            td_abs_max = td_error.abs().max().item()
            q_val_max = self.q_table_tensor.max().item()

            # 触发条件: TD Error 剧烈波动 或 Q值爆炸
            is_anomaly = (td_abs_max > 10.0) or (q_val_max > 100.0)

            # 或者是定期的心跳日志 (例如每 2000 步)
            is_heartbeat = (self.train_step_cnt % 2000 == 0)

            if is_anomaly or is_heartbeat:
                # 深入分析: 状态碰撞
                unique_states, counts = torch.unique(state_indices, return_counts=True)
                max_collision = counts.max().item()
                avg_collision = counts.float().mean().item()

                # 深入分析: 有效更新量 (Effective Update)
                # 估算: 碰撞次数 * LR * TD_Error
                worst_effective_update = max_collision * self.lr * td_abs_max

                log_tag = "[Diag Alert]" if is_anomaly else "[Diag Heartbeat]"

                print(f"{log_tag} Step {self.train_step_cnt} | TD_Error Max: {td_abs_max:.2f}")
                print(f"   > Components:")
                print(f"     - Reward Range: [{rewards.min().item():.4f}, {rewards.max().item():.4f}]")
                print(
                    f"     - Q_Predict:    mean={q_predict.mean().item():.2f}, max={q_predict.max().item():.2f}, min={q_predict.min().item():.2f}")
                print(f"     - Q_Target:     mean={q_target.mean().item():.2f}, max={q_target.max().item():.2f}")
                print(f"     - Next_Q_Max:   mean={q_next_max.mean().item():.2f}, max={q_next_max.max().item():.2f}")
                print(f"   > Critical Impact:")
                print(f"     - Max Collision: {max_collision} (Avg: {avg_collision:.1f})")
                print(f"     - Max Effective Update: ~{worst_effective_update:.4f}")
                print("-" * 60)
        # === [DIAGNOSTIC SYSTEM END] ===

        # 5. 安全检查
        if torch.isnan(td_error).any() or torch.isinf(td_error).any():
            print(f"[FATAL ERROR] NaN/Inf in TD Error at step {self.train_step_cnt}")
            return 0.0

        # 6. Apply Update
        self.q_table_tensor.index_put_((state_indices, actions), self.lr * td_error, accumulate=True)

        # 7. Neighbor Diffusion
        if self.use_spec_logic and diffusion_layers > 0 and diffusion_rate > 1e-4:
            feats = states[:, self.spec_idxs_t]
            spans = self.spec_maxs_t - self.spec_mins_t
            spans[spans < 1e-9] = 1e-9
            norm_vals = (feats - self.spec_mins_t) / spans
            idx_vals = torch.floor(norm_vals * self.spec_bins_t)
            local_coords = torch.clamp(idx_vals, min=torch.tensor(0.0), max=self.spec_bins_t - 1).int()

            for d in range(local_coords.shape[1]):
                stride = int(self.spec_strides_t[d].item())
                dim_bins = int(self.spec_bins_t[d].item())

                for layer in range(1, diffusion_layers + 1):
                    effective_rate = diffusion_rate * (0.5 ** (layer - 1))
                    diffused_update = self.lr * effective_rate * td_error

                    mask_left = (local_coords[:, d] - layer) >= 0
                    if mask_left.any():
                        valid_indices = torch.nonzero(mask_left).squeeze()
                        target_indices = state_indices[valid_indices] - (stride * layer)
                        target_actions = actions[valid_indices]
                        target_updates = diffused_update[valid_indices]
                        self.q_table_tensor.index_put_((target_indices, target_actions), target_updates,
                                                       accumulate=True)

                    mask_right = (local_coords[:, d] + layer) < dim_bins
                    if mask_right.any():
                        valid_indices = torch.nonzero(mask_right).squeeze()
                        target_indices = state_indices[valid_indices] + (stride * layer)
                        target_actions = actions[valid_indices]
                        target_updates = diffused_update[valid_indices]
                        self.q_table_tensor.index_put_((target_indices, target_actions), target_updates,
                                                       accumulate=True)

        return torch.mean(torch.abs(td_error)).item()

    def learn_behavior_cloning(self, batch_size=None):
        """
        [Training Engine]
        离线训练 - 行为克隆 (Identity Mapping Implementation).

        Q-Learning 特有的"恒等初始化"逻辑。
        通过解析状态空间的物理含义，直接将 Q 表初始化为"输入均值=输出动作"的恒等映射。
        这替代了传统的基于梯度的 BC 训练，因为表格型方法可以直接修改内存。

        Args:
            batch_size: 兼容性参数，本实现中不使用。
        """
        if not self.use_spec_logic:
            print("[Agent] Warning: Identity Mapping BC requires state_spec. Skipping.")
            return None

        print(f"[Agent] Starting Analytical Behavior Cloning (Identity Mapping)...")

        # 1. 建立参数到状态特征的映射
        # map: param_index (in action space) -> feature_index (in state spec)
        param_to_feat_idx = {}
        for p_idx, p_name in enumerate(self.param_names):
            for s_idx, spec in enumerate(self.state_spec):
                if spec.get('name') == p_name:
                    param_to_feat_idx[p_idx] = s_idx
                    break

        # 2. 遍历所有局部状态 (Local States)
        # 预缓存 strides 和 bins 以加速循环
        s_strides = self.state_strides
        s_specs = self.state_spec

        # 针对 78125 状态 (5^7)，Python 循环约需 0.X 秒
        for s_idx in range(self.total_states_per_dim):
            # A. 状态解码 (Index -> Bin Indices)
            rem = s_idx
            bin_indices = []
            for stride in s_strides:
                bin_indices.append(rem // stride)
                rem %= stride

            # B. 参数重构 (Reconstruct Parameters from State)
            target_params = []
            for p_idx in range(len(self.param_names)):
                if p_idx in param_to_feat_idx:
                    # 状态中存在该参数：根据分箱反推物理值 (取中心)
                    feat_idx = param_to_feat_idx[p_idx]
                    bin_idx = bin_indices[feat_idx]
                    spec = s_specs[feat_idx]

                    # Val = Min + (BinIdx + 0.5) * BinWidth
                    bin_width = (spec['max'] - spec['min']) / spec['bins']
                    val = spec['min'] + (bin_idx + 0.5) * bin_width
                    target_params.append(val)
                else:
                    # 状态中缺失该参数：回退到全局均值
                    target_params.append(self.default_mean_params[p_idx])

            # C. 动作锁定 (Find Closest Action)
            # 找到最匹配 target_params 的动作索引
            target_action_idx = self.get_closest_action(target_params)

            # D. 注入偏置 (Bias Injection)
            # 这里利用广播机制，一次性设置该局部状态在所有全局维度 (Contexts) 的值
            # global_idx = context_idx * stride + local_idx
            # 我们直接切片: [local_idx, local_idx + stride, ...]
            # 写入 1e-5 确保在全零初始化下 argmax 能选中该动作
            self.q_table[s_idx::self.total_states_per_dim, target_action_idx] = 1e-5

        # 如果 Tensor 存在，手动同步一次
        if self.q_table_tensor is not None:
            self.q_table_tensor.copy_(torch.from_numpy(self.q_table))

        print(f"[Agent] Identity Mapping BC Completed. Mapped rules for {self.total_states_per_dim} local states.")
        return 0.0

    def update_target_network(self):
        """
        [FIX] 同步主网络参数到目标网络
        """
        if self.q_table_target_tensor is not None and self.q_table_tensor is not None:
            self.q_table_target_tensor.copy_(self.q_table_tensor)

    def save(self, path):
        # 保存时使用 NumPy 视图，确保兼容性
        data = {
            "q_table": self.q_table,
            "visits": self.visits
        }
        with open(path, 'wb') as f:
            pickle.dump(data, f)
        print(f"[Agent] Q-Table saved to {path}")

    def load(self, path):
        if not os.path.exists(path):
            print(f"[Agent] Warning: Model {path} not found.")
            return

        with open(path, 'rb') as f:
            data = pickle.load(f)

        if isinstance(data, dict):
            # 将数据加载到 NumPy 视图中 -> 自动同步到 Tensor 视图
            if data["q_table"].shape == self.q_table.shape:
                self.q_table[:] = data["q_table"][:]
                self.visits[:] = data["visits"][:]
                print(f"[Agent] Q-Table loaded from {path}")

                # [FIX] Critical: 加载预训练模型后，立即同步 Target Network
                # 防止 "冷启动" (Cold Target) 导致的灾难性遗忘
                if self.q_table_target is not None:
                    print("[Agent] Syncing Target Network with loaded model...")
                    self.q_table_target[:] = self.q_table[:]
                    if self.q_table_target_tensor is not None:
                        self.q_table_target_tensor.copy_(self.q_table_tensor)
            else:
                print(f"[Agent] Error: Shape mismatch.")
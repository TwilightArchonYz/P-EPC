import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import os
from collections import deque
from torch.distributions import Normal


# ==============================================================================
# 网络架构定义
# ==============================================================================

class Actor(nn.Module):
    """
    PPO Actor 网络: State -> Normal Distribution (Mean, Std)
    输出连续动作空间的分布参数。
    Mean 范围: [0, 1] (Sigmoid)
    Std 范围: Positive (Softplus)
    """

    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Actor, self).__init__()
        # 公共特征层
        self.feature_net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.Tanh(),  # PPO 通常使用 Tanh
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh()
        )

        # Mean 头
        self.mean_head = nn.Sequential(
            nn.Linear(hidden_dim, action_dim),
            nn.Sigmoid()  # 映射到 [0, 1]
        )

        # Std 头 (对数标准差，保证非负)
        self.log_std_head = nn.Sequential(
            nn.Linear(hidden_dim, action_dim),
        )

    def forward(self, state):
        features = self.feature_net(state)
        mean = self.mean_head(features)

        # 限制 log_std 范围防止数值不稳定
        log_std = self.log_std_head(features)
        log_std = torch.clamp(log_std, -20, 2)
        std = log_std.exp()

        return mean, std


class Critic(nn.Module):
    """
    PPO Critic 网络: State -> Value
    """

    def __init__(self, state_dim, hidden_dim=128):
        super(Critic, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state):
        return self.net(state)


class PPOAgent:
    """
    PPO 智能体 (Proximal Policy Optimization)
    --------------------------------------------------
    适用于连续动作空间。
    支持与 EA 混合的 Off-Policy 数据训练 (通过 Replay Buffer 近似)。
    """

    def __init__(self, state_dim, action_dim,
                 lr=3e-4,
                 gamma=0.99,
                 buffer_size=2048,  # PPO 通常不需要很大的 Buffer
                 batch_size=64,
                 hidden_dim=128,
                 device='cpu',
                 algo_params=None,
                 shared_visits=None,
                 clip_param=0.2,
                 value_coef=0.5,
                 entropy_coef=0.01,
                 grad_clip=0.5,
                 **kwargs):

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.batch_size = batch_size
        self.device = device
        self.buffer_capacity = buffer_size

        # PPO 超参数
        self.clip_param = clip_param
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.grad_clip = grad_clip

        # 1. 初始化网络
        self.actor = Actor(state_dim, action_dim, hidden_dim).to(device)
        self.critic = Critic(state_dim, hidden_dim).to(device)

        # [关键兼容性] 别名 eval_net 供 Adapter 使用
        self.eval_net = self.actor

        # 2. 优化器
        self.optimizer = optim.Adam([
            {'params': self.actor.parameters(), 'lr': lr},
            {'params': self.critic.parameters(), 'lr': lr}
        ])

        self.criterion_val = nn.MSELoss()

        # 3. 经验回放
        # 虽然 PPO 是 On-Policy，但在混合架构中我们使用 ReplayBuffer 暂存 Worker 返回的数据
        self.memory = deque(maxlen=buffer_size)

    def choose_action(self, state, mode='train', beta=None):
        """
        选择动作。
        """
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)

        mean, std = self.actor(state_tensor)

        if mode == 'train':
            dist = Normal(mean, std)
            action = dist.sample()
        else:
            action = mean  # Test 模式使用均值

        # 裁剪到有效范围 [0, 1]
        action = torch.clamp(action, 0.0, 1.0)
        return action.cpu().detach().numpy().flatten()

    def get_action_params(self, action):
        """
        [接口兼容 - Identity]
        PPO 输出即为连续参数，无需解码。
        """
        return action

    def get_closest_action(self, action_params):
        """
        [接口兼容]
        OfflineTrainer 加载数据时调用。
        直接返回连续向量，确保 Buffer 存储正确格式。
        """
        return np.array(action_params, dtype=np.float32)

    def store_transition(self, s, a, r, s_next):
        self.memory.append((s, a, r, s_next))

    def learn(self):
        """
        PPO 更新逻辑。
        注意：由于 OnlineTrainer 架构限制 (learn 被调用多次)，
        这里实现为从 Buffer 中采样 Batch 进行单步更新 (类似 Mini-batch PPO)。
        """
        if len(self.memory) < self.batch_size:
            return None

        # 1. 采样 Batch
        batch = random.sample(self.memory, self.batch_size)
        s_batch, a_batch, r_batch, s_next_batch = zip(*batch)

        # 2. 数据转换
        # [Auto-Adaptation] 处理可能存在的标量动作 (旧数据兼容)
        sample_action = a_batch[0]
        if not hasattr(sample_action, '__len__'):
            # 如果是标量，说明是旧数据，虽然 PPO 是新写的，但为了防守性兼容 DDPG 生成的离散数据
            # 这里可以做一个简单处理或者报错。
            # 鉴于 DDPG 已经强制要求数据清洗，这里假设数据已是连续向量。
            pass

        s_tensor = torch.FloatTensor(np.array(s_batch)).to(self.device)
        a_tensor = torch.FloatTensor(np.array(a_batch)).to(self.device)
        r_tensor = torch.FloatTensor(np.array(r_batch)).unsqueeze(1).to(self.device)
        s_next_tensor = torch.FloatTensor(np.array(s_next_batch)).to(self.device)

        # [Safety] 维度保障
        if a_tensor.dim() == 1:
            a_tensor = a_tensor.unsqueeze(1)

        # 3. 计算 Returns (TD Target)
        with torch.no_grad():
            next_value = self.critic(s_next_tensor)
            target_value = r_tensor + self.gamma * next_value

        # 4. 计算当前策略的分布和价值
        mean, std = self.actor(s_tensor)
        dist = Normal(mean, std)

        current_value = self.critic(s_tensor)

        # 计算 Log Prob 和 Entropy
        log_prob = dist.log_prob(a_tensor).sum(dim=1, keepdim=True)
        entropy = dist.entropy().sum(dim=1, keepdim=True).mean()

        # 5. PPO Loss Calculation
        # 注意：在标准 PPO 中，我们应该使用 old_log_prob (采样时的概率)。
        # 但由于 OnlineTrainer 的 generic buffer 不存储 log_prob，
        # 我们这里使用 collected data 视为 "Behavior Policy" 数据。
        # 为了应用 Clip 机制防止更新过大，我们将当前的 log_prob detach 作为 old_log_prob 的近似。
        # 这在 One-Step-Update 场景下退化为带 Clip 的 Actor-Critic。
        old_log_prob = log_prob.detach()

        advantage = target_value - current_value.detach()

        ratio = torch.exp(log_prob - old_log_prob)
        surr1 = ratio * advantage
        surr2 = torch.clamp(ratio, 1.0 - self.clip_param, 1.0 + self.clip_param) * advantage

        actor_loss = -torch.min(surr1, surr2).mean() - self.entropy_coef * entropy
        critic_loss = self.criterion_val(current_value, target_value) * self.value_coef

        total_loss = actor_loss + critic_loss

        # 6. 反向传播
        self.optimizer.zero_grad()
        total_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), self.grad_clip)
        nn.utils.clip_grad_norm_(self.critic.parameters(), self.grad_clip)
        self.optimizer.step()

        return total_loss.item()

    def update_target_network(self):
        # PPO 没有 Target Network
        pass

    def save(self, path):
        state = {
            'actor': self.actor.state_dict(),
            'critic': self.critic.state_dict()
        }
        torch.save(state, path)

    def load(self, path):
        if isinstance(path, str) and os.path.exists(path):
            try:
                checkpoint = torch.load(path)
                if isinstance(checkpoint, dict) and 'actor' in checkpoint:
                    self.actor.load_state_dict(checkpoint['actor'])
                    self.critic.load_state_dict(checkpoint['critic'])
                    print(f"[Agent] Loaded PPO checkpoint from {path}")
                else:
                    self.actor.load_state_dict(checkpoint)
                    print(f"[Agent] Loaded PPO Actor from {path}")
            except Exception as e:
                print(f"[Agent] Error loading checkpoint {path}: {e}")
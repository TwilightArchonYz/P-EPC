import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import random
import os
from torch.distributions import Normal
from collections import deque


# ==============================================================================
# 网络架构定义
# ==============================================================================

class GaussianPolicy(nn.Module):
    """
    SAC Actor 网络: State -> Action (Tanh Squashed Gaussian)
    输出范围: [0, 1] (经过 Tanh [-1, 1] 后线性变换)
    """

    def __init__(self, state_dim, action_dim, hidden_dim=256, log_std_min=-20, log_std_max=2):
        super(GaussianPolicy, self).__init__()
        self.log_std_min = log_std_min
        self.log_std_max = log_std_max

        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )

        self.mean_layer = nn.Linear(hidden_dim, action_dim)
        self.log_std_layer = nn.Linear(hidden_dim, action_dim)

    def forward(self, state):
        x = self.net(state)
        mean = self.mean_layer(x)
        log_std = self.log_std_layer(x)

        # 限制 Log Std 范围
        log_std = torch.clamp(log_std, self.log_std_min, self.log_std_max)

        return mean, log_std

    def sample(self, state):
        """
        采样动作。
        Returns:
            action: 变换后的动作 [0, 1]
            log_prob: 对应的对数概率 (包含 Jacobian 修正)
            mean: 确定性动作 (用于评估)
        """
        mean, log_std = self.forward(state)
        std = log_std.exp()

        normal = Normal(mean, std)

        # 重参数化采样 (Reparameterization Trick)
        # x_t = mu + sigma * epsilon
        x_t = normal.rsample()

        # Tanh Squashing: [-inf, inf] -> [-1, 1]
        y_t = torch.tanh(x_t)

        # Scaling: [-1, 1] -> [0, 1] (匹配 EA 参数范围)
        action = (y_t + 1.0) / 2.0

        # Log Prob Calculation with Jacobian Correction
        # 1. Tanh 修正: log(1 - tanh^2(x))
        log_prob = normal.log_prob(x_t)
        log_prob -= torch.log(1 - y_t.pow(2) + 1e-6)

        # 2. Scaling 修正: y = (x+1)/2 => dy/dx = 0.5 => log(0.5)
        # log_prob(y) = log_prob(x) - log(0.5)
        log_prob -= np.log(0.5)

        # Sum over action dimensions
        log_prob = log_prob.sum(dim=1, keepdim=True)

        # 计算确定性输出 (用于 Eval)
        mean_t = torch.tanh(mean)
        mean_action = (mean_t + 1.0) / 2.0

        return action, log_prob, mean_action


class TwinQNetwork(nn.Module):
    """
    SAC Critic 网络: Twin Q-Networks (Q1, Q2)
    """

    def __init__(self, state_dim, action_dim, hidden_dim=256):
        super(TwinQNetwork, self).__init__()

        # Q1 Architecture
        self.l1_1 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.l1_2 = nn.Linear(hidden_dim, hidden_dim)
        self.l1_3 = nn.Linear(hidden_dim, 1)

        # Q2 Architecture
        self.l2_1 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.l2_2 = nn.Linear(hidden_dim, hidden_dim)
        self.l2_3 = nn.Linear(hidden_dim, 1)

    def forward(self, state, action):
        xu = torch.cat([state, action], dim=1)

        # Q1
        x1 = F.relu(self.l1_1(xu))
        x1 = F.relu(self.l1_2(x1))
        q1 = self.l1_3(x1)

        # Q2
        x2 = F.relu(self.l2_1(xu))
        x2 = F.relu(self.l2_2(x2))
        q2 = self.l2_3(x2)

        return q1, q2


class SACAgent:
    """
    SAC 智能体 (Soft Actor-Critic)
    --------------------------------------------------
    适用于连续动作空间。
    """

    def __init__(self, state_dim, action_dim,
                 lr=3e-4,
                 gamma=0.99,
                 tau=0.005,
                 alpha=0.2,
                 auto_entropy_tuning=True,
                 buffer_size=1000000,
                 batch_size=256,
                 hidden_dim=256,
                 device='cpu',
                 algo_params=None,
                 shared_visits=None,
                 **kwargs):

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size
        self.device = device
        self.buffer_capacity = buffer_size

        # 1. 初始化网络
        self.actor = GaussianPolicy(state_dim, action_dim, hidden_dim).to(device)
        self.critic = TwinQNetwork(state_dim, action_dim, hidden_dim).to(device)
        self.critic_target = TwinQNetwork(state_dim, action_dim, hidden_dim).to(device)
        self.critic_target.load_state_dict(self.critic.state_dict())

        # [关键兼容性] 别名 eval_net
        self.eval_net = self.actor

        # 2. 熵调节 (Alpha)
        self.auto_entropy_tuning = auto_entropy_tuning
        if self.auto_entropy_tuning:
            self.target_entropy = -torch.prod(torch.Tensor([action_dim]).to(device)).item()
            self.log_alpha = torch.zeros(1, requires_grad=True, device=device)
            self.alpha_optimizer = optim.Adam([self.log_alpha], lr=lr)
            self.alpha = self.log_alpha.exp()
        else:
            self.alpha = torch.tensor(alpha).to(device)
            self.alpha_optimizer = None

        # 3. 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr)

        # 4. 经验回放
        self.memory = deque(maxlen=buffer_size)

    def choose_action(self, state, mode='train', beta=None):
        """
        选择动作。
        """
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)

        with torch.no_grad():
            if mode == 'train':
                action, _, _ = self.actor.sample(state_tensor)
            else:
                _, _, action = self.actor.sample(state_tensor)  # Eval 使用 Mean

        return action.cpu().numpy().flatten()

    def get_action_params(self, action):
        """[接口兼容 - Identity]"""
        return action

    def get_closest_action(self, action_params):
        """
        [接口兼容 - Data Loading]
        OfflineTrainer 加载数据时调用。直接返回连续向量。
        """
        return np.array(action_params, dtype=np.float32)

    def store_transition(self, s, a, r, s_next):
        self.memory.append((s, a, r, s_next))

    def learn_behavior_cloning(self, batch_size=None):
        """
        [New] 离线预训练专用接口: 行为克隆 (Behavior Cloning)
        仅使用监督学习更新 Actor，完全绕过 Critic，防止 OOD 导致的 Q 值爆炸。
        """
        use_batch_size = batch_size if batch_size is not None else self.batch_size

        if len(self.memory) < use_batch_size:
            return None

        # 1. 采样
        batch = random.sample(self.memory, use_batch_size)
        s_batch, a_batch, _, _ = zip(*batch)  # 忽略 Reward 和 Next State

        # 2. 准备数据
        s_tensor = torch.FloatTensor(np.array(s_batch)).to(self.device)
        a_tensor = torch.FloatTensor(np.array(a_batch)).to(self.device)

        # 维度修正 (如果动作是 1 维)
        if a_tensor.dim() == 1:
            a_tensor = a_tensor.unsqueeze(1)

        # 3. 计算 Actor 确定性输出
        # BC 目标是让 Policy 的均值逼近专家动作
        _, _, mean_action = self.actor.sample(s_tensor)

        # 4. 计算 MSE Loss
        bc_loss = F.mse_loss(mean_action, a_tensor)

        # 5. 更新 Actor
        self.actor_optimizer.zero_grad()
        bc_loss.backward()
        # [Safety] 梯度裁剪 (防止监督信号过强)
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=10.0)
        self.actor_optimizer.step()

        return bc_loss.item()

    def learn(self):
        """
        SAC 更新逻辑 (在线 RL 模式)
        [Update] 增加梯度裁剪以增强数值稳定性
        """
        if len(self.memory) < self.batch_size:
            return None

        batch = random.sample(self.memory, self.batch_size)
        s_batch, a_batch, r_batch, s_next_batch = zip(*batch)

        # 1. 准备数据
        s_tensor = torch.FloatTensor(np.array(s_batch)).to(self.device)

        # [Auto-Adaptation] 处理离散/连续动作兼容性
        sample_action = a_batch[0]
        # 假设数据已经是连续的 (在 get_closest_action 中处理)
        a_tensor = torch.FloatTensor(np.array(a_batch)).to(self.device)
        # [Safety] 维度检查
        if a_tensor.dim() == 1:
            a_tensor = a_tensor.unsqueeze(1)

        r_tensor = torch.FloatTensor(np.array(r_batch)).unsqueeze(1).to(self.device)
        s_next_tensor = torch.FloatTensor(np.array(s_next_batch)).to(self.device)

        # ----------------------
        # 2. 更新 Critic (Q1, Q2)
        # ----------------------
        with torch.no_grad():
            # 计算 Next Action 和 Next LogProb
            next_action, next_log_prob, _ = self.actor.sample(s_next_tensor)

            # 计算 Target Q
            q1_target, q2_target = self.critic_target(s_next_tensor, next_action)
            min_q_target = torch.min(q1_target, q2_target)

            # Soft Q Target
            if self.auto_entropy_tuning:
                alpha = self.log_alpha.exp()
            else:
                alpha = self.alpha

            next_q_value = r_tensor + self.gamma * (min_q_target - alpha * next_log_prob)

        # 计算 Current Q
        q1, q2 = self.critic(s_tensor, a_tensor)

        q1_loss = F.mse_loss(q1, next_q_value)
        q2_loss = F.mse_loss(q2, next_q_value)
        critic_loss = q1_loss + q2_loss

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        # [Safety] 梯度裁剪
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=10.0)
        self.critic_optimizer.step()

        # ----------------------
        # 3. 更新 Actor
        # ----------------------
        # 重新采样当前状态下的动作
        new_action, log_prob, _ = self.actor.sample(s_tensor)

        q1_new, q2_new = self.critic(s_tensor, new_action)
        min_q_new = torch.min(q1_new, q2_new)

        # Actor Loss: Minimize (alpha * log_prob - Q)
        # 即最大化 (Q - alpha * log_prob)
        actor_loss = (alpha * log_prob - min_q_new).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        # [Safety] 梯度裁剪
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=10.0)
        self.actor_optimizer.step()

        # ----------------------
        # 4. 更新 Alpha (Optional)
        # ----------------------
        if self.auto_entropy_tuning:
            alpha_loss = -(self.log_alpha * (log_prob + self.target_entropy).detach()).mean()

            self.alpha_optimizer.zero_grad()
            alpha_loss.backward()
            # [Safety] 梯度裁剪 (通常不需要，但为了统一性加上)
            torch.nn.utils.clip_grad_norm_([self.log_alpha], max_norm=10.0)
            self.alpha_optimizer.step()

            self.alpha = self.log_alpha.exp()

        # ----------------------
        # 5. 软更新 Target Networks
        # ----------------------
        self.soft_update(self.critic, self.critic_target)

        return critic_loss.item() + actor_loss.item()

    def soft_update(self, local_model, target_model):
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()):
            target_param.data.copy_(self.tau * local_param.data + (1.0 - self.tau) * target_param.data)

    def update_target_network(self):
        pass

    def save(self, path):
        state = {
            'actor': self.actor.state_dict(),
            'critic': self.critic.state_dict(),
            'critic_target': self.critic_target.state_dict(),
            'log_alpha': self.log_alpha if self.auto_entropy_tuning else None
        }
        torch.save(state, path)

    def load(self, path):
        if isinstance(path, str) and os.path.exists(path):
            try:
                checkpoint = torch.load(path)
                if isinstance(checkpoint, dict) and 'actor' in checkpoint:
                    self.actor.load_state_dict(checkpoint['actor'])
                    self.critic.load_state_dict(checkpoint['critic'])
                    self.critic_target.load_state_dict(checkpoint['critic_target'])
                    if self.auto_entropy_tuning and checkpoint.get('log_alpha') is not None:
                        with torch.no_grad():
                            self.log_alpha.copy_(checkpoint['log_alpha'])
                    print(f"[Agent] Loaded SAC checkpoint from {path}")
                else:
                    self.actor.load_state_dict(checkpoint)
                    print(f"[Agent] Loaded SAC Actor from {path}")
            except Exception as e:
                print(f"[Agent] Error loading checkpoint {path}: {e}")
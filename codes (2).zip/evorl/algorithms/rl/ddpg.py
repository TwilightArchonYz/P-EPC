import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import os
from collections import deque


# ==============================================================================
# 网络架构定义
# ==============================================================================

class Actor(nn.Module):
    """
    Actor 网络: State -> Action (Continuous)
    输出范围限制在 [0, 1] (通过 Sigmoid)，对应参数 F 和 CR 的归一化范围。
    """

    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Actor, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Sigmoid()  # 输出 [0, 1]
        )

    def forward(self, state):
        return self.net(state)


class Critic(nn.Module):
    """
    Critic 网络: (State, Action) -> Q-Value
    """

    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Critic, self).__init__()
        # 先处理 State
        self.f1 = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU()
        )
        # 再合并 Action
        self.f2 = nn.Sequential(
            nn.Linear(hidden_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state, action):
        s_feat = self.f1(state)

        # [Safety Check] 确保 action 是 2D 张量 (Batch, Dim)
        # 防止标量输入导致 cat 失败
        if action.dim() == 1:
            action = action.unsqueeze(1)

        combined = torch.cat([s_feat, action], dim=1)
        q_val = self.f2(combined)
        return q_val


class OUNoise:
    """
    Ornstein-Uhlenbeck 噪声过程，用于 DDPG 的动作探索。
    """

    def __init__(self, action_dim, mu=0.0, theta=0.15, sigma=0.2):
        self.action_dim = action_dim
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(self.action_dim) * self.mu
        self.reset()

    def reset(self):
        self.state = np.ones(self.action_dim) * self.mu

    def noise(self):
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * np.random.randn(len(x))
        self.state = x + dx
        return self.state


class DDPGAgent:
    """
    DDPG 智能体 (Deep Deterministic Policy Gradient)
    --------------------------------------------------
    适用于连续动作空间。
    """

    def __init__(self, state_dim, action_dim,
                 lr=1e-4,
                 gamma=0.99,
                 tau=0.005,  # 软更新系数
                 buffer_size=100000,
                 batch_size=64,
                 hidden_dim=128,
                 device='cpu',
                 algo_params=None,  # 接收但不使用 (连续空间无需网格)
                 shared_visits=None,  # 接收但不使用 (兼容性)
                 **kwargs):

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size
        self.device = device
        self.buffer_capacity = buffer_size

        # 1. 初始化网络
        self.actor = Actor(state_dim, action_dim, hidden_dim).to(device)
        self.actor_target = Actor(state_dim, action_dim, hidden_dim).to(device)
        self.actor_target.load_state_dict(self.actor.state_dict())

        self.critic = Critic(state_dim, action_dim, hidden_dim).to(device)
        self.critic_target = Critic(state_dim, action_dim, hidden_dim).to(device)
        self.critic_target.load_state_dict(self.critic.state_dict())

        # [关键兼容性] 将 actor 别名为 eval_net，以便 Evaluator/Adapter 提取策略权重
        self.eval_net = self.actor

        # 2. 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr)

        self.criterion = nn.MSELoss()

        # 3. 经验回放与噪声
        self.memory = deque(maxlen=buffer_size)
        self.noise = OUNoise(action_dim)

    def choose_action(self, state, mode='train', beta=None):
        """
        选择动作。
        """
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)

        self.actor.eval()
        with torch.no_grad():
            action = self.actor(state_tensor).cpu().data.numpy().flatten()
        self.actor.train()

        if mode == 'train':
            noise = self.noise.noise()
            action = action + noise
            # 裁剪到 [0, 1] 有效范围
            action = np.clip(action, 0.0, 1.0)

        return action

    def get_action_params(self, action):
        """
        [接口兼容 - Identity]
        对于连续动作空间，action 已经是参数本身，无需解码。
        """
        return action

    def get_closest_action(self, action_params):
        """
        [接口兼容 - Critical Fix]
        OfflineTrainer 加载 expert_data (raw_action list) 时会调用此方法。
        对于 DDPG，不需要将参数编码为离散索引，而是直接返回参数向量供 Buffer 存储。

        参数:
            action_params (list or np.array): 如 [0.5, 0.3]
        返回:
            np.array: 如 array([0.5, 0.3])
        """
        return np.array(action_params, dtype=np.float32)

    def store_transition(self, s, a, r, s_next):
        self.memory.append((s, a, r, s_next))

    def learn(self):
        """
        DDPG 更新逻辑
        """
        if len(self.memory) < self.batch_size:
            return None

        batch = random.sample(self.memory, self.batch_size)
        s_batch, a_batch, r_batch, s_next_batch = zip(*batch)

        s_tensor = torch.FloatTensor(np.array(s_batch)).to(self.device)

        # 此时 a_batch 应该已经是 2D 数组列表 (由于修复了 get_closest_action)
        # shape: (batch_size, action_dim)
        a_tensor = torch.FloatTensor(np.array(a_batch)).to(self.device)

        # [Safety] 如果万一输入是标量，unsqueeze
        if a_tensor.dim() == 1:
            a_tensor = a_tensor.unsqueeze(1)

        r_tensor = torch.FloatTensor(np.array(r_batch)).unsqueeze(1).to(self.device)
        s_next_tensor = torch.FloatTensor(np.array(s_next_batch)).to(self.device)

        # ----------------------
        # 1. 更新 Critic
        # ----------------------
        with torch.no_grad():
            next_actions = self.actor_target(s_next_tensor)
            target_q = self.critic_target(s_next_tensor, next_actions)
            target_val = r_tensor + self.gamma * target_q

        current_q = self.critic(s_tensor, a_tensor)
        critic_loss = self.criterion(current_q, target_val)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # ----------------------
        # 2. 更新 Actor
        # ----------------------
        actor_actions = self.actor(s_tensor)
        actor_loss = -self.critic(s_tensor, actor_actions).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # ----------------------
        # 3. 软更新 Target Networks
        # ----------------------
        self.soft_update(self.actor, self.actor_target)
        self.soft_update(self.critic, self.critic_target)

        return critic_loss.item()

    def soft_update(self, local_model, target_model):
        """
        Soft update model parameters.
        θ_target = τ*θ_local + (1 - τ)*θ_target
        """
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()):
            target_param.data.copy_(self.tau * local_param.data + (1.0 - self.tau) * target_param.data)

    def update_target_network(self):
        """兼容接口"""
        pass

    def save(self, path):
        # 保存完整状态，以便后续恢复
        state = {
            'actor': self.actor.state_dict(),
            'critic': self.critic.state_dict(),
            'actor_target': self.actor_target.state_dict(),
            'critic_target': self.critic_target.state_dict()
        }
        torch.save(state, path)

    def load(self, path):
        """
        加载模型。
        """
        # 仅当 path 是字符串(文件路径)时尝试从磁盘加载
        if isinstance(path, str) and os.path.exists(path):
            try:
                checkpoint = torch.load(path)
                if isinstance(checkpoint, dict) and 'actor' in checkpoint:
                    # 完整加载
                    self.actor.load_state_dict(checkpoint['actor'])
                    self.critic.load_state_dict(checkpoint['critic'])
                    self.actor_target.load_state_dict(checkpoint['actor_target'])
                    self.critic_target.load_state_dict(checkpoint['critic_target'])
                    print(f"[Agent] Loaded DDPG checkpoint from {path}")
                else:
                    # 仅 Actor 的情况
                    self.actor.load_state_dict(checkpoint)
                    print(f"[Agent] Loaded DDPG Actor from {path}")
            except Exception as e:
                print(f"[Agent] Error loading checkpoint {path}: {e}")
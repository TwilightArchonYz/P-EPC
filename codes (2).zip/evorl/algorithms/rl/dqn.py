import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from collections import deque

# ==============================================================================
# 默认配置常量
# ==============================================================================
# [通用设置] 默认状态分箱数
# 对应 state_def.py 中的特征顺序:
# [Progress, Diversity, Stagnation, FitDist, EvoRate] + [Params...]
# 注意: Dimension 在 Index 5，不参与此处分箱
DEFAULT_STATE_BINS = [5, 4, 4, 4, 4, 4, 4]
DEFAULT_DIM_NORM_FACTOR = 100.0

# 网络架构默认参数
DEFAULT_HIDDEN_DIM = 128
# 注意: Standard DQN 不使用 stream_hidden_dim，但保留常量定义以保持一致性
DEFAULT_STREAM_HIDDEN_DIM = 64


class QNetwork(nn.Module):
    """
    标准 Q 网络架构 (Standard Q-Network)
    --------------------------------------------------
    简单的多层感知机 (MLP)，直接输出动作价值 Q(s, a)。
    """

    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(QNetwork, self).__init__()

        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim)
        )

    def forward(self, state):
        return self.net(state)


class DQNAgent:
    """
    Standard DQN 智能体 (Nature DQN)
    --------------------------------------------------
    特性：
    1. 使用标准 Target Network 更新机制 (Y = r + gamma * max Q_target)。
    2. 支持通用 N 维动作空间 (通过 algo_params 配置)。
    3. 集成基于访问计数 (Count-Based) 的 UCB 探索策略。
    4. [Updated] 支持配置驱动的状态离散化 (Spec-Driven Discretization)。
    """

    def __init__(self, state_dim, action_dim,
                 lr=1e-3,
                 gamma=0.9,
                 buffer_size=10000,
                 batch_size=64,
                 hidden_dim=DEFAULT_HIDDEN_DIM,
                 stream_hidden_dim=DEFAULT_STREAM_HIDDEN_DIM,  # 接收此参数但不使用，兼容接口
                 device='cpu',
                 shared_visits=None,
                 target_dims=None,
                 state_spec=None,  # [New] 状态规格说明书
                 context_spec=None, # [New] 上下文规格说明书
                 state_bins=None,
                 dim_norm_factor=None,
                 algo_params=None,  # [关键参数] 通用算法参数配置
                 **kwargs):  # 捕获可能的遗留参数，防止崩溃

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.batch_size = batch_size
        self.device = device
        self.buffer_capacity = buffer_size

        # 1. 保存配置规格 (Spec)
        self.state_spec = state_spec
        self.context_spec = context_spec
        self.target_dims = target_dims
        self.use_spec_logic = (self.state_spec is not None)

        # 2. 初始化离散化参数
        if self.use_spec_logic:
            # 优先使用 Spec 中的定义
            self.state_bins = [spec['bins'] for spec in self.state_spec]
            if self.context_spec:
                self.dim_norm_factor = self.context_spec.get('norm_factor', 100.0)
            else:
                self.dim_norm_factor = dim_norm_factor if dim_norm_factor is not None else DEFAULT_DIM_NORM_FACTOR
        else:
            # Fallback 到旧逻辑
            self.state_bins = state_bins if state_bins is not None else DEFAULT_STATE_BINS
            self.dim_norm_factor = dim_norm_factor if dim_norm_factor is not None else DEFAULT_DIM_NORM_FACTOR

        # 3. 构建参数网格 (Generic Action Space)
        self.param_grids = []
        if algo_params is not None:
            for param in algo_params:
                if 'options' in param:
                    self.param_grids.append(param['options'])

        if not self.param_grids:
            print("[Agent] Warning: 未提供 'algo_params'。动作空间可能未定义。")
            self.param_grids = [[0.5]]

        # 4. 预计算动作步长 (Action Strides)
        self.action_strides = []
        curr_act_stride = 1
        for grid in reversed(self.param_grids[1:]):
            curr_act_stride *= len(grid)
            self.action_strides.insert(0, curr_act_stride)
        self.action_strides.append(1)

        # 5. 预计算状态步长 (State Strides) - 用于 UCB 访问计数
        self.state_strides = []
        curr_state_stride = 1
        for b in reversed(self.state_bins[1:]):
            curr_state_stride *= b
            self.state_strides.insert(0, curr_state_stride)
        self.state_strides.append(1)

        self.total_states_per_dim = int(np.prod(self.state_bins))

        # 6. 初始化神经网络 (Standard QNetwork)
        self.eval_net = QNetwork(state_dim, action_dim, hidden_dim).to(device)
        self.target_net = QNetwork(state_dim, action_dim, hidden_dim).to(device)
        self.target_net.load_state_dict(self.eval_net.state_dict())
        self.target_net.eval()

        # 7. 优化器与损失函数
        self.optimizer = optim.Adam(self.eval_net.parameters(), lr=lr)
        # 使用 SmoothL1Loss (Huber Loss) 提高数值稳定性
        self.loss_func = nn.SmoothL1Loss()

        # 8. 经验回放池
        self.memory = deque(maxlen=buffer_size)

        # 9. 共享访问计数表 (Shared Visits)
        # 用于多进程环境下的 Count-Based Exploration
        self.visits = None
        if shared_visits is not None and target_dims is not None:
            expected_size = self.total_states_per_dim * len(target_dims)
            # 从共享内存缓冲区重建 NumPy 数组
            self.visits = np.frombuffer(shared_visits, dtype=np.float64, count=expected_size)
            self.visits_flat = self.visits

    def get_state_idx(self, state):
        """
        将连续状态向量映射为离散索引 (用于访问计数)。
        [Updated] 支持 Spec-Driven 逻辑，适配 V2 状态定义。
        """

        # --- 1. 确定当前问题维度 (Context Dimension) ---
        current_dim_val = 0
        if self.context_spec:
            c_idx = self.context_spec['idx']
            if c_idx < len(state):
                current_dim_val = state[c_idx]
        elif not self.use_spec_logic:
            # [Fallback] V2 Default: NormDim at Index 5
            if len(state) > 5:
                current_dim_val = state[5]
            elif len(state) > 3:
                current_dim_val = state[3] # Old fallback

        current_dim = int(round(current_dim_val * self.dim_norm_factor))

        # --- 2. 计算局部状态索引 (Local Index) ---
        local_idx = 0

        if self.use_spec_logic:
            # [Spec-Driven Logic]
            for i, spec in enumerate(self.state_spec):
                # a. 提取
                feat_idx = spec['idx']
                if feat_idx >= len(state):
                    val = 0.0
                else:
                    val = state[feat_idx]

                # b. 归一化
                v_min = spec.get('min', 0.0)
                v_max = spec.get('max', 1.0)
                span = v_max - v_min
                if span < 1e-9: span = 1e-9
                norm_val = (val - v_min) / span

                # c. 截断与分箱
                bins = spec['bins']
                idx_val = int(norm_val * bins)
                idx_val = max(0, min(idx_val, bins - 1))

                # d. 累加步长
                local_idx += idx_val * self.state_strides[i]
        else:
            # [Legacy Logic] 适配 V2: [0,1,2,3,4] + [6...]
            # 跳过 Index 5 (NormDim)
            meta_feats = []
            if len(state) > 4:
                meta_feats = [state[0], state[1], state[2], state[3], state[4]]

            param_feats = []
            if len(state) > 6:
                param_feats = list(state[6:])

            feats_to_bin = meta_feats + param_feats

            for i, val in enumerate(feats_to_bin):
                if i >= len(self.state_bins): break
                bins = self.state_bins[i]
                stride = self.state_strides[i]

                # EvoRate (Index 4 in feats) correction: [-1, 1] -> [0, 1]
                if i == 4:
                    val = (val + 1.0) / 2.0

                idx_val = int(val * bins)
                idx_val = max(0, min(idx_val, bins - 1))
                local_idx += idx_val * stride

        # --- 3. 计算全局索引 (Global Index) ---
        dim_idx = 0
        if self.target_dims:
            try:
                dim_idx = self.target_dims.index(current_dim)
            except ValueError:
                dim_idx = 0

        final_idx = dim_idx * self.total_states_per_dim + local_idx

        if self.visits is not None:
            return min(final_idx, len(self.visits_flat) - 1)
        return 0

    def get_closest_action(self, action_params):
        """
        [编码] 将 N 维连续参数映射为离散动作索引。
        """
        flat_idx = 0

        # 遍历每个参数维度
        for i, val in enumerate(action_params):
            if i >= len(self.param_grids): break

            grid = self.param_grids[i]
            stride = self.action_strides[i]

            # 在当前维度的网格中找到最近邻
            best_val = min(grid, key=lambda x: abs(x - val))
            idx = grid.index(best_val)

            # 累加步长
            flat_idx += idx * stride

        return flat_idx

    def get_action_params(self, action_idx):
        """
        [解码] 将离散动作索引映射回 N 维参数元组。
        """
        params = []
        rem = int(action_idx)

        for i, stride in enumerate(self.action_strides):
            grid = self.param_grids[i]

            # 计算当前维度的索引
            idx = rem // stride

            # 安全性截断 (防止越界)
            idx = min(idx, len(grid) - 1)

            params.append(grid[idx])

            # 更新余数
            rem = rem % stride

        return tuple(params)

    def choose_action(self, state, mode='train', beta=1.0):
        """
        选择动作。
        训练模式: 使用带有 UCB 探索的 Epsilon-Greedy 策略。
        测试模式: 全贪婪策略。
        """
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        state_idx = self.get_state_idx(state)

        with torch.no_grad():
            q_values = self.eval_net(state_tensor).cpu().numpy().flatten()

        if mode == 'train':
            local_eps = 0.1  # 基础 Epsilon
            if self.visits is not None:
                n_visits = self.visits_flat[state_idx]

                # UCB 风格的衰减探索率
                # 访问次数越多，Epsilon 越小
                local_eps = beta / np.sqrt(n_visits + 1e-6)
                local_eps = min(1.0, max(0.01, local_eps))

                # [Side Effect] 增加全局访问计数
                self.visits_flat[state_idx] += 1.0

            if np.random.uniform() < local_eps:
                return np.random.randint(self.action_dim)
            else:
                return np.argmax(q_values)
        else:
            # 测试模式: 贪婪选择
            return np.argmax(q_values)

    def store_transition(self, s, a, r, s_next):
        self.memory.append((s, a, r, s_next))

    def learn(self):
        """
        执行一步梯度下降更新。
        使用 Standard DQN 逻辑计算目标 Q 值。
        Target = r + gamma * max(Q_target(s', a'))
        """
        if len(self.memory) < self.batch_size:
            return None

        batch = random.sample(self.memory, self.batch_size)
        s_batch, a_batch, r_batch, s_next_batch = zip(*batch)

        s_tensor = torch.FloatTensor(np.array(s_batch)).to(self.device)
        a_tensor = torch.LongTensor(np.array(a_batch)).unsqueeze(1).to(self.device)
        r_tensor = torch.FloatTensor(np.array(r_batch)).unsqueeze(1).to(self.device)
        s_next_tensor = torch.FloatTensor(np.array(s_next_batch)).to(self.device)

        # 1. 计算当前 Q 值 (Q_eval)
        q_eval = self.eval_net(s_tensor).gather(1, a_tensor)

        # 2. 计算目标 Q 值 (Q_target) - Standard DQN Logic
        with torch.no_grad():
            next_q_target_values = self.target_net(s_next_tensor)
            # Max 操作: values, indices = max(dim=1)
            # 我们只需要 values
            max_next_q_target = next_q_target_values.max(dim=1, keepdim=True)[0]

            q_target = r_tensor + self.gamma * max_next_q_target

        # 3. 计算损失并更新
        loss = self.loss_func(q_eval, q_target)

        self.optimizer.zero_grad()
        loss.backward()

        # 梯度裁剪 (防止梯度爆炸)
        torch.nn.utils.clip_grad_norm_(self.eval_net.parameters(), max_norm=1.0)

        self.optimizer.step()

        return loss.item()

    def update_target_network(self):
        """同步 Target 网络参数"""
        self.target_net.load_state_dict(self.eval_net.state_dict())

    def save(self, path):
        torch.save(self.eval_net.state_dict(), path)

    def load(self, path):
        if os.path.exists(path):
            self.eval_net.load_state_dict(torch.load(path))
            self.target_net.load_state_dict(self.eval_net.state_dict())
            print(f"[Agent] Loaded model from {path}")
        else:
            print(f"[Agent] Warning: Model {path} not found.")
import numpy as np
from evorl.algorithms.ea.shade import SolverSHADE
# [Modified] 引入新的双轨奖励计算器
# 移除了不存在的 calc_immediate_reward
from evorl.core.reward_def import TrajectoryRewardCalculator

# 使用统一的状态定义模块，确保离线训练和在线训练的特征一致性
from evorl.core import state_def


class SHADE_RL(SolverSHADE):
    """
    SHADE-RL 混合求解器 (SHADE-RL Hybrid Solver)
    --------------------------------------------------
    结合了 SHADE 演化算法与 Dueling DQN 强化学习智能体。
    RL Agent 根据当前进化状态，动态输出 SHADE 的关键控制参数 (F, CR)。
    """

    def __init__(self, problem, agent, pop_size=100, max_nfes=100000, seed=None,
                 mode='train',
                 # [New] 双基准曲线输入
                 baseline_seed_curve=None,
                 baseline_mean_curve=None,
                 # [New] 奖励窗口超参数 (保留参数接口但可能不再用于 TrajectoryRewardCalculator)
                 reward_window_long=0.5,
                 reward_window_short=0.05,
                 ucb_beta=1.0,
                 **kwargs):
        """
        初始化混合求解器。

        参数:
            problem: 优化问题实例。
            agent: RL 智能体实例 (通常是 DuelingDQNAgent)。
            baseline_seed_curve: (np.array) 对应特定种子的基准曲线 (用于轨道A)。
            baseline_mean_curve: (np.array) 对应实例的均值基准曲线 (用于轨道B)。
            reward_window_long: (float) 种子基准的向前传播窗口比例。
            reward_window_short: (float) 均值基准的向前传播窗口比例。
            ucb_beta: UCB 探索参数。
            kwargs: 其他通用参数，包括特征计算的比例参数和特征选择列表。
        """
        super().__init__(problem, pop_size, max_nfes, seed)
        self.agent = agent
        self.mode = mode

        # [New] 存储双轨基准数据
        self.baseline_seed = baseline_seed_curve
        self.baseline_mean = baseline_mean_curve

        # [New] 存储奖励窗口参数
        self.rw_long = reward_window_long
        self.rw_short = reward_window_short

        # 保存 UCB 探索系数 (用于传递给 Agent)
        self.ucb_beta = ucb_beta

        # 提取特征计算的时间窗口比例 (用于 State Generation)
        self.evo_long_ratio = kwargs.get('evo_long_ratio', 0.1)
        self.evo_short_ratio = kwargs.get('evo_short_ratio', 0.05)

        # 提取特征选择列表
        self.use_features = kwargs.get('use_features', None)

        # RL 交互状态变量
        self.state = None
        self.action_idx = None
        self.mu_f = 0.5  # 初始 F 均值
        self.mu_cr = 0.5  # 初始 CR 均值
        self.last_best_fit = float('inf')
        self.transitions = []

        # 初始化收敛历史记录列表
        self.fit_history = []

    def get_state_vector(self):
        """
        获取当前进化状态向量。
        委托给 evorl.core.state_def 实现，确保与离线数据生成的格式完全一致。
        """
        # 如果 Agent 具有自定义的维度归一化因子，则使用之；否则默认为 100.0
        norm = getattr(self.agent, 'dim_norm_factor', 100.0)

        # 传递动态时间窗口比例
        time_horizon_ratios = {
            'long': self.evo_long_ratio,
            'short': self.evo_short_ratio
        }

        # 传递特征选择列表 use_features
        return state_def.get_state_vector(
            self,
            dim_norm_factor=norm,
            time_horizon_ratios=time_horizon_ratios,
            use_features=self.use_features
        )

    def initialize(self):
        super().initialize()
        self.last_best_fit = self.gbest_val
        self.transitions = []

        # 重置并记录初始代适应度
        self.fit_history = []
        self.fit_history.append(self.gbest_val)

        # 1. 获取初始状态
        self.state = self.get_state_vector()

        # 2. RL 选择初始动作
        # 显式传递 beta 参数以控制探索程度
        self.action_idx = self.agent.choose_action(self.state, mode=self.mode, beta=self.ucb_beta)

        # 3. 解析动作参数
        self.mu_f, self.mu_cr = self.agent.get_action_params(self.action_idx)

    def evolve(self):
        """
        执行一代进化。
        使用 RL Agent 输出的参数 (mu_f, mu_cr) 来指导种群变异。
        """
        # 1. 参数生成 (由 RL 动作指导)
        pop_size = self.pop_size

        # CR 采样: 正态分布 N(mu_cr, 0.1)
        cr = np.clip(self.rng.normal(self.mu_cr, 0.1, pop_size), 0.0, 1.0)

        # F 采样: 柯西分布 Cauchy(mu_f, 0.1)
        f_raw = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))
        f_param = np.where(f_raw <= 0, 0.5, f_raw)
        f_param = np.clip(f_param, 0.1, 1.0)

        # 2. 标准 SHADE 演化操作 (变异、交叉、选择、内存更新)
        X = self.X
        fitness = self.fitness

        sorted_idx = np.argsort(fitness)
        num_pbest = max(1, int(pop_size * self.p_best_rate))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        r1 = self.rng.randint(0, pop_size, pop_size)
        Union_X = np.vstack([X, np.array(self.archive_X)]) if self.archive_X else X
        r2 = self.rng.randint(0, len(Union_X), pop_size)

        V = X + f_param[:, None] * (X_pbest - X) + f_param[:, None] * (X[r1] - Union_X[r2])
        V = np.clip(V, self.problem.lb, self.problem.ub)

        mask = self.rng.rand(pop_size, self.dim) < cr[:, None]
        mask[np.arange(pop_size), self.rng.randint(0, self.dim, pop_size)] = True
        U = np.where(mask, V, X)

        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        # 选择操作
        improved = (cv_U < self.cv) | ((cv_U == self.cv) & (fit_U < fitness))
        if np.any(improved):
            for p in X[improved]:
                self.archive_X.append(p.copy())
            while len(self.archive_X) > pop_size:
                idx = self.rng.randint(0, len(self.archive_X))
                self.archive_X.pop(idx)

            diff = np.abs(fitness[improved] - fit_U[improved])
            w = diff / (np.sum(diff) + 1e-15)

            if np.sum(w) > 0:
                mean_pow_f = np.sum(w * (f_param[improved] ** 2)) / (np.sum(w * f_param[improved]) + 1e-15)
                mean_cr = np.sum(w * cr[improved])

                self.M_f[self.k_mem] = mean_pow_f
                self.M_cr[self.k_mem] = mean_cr
                self.k_mem = (self.k_mem + 1) % self.memory_size

            X[improved] = U[improved]
            fitness[improved] = fit_U[improved]
            self.cv[improved] = cv_U[improved]
            self.raw_f[improved] = raw_U[improved]

        self._update_gbest()

        # 3. RL 交互步骤 (计算奖励、存储转换、选择新动作)
        self.update_rl_step()

    def update_rl_step(self):
        """
        执行 RL 的单步交互逻辑。
        [Modified] 使用 TrajectoryRewardCalculator.calc_step_reward 计算即时奖励
        """
        # 准备基准数据 (优先 Seed, 其次 Mean)
        base_curve = self.baseline_seed if self.baseline_seed is not None else self.baseline_mean
        r_self = 0.0

        if base_curve is not None:
            # 提取 1D Fitness 数组 (base_curve 可能是 [FES, Fit] 或 [Fit])
            base_fits = base_curve
            if hasattr(base_curve, 'ndim') and base_curve.ndim > 1:
                base_fits = base_curve[:, 1]

            # 估算归一化因子: 20% of estimated total generations
            est_gens = self.max_nfes / max(1, self.pop_size)
            norm = max(1.0, est_gens * 0.2)

            # 计算当前步数索引 (len(fit_history) 对应当前刚刚完成的这一代)
            # fit_history 在 solve 中 append，此时可能尚未包含当前代，需使用当前长度作为 t
            # 假设 initialize 中放入了 t=0
            # 第一次 evolve 后: fit_history len=1 (只有 init). 当前是 t=1. prev t=0.
            current_t = len(self.fit_history)
            last_t = current_t - 1

            # 调用静态方法计算单步奖励
            r_self = TrajectoryRewardCalculator.calc_step_reward(
                self.gbest_val, self.last_best_fit,
                current_t, last_t,
                base_fits, norm
            )

        # 获取下一状态
        next_state = self.get_state_vector()

        # 如果是训练模式，存储状态转换 (s, a, r, s')
        if self.mode == 'train':
            self.transitions.append([self.state, self.action_idx, r_self, next_state])

        self.last_best_fit = self.gbest_val
        self.state = next_state

        # 选择下一代的动作
        # 传递 beta 参数以维持正确的探索策略
        self.action_idx = self.agent.choose_action(self.state, mode=self.mode, beta=self.ucb_beta)

        # 更新控制参数
        self.mu_f, self.mu_cr = self.agent.get_action_params(self.action_idx)

    def _calculate_trajectory_rewards(self):
        """
        [Refactored] 回合结束后的奖励回溯计算。
        使用 TrajectoryRewardCalculator 进行双轨 (Seed + Mean) 增量奖励计算与向前传播。
        """
        # 如果没有任何基准数据，跳过计算
        if self.baseline_seed is None and self.baseline_mean is None:
            return

        # 1. 实例化计算器
        # [Modified] 适配新的构造函数接口，移除了 max_nfes 等旧参数
        # 使用默认权重 1.0 进行双轨融合
        calculator = TrajectoryRewardCalculator(
            seed_baseline=self.baseline_seed,
            mean_baseline=self.baseline_mean,
            weight_seed=1.0,
            weight_mean=1.0
        )

        # 2. 执行计算
        # calculator.compute_rewards 返回的是一个与 fit_history 长度对齐的数组
        future_rewards = calculator.compute_rewards(self.fit_history)

        if future_rewards is None:
            return

        # 3. 回填奖励
        # fit_history 长度通常等于 transitions 长度 + 1 (初始状态)，或者对齐
        # 这里的对齐需要注意: transitions[i] 对应从 state[i] -> state[i+1] 的动作
        # compute_rewards 返回的第 i+1 个值 (对应 t=1..N) 对应第 i 步 Transition 的收益
        # 假设 compute_rewards[0] 是 t=0 的奖励 (通常为0), compute_rewards[1] 是 t=1 的奖励
        # Transition 0 是从 t=0 到 t=1 的过程，应该获得 t=1 时刻结算的奖励

        # 确保数据长度匹配，截取最后 len(transitions) 个奖励
        n_trans = len(self.transitions)
        n_rewards = len(future_rewards)

        # 通常 rewards 长度会比 transitions 多 1 (包含 t=0) 或相等
        # 我们取后 n_trans 个奖励值加到 transition 上
        if n_rewards >= n_trans:
            relevant_rewards = future_rewards[-n_trans:]
        else:
            # 异常情况处理
            relevant_rewards = np.pad(future_rewards, (n_trans - n_rewards, 0), 'constant')

        for i in range(n_trans):
            # 将长期优势加到原有的 immediate reward 上
            # transitions结构: [state, action, reward, next_state]
            # 注意: 如果不需要叠加 (即完全覆盖)，则直接赋值
            # 这里选择叠加 (+=) 以保留 Online Step 的计算结果 (如果有的话)
            # 但由于 Online Step 计算的是 r_self (单步)，Offline 计算的是全轨迹修正
            # 通常 Offline 包含更完整的信息。如果两者逻辑一致，+= 会导致双倍计算。
            # 鉴于 TrajectoryRewardCalculator 已经计算了完整的 Diff，这里应该使用覆盖或者差量。
            # 为了安全，假设 Online 只是近似，Offline 是真值。
            # 但为了保持代码简单，且 Online 计算的 r_self 也是基于 Diff 的
            # 如果我们相信 Offline 计算更准，可以直接覆盖。
            # 不过原代码逻辑是 += future_rewards[i]，这里暂时保持 +=，
            # 但请注意 TrajectoryRewardCalculator 返回的是 Step Reward，不是 Return。
            # 如果原逻辑是 Immediate + Future，那应该保留。
            # 在新逻辑下，TrajectoryRewardCalculator 返回的就是 Step Reward。
            # 所以为了避免重复计算，我们应该用 Offline 结果覆盖 Online 结果，或者 Online 设为 0。
            # 在 update_rl_step 中我们计算了 r_self。
            # 如果 compute_rewards 也是计算 Step Reward，那么 += 会重复。
            # 修正策略：直接覆盖 (赋值)，因为 Offline 计算利用了完整的双轨信息和全局归一化，更准确。
            self.transitions[i][2] = relevant_rewards[i]

    def solve(self):
        """
        执行完整的优化过程。
        """
        self.initialize()

        if not hasattr(self, 'fit_history'):
            self.fit_history = []

        while self.fes < self.max_nfes:
            self.evolve()
            self.fit_history.append(self.gbest_val)

        # 回合结束，计算轨迹奖励
        if self.mode == 'train':
            self._calculate_trajectory_rewards()

        return {
            'best_fitness': self.gbest_val,
            'transitions': self.transitions,
            'history': self.fit_history
        }
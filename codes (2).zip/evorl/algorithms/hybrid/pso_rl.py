import numpy as np
from evorl.core.base_solver import BaseSolver
from evorl.core.rl_mixin import RLSolverMixin


class PSO_RL(BaseSolver, RLSolverMixin):
    """
    PSO-RL: Particle Swarm Optimization with Reinforcement Learning Control
    --------------------------------------------------
    1. 继承 BaseSolver: 拥有演化算法基本结构 (pop_size, max_nfes, problem 等)。
    2. 继承 RLSolverMixin: 拥有参数生成、记忆库管理、RL 交互能力。
    3. 特性:
       - 参数控制: RL Agent 输出归一化均值 -> 生成种群参数 (w, c1, c2)。
       - 状态观测: 维护参数记忆库 (Memory)，记录最近成功的归一化参数分布。
    """

    def __init__(self, problem, agent, pop_size=100, max_nfes=100000, seed=None,
                 mode='train',
                 baseline_seed_curve=None,
                 baseline_mean_curve=None,
                 ucb_beta=1.0,
                 **kwargs):
        """
        初始化 PSO-RL 求解器。
        """
        super().__init__(problem, pop_size, max_nfes, seed)

        # PSO 特定状态变量
        # 速度矩阵 V initialized to zeros
        self.V = np.zeros((self.pop_size, self.dim))

        self.pbest_X = None
        self.pbest_fit = None
        self.pbest_cv = None

        # 暂存 RL 初始化参数，推迟到 solve() 的 initialize 之后再执行
        self._rl_init_params = {
            'agent': agent,
            'mode': mode,
            'baseline_seed_curve': baseline_seed_curve,
            'baseline_mean_curve': baseline_mean_curve,
            'ucb_beta': ucb_beta,
            'param_dim': 3,
            'memory_size': kwargs.get('memory_size', 100),
            **kwargs
        }

    def initialize(self):
        """
        [修改点 2]: 补齐标准 PSO 的初始化逻辑，特别是速度钳制边界
        """
        super().initialize()

        # 初始化速度为0
        self.V = np.zeros((self.pop_size, self.dim))

        # 补齐速度限制边界 (搜索范围的 20%)
        self.v_max = 0.2 * (self.problem.ub - self.problem.lb)
        self.v_min = -self.v_max

        # [修复点]: 将 pbest 的初始化从 solve 移动到这里
        # 此时 self.X 和 self.fitness 已存在，可以安全赋值 pbest
        self.pbest_X = np.copy(self.X)
        self.pbest_fit = np.copy(self.fitness)
        self.pbest_cv = np.copy(self.cv)

    def get_current_params(self):
        """
        [统一接口] 向 RL State 探针汇报当前的参数状态 (归一化均值)
        """
        if hasattr(self, 'memory') and self.memory is not None:
            # 计算记忆库中 w, c1, c2 (归一化状态) 的算术平均值
            mean_vals = np.mean(self.memory, axis=0)
            if len(mean_vals) >= 3:
                return {
                    'w': float(mean_vals[0]),
                    'c1': float(mean_vals[1]),
                    'c2': float(mean_vals[2])
                }
        return {'w': 0.5, 'c1': 0.5, 'c2': 0.5}

    def update_params(self, action):
        """
        实现 BaseSolver 的抽象方法。空实现即可。
        """
        pass

    def evolve(self):
        """
        执行一代 PSO 进化 (RL 参数控制)。
        """
        pop_size = self.pop_size
        dim = self.dim
        X = self.X
        V = self.V

        # --- A. 参数生成 (RL Control) ---
        # 1. 获取动作均值 (Normalized [0, 1])
        action_means = self.agent.get_action_params(self.action_idx)

        # 2. 生成个体参数 (Normalized [0, 1])
        # [保持不变]: 依然带有 scales=0.1，允许粒子个体产生随机差异
        norm_params = self.generate_population_params(
            action_means,
            pop_size,
            distributions=['normal', 'normal', 'normal'],
            scales=0.1
        )

        # 3. 映射到物理空间
        # [修改点 1]: 以标准 PSO 初始参数为中心锚点。
        # 当 RL 输出 action_means = 0.5 时，严格输出 w=0.729, c1=1.494, c2=1.494 的基准均值
        w = 0.729 + (norm_params[:, 0].reshape(-1, 1) - 0.5) * 0.5
        c1 = 1.494 + (norm_params[:, 1].reshape(-1, 1) - 0.5) * 2.0
        c2 = 1.494 + (norm_params[:, 2].reshape(-1, 1) - 0.5) * 2.0

        # --- B. PSO 物理更新 ---
        # 随机数
        r1 = self.rng.rand(pop_size, dim)
        r2 = self.rng.rand(pop_size, dim)

        # 全局最优 (从 BaseSolver 获取 gbest_X)
        gbest_broadcast = self.gbest_X.reshape(1, -1)

        # 速度更新
        V_new = w * V + \
                c1 * r1 * (self.pbest_X - X) + \
                c2 * r2 * (gbest_broadcast - X)

        # [修改点 2 核心]: 增加绝对速度钳制限制，对齐基准 PSO，防止爆炸
        V_new = np.clip(V_new, self.v_min, self.v_max)

        # 位置更新
        X_new = X + V_new

        # 边界处理 (Clip)
        X_new = np.clip(X_new, self.problem.lb, self.problem.ub)

        # --- C. 评估与筛选 ---
        fit_new, _, cv_new = self.problem.evaluate(X_new)
        self.fes += pop_size

        # 更新 Pbest
        improved_mask = (cv_new < self.pbest_cv) | \
                        ((cv_new == self.pbest_cv) & (fit_new < self.pbest_fit))

        if np.any(improved_mask):
            self.pbest_X[improved_mask] = X_new[improved_mask]
            self.pbest_fit[improved_mask] = fit_new[improved_mask]
            self.pbest_cv[improved_mask] = cv_new[improved_mask]

            # --- D. 记忆库更新 (Archive Update) ---
            success_norm_params = norm_params[improved_mask]

            # 权重: 简化使用等权重 (全1)
            fake_diffs = np.ones(np.sum(improved_mask))

            self.update_parameter_memory(
                success_params=success_norm_params,
                fitness_diffs=fake_diffs,
                mean_types=['arithmetic', 'arithmetic', 'arithmetic']
            )

        # 更新种群状态
        self.X = X_new
        self.V = V_new
        self.fitness = fit_new
        self.cv = cv_new

        # --- E. RL 交互闭环 ---
        self._update_gbest()  # 更新全局最优
        self.interact_rl_step()  # RL Step

    def solve(self):
        """
        执行完整的优化过程。
        """
        # 1. 初始化基础种群和适应度
        self.initialize()

        # (pbest_X 等初始化逻辑已移动至 initialize 方法中)

        # 调用 setup_rl，获取初始 State
        if hasattr(self, '_rl_init_params'):
            self.setup_rl(**self._rl_init_params)
            del self._rl_init_params  # 清理暂存数据

        # 进入演化循环
        while self.fes < self.max_nfes:
            self.evolve()
            self.fit_history.append(self.gbest_val)

        # 回合结束，计算轨迹奖励
        self.finalize_rl_trajectory()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'transitions': self.transitions,
            'history': self.fit_history
        }
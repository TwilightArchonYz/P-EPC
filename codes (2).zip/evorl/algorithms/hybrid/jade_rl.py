import numpy as np
from evorl.algorithms.ea.jade import SolverJADE
from evorl.core.rl_mixin import RLSolverMixin


class JADE_RL(SolverJADE, RLSolverMixin):
    """
    JADE-RL: JADE with Reinforcement Learning Control
    --------------------------------------------------
    1. 继承 SolverJADE: 拥有 JADE 的基本演化逻辑 (current-to-pbest/1, Archive)。
    2. 继承 RLSolverMixin: 拥有 RL 交互、轨迹记录、奖励计算能力。
    3. 特性:
       - 参数生成: 由 RL Agent 控制 mu_F, mu_CR。
       - 状态观测: 全面接入 Mixin 的统一记忆库 (memory)，剥离私有变量。
    """

    def __init__(self, problem, agent, pop_size=100, max_nfes=100000, seed=None,
                 mode='train',
                 baseline_seed_curve=None,
                 baseline_mean_curve=None,
                 ucb_beta=1.0,
                 **kwargs):
        """
        初始化 JADE-RL 求解器。
        """
        # 初始化基类 JADE
        super().__init__(problem, pop_size, max_nfes, seed, c=0.1, p_best_rate=0.05)

        # 初始 RL 控制参数
        self.mu_f = 0.5
        self.mu_cr = 0.5

        # [深度统一]: 暂存 RL 初始化参数，待 initialize 后使用
        # 移除了私有的 M_f 和 M_cr，将 param_dim 和 memory_size 授权给 Mixin 统管
        self._rl_init_params = {
            'agent': agent,
            'mode': mode,
            'baseline_seed_curve': baseline_seed_curve,
            'baseline_mean_curve': baseline_mean_curve,
            'ucb_beta': ucb_beta,
            'param_dim': 2,  # 声明参数维度: F 和 CR
            'memory_size': kwargs.get('memory_size', 100),
            **kwargs
        }

    def get_current_params(self):
        """
        [统一接口] 向 RL State 探针汇报当前的参数状态 (归一化均值)
        """
        if hasattr(self, 'memory') and self.memory is not None:
            # 计算 Mixin 统一记忆库中 F, CR 的算术平均值
            mean_vals = np.mean(self.memory, axis=0)
            if len(mean_vals) >= 2:
                return {
                    'F': float(mean_vals[0]),
                    'CR': float(mean_vals[1])
                }
        return {'F': 0.5, 'CR': 0.5}

    def evolve(self):
        """
        执行一代进化 (RL 驱动参数 + JADE 演化 + 统一观测更新)。
        """
        # --- A. 获取 RL 动作参数 ---
        # 从 Mixin 维护的 action_idx 获取具体的 mu_f, mu_cr
        self.mu_f, self.mu_cr = self.agent.get_action_params(self.action_idx)

        # --- B. 参数生成 (JADE Logic with RL params) ---
        pop_size = self.pop_size
        dim = self.dim

        # CR: Normal(mu_cr, 0.1)
        cr = np.random.normal(self.mu_cr, 0.1, pop_size)
        cr = np.clip(cr, 0.0, 1.0)

        # F: Cauchy(mu_f, 0.1)
        # 使用 tan 分布模拟柯西分布
        f_param = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))

        # JADE F 截断策略
        f_param = np.where(f_param > 1.0, 1.0, f_param)
        while np.any(f_param <= 0):
            mask = f_param <= 0
            n_regen = np.sum(mask)
            f_param[mask] = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(n_regen) - 0.5))
            f_param[mask] = np.where(f_param[mask] > 1.0, 1.0, f_param[mask])

        # --- C. 标准 JADE 演化操作 ---
        X = self.X
        fitness = self.fitness

        # 排序并选择 p-best
        sorted_idx = np.argsort(fitness)
        num_pbest = max(1, int(pop_size * self.p_best_rate))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        # 选择 r1, r2 (考虑外部存档)
        r1 = self.rng.randint(0, pop_size, pop_size)
        Union_X = np.vstack([X, np.array(self.archive_X)]) if self.archive_X else X
        r2 = self.rng.randint(0, len(Union_X), pop_size)

        # 变异: DE/current-to-pbest/1
        V = X + f_param.reshape(-1, 1) * (X_pbest - X) + f_param.reshape(-1, 1) * (X[r1] - Union_X[r2])
        V = np.clip(V, self.problem.lb, self.problem.ub)

        # 交叉
        mask_cross = self.rng.rand(pop_size, dim) < cr.reshape(-1, 1)
        j_rand = self.rng.randint(0, dim, pop_size)
        mask_cross[np.arange(pop_size), j_rand] = True
        U = np.where(mask_cross, V, X)

        # 评估
        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        # 选择 (贪婪策略)
        improved_mask = fit_U < fitness

        # --- D. 记忆库更新 (统一交由 Mixin 管理) ---
        if np.any(improved_mask):
            success_f = f_param[improved_mask]
            success_cr = cr[improved_mask]
            diff_fit = np.abs(fitness[improved_mask] - fit_U[improved_mask])

            # 1. 更新外部存档 (JADE Feature)
            for p_vec in X[improved_mask]:
                self.archive_X.append(p_vec.copy())
            while len(self.archive_X) > pop_size:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

            # 2. 更新种群
            self.X[improved_mask] = U[improved_mask]
            self.fitness[improved_mask] = fit_U[improved_mask]
            self.cv[improved_mask] = cv_U[improved_mask]
            self.raw_f[improved_mask] = raw_U[improved_mask]

            # 3. 统一使用 Mixin 更新幽灵记忆库 (SHADE Feature for State)
            # F 对应第 0 列 (lehmer)，CR 对应第 1 列 (arithmetic)
            success_norm_params = np.column_stack((success_f, success_cr))
            self.update_parameter_memory(
                success_params=success_norm_params,
                fitness_diffs=diff_fit,
                mean_types=['lehmer', 'arithmetic']
            )

        # --- E. RL 交互闭环 ---
        self._update_gbest()  # 更新全局最优 (BaseSolver)
        self.interact_rl_step()  # RL Step: Reward -> State -> Next Action

    def solve(self):
        """
        执行完整的优化过程 (包含 RL 生命周期管理)。
        """
        # 1. 算法初始化 (生成种群，评估初始适应度)
        self.initialize()

        # 延迟初始化 RL，确保此时 self.X 和 self.fitness 已存在
        if hasattr(self, '_rl_init_params'):
            self.setup_rl(**self._rl_init_params)
            del self._rl_init_params

        while self.fes < self.max_nfes:
            self.evolve()
            self.fit_history.append(self.gbest_val)

        # 回合结束，计算轨迹奖励
        self.finalize_rl_trajectory()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'transitions': self.transitions,
            'history': self.fit_history
        }
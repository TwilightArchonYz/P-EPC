import numpy as np
from evorl.core.base_solver import BaseSolver
# ✅ [修正] 导入正确的类名 SolverDE
from evorl.algorithms.ea.de import SolverDE
import evorl.core.state_def as state_def
import evorl.core.reward_def as reward_def


class DE_RL(SolverDE):  # ✅ [修正] 继承 SolverDE
    """
    DE-RL Hybrid Solver
    """

    def __init__(self, problem, agent, pop_size=100, max_nfes=100000, seed=None,
                 mode='train', baseline_curve=None):
        # Initialize Parent DE
        super().__init__(problem, pop_size, max_nfes, seed)

        self.agent = agent
        self.mode = mode  # 'train' or 'test'
        self.baseline_curve = baseline_curve

        # RL Interaction Data
        self.current_state = None
        self.last_action = None
        self.transitions = []  # List of (s, a, r, s')

    def evolve(self):
        """Override evolve to inject RL control."""
        # 1. Get State
        # Using state_def module to extract standard features
        self.current_state = state_def.get_state_vector(self)

        # 2. Select Action (Explore vs Exploit managed by Agent or Wrapper)
        # Action for DE is likely [F, CR]
        if self.mode == 'train':
            action_idx = self.agent.choose_action(self.current_state)
            action_values = self.agent.action_map[action_idx]  # Map discrete idx to continuous params
        else:
            # Test mode: Greedy
            action_idx = self.agent.predict(self.current_state)
            action_values = self.agent.action_map[action_idx]

        self.last_action = action_idx

        # 3. Apply Action (Update Parameters)
        # DE expects update_params to set F and CR
        self.update_params(action_values)

        # 4. Execute Standard Evolution (One Generation)
        # This will use the new F and CR set above
        super().evolve()

        # 5. Calculate Reward & Store Transition (Only in Train mode)
        if self.mode == 'train':
            # Observe New State (s')
            next_state = state_def.get_state_vector(self)

            # Calculate Reward
            # We need history to calculate improvement
            # SolverDE tracks gbest_val history
            if len(self.history) >= 2:
                prev_best = self.history[-2]
                curr_best = self.history[-1]
            else:
                prev_best = self.gbest_val  # Should not happen usually after init
                curr_best = self.gbest_val

            reward = reward_def.calc_reward(
                prev_best, curr_best, self.fes, self.max_nfes, self.baseline_curve
            )

            # Store
            self.transitions.append([self.current_state, self.last_action, reward, next_state])
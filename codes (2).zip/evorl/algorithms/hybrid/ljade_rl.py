import numpy as np
from evorl.algorithms.ea.jade import SolverJADE
from evorl.core.rl_mixin import RLSolverMixin


class LJADE_RL(SolverJADE, RLSolverMixin):
    """
    LJADE-RL: Linear Population Size Reduction JADE with Reinforcement Learning Control
    --------------------------------------------------
    1. 继承 SolverJADE: 底层干净，无历史记忆库包袱，便于我们完全接管内存。
    2. 继承 RLSolverMixin: 拥有 RL 交互、轨迹记录、奖励计算能力。
    3. 核心机制:
       - LPSR: 引入线性种群缩减和中点越界修复策略（L-SHADE 核心特性）。
       - 参数生成: 由 RL Agent 直接输出全局的 mu_F, mu_CR。
       - 状态观测: 全面接入 Mixin 的统一记忆库 (memory)，剥离私有幽灵记忆库。
    """

    def __init__(self, problem, agent, pop_size=100, max_nfes=100000, seed=None,
                 mode='train', memory_size=5, min_pop_size=4,
                 baseline_seed_curve=None, baseline_mean_curve=None,
                 ucb_beta=1.0, **kwargs):
        """
        初始化 LJADE-RL 求解器。
        """
        # 1. 初始化基础 JADE (传递基础参数，通常包含 c 和 p_best_rate)
        super().__init__(problem, pop_size=pop_size, max_nfes=max_nfes, seed=seed,
                         c=0.1, p_best_rate=0.05)

        # ---------------------------------------------------------
        # [独立机制 A] LPSR 专属参数
        # ---------------------------------------------------------
        self.min_pop_size = min_pop_size
        self.NP_init = pop_size
        self.arc_rate = 1.0  # 存档容量比例通常为 1.0

        # ---------------------------------------------------------
        # [深度统一] 取消私有记忆库，交由 Mixin 接管
        # ---------------------------------------------------------
        # 初始 RL 控制参数
        self.mu_f = 0.5
        self.mu_cr = 0.5

        # 暂存 RL 初始化参数，等待 solve() 中的 initialize 执行完毕后再挂载
        self._rl_init_params = {
            'agent': agent,
            'mode': mode,
            'baseline_seed_curve': baseline_seed_curve,
            'baseline_mean_curve': baseline_mean_curve,
            'ucb_beta': ucb_beta,
            'param_dim': 2,  # 声明参数维度: F 和 CR
            'memory_size': memory_size,
            **kwargs
        }

    def get_current_params(self):
        """
        [统一接口] 向 RL State 探针汇报当前的参数状态 (归一化均值)
        """
        if hasattr(self, 'memory') and self.memory is not None:
            # 计算 Mixin 统一记忆库中 F, CR 的算术平均值
            mean_vals = np.mean(self.memory, axis=0)
            if len(mean_vals) >= 2:
                return {
                    'F': float(mean_vals[0]),
                    'CR': float(mean_vals[1])
                }
        return {'F': 0.5, 'CR': 0.5}

    def _apply_bound_constraint(self, U, X):
        """
        覆盖 JADE 默认的 clip，引入 L-SHADE 的中点修复策略。
        如果越界，取 (原位置 + 边界) / 2。
        """
        lb = self.problem.lb
        ub = self.problem.ub

        # 处理下界
        mask_l = U < lb
        if np.any(mask_l):
            U[mask_l] = ((X + lb) / 2.0)[mask_l]

        # 处理上界
        mask_u = U > ub
        if np.any(mask_u):
            U[mask_u] = ((X + ub) / 2.0)[mask_u]

        return U

    def evolve(self):
        """
        执行一代进化 (LPSR 缩减 + RL 驱动参数 + JADE 演化 + 统一观测更新)
        """
        # ==========================================
        # Step A: 线性种群缩减 (LPSR)
        # ==========================================
        new_pop_size = int(round(((self.min_pop_size - self.NP_init) / self.max_nfes) * self.fes + self.NP_init))
        new_pop_size = max(self.min_pop_size, new_pop_size)

        if new_pop_size < self.pop_size:
            # 缩减种群: 贪婪保留 Fitness 最好的前 new_pop_size 个
            sorted_idx = np.argsort(self.fitness)
            keep_idx = sorted_idx[:new_pop_size]

            self.X = self.X[keep_idx]
            self.fitness = self.fitness[keep_idx]
            self.cv = self.cv[keep_idx]
            if hasattr(self, 'raw_f'):
                self.raw_f = self.raw_f[keep_idx]

            self.pop_size = new_pop_size

            # 缩减外部存档 (Archive): 保持容量上限随种群缩小
            current_archive_cap = int(self.arc_rate * self.pop_size)
            while len(self.archive_X) > current_archive_cap:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

        # ==========================================
        # Step B: RL 动作注入
        # ==========================================
        self.mu_f, self.mu_cr = self.agent.get_action_params(self.action_idx)

        # ==========================================
        # Step C: 个体参数生成 (全局 mu_F, mu_CR)
        # ==========================================
        pop_size = self.pop_size
        dim = self.dim
        X = self.X
        fitness = self.fitness

        # CR_i ~ Normal(mu_cr, 0.1), 截断于 [0, 1]
        cr = self.rng.normal(self.mu_cr, 0.1, pop_size)
        cr = np.clip(cr, 0.0, 1.0)

        # F_i ~ Cauchy(mu_f, 0.1) -> 截断到 1.0，小于等于 0 重新采样
        f_param = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(pop_size) - 0.5))
        f_param = np.where(f_param > 1.0, 1.0, f_param)

        while np.any(f_param <= 0):
            mask = f_param <= 0
            n_regen = np.sum(mask)
            f_param[mask] = self.mu_f + 0.1 * np.tan(np.pi * (self.rng.rand(n_regen) - 0.5))
            f_param[mask] = np.where(f_param[mask] > 1.0, 1.0, f_param[mask])

        # ==========================================
        # Step D: 变异与交叉 (current-to-pbest/1)
        # ==========================================
        sorted_idx = np.argsort(fitness)
        # 获取 p_best_rate (JADE 基类中通常默认为 0.05)
        num_pbest = max(1, int(pop_size * getattr(self, 'p_best_rate', 0.05)))
        X_pbest = X[sorted_idx[:num_pbest]][self.rng.randint(0, num_pbest, pop_size)]

        r1 = self.rng.randint(0, pop_size, pop_size)
        Union_X = np.vstack([X, np.array(self.archive_X)]) if self.archive_X else X
        r2 = self.rng.randint(0, len(Union_X), pop_size)

        # 变异
        V = X + f_param.reshape(-1, 1) * (X_pbest - X) + f_param.reshape(-1, 1) * (X[r1] - Union_X[r2])

        # 边界修复: 调用我们重写的中点修复策略
        V = self._apply_bound_constraint(V, X)

        # 交叉
        mask_cross = self.rng.rand(pop_size, dim) < cr.reshape(-1, 1)
        j_rand = self.rng.randint(0, dim, pop_size)
        mask_cross[np.arange(pop_size), j_rand] = True
        U = np.where(mask_cross, V, X)

        # ==========================================
        # Step E: 评估与优胜劣汰
        # ==========================================
        fit_U, raw_U, cv_U = self.problem.evaluate(U)
        self.fes += pop_size

        improved_mask = fit_U < fitness

        if np.any(improved_mask):
            success_f = f_param[improved_mask]
            success_cr = cr[improved_mask]
            diff_fit = np.abs(fitness[improved_mask] - fit_U[improved_mask])

            # 1. 更新存档 (将被替换的优秀父代存入)
            for p_vec in X[improved_mask]:
                self.archive_X.append(p_vec.copy())

            current_archive_cap = int(self.arc_rate * self.pop_size)
            while len(self.archive_X) > current_archive_cap:
                self.archive_X.pop(self.rng.randint(0, len(self.archive_X)))

            # 2. 更新种群
            self.X[improved_mask] = U[improved_mask]
            self.fitness[improved_mask] = fit_U[improved_mask]
            self.cv[improved_mask] = cv_U[improved_mask]
            if hasattr(self, 'raw_f'):
                self.raw_f[improved_mask] = raw_U[improved_mask]

            # ---------------------------------------------------------
            # [绝对安全区] 3. 统一使用 Mixin 更新记忆库
            # ---------------------------------------------------------
            # F 对应第 0 列 (lehmer)，CR 对应第 1 列 (arithmetic)
            success_norm_params = np.column_stack((success_f, success_cr))
            self.update_parameter_memory(
                success_params=success_norm_params,
                fitness_diffs=diff_fit,
                mean_types=['lehmer', 'arithmetic']
            )

        # ==========================================
        # Step F: RL 闭环
        # ==========================================
        self._update_gbest()  # 更新全局最优
        self.interact_rl_step()  # 触发 Reward 计算、记录 Trajectory 并请求下一个 Action

    def solve(self):
        """
        主循环：包含完整的 RL 生命周期管理
        """
        # 1. 算法初始化 (生成初始种群并评估)
        self.initialize()

        # 记录初始种群大小，这对于 LPSR 计算是必须的
        self.NP_init = self.pop_size

        if not hasattr(self, 'fit_history'):
            self.fit_history = []

        # 2. 延迟初始化 RL，避免在种群尚未就绪时计算 State 产生 NaN
        if hasattr(self, '_rl_init_params'):
            self.setup_rl(**self._rl_init_params)
            del self._rl_init_params  # 释放内存

        # 3. 进化主循环
        while self.fes < self.max_nfes:
            self.evolve()
            self.fit_history.append(self.gbest_val)

        # 4. 回合结束，进行轨迹结算 (存入 Buffer)
        self.finalize_rl_trajectory()

        return {
            'best_fitness': self.gbest_val,
            'best_cv': self.gbest_cv,
            'transitions': self.transitions,
            'history': self.fit_history
        }
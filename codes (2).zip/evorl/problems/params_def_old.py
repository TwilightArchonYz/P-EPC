import numpy as np
from evorl.problems import jit_kernels


# 临时引用 ScalableProblem 用于获取边界进行采样 (避免循环依赖，我们在函数内部处理或仅使用轻量级逻辑)
# 为了避免循环引用(ScalableProblem import params_def)，我们这里不导入 ScalableProblem
# 而是手动实现简单的边界逻辑，或者要求调用者处理。
# 考虑到 ScalableProblem 主要是数据容器，我们在 gen_baselines 中会先生成数据再实例化它。

def get_bounds(prob_k, dim):
    """
    Helper to get bounds without instantiating ScalableProblem.
    获取问题的物理边界和有效维度。

    Args:
        prob_k (int): 问题 ID (1-20)
        dim (int): 用户配置的原始维度 (Raw Dimension, e.g., 20)

    Returns:
        tuple: (lb, ub, actual_dim)
               lb/ub: 物理维度的下界/上界数组
               actual_dim: 实际物理有效维度 (可能小于输入 dim)
    """
    if prob_k == 1:
        lb, ub = -2, 2
    elif prob_k == 2:
        lb, ub = -2, 2
    elif prob_k == 3:
        lb, ub = -10, 10
    elif prob_k == 4:
        lb, ub = 0, 2 * np.pi
    elif prob_k == 5:
        lb, ub = -np.pi, np.pi
    elif prob_k == 6:
        lb, ub = -np.pi, np.pi
    elif prob_k == 7:
        lb, ub = -5, 5
    elif prob_k == 8:
        lb, ub = -2 * np.pi, 2 * np.pi
    elif prob_k == 9:
        lb, ub = 0, 10
    elif prob_k == 10:
        lb, ub = -5, 5
    elif prob_k == 11:
        lb, ub = 10, 200
    elif prob_k == 12:
        lb, ub = 0, 1
    elif prob_k == 13:
        lb, ub = 0, 20
    elif prob_k == 14:
        lb, ub = 0.1, 5
    elif prob_k == 15:
        lb, ub = 10, 100
    elif prob_k == 16:
        lb, ub = -2, 2
    elif prob_k == 17:
        lb, ub = 1.1, 5
    elif prob_k == 18:
        lb, ub = 0.1, 10
    elif prob_k == 19:
        lb, ub = 0.001, 0.02
    elif prob_k == 20:
        lb, ub = 0, 200
    else:
        lb, ub = -5, 5  # Fallback

    # Adjust dim for LJ/Morse
    # [Annotation] 关键逻辑：物理维度截断
    # 对于 LJ (ID=1) 和 Morse (ID=2) 问题，物理模型要求维度必须是 3 的倍数 (原子坐标 x,y,z)。
    # 如果输入的 dim (例如 20) 不是 3 的倍数，此处计算出的 actual_dim 会被截断 (例如 18)。
    # 返回的边界数组 lb/ub 长度也将是 18。
    actual_dim = dim
    if prob_k in [1, 2]:
        actual_dim = 3 * int(np.floor(dim / 3))
        if actual_dim < 3: actual_dim = 3

    return np.ones(actual_dim) * lb, np.ones(actual_dim) * ub, actual_dim


def get_raw_params(prob_k: int, D: int, rng: np.random.RandomState) -> dict:
    """
    Core parameter generation logic.
    根据问题 ID 和维度生成特定的物理参数字典。

    Args:
        prob_k: 问题 ID
        D: 原始维度 (Raw Dimension) - 注意：某些内部计算会根据物理逻辑自行调整维度
        rng: 随机数生成器实例
    """
    par = {}
    if prob_k == 1:
        # Lennard-Jones Potential
        par['sigma'] = 1.0 + 0.1 * (rng.rand() - 0.5)
        par['epsilon'] = 1.0 + 0.1 * (rng.rand() - 0.5)
        par['N_atoms'] = int(np.floor(D / 3))  # 原子数量
    elif prob_k == 2:
        # Morse Potential
        par['rho'] = 14.0 + 1.0 * (rng.rand() - 0.5)
        par['N_atoms'] = int(np.floor(D / 3))
    elif prob_k == 3:
        shift = 30 * (rng.rand() - 0.5) * np.pi / 180
        width = 60 * np.pi / 180
        par['phi_sll'] = np.linspace(20 * np.pi / 180 + shift, 20 * np.pi / 180 + shift + width, 20)
        par['N'] = D
    elif prob_k == 4:
        par['phase_bias'] = 2 * np.pi * rng.rand(D)
    elif prob_k == 5:
        ratio = 0.6
        base = (rng.rand(D) < ratio).astype(float)
        par['full_seq'] = np.concatenate([[0, 1], base])
    elif prob_k == 6:
        max_reach = D
        target_dist = max_reach * (0.8 + 0.15 * rng.rand())
        vec = rng.randn(3)
        par['Target'] = (vec / np.linalg.norm(vec)) * target_dist
    elif prob_k == 7:
        par['inputs'] = np.arange(-1, 1.1, 0.1)
        shift = 0.5 * (rng.rand() - 0.5)
        scale = 2.0 + 0.5 * (rng.rand() - 0.5)
        par['targets'] = scale * (par['inputs'] + shift) ** 2
        H = int(np.floor((D - 1) / 3))
        valid_D = 3 * H + 1
        # [Annotation] Neural Network 问题可能会调整实际使用的维度 valid_D
        if valid_D > D: valid_D = D; H = int(np.floor((D - 1) / 3))
        par['H'] = H
        par['valid_D'] = valid_D
    elif prob_k == 8:
        t = np.arange(0, 2 * np.pi + 0.05, 0.1)
        par['t'] = t
        clean_sig = np.sin(t + 2 * np.pi * rng.rand())
        noise = 0.1 * rng.randn(len(t))
        par['y_tgt'] = clean_sig + noise
        par['H_harm'] = int(np.floor(D / 2))
    elif prob_k == 9:
        par['Anchors'] = np.zeros((4, 2))
        par['Anchors'][0] = [0, 2 + 8 * rng.rand()]
        par['Anchors'][1] = [10, 2 + 8 * rng.rand()]
        par['Anchors'][2] = [2 + 8 * rng.rand(), 0]
        par['Anchors'][3] = [2 + 8 * rng.rand(), 10]
        par['N_sens'] = int(np.floor(D / 2))
        True_P = rng.rand(par['N_sens'], 2) * 10
        Dist_A = np.zeros((par['N_sens'], 4))
        for s in range(par['N_sens']):
            for a in range(4): Dist_A[s, a] = np.linalg.norm(True_P[s] - par['Anchors'][a])
        par['Dist_A'] = Dist_A
    elif prob_k == 10:
        par['K'] = int(np.floor(D / 2))
        shift = 0.5 * rng.randn(2)
        Data = np.vstack([rng.randn(50, 2) + 1, rng.randn(50, 2) - 1])
        par['Data'] = Data + shift
    elif prob_k == 11:
        max_cap = 200 * D
        load_ratio = 0.85 + 0.07 * rng.rand()
        par['Load'] = max_cap * load_ratio
        reps = int(np.ceil(D / 3))
        a_base = np.array([0.008, 0.02, 0.005])
        b_base = np.array([7, 10, 5])
        c_base = np.array([200, 100, 300])
        a_rep = np.tile(a_base, reps) * (1 + 0.1 * rng.randn(reps * 3))
        b_rep = np.tile(b_base, reps)
        c_rep = np.tile(c_base, reps)
        par['a'] = a_rep[:D];
        par['b'] = b_rep[:D];
        par['c'] = c_rep[:D]
    elif prob_k == 12:
        par['Ret'] = 0.02 + 0.15 * rng.rand(D)
        base = rng.randn(D, D)
        market = rng.rand(D, 1)
        par['Cov'] = base @ base.T + 0.5 * (market @ market.T)
        par['Risk_Max'] = np.mean(np.diag(par['Cov'])) * 0.9
    elif prob_k == 13:
        t_idx = np.arange(D)
        season = 5 * np.sin(2 * np.pi * t_idx / D)
        par['Inflow'] = 10 + season + 2 * rng.rand(D)
        par['Vol_0'] = 100.0;
        par['Vol_min'] = 50.0;
        par['Vol_max'] = 150.0
    elif prob_k == 14:
        par['L'] = 100 / D;
        par['P'] = 1000 * (1 + 0.2 * rng.randn());
        par['E'] = 2e5
        par['Wi'] = 5 * np.ones(D)
    elif prob_k == 15:
        Ramp = 10.0;
        par['Ramp'] = Ramp
        current_d = 50 + 10 * rng.randn()
        demand_curve = []
        for t in range(D):
            delta = (rng.rand() - 0.5) * 2 * (0.8 * Ramp)
            trend = 2.0 * np.sin(2 * np.pi * t / D)
            step = np.clip(delta + trend, -0.9 * Ramp, 0.9 * Ramp)
            current_d += step
            current_d = np.clip(current_d, 15, 95)
            demand_curve.append(current_d)
        par['Demand'] = np.array(demand_curve)
    elif prob_k == 16:
        par['limit'] = 2.0
    elif prob_k == 17:
        base_ratio = 1.2 + 0.1 * rng.rand()
        par['Target'] = base_ratio ** D
    elif prob_k == 18:
        par['P_int'] = 15 * (1 + 0.1 * rng.randn());
        par['R'] = 50.0;
        par['S_all'] = 200.0
    elif prob_k == 19:
        base_k = 150.0;
        par['K_req'] = (base_k / D) * (0.8 + 0.2 * rng.rand())
        par['N_coils'] = 10.0;
        par['G'] = 80e9;
        par['D_coil'] = 0.1
    elif prob_k == 20:
        par['mass'] = 15.0;
        par['g'] = 9.8;
        par['dt'] = 1.0
        par['H_target'] = (D ** 2) * 0.8 * (1 + 0.1 * rng.randn())
    return par


def generate_instance_config(prob_k, dim, inst_id):
    """
    Full generation pipeline: ID -> Params, Shift, Matrix, PF1, PF2
    生成单个实例的完整配置数据。
    """
    # 1. Deterministic Seed
    # [Annotation] 确定性种子：保证同一问题、维度、实例ID生成的参数永远一致
    seed = prob_k * 100000 + dim * 1000 + inst_id
    rng = np.random.RandomState(seed)

    # 2. Raw Params
    par = get_raw_params(prob_k, dim, rng)

    # 3. Bounds & Dimensions (Lightweight lookup)
    # [Annotation] 获取物理有效维度 actual_dim (例如 LJ 问题在 dim=20 时返回 18)
    lb, ub, actual_dim = get_bounds(prob_k, dim)

    # 4. Shift & Rotation
    if prob_k <= 10:
        # [Annotation] Shift 和 Rotation 矩阵是基于 actual_dim 生成的
        shift = lb + (ub - lb) * rng.rand(actual_dim)
        H_mat = rng.randn(actual_dim, actual_dim)
        Q, _ = np.linalg.qr(H_mat)
        matrix = Q
    else:
        shift = np.zeros(actual_dim)
        matrix = np.eye(actual_dim)

    par['shift'] = shift
    par['matrix'] = matrix

    # 5. Penalty Factors (PF1, PF2) via Sampling
    # We need to use the JIT kernels directly to check constraints,
    # to avoid circular dependency on ScalableProblem

    # 5.1 Sample
    # [Annotation] 在物理维度空间内进行采样，用于估算约束违反程度
    sample_size = 1000  # Efficient sampling
    X_sample = lb + rng.rand(sample_size, actual_dim) * (ub - lb)

    # 5.2 Transform
    X_trans = X_sample - shift
    X_trans = X_trans @ matrix

    # 5.3 Dispatch Kernel (Simplified copy of ScalableProblem._dispatch_kernel logic)
    # Note: We must import jit_kernels here
    f, g, h = _dispatch_kernel_proxy(prob_k, dim, par, X_trans)

    # 5.4 Calc CV
    epsilon = 1e-4
    cv_g = np.zeros(sample_size)
    if g is not None:
        if g.ndim == 2:
            cv_g = np.sum(np.maximum(0, g), axis=1)
        else:
            cv_g = np.maximum(0, g)

    cv_h = np.zeros(sample_size)
    if h is not None:
        if h.ndim == 2:
            cv_h = np.sum(np.maximum(0, np.abs(h) - epsilon), axis=1)
        else:
            cv_h = np.maximum(0, np.abs(h) - epsilon)

    cv = cv_g + cv_h

    # 5.5 Calc PF1/PF2
    max_abs_f = np.max(np.abs(f))
    if max_abs_f == 0: max_abs_f = 1.0

    pf1 = 0.0
    pf2 = 0.0
    if np.max(cv) > 1e-9:
        target_order = 10 ** (np.ceil(np.log10(max_abs_f)) + 1)
        pf1 = target_order
        nonzero_cv = cv[cv > 1e-9]
        min_cv = np.min(nonzero_cv) if len(nonzero_cv) > 0 else 1e-4
        pf2 = target_order / min_cv

    return par, pf1, pf2


def _dispatch_kernel_proxy(pk, dim, par, x):
    """
    Proxy for JIT dispatch without ScalableProblem class.
    [Annotation] 这是一个轻量级的 JIT 内核调用代理，仅用于参数生成阶段估算 PF1/PF2。
    它避免了在此文件中导入 ScalableProblem 类导致的循环依赖。
    """
    if pk == 1:
        return jit_kernels._fast_calc_lj(x, int(par['N_atoms']), float(par['sigma']), float(par['epsilon']))
    elif pk == 2:
        return jit_kernels._fast_calc_morse(x, int(par['N_atoms']), float(par['rho']))
    elif pk == 3:
        return jit_kernels._fast_calc_antenna(x, int(par['N']), np.array(par['phi_sll']))
    elif pk == 4:
        return jit_kernels._fast_calc_radar(x, dim, np.array(par['phase_bias']))
    elif pk == 5:
        return jit_kernels._fast_calc_protein(x, dim, np.array(par['full_seq']))
    elif pk == 6:
        return jit_kernels._fast_calc_robot(x, dim, np.array(par['Target']))
    elif pk == 7:
        return jit_kernels._fast_calc_nn(x, int(par['H']), int(par['valid_D']), np.array(par['inputs']),
                                         np.array(par['targets']))
    elif pk == 8:
        return jit_kernels._fast_calc_fm(x, int(par['H_harm']), np.array(par['t']), np.array(par['y_tgt']))
    elif pk == 9:
        return jit_kernels._fast_calc_wsn(x, int(par['N_sens']), np.array(par['Anchors']), np.array(par['Dist_A']))
    elif pk == 10:
        return jit_kernels._fast_calc_kmeans(x, int(par['K']), np.array(par['Data']))
    elif pk == 11:
        return jit_kernels._fast_calc_eld(x, float(par['Load']), np.array(par['a']), np.array(par['b']),
                                          np.array(par['c']))
    elif pk == 12:
        return jit_kernels._fast_calc_portfolio(x, np.array(par['Ret']), np.array(par['Cov']), float(par['Risk_Max']))
    elif pk == 13:
        inf = par['Inflow'];
        inf = np.array([inf]) if np.isscalar(inf) else np.array(inf)
        return jit_kernels._fast_calc_hydro(x, dim, inf, float(par['Vol_0']), float(par['Vol_min']),
                                            float(par['Vol_max']))
    elif pk == 14:
        return jit_kernels._fast_calc_beam(x, float(par['L']), float(par['P']), float(par['E']), np.array(par['Wi']))
    elif pk == 15:
        return jit_kernels._fast_calc_dispatch(x, np.array(par['Demand']), float(par['Ramp']))
    elif pk == 16:
        return jit_kernels._fast_calc_iir(x, float(par['limit']))
    elif pk == 17:
        return jit_kernels._fast_calc_gearbox(x, float(par['Target']))
    elif pk == 18:
        return jit_kernels._fast_calc_vessel(x, float(par['P_int']), float(par['R']), float(par['S_all']))
    elif pk == 19:
        return jit_kernels._fast_calc_spring(x, float(par['K_req']), float(par['N_coils']), float(par['G']),
                                             float(par['D_coil']))
    elif pk == 20:
        return jit_kernels._fast_calc_rocket(x, float(par['H_target']), float(par['g']), float(par['mass']),
                                             float(par['dt']))
    else:
        return None, None, None
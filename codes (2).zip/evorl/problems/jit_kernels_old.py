import numpy as np
from numba import njit


# ==============================================================================
# [JIT Accelerated Kernels]
# All 20 problem core logic, compiled to machine code.
# Extracted from original problems.py to ensure statelessness.
# [Annotation] 使用 Numba JIT 编译以提升计算性能。
# fastmath=True 允许编译器进行激进的浮点优化（如忽略 NaN/Inf 检查，重排浮点运算），
# 这对进化算法的大规模种群评估至关重要。
# ==============================================================================

@njit(fastmath=True)
def _fast_calc_lj(x, N_atoms, sigma, eps_val):
    """
    Problem 1: Lennard-Jones Potential (Minimization)
    计算原子团簇的势能。

    Args:
        x: (ps, 3*N_atoms) 种群矩阵。每行是一个展平的坐标向量: [x1, y1, z1, x2, y2, z2, ...]
        N_atoms: 原子数量 ( = dim / 3 )
        sigma, eps_val: 物理常数
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        E = 0.0
        # 双重循环计算两两原子之间的相互作用
        for j in range(N_atoms - 1):
            jx, jy, jz = x[i, j * 3], x[i, j * 3 + 1], x[i, j * 3 + 2]
            for k in range(j + 1, N_atoms):
                kx, ky, kz = x[i, k * 3], x[i, k * 3 + 1], x[i, k * 3 + 2]
                dx, dy, dz = jx - kx, jy - ky, jz - kz
                r2 = dx * dx + dy * dy + dz * dz
                r = np.sqrt(r2)
                if r < 1e-3: r = 1e-3  # 防止除零

                # LJ Formula: 4*epsilon * ((sigma/r)^12 - (sigma/r)^6)
                ratio = sigma / r
                inv_r6 = ratio * ratio * ratio * ratio * ratio * ratio
                E += 4.0 * eps_val * (inv_r6 * inv_r6 - inv_r6)
        f[i] = E
    return f, None, None


@njit(fastmath=True)
def _fast_calc_morse(x, N_atoms, rho):
    """
    Problem 2: Morse Potential (Minimization)
    另一种原子间势能模型。
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        E = 0.0
        for j in range(N_atoms - 1):
            jx, jy, jz = x[i, j * 3], x[i, j * 3 + 1], x[i, j * 3 + 2]
            for k in range(j + 1, N_atoms):
                kx, ky, kz = x[i, k * 3], x[i, k * 3 + 1], x[i, k * 3 + 2]
                dx, dy, dz = jx - kx, jy - ky, jz - kz
                r = np.sqrt(dx * dx + dy * dy + dz * dz)

                # Morse Formula Pairwise term: exp(rho*(1-r)) * (exp(rho*(1-r)) - 2)
                # Note: This is a simplified form often used in benchmarks
                tmp = np.exp(rho * (1.0 - r))
                E += tmp * (tmp - 2.0)
        f[i] = E
    return f, None, None


@njit(fastmath=True)
def _fast_calc_antenna(x, N, phi_sll):
    """
    Problem 3: Antenna Array Design (Minimization)
    最小化旁瓣电平 (Side Lobe Level)。

    Args:
        x: (ps, N) 天线阵元位置/间距
        N: 阵元数量
        phi_sll: 需要抑制旁瓣的角度列表
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_angles = len(phi_sll)
    for i in range(ps):
        max_sll = 0.0
        # 遍历所有需要抑制的角度
        for idx_ang in range(n_angles):
            ang = phi_sll[idx_ang]
            real_part = 0.0
            imag_part = 0.0
            # Array Factor calculation: Sum(I_k * exp(j * (2*pi*(k-1)/N * ...)))
            # Simplified benchmark version
            for k in range(1, N + 1):
                phi_k = 2.0 * np.pi * (k - 1) / N
                phase = np.cos(ang - phi_k)
                # I_curr[k-1] is x[i, k-1]
                val = x[i, k - 1]
                # exp(1j * phase) = cos(phase) + j*sin(phase)
                real_part += val * np.cos(phase)
                imag_part += val * np.sin(phase)
            mag = np.sqrt(real_part * real_part + imag_part * imag_part)
            if mag > max_sll:
                max_sll = mag
        f[i] = max_sll
    return f, None, None


@njit(fastmath=True)
def _fast_calc_radar(x, D, bias):
    """
    Problem 4: Radar Polyphase Code Design (Minimization)
    最小化波形的相关峰值。
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        H_val = 0.0
        # phi = x[i, :] + bias
        # Directly calculate phi_j inside loop to avoid array allocation
        for k in range(1, D):
            real_sum = 0.0
            imag_sum = 0.0
            # Autocorrelation function calculation
            for j in range(1, D - k + 1):
                # j indices are 1-based in loop, 0-based in array
                phi_j = x[i, j - 1] + bias[j - 1]
                phi_jk = x[i, j + k - 1] + bias[j + k - 1]
                diff = phi_j - phi_jk
                real_sum += np.cos(diff)
                imag_sum += np.sin(diff)
            mag = np.sqrt(real_sum * real_sum + imag_sum * imag_sum)
            if mag > H_val:
                H_val = mag
        f[i] = H_val
    return f, None, None


@njit(fastmath=True)
def _fast_calc_protein(x, D, full_seq):
    """
    Problem 5: 2D HP Protein Folding (Minimization)
    Args:
        x: (ps, D) 相对折叠角度序列
        full_seq: 氨基酸序列 (0=H Hydrophobic, 1=P Polar)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    # Pre-allocate coord arrays, size D+2 (Start at 0,0 and 1,0)
    Xc = np.zeros(D + 2)
    Yc = np.zeros(D + 2)

    for i in range(ps):
        # Reset coords for first two residues
        Xc[0] = 0.0;
        Yc[0] = 0.0
        Xc[1] = 1.0;
        Yc[1] = 0.0
        curr = 0.0

        # Calculate Coords based on relative angles x
        for k in range(2, D + 2):
            ang = x[i, k - 2]
            curr += ang
            Xc[k] = Xc[k - 1] + np.cos(curr)
            Yc[k] = Yc[k - 1] + np.sin(curr)

        E = 0.0
        # Calculate Interaction Energy (Lennard-Jones style 12-6 potential for H-H contacts)
        for j in range(D):
            for k in range(j + 2, D + 2):
                dx = Xc[j] - Xc[k]
                dy = Yc[j] - Yc[k]
                r = np.sqrt(dx * dx + dy * dy)
                if r < 1e-6: r = 1e-6

                # full_seq comparison
                # If both are H (Hydrophobic), attractive (C=1). Else repulsive (C=-0.5).
                if full_seq[j] == full_seq[k]:
                    C = 1.0
                else:
                    C = -0.5

                r6 = r * r * r * r * r * r
                r12 = r6 * r6
                # Formula: 4 * (1/r^12 - C/r^6)
                E += 4.0 * (1.0 / r12 - C / r6)

        # Penalty term: Keep angles valid (approximate constraint)
        pen = 0.0
        for k in range(D):
            pen += (1.0 - np.cos(x[i, k]))

        f[i] = E + 0.25 * pen
    return f, None, None


@njit(fastmath=True)
def _fast_calc_robot(x, D, Target):
    """
    Problem 6: Robot Kinematics (Minimization)
    计算机械臂末端执行器与目标点的距离。

    Args:
        x: (ps, D) 关节角度
        Target: (3,) 目标坐标 (x, y, z)
    """
    ps = x.shape[0]
    f = np.zeros(ps)

    for i in range(ps):
        # Transformation Matrix T starts as Identity
        T00, T01, T02, T03 = 1.0, 0.0, 0.0, 0.0
        T10, T11, T12, T13 = 0.0, 1.0, 0.0, 0.0
        T20, T21, T22, T23 = 0.0, 0.0, 1.0, 0.0

        for k in range(D):
            tk = x[i, k]
            cos_t = np.cos(tk)
            sin_t = np.sin(tk)

            # Standard DH Parameter Transformation (simplified unit length)
            # M = Rotate_z(theta) * Translate_x(1)
            # M matrix 4x4:
            # c -s  0  c
            # s  c  0  s
            # 0  0  1  0
            # 0  0  0  1

            # Update T = T * M (Manual Matrix Multiplication 4x4)
            # Only need first 3 rows as row 4 is always [0,0,0,1]
            N00 = T00 * cos_t + T01 * sin_t
            N01 = T00 * (-sin_t) + T01 * cos_t
            # N02 = T02 (unchanged because M col 2 is [0,0,1,0]^T)
            N03 = T00 * cos_t + T01 * sin_t + T03  # Translation part

            N10 = T10 * cos_t + T11 * sin_t
            N11 = T10 * (-sin_t) + T11 * cos_t
            # N12 = T12
            N13 = T10 * cos_t + T11 * sin_t + T13

            N20 = T20 * cos_t + T21 * sin_t
            N21 = T20 * (-sin_t) + T21 * cos_t
            # N22 = T22
            N23 = T20 * cos_t + T21 * sin_t + T23

            T00, T01, T03 = N00, N01, N03
            T10, T11, T13 = N10, N11, N13
            T20, T21, T23 = N20, N21, N23

        # Euclidean distance from End Effector (T03, T13, T23) to Target
        dx = T03 - Target[0]
        dy = T13 - Target[1]
        dz = T23 - Target[2]
        f[i] = np.sqrt(dx * dx + dy * dy + dz * dz)
    return f, None, None


@njit(fastmath=True)
def _fast_calc_nn(x, H, valid_D, inp, tgt):
    """
    Problem 7: Neural Network Weights Training (Minimization)
    Args:
        x: 权重向量。Layout: [W1(H), B1(H), W2(H), B2(1)]
        H: 隐层神经元数量
        inp, tgt: 训练数据输入与目标
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_samples = len(inp)

    for i in range(ps):
        if H < 1:
            f[i] = 1e5
            continue

        # Unpack weights manually based on valid_D logic
        # W1: 0 to H
        # B1: H to 2H
        # W2: 2H to 3H
        # B2: 3H

        err_val = 0.0
        for k in range(n_samples):
            # Forward pass: 1-Input -> Hidden(Tanh) -> 1-Output(Linear)
            # hidden = tanh(W1 * inp[k] + B1)
            # out = dot(W2, hidden) + B2

            hidden_dot_W2 = 0.0
            in_val = inp[k]

            for h in range(H):
                w1_val = x[i, h]
                b1_val = x[i, H + h]
                w2_val = x[i, 2 * H + h]

                node_in = w1_val * in_val + b1_val
                node_out = np.tanh(node_in)
                hidden_dot_W2 += w2_val * node_out

            b2_val = x[i, 3 * H]
            out = hidden_dot_W2 + b2_val

            diff = out - tgt[k]
            err_val += diff * diff

        f[i] = err_val
    return f, None, None


@njit(fastmath=True)
def _fast_calc_fm(x, H_harm, t, y_tgt):
    """
    Problem 8: Frequency Modulation Sound Synthesis (Minimization)
    拟合目标声波。
    Args:
        x: [amp1, freq1, amp2, freq2, ...]
        H_harm: 谐波数量 ( = dim / 2 )
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_points = len(t)

    for i in range(ps):
        err_sum = 0.0
        for ti in range(n_points):
            t_val = t[ti]
            y_syn = 0.0
            # Synthesis: Sum( amp_k * sin(freq_k * t) )
            for k in range(1, H_harm + 1):
                amp = x[i, 2 * k - 2]
                freq = x[i, 2 * k - 1]
                y_syn += amp * np.sin(freq * t_val)

            diff = y_tgt[ti] - y_syn
            err_sum += diff * diff
        f[i] = err_sum
    return f, None, None


@njit(fastmath=True)
def _fast_calc_wsn(x, N_sens, Anchors, Dist_A):
    """
    Problem 9: Wireless Sensor Network Localization (Minimization)
    根据锚点距离推算传感器位置。
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        err_val = 0.0
        for k in range(N_sens):
            px = x[i, k * 2]
            py = x[i, k * 2 + 1]
            # Sum of errors to 4 anchors
            for a in range(4):
                ax = Anchors[a, 0]
                ay = Anchors[a, 1]
                d_est = np.sqrt((px - ax) ** 2 + (py - ay) ** 2)
                d_true = Dist_A[k, a]
                diff = d_est - d_true
                err_val += diff * diff
        f[i] = err_val
    return f, None, None


@njit(fastmath=True)
def _fast_calc_kmeans(x, K, Data):
    """
    Problem 10: K-Means Clustering (Minimization)
    最小化簇内距离平方和 (Within-Cluster Sum of Squares).
    Args:
        x: [cx1, cy1, cx2, cy2, ...] 聚类中心坐标
        Data: 样本点
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_data = Data.shape[0]

    for i in range(ps):
        J = 0.0
        for d in range(n_data):
            dx = Data[d, 0]
            dy = Data[d, 1]
            min_dist2 = 1e20

            # Find closest centroid
            for k in range(K):
                cx = x[i, k * 2]
                cy = x[i, k * 2 + 1]
                dist2 = (cx - dx) ** 2 + (cy - dy) ** 2
                if dist2 < min_dist2:
                    min_dist2 = dist2
            J += min_dist2
        f[i] = J
    return f, None, None


@njit(fastmath=True)
def _fast_calc_eld(x, Load, a, b, c):
    """
    Problem 11: Economic Load Dispatch (Constrained Minimization)
    电力系统负荷分配。

    Returns:
        f: 燃料成本
        h: 等式约束 (总发电量 - 负荷 = 0)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))
    D = x.shape[1]

    for i in range(ps):
        cost = 0.0
        p_sum = 0.0
        for k in range(D):
            P = x[i, k]
            # Quadratic Cost Function: a*P^2 + b*P + c
            cost += a[k] * P * P + b[k] * P + c[k]
            p_sum += P
        f[i] = cost
        h[i, 0] = p_sum - Load
    return f, None, h


@njit(fastmath=True)
def _fast_calc_portfolio(x, Ret, Cov, Risk_Max):
    """
    Problem 12: Portfolio Optimization (Constrained Minimization)
    修正说明：
    1. 补全了 ret_sum 的累加逻辑。
    2. 补全了 w_sum (权重之和) 的累加逻辑。
    3. 优化了风险矩阵乘法的逻辑结构。
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))
    g = np.zeros((ps, 1))

    for i in range(ps):
        ret_sum = 0.0
        w_sum = 0.0
        risk_calc = 0.0

        # 1. 计算总收益和权重和
        for k in range(D):
            w = x[i, k]
            ret_sum += w * Ret[k]  # 之前这里是空的
            w_sum += w  # 之前这里是空的

        # 2. 计算风险 (w.T @ Cov @ w)
        for r in range(D):
            # 内部循环优化：先计算 (w * Cov) 的中间项
            temp = 0.0
            for c in range(D):
                temp += x[i, c] * Cov[r, c]
            risk_calc += x[i, r] * temp

        f[i] = -ret_sum  # 最小化负收益 = 最大化收益
        h[i, 0] = w_sum - 1.0  # 权重和必须为1
        g[i, 0] = risk_calc - Risk_Max  # 风险不能超过上限

    return f, g, h


@njit(fastmath=True)
def _fast_calc_hydro(x, D, Inflow, Vol_0, Vmin, Vmax):
    """
    Problem 13: Hydrothermal Scheduling (Constrained Minimization)
    水库调度优化。

    Returns:
        f: 发电成本 (简化为流量的二次函数)
        g: 库容约束 (Vmin <= Vol <= Vmax)
        h: 终末库容约束 (Vol_end = Vol_0)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))
    g = np.zeros((ps, D * 2))

    for i in range(ps):
        cost = 0.0
        Vol = Vol_0
        for t in range(D):
            Q = x[i, t]  # Discharge
            cost += 0.1 * Q * Q

            inf_t = Inflow[t]
            # Volume Balance Equation: V(t+1) = V(t) + Inflow - Discharge
            Vol = Vol + inf_t - Q

            # Constraints: Vmin <= Vol <= Vmax
            g[i, t] = Vmin - Vol  # Vmin - Vol <= 0  => Vol >= Vmin
            g[i, t + D] = Vol - Vmax  # Vol - Vmax <= 0  => Vol <= Vmax

        f[i] = cost
        h[i, 0] = Vol - Vol_0  # End volume must equal start volume
    return f, g, h


@njit(fastmath=True)
def _fast_calc_beam(x, L, P_load, E, Wi):
    """
    Problem 14: Welded Beam Design (Constrained Minimization)

    Returns:
        f: 重量 (Weight)
        g: 挠度约束 (Deflection - Limit <= 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    g = np.zeros((ps, 1))

    for i in range(ps):
        weight = 0.0
        deflection = 0.0
        for k in range(D):
            Hi = x[i, k]  # Height/Thickness
            Wi_val = Wi[k]
            weight += Wi_val * Hi * L

            I_val = (Wi_val * Hi * Hi * Hi) / 12.0  # Moment of Inertia
            deflection += (P_load * L * L * L) / (3.0 * E * I_val)

        f[i] = weight
        g[i, 0] = deflection - 2.0  # Limit = 2.0
    return f, g, None


@njit(fastmath=True)
def _fast_calc_dispatch(x, Demand, Ramp):
    """
    Problem 15: Power Dispatch with Ramp Constraints (Constrained)

    Returns:
        f: 发电成本
        g: 爬坡约束 (|P(t) - P(t-1)| <= Ramp)
        h: 供需平衡约束 (P(t) - Demand(t) = 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    h = np.zeros((ps, D))

    has_ramp = (D > 1)
    g_cols = D - 1 if D > 1 else 1
    g = np.zeros((ps, g_cols))

    for i in range(ps):
        cost = 0.0
        for k in range(D):
            P = x[i, k]
            cost += 0.01 * P * P + 2.0 * P
            h[i, k] = P - Demand[k]  # Demand Balance

            if has_ramp and k < D - 1:
                P_next = x[i, k + 1]
                diff = np.abs(P_next - P)
                g[i, k] = diff - Ramp  # Ramp constraint

        f[i] = cost

    if not has_ramp:
        g[:] = -1.0  # Satisfied if no ramp check needed

    return f, g, h


@njit(fastmath=True)
def _fast_calc_iir(x, limit):
    """
    Problem 16: IIR Filter Design (Constrained)

    Returns:
        f: 系数平方和 (Energy)
        g: 稳定性约束 (Sum(|coeffs|) <= limit)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    g = np.zeros((ps, 1))

    for i in range(ps):
        s_sq = 0.0
        s_abs = 0.0
        for k in range(D):
            val = x[i, k]
            s_sq += val * val
            s_abs += np.abs(val)
        f[i] = s_sq
        g[i, 0] = s_abs - limit
    return f, g, None


@njit(fastmath=True)
def _fast_calc_gearbox(x, Target):
    """
    Problem 17: Gearbox Design (Constrained)

    Returns:
        f: 齿数平方和 (Weight proxy)
        h: 总传动比约束 (Product(gears) - Target = 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))

    for i in range(ps):
        s_sq = 0.0
        prod = 1.0
        for k in range(D):
            val = x[i, k]
            s_sq += val * val
            prod *= val
        f[i] = s_sq
        h[i, 0] = prod - Target
    return f, None, h


@njit(fastmath=True)
def _fast_calc_vessel(x, P_int, R, S):
    """
    Problem 18: Pressure Vessel Design (Constrained)

    Returns:
        f: 金属体积 (Material Volume)
        g: 应力约束 (Stress - MaxStress <= 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    g = np.zeros((ps, 1))

    for i in range(ps):
        vol_metal = 0.0
        max_stress = -1e20

        for k in range(D):
            Th = x[i, k]  # Thickness
            vol_metal += 2.0 * np.pi * R * Th

            stress = (P_int * R) / Th  # Hoop stress
            if stress > max_stress:
                max_stress = stress

        f[i] = vol_metal
        g[i, 0] = max_stress - S
    return f, g, None


@njit(fastmath=True)
def _fast_calc_spring(x, K_req, N_c, G, D_coil):
    """
    Problem 19: Tension/Compression Spring Design (Constrained)

    Returns:
        f: 线径平方和 (Mass proxy)
        h: 刚度约束 (K_eq - K_req = 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))

    for i in range(ps):
        sum_sq = 0.0
        sum_inv_k = 0.0

        for k in range(D):
            d = x[i, k]  # Wire diameter
            sum_sq += d * d

            d4 = d * d * d * d
            # Spring constant formula: k = (G*d^4) / (8*D^3*N)
            ki = (G * d4) / (8.0 * D_coil * D_coil * D_coil * N_c)
            sum_inv_k += 1.0 / ki

        f[i] = sum_sq
        k_eq = 1.0 / sum_inv_k
        h[i, 0] = k_eq - K_req
    return f, None, h


@njit(fastmath=True)
def _fast_calc_rocket(x, H_tgt, g_g, m, dt):
    """
    Problem 20: Rocket Dynamics (Constrained)

    Returns:
        f: 推力平方和 (Fuel Consumption)
        h: 最终高度约束 (y_final - Target = 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))

    for i in range(ps):
        thrust_sq = 0.0
        v = 0.0
        y = 0.0

        # Simple Euler Integration
        for k in range(D):
            th = x[i, k]  # Thrust at step k
            thrust_sq += th * th

            acc = (th / m) - g_g
            v += acc * dt
            y += v * dt

        f[i] = thrust_sq
        h[i, 0] = y - H_tgt
    return f, None, h
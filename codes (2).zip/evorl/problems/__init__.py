# 显示导出 ScalableProblem，确保外部可以通过 evorl.problems 导入
from .scalable_problem import ScalableProblem
import numpy as np
from evorl.core.problem import Problem
from evorl.problems import jit_kernels


class ScalableProblem(Problem):
    """
    Implementation of the 20 Scalable Real-World Problems (CEC 2011/2013).
    Wraps the JIT kernels and manages problem state (bounds, parameters).
    [Annotation] 此类封装了20个基准问题的状态管理。
    它负责维护问题的维度、边界、物理参数，并协调 JIT 内核进行高性能计算。
    """

    def __init__(self, problem_id: int, dim: int, param_dict: dict, pf1: float = 0.0, pf2: float = 0.0):
        """
        Initialize the problem instance.

        Args:
            problem_id (int): The ID of the problem (1-20).
            dim (int): The RAW dimension configured by user (e.g., 20).
                       Note: Actual physical dimension might be adjusted (e.g., to 18).
            param_dict (dict): Dictionary containing problem-specific parameters
                               (e.g., 'Target', 'sigma', 'shift', 'matrix').
            pf1 (float): Penalty factor 1 (constant base penalty).
            pf2 (float): Penalty factor 2 (coefficient for CV).
        """
        self.problem_id = problem_id
        self._raw_dim = dim
        self.params = param_dict
        self.pf1 = pf1
        self.pf2 = pf2

        # Extract shift and rotation if they exist, else default to Identity/Zero
        # [Annotation] 这里的 shift/matrix 通常由 params_def.py 生成，且维度已适配物理维度
        self.shift_vec = self.params.get('shift', np.zeros(dim))
        self.rot_mat = self.params.get('matrix', np.eye(dim))

        # Ensure shift/rot dimensions match current D (Safety check for data integrity)
        # Note: Some problems modify D (e.g., LJ, Morse), handled in _setup_properties
        self._name = f"Prob_{problem_id}"
        self._setup_properties()

    def _setup_properties(self):
        """
        Define bounds and actual dimension based on problem ID.
        [Annotation] 核心逻辑：定义物理边界和有效维度。
        注意：对于 Problem 1 & 2，此处会修改 self._dim，从而实现“自动切换”到物理维度。
        """
        pk = self.problem_id
        d_in = self._raw_dim

        # Default initialization (assume raw dimension)
        self._dim = d_in
        self._lb = np.zeros(d_in)
        self._ub = np.zeros(d_in)

        if pk == 1:  # LJ
            # [Annotation] LJ 问题强制维度为 3 的倍数
            self._dim = 3 * int(np.floor(d_in / 3))
            if self._dim < 3: self._dim = 3
            self._name = "Lennard-Jones"
            self._lb = -2 * np.ones(self._dim)
            self._ub = 2 * np.ones(self._dim)
        elif pk == 2:  # Morse
            # [Annotation] Morse 问题强制维度为 3 的倍数
            self._dim = 3 * int(np.floor(d_in / 3))
            if self._dim < 3: self._dim = 3
            self._name = "Morse"
            self._lb = -2 * np.ones(self._dim)
            self._ub = 2 * np.ones(self._dim)
        elif pk == 3:  # Antenna
            self._name = "Antenna"
            self._lb = -10 * np.ones(self._dim)
            self._ub = 10 * np.ones(self._dim)
        elif pk == 4:  # Radar
            self._name = "Radar"
            self._lb = 0 * np.ones(self._dim)
            self._ub = 2 * np.pi * np.ones(self._dim)
        elif pk == 5:  # Protein
            self._name = "Protein"
            self._lb = -np.pi * np.ones(self._dim)
            self._ub = np.pi * np.ones(self._dim)
        elif pk == 6:  # Robot
            self._name = "Robot"
            self._lb = -np.pi * np.ones(self._dim)
            self._ub = np.pi * np.ones(self._dim)
        elif pk == 7:  # NN
            self._name = "NeuralNetwork"
            self._lb = -5 * np.ones(self._dim)
            self._ub = 5 * np.ones(self._dim)
        elif pk == 8:  # FM Synth
            self._name = "FMSynth"
            self._lb = -2 * np.pi * np.ones(self._dim)
            self._ub = 2 * np.pi * np.ones(self._dim)
        elif pk == 9:  # WSN
            self._name = "WSN"
            self._lb = 0 * np.ones(self._dim)
            self._ub = 10 * np.ones(self._dim)
        elif pk == 10:  # K-Means
            self._name = "KMeans"
            self._lb = -5 * np.ones(self._dim)
            self._ub = 5 * np.ones(self._dim)
        elif pk == 11:  # ELD
            self._name = "ELD"
            self._lb = 10 * np.ones(self._dim)
            self._ub = 200 * np.ones(self._dim)
        elif pk == 12:  # Portfolio
            self._name = "Portfolio"
            self._lb = 0 * np.ones(self._dim)
            self._ub = 1 * np.ones(self._dim)
        elif pk == 13:  # Hydro
            self._name = "Hydro"
            self._lb = 0 * np.ones(self._dim)
            self._ub = 20 * np.ones(self._dim)
        elif pk == 14:  # Beam
            self._name = "Beam"
            self._lb = 0.1 * np.ones(self._dim)
            self._ub = 5 * np.ones(self._dim)
        elif pk == 15:  # Dynamic Dispatch
            self._name = "Dispatch"
            self._lb = 10 * np.ones(self._dim)
            self._ub = 100 * np.ones(self._dim)
        elif pk == 16:  # IIR Filter
            self._name = "IIR"
            self._lb = -2 * np.ones(self._dim)
            self._ub = 2 * np.ones(self._dim)
        elif pk == 17:  # Gearbox
            self._name = "Gearbox"
            self._lb = 1.1 * np.ones(self._dim)
            self._ub = 5 * np.ones(self._dim)
        elif pk == 18:  # Pressure Vessel
            self._name = "Vessel"
            self._lb = 0.1 * np.ones(self._dim)
            self._ub = 10 * np.ones(self._dim)
        elif pk == 19:  # Spring
            self._name = "Spring"
            self._lb = 0.001 * np.ones(self._dim)
            self._ub = 0.02 * np.ones(self._dim)
        elif pk == 20:  # Rocket
            self._name = "Rocket"
            self._lb = 0 * np.ones(self._dim)
            self._ub = 200 * np.ones(self._dim)
        else:
            raise ValueError(f"Unknown Problem ID: {pk}")

        # Update shift/rot shape if dim changed (e.g. LJ/Morse)
        if self._dim != self._raw_dim:
            # We assume the passed shift/rot matches the ACTUAL functional dim
            # If the data generator generated for raw_dim, we must slice.
            # However, typically the generator should respect the problem logic.
            # Here we trust the injected params match the expected dim logic.
            pass

    @property
    def name(self) -> str:
        return self._name

    @property
    def dim(self) -> int:
        """Return the effective physical dimension (may be < raw_dim)."""
        return self._dim

    @property
    def lb(self) -> np.ndarray:
        return self._lb

    @property
    def ub(self) -> np.ndarray:
        return self._ub

    def evaluate(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Evaluate the population X.
        Flow: Transform -> JIT Kernel -> CV -> Penalty

        Args:
            X: (N, dim) population array.
        Returns:
            fitness: (N,) penalized objective values
            f: (N,) raw objective values
            cv: (N,) constraint violation values
        """
        N = X.shape[0]

        # 1. Coordinate Transformation
        # Apply Shift and Rotation: X' = (X - shift) * M
        X_trans = X - self.shift_vec
        X_trans = X_trans @ self.rot_mat

        # 2. Physical Evaluation (Dispatch to JIT)
        # Returns raw f, g (inequality), h (equality)
        f, g, h = self._dispatch_kernel(X_trans)

        # 3. Constraint Handling
        epsilon = 1e-4
        cv_g = np.zeros(N)
        if g is not None:
            if g.ndim == 2:
                cv_g = np.sum(np.maximum(0, g), axis=1)
            else:
                cv_g = np.maximum(0, g)

        cv_h = np.zeros(N)
        if h is not None:
            if h.ndim == 2:
                cv_h = np.sum(np.maximum(0, np.abs(h) - epsilon), axis=1)
            else:
                cv_h = np.maximum(0, np.abs(h) - epsilon)

        cv = cv_g + cv_h

        # 4. Penalty Calculation
        # fitness = f + pf1 + pf2 * cv (if infeasible)
        fitness = f.copy()
        mask_infeasible = cv > 0

        # Apply penalty only if pf1 > 0 (implying penalties are set)
        if self.pf1 > 0:
            fitness[mask_infeasible] = f[mask_infeasible] + self.pf1 + self.pf2 * cv[mask_infeasible]

        return fitness, f, cv

    def _dispatch_kernel(self, x):
        """
        Dispatch execution to the correct JIT kernel.
        Extracts specific parameters from self.params dictionary.
        """
        pk = self.problem_id
        par = self.params

        if pk == 1:  # LJ
            return jit_kernels._fast_calc_lj(x, int(par['N_atoms']), float(par['sigma']), float(par['epsilon']))
        elif pk == 2:  # Morse
            return jit_kernels._fast_calc_morse(x, int(par['N_atoms']), float(par['rho']))
        elif pk == 3:  # Antenna
            return jit_kernels._fast_calc_antenna(x, int(par['N']), np.array(par['phi_sll']))
        elif pk == 4:  # Radar
            return jit_kernels._fast_calc_radar(x, self._dim, np.array(par['phase_bias']))
        elif pk == 5:  # Protein
            return jit_kernels._fast_calc_protein(x, self._dim, np.array(par['full_seq']))
        elif pk == 6:  # Robot
            return jit_kernels._fast_calc_robot(x, self._dim, np.array(par['Target']))
        elif pk == 7:  # NN
            return jit_kernels._fast_calc_nn(x, int(par['H']), int(par['valid_D']), np.array(par['inputs']),
                                             np.array(par['targets']))
        elif pk == 8:  # FM Synth
            return jit_kernels._fast_calc_fm(x, int(par['H_harm']), np.array(par['t']), np.array(par['y_tgt']))
        elif pk == 9:  # WSN
            return jit_kernels._fast_calc_wsn(x, int(par['N_sens']), np.array(par['Anchors']), np.array(par['Dist_A']))
        elif pk == 10:  # K-Means
            return jit_kernels._fast_calc_kmeans(x, int(par['K']), np.array(par['Data']))
        elif pk == 11:  # ELD
            return jit_kernels._fast_calc_eld(x, float(par['Load']), np.array(par['a']), np.array(par['b']),
                                              np.array(par['c']))
        elif pk == 12:  # Portfolio
            return jit_kernels._fast_calc_portfolio(x, np.array(par['Ret']), np.array(par['Cov']),
                                                    float(par['Risk_Max']))
        elif pk == 13:  # Hydro
            inf = par['Inflow']
            if np.isscalar(inf):
                inf = np.array([inf])
            else:
                inf = np.array(inf)
            return jit_kernels._fast_calc_hydro(x, self._dim, inf, float(par['Vol_0']), float(par['Vol_min']),
                                                float(par['Vol_max']))
        elif pk == 14:  # Beam
            return jit_kernels._fast_calc_beam(x, float(par['L']), float(par['P']), float(par['E']),
                                               np.array(par['Wi']))
        elif pk == 15:  # Dispatch
            return jit_kernels._fast_calc_dispatch(x, np.array(par['Demand']), float(par['Ramp']))
        elif pk == 16:  # IIR
            return jit_kernels._fast_calc_iir(x, float(par['limit']))
        elif pk == 17:  # Gearbox
            return jit_kernels._fast_calc_gearbox(x, float(par['Target']))
        elif pk == 18:  # Vessel
            return jit_kernels._fast_calc_vessel(x, float(par['P_int']), float(par['R']), float(par['S_all']))
        elif pk == 19:  # Spring
            return jit_kernels._fast_calc_spring(x, float(par['K_req']), float(par['N_coils']), float(par['G']),
                                                 float(par['D_coil']))
        elif pk == 20:  # Rocket
            return jit_kernels._fast_calc_rocket(x, float(par['H_target']), float(par['g']), float(par['mass']),
                                                 float(par['dt']))
        else:
            raise NotImplementedError(f"Problem {pk} kernel logic missing.")
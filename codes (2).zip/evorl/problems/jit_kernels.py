import numpy as np
from numba import njit


# ==============================================================================
# [JIT Accelerated Kernels]
# All 20 problem core logic, compiled to machine code.
# Extracted from original problems.py to ensure statelessness.
# [Annotation] 使用 Numba JIT 编译以提升计算性能。
# fastmath=True 允许编译器进行激进的浮点优化（如忽略 NaN/Inf 检查，重排浮点运算），
# 这对进化算法的大规模种群评估至关重要。
# ==============================================================================

@njit(fastmath=True)
def _fast_calc_lj(x, N_atoms, sigma, eps_val):
    """
    Problem 1: Lennard-Jones Potential (Minimization)
    计算原子团簇的势能。

    Args:
        x: (ps, 3*N_atoms) 种群矩阵。每行是一个展平的坐标向量: [x1, y1, z1, x2, y2, z2, ...]
        N_atoms: 原子数量 ( = dim / 3 )
        sigma, eps_val: 物理常数
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        E = 0.0
        # 双重循环计算两两原子之间的相互作用
        for j in range(N_atoms - 1):
            jx, jy, jz = x[i, j * 3], x[i, j * 3 + 1], x[i, j * 3 + 2]
            for k in range(j + 1, N_atoms):
                kx, ky, kz = x[i, k * 3], x[i, k * 3 + 1], x[i, k * 3 + 2]
                dx, dy, dz = jx - kx, jy - ky, jz - kz
                r2 = dx * dx + dy * dy + dz * dz
                if r2 < 1e-6: r2 = 1e-6  # 防止除零 (阈值改为平方级)

                # 优化后的计算，无需 sqrt
                inv_r2 = (sigma * sigma) / r2  # (σ^2 / r^2)
                inv_r6 = inv_r2 * inv_r2 * inv_r2  # ((σ/r)^2)^3 = (σ/r)^6
                E += 4.0 * eps_val * (inv_r6 * inv_r6 - inv_r6)
        f[i] = E
    return f, None, None


@njit(fastmath=True)
def _fast_calc_morse(x, N_atoms, rho):
    """
    Problem 2: Morse Potential (Minimization)
    另一种原子间势能模型。
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        E = 0.0
        for j in range(N_atoms - 1):
            jx, jy, jz = x[i, j * 3], x[i, j * 3 + 1], x[i, j * 3 + 2]
            for k in range(j + 1, N_atoms):
                kx, ky, kz = x[i, k * 3], x[i, k * 3 + 1], x[i, k * 3 + 2]
                dx, dy, dz = jx - kx, jy - ky, jz - kz
                r = np.sqrt(dx * dx + dy * dy + dz * dz)

                # Morse Formula Pairwise term: exp(rho*(1-r)) * (exp(rho*(1-r)) - 2)
                # Note: This is a simplified form often used in benchmarks
                tmp = np.exp(rho * (1.0 - r))
                E += tmp * (tmp - 2.0)
        f[i] = E
    return f, None, None


@njit(fastmath=True)
def _fast_calc_antenna(x, N, phi_sll):
    """
    Problem 3: Antenna Array Design (Minimization)
    最小化旁瓣电平 (Side Lobe Level)。

    Args:
        x: (ps, N) 天线阵元激励权重 (Excitation Weights)  # 修正：此处 x 代表幅度权重而非位置
        N: 阵元数量
        phi_sll: 需要抑制旁瓣的角度列表 (Sidelobe Angles)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_angles = len(phi_sll)

    for i in range(ps):
        max_sll = 0.0
        # 遍历所有需要抑制的角度 [cite: 395]
        for idx_ang in range(n_angles):
            ang = phi_sll[idx_ang]
            real_part = 0.0
            imag_part = 0.0

            # Array Factor calculation: Sum(x_k * exp(j * cos(theta - phi_k)))
            # 依据公式 (26) [cite: 395]
            for k in range(1, N + 1):
                # 几何位置是固定的均匀圆阵分布 [cite: 396]
                phi_k = 2.0 * np.pi * (k - 1) / N

                # 相位项: cos(theta - phi_k)
                phase = np.cos(ang - phi_k)

                # x[i, k-1] 是第 k 个阵元的激励权重
                val = x[i, k - 1]

                # exp(j * phase) = cos(phase) + j*sin(phase)
                real_part += val * np.cos(phase)
                imag_part += val * np.sin(phase)

            # 计算复数的模 (Magnitude)
            mag = np.sqrt(real_part * real_part + imag_part * imag_part)

            # 寻找在所有旁瓣角度中的最大值 (Minimax formulation)
            if mag > max_sll:
                max_sll = mag

        f[i] = max_sll
    return f, None, None


@njit(fastmath=True)
def _fast_calc_radar(x, D, bias):
    """
    Problem 4: Radar Polyphase Code Design (Minimization)
    最小化波形的相关峰值。
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        H_val = 0.0
        # phi = x[i, :] + bias
        # Directly calculate phi_j inside loop to avoid array allocation
        for k in range(1, D):
            real_sum = 0.0
            imag_sum = 0.0
            # Autocorrelation function calculation
            for j in range(1, D - k + 1):
                # j indices are 1-based in loop, 0-based in array
                phi_j = x[i, j - 1] + bias[j - 1]
                phi_jk = x[i, j + k - 1] + bias[j + k - 1]
                diff = phi_j - phi_jk
                real_sum += np.cos(diff)
                imag_sum += np.sin(diff)
            mag = np.sqrt(real_sum * real_sum + imag_sum * imag_sum)
            if mag > H_val:
                H_val = mag
        f[i] = H_val
    return f, None, None


@njit(fastmath=True)
def _fast_calc_protein(x, D, full_seq):
    """
    Problem 5: 2D HP Protein Folding (Minimization)
    Args:
        x: (ps, D) 相对折叠角度序列
        full_seq: 氨基酸序列 (0=H Hydrophobic, 1=P Polar)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    # Pre-allocate coord arrays, size D+2 (Start at 0,0 and 1,0)
    Xc = np.zeros(D + 2)
    Yc = np.zeros(D + 2)

    for i in range(ps):
        # Reset coords for first two residues
        Xc[0] = 0.0;
        Yc[0] = 0.0
        Xc[1] = 1.0;
        Yc[1] = 0.0
        curr = 0.0

        # Calculate Coords based on relative angles x
        for k in range(2, D + 2):
            ang = x[i, k - 2]
            curr += ang
            Xc[k] = Xc[k - 1] + np.cos(curr)
            Yc[k] = Yc[k - 1] + np.sin(curr)

        E = 0.0
        # Calculate Interaction Energy (Lennard-Jones style 12-6 potential for H-H contacts)
        for j in range(D):
            for k in range(j + 2, D + 2):
                dx = Xc[j] - Xc[k]
                dy = Yc[j] - Yc[k]
                r = np.sqrt(dx * dx + dy * dy)
                if r < 1e-6: r = 1e-6

                # full_seq comparison
                # If both are H (Hydrophobic), attractive (C=1). Else repulsive (C=-0.5).
                if full_seq[j] == full_seq[k]:
                    C = 1.0
                else:
                    C = -0.5

                r6 = r * r * r * r * r * r
                r12 = r6 * r6
                # Formula: 4 * (1/r^12 - C/r^6)
                E += 4.0 * (1.0 / r12 - C / r6)

        # Penalty term: Keep angles valid (approximate constraint)
        pen = 0.0
        for k in range(D):
            pen += (1.0 - np.cos(x[i, k]))

        f[i] = E + 0.25 * pen
    return f, None, None


@njit(fastmath=True)
def _fast_calc_robot(x, D, Target):
    """
    Problem 6: Robot Kinematics (Minimization)
    计算机械臂末端执行器与目标点的距离。
    修正版：实现了论文定义的 3D 机械臂 (Twist alpha = 90度)。

    Args:
        x: (ps, D) 关节角度
        Target: (3,) 目标坐标 (x, y, z)
    """
    ps = x.shape[0]
    f = np.zeros(ps)

    for i in range(ps):
        # T 初始化为单位矩阵
        # Row 0
        r00, r01, r02, r03 = 1.0, 0.0, 0.0, 0.0
        # Row 1
        r10, r11, r12, r13 = 0.0, 1.0, 0.0, 0.0
        # Row 2
        r20, r21, r22, r23 = 0.0, 0.0, 1.0, 0.0

        for k in range(D):
            tk = x[i, k]
            c = np.cos(tk)
            s = np.sin(tk)

            # 标准 DH 变换矩阵 M (a=1, alpha=pi/2, d=0)
            # M = [ c  0  s  c ]
            #     [ s  0 -c  s ]
            #     [ 0  1  0  0 ]
            #     [ 0  0  0  1 ]

            # 执行矩阵乘法 T_new = T_old * M
            # 只需要更新前三行 (第四行恒为 0 0 0 1)

            # --- Row 0 ---
            # n00 = r00*c + r01*s + r02*0
            n00 = r00 * c + r01 * s
            # n01 = r00*0 + r01*0 + r02*1
            n01 = r02
            # n02 = r00*s + r01*(-c) + r02*0
            n02 = r00 * s - r01 * c
            # n03 = r00*c + r01*s + r03*1
            n03 = r00 * c + r01 * s + r03

            # --- Row 1 ---
            n10 = r10 * c + r11 * s
            n11 = r12
            n12 = r10 * s - r11 * c
            n13 = r10 * c + r11 * s + r13

            # --- Row 2 ---
            n20 = r20 * c + r21 * s
            n21 = r22
            n22 = r20 * s - r21 * c
            n23 = r20 * c + r21 * s + r23

            # Update T
            r00, r01, r02, r03 = n00, n01, n02, n03
            r10, r11, r12, r13 = n10, n11, n12, n13
            r20, r21, r22, r23 = n20, n21, n22, n23

        # Euclidean distance from End Effector (r03, r13, r23) to Target
        dx = r03 - Target[0]
        dy = r13 - Target[1]
        dz = r23 - Target[2]
        f[i] = np.sqrt(dx * dx + dy * dy + dz * dz)

    return f, None, None


@njit(fastmath=True)
def _fast_calc_nn(x, H, valid_D, inp, tgt):
    """
    Problem 7: Neural Network Weights Training (Minimization)
    Args:
        x: 权重向量。Layout: [W1(H), B1(H), W2(H), B2(1)]
        H: 隐层神经元数量
        inp, tgt: 训练数据输入与目标
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_samples = len(inp)

    for i in range(ps):
        if H < 1:
            f[i] = 1e5
            continue

        # Unpack weights manually based on valid_D logic
        # W1: 0 to H
        # B1: H to 2H
        # W2: 2H to 3H
        # B2: 3H

        err_val = 0.0
        for k in range(n_samples):
            # Forward pass: 1-Input -> Hidden(Tanh) -> 1-Output(Linear)
            # hidden = tanh(W1 * inp[k] + B1)
            # out = dot(W2, hidden) + B2

            hidden_dot_W2 = 0.0
            in_val = inp[k]

            for h in range(H):
                w1_val = x[i, h]
                b1_val = x[i, H + h]
                w2_val = x[i, 2 * H + h]

                node_in = w1_val * in_val + b1_val
                node_out = np.tanh(node_in)
                hidden_dot_W2 += w2_val * node_out

            b2_val = x[i, 3 * H]
            out = hidden_dot_W2 + b2_val

            diff = out - tgt[k]
            err_val += diff * diff

        f[i] = err_val
    return f, None, None


@njit(fastmath=True)
def _fast_calc_fm(x, H_harm, t, y_tgt):
    """
    Problem 8: Frequency Modulation Sound Synthesis (Minimization)
    拟合目标声波。
    Args:
        x: [amp1, freq1, amp2, freq2, ...]
        H_harm: 谐波数量 ( = dim / 2 )
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_points = len(t)

    for i in range(ps):
        err_sum = 0.0
        for ti in range(n_points):
            t_val = t[ti]
            y_syn = 0.0
            # Synthesis: Sum( amp_k * sin(freq_k * t) )
            for k in range(1, H_harm + 1):
                amp = x[i, 2 * k - 2]
                freq = x[i, 2 * k - 1]
                y_syn += amp * np.sin(freq * t_val)

            diff = y_tgt[ti] - y_syn
            err_sum += diff * diff
        f[i] = err_sum
    return f, None, None


@njit(fastmath=True)
def _fast_calc_wsn(x, N_sens, Anchors, Dist_A):
    """
    Problem 9: Wireless Sensor Network Localization (Minimization)
    根据锚点距离推算传感器位置。
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    for i in range(ps):
        err_val = 0.0
        for k in range(N_sens):
            px = x[i, k * 2]
            py = x[i, k * 2 + 1]
            # Sum of errors to 4 anchors
            for a in range(4):
                ax = Anchors[a, 0]
                ay = Anchors[a, 1]
                d_est = np.sqrt((px - ax) ** 2 + (py - ay) ** 2)
                d_true = Dist_A[k, a]
                diff = d_est - d_true
                err_val += diff * diff
        f[i] = err_val
    return f, None, None


@njit(fastmath=True)
def _fast_calc_kmeans(x, K, Data):
    """
    Problem 10: K-Means Clustering (Minimization)
    最小化簇内距离平方和 (Within-Cluster Sum of Squares).
    Args:
        x: [cx1, cy1, cx2, cy2, ...] 聚类中心坐标
        Data: 样本点
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    n_data = Data.shape[0]

    for i in range(ps):
        J = 0.0
        for d in range(n_data):
            dx = Data[d, 0]
            dy = Data[d, 1]
            min_dist2 = 1e20

            # Find closest centroid
            for k in range(K):
                cx = x[i, k * 2]
                cy = x[i, k * 2 + 1]
                dist2 = (cx - dx) ** 2 + (cy - dy) ** 2
                if dist2 < min_dist2:
                    min_dist2 = dist2
            J += min_dist2
        f[i] = J
    return f, None, None


@njit(fastmath=True)
def _fast_calc_eld(x, Load, a, b, c):
    """
    Problem 11: Economic Load Dispatch (Constrained Minimization)
    电力系统负荷分配。

    Returns:
        f: 燃料成本
        h: 等式约束 (总发电量 - 负荷 = 0)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))
    D = x.shape[1]

    for i in range(ps):
        cost = 0.0
        p_sum = 0.0
        for k in range(D):
            P = x[i, k]
            # Quadratic Cost Function: a*P^2 + b*P + c
            cost += a[k] * P * P + b[k] * P + c[k]
            p_sum += P
        f[i] = cost
        h[i, 0] = p_sum - Load
    return f, None, h


@njit(fastmath=True)
def _fast_calc_portfolio(x, Ret, Cov, Risk_Max):
    """
    Problem 12: Portfolio Optimization (Constrained Minimization)
    最大化收益 (Minimize negative return)，同时满足风险约束。

    Returns:
        f: 负的总预期收益 (Negative Expected Return)
        g: 风险约束 (Risk - MaxRisk <= 0)
        h: 权重和约束 (Sum(w) - 1 = 0)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))
    g = np.zeros((ps, 1))
    D = x.shape[1]

    for i in range(ps):
        ret_sum = 0.0
        w_sum = 0.0
        risk_calc = 0.0

        # 一次性遍历 D 个资产，同时计算一维项和二维项
        for r in range(D):
            w_r = x[i, r]

            # 1. 累加预期收益: sum(r_i * x_i)
            ret_sum += Ret[r] * w_r

            # 2. 累加权重和: sum(x_i)
            w_sum += w_r

            # 3. 累加风险 (二次型): sum(sum(xi * Cij * xj))
            for c in range(D):
                risk_calc += w_r * Cov[r, c] * x[i, c]

        # 赋值并满足标准优化形式
        f[i] = -ret_sum  # 最小化负收益
        g[i, 0] = risk_calc - Risk_Max  # 风险约束 <= 0
        h[i, 0] = w_sum - 1.0  # 权重和约束 == 0

    return f, g, h

@njit(fastmath=True)
def _fast_calc_hydro(x, D, Inflow, Vol_0, Vmin, Vmax):
    """
    Problem 13: Hydrothermal Scheduling (Constrained Minimization)
    水库调度优化。

    Returns:
        f: 发电成本 (简化为流量的二次函数)
        g: 库容约束 (Vmin <= Vol <= Vmax)
        h: 终末库容约束 (Vol_end = Vol_0)
    """
    ps = x.shape[0]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))
    g = np.zeros((ps, D * 2))

    for i in range(ps):
        cost = 0.0
        Vol = Vol_0
        for t in range(D):
            Q = x[i, t]  # Discharge
            cost += 0.1 * Q * Q

            inf_t = Inflow[t]
            # Volume Balance Equation: V(t+1) = V(t) + Inflow - Discharge
            Vol = Vol + inf_t - Q

            # Constraints: Vmin <= Vol <= Vmax
            g[i, t] = Vmin - Vol  # Vmin - Vol <= 0  => Vol >= Vmin
            g[i, t + D] = Vol - Vmax  # Vol - Vmax <= 0  => Vol <= Vmax

        f[i] = cost
        h[i, 0] = Vol - Vol_0  # End volume must equal start volume
    return f, g, h


@njit(fastmath=True)
def _fast_calc_beam(x, L, P_load, E, Wi):
    """
    Problem 14: Stepped Cantilever Beam Design (Constrained Minimization)
    阶梯悬臂梁设计：最小化总重量，同时满足端点最大挠度约束。

    Returns:
        f: 重量 (Weight/Volume)
        g: 挠度约束 (Deflection - Limit <= 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    g = np.zeros((ps, 1))

    for i in range(ps):
        weight = 0.0
        deflection = 0.0
        for k in range(D):
            Hi = x[i, k]  # Height/Thickness (决策变量)
            Wi_val = Wi[k]

            # 1. 累加体积/重量
            weight += Wi_val * Hi * L

            # 2. 计算当前梁段的惯性矩，并累加端点挠度贡献
            I_val = (Wi_val * Hi * Hi * Hi) / 12.0  # Moment of Inertia
            deflection += (P_load * L * L * L) / (3.0 * E * I_val)

        f[i] = weight
        g[i, 0] = deflection - 2.0  # 最大挠度限制 Limit = 2.0

    return f, g, None


@njit(fastmath=True)
def _fast_calc_dispatch(x, Demand, Ramp, E_max, E_min, E_init):
    """
    Problem 15: Generator Scheduling with Energy Storage (Constrained)
    完全解耦版：支持任意维度 D，支持外部动态传入不同规模的算例参数。

    Args:
        x: (ps, D) 发电机在 D 个时段的出力序列
        Demand: (D,) 该算例在 D 个时段的负荷序列
        Ramp: 该算例的爬坡率限制
        E_max, E_min, E_init: 该算例的电池容量上限、下限和初始电量

    Returns:
        f: (ps,) 目标函数值 (发电成本)
        g: (ps, D*3) 约束违背度矩阵
    """
    ps = x.shape[0]
    D = x.shape[1]

    f = np.zeros(ps)
    g = np.zeros((ps, D * 3))

    for i in range(ps):
        cost = 0.0
        current_E = E_init  # 从外部传入的初始电量开始

        for k in range(D):
            P_gen = x[i, k]
            P_load = Demand[k]

            # 1. 成本累加
            cost += 0.01 * P_gen * P_gen + 2.0 * P_gen

            # 2. 爬坡约束 (存储在 g 的 0 到 D-1 列)
            if k > 0:
                P_prev = x[i, k - 1]
                g[i, k] = np.abs(P_gen - P_prev) - Ramp
            else:
                g[i, k] = -1.0  # 首个时段无爬坡限制

            # 3. 严格按数学模型更新状态
            current_E += (P_gen - P_load)

            # 4. 储能边界约束
            # 下限约束 (存储在 g 的 D 到 2D-1 列)
            g[i, D + k] = E_min - current_E
            # 上限约束 (存储在 g 的 2D 到 3D-1 列)
            g[i, 2 * D + k] = current_E - E_max

        f[i] = cost

    return f, g, None


@njit(fastmath=True)
def _fast_calc_iir_true(x, limit, u_in, d_target):
    """
    Problem 16: IIR Filter Design (Constrained)
    真正符合公式 (39) 的实现：执行差分方程，计算信号拟合 MSE。

    Args:
        x: (ps, D) 滤波器系数。假设前 D/2 为前馈系数(分子b)，后 D/2 为反馈系数(分母a)。
        limit: 稳定性绝对值约束阈值
        u_in: (T,) 输入激励信号 (如白噪声或阶跃信号)
        d_target: (T,) 期望的目标响应信号
    """
    ps = x.shape[0]
    D = x.shape[1]
    T = len(u_in)

    f = np.zeros(ps)
    g = np.zeros((ps, 1))

    order = D // 2  # 滤波器阶数 (假设分子分母同阶)

    for i in range(ps):
        # 1. 稳定性约束 (L1 范数)
        s_abs = 0.0
        # 【修改点 1】：只对反馈系数（分母，索引从 order 到 D-1）进行稳定性约束惩罚
        for k in range(order, D):
            s_abs += np.abs(x[i, k])
        g[i, 0] = s_abs - limit

        # 2. 目标函数：执行 IIR 差分方程并计算误差
        sse = 0.0
        y_out = np.zeros(T)  # 存储实际输出

        for t in range(T):
            y_val = 0.0
            # 前馈部分 (Feedforward: 对应分子系数 b)
            for j in range(order):
                if t - j >= 0:
                    y_val += x[i, j] * u_in[t - j]

            # 反馈部分 (Feedback: 对应分母系数 a)
            for j in range(order):
                if t - j - 1 >= 0:
                    # x 的后半段是反馈系数 a_1 到 a_order
                    y_val -= x[i, order + j] * y_out[t - j - 1]

            y_out[t] = y_val

            # 计算误差平方和
            diff = y_val - d_target[t]
            sse += diff * diff

        # 【修改点 2】：将 SSE 转换为真正的 MSE，与论文基准量级对齐
        f[i] = sse / T

    return f, g, None


from numba import njit
import numpy as np


@njit(fastmath=True)
def _fast_calc_inventory_opt(x, h_cost, s_cost, d_rate, v_unit, c_unit, v_max, b_max):
    """
    Problem 17 (Replaced): Multi-Item Inventory Optimization
    计算总库存成本，并评估物理容量和采购预算的不等式约束。

    Args:
        x: (ps, D) 种群矩阵，D 为商品种类数，x_i 为第 i 种商品的订货量。
        h_cost: (D,) 每种商品的单位持有成本 h_i
        s_cost: (D,) 每种商品的单次订购成本 s_i
        d_rate: (D,) 每种商品的年需求率 d_i
        v_unit: (D,) 每种商品的单位体积 v_i
        c_unit: (D,) 每种商品的单位采购成本 c_i
        v_max: (float) 仓库最大物理总容积 V_{max}
        b_max: (float) 可用总预算 B_{max}
    """
    ps = x.shape[0]
    D = x.shape[1]

    f = np.zeros(ps)
    g = np.zeros((ps, 2))  # 2 个不等式约束

    for i in range(ps):
        total_cost = 0.0
        total_volume = 0.0
        total_budget = 0.0

        for j in range(D):
            xj = x[i, j]
            # 目标函数：总成本
            total_cost += (h_cost[j] * xj / 2.0) + (s_cost[j] * d_rate[j] / xj)
            # 约束累加项
            total_volume += v_unit[j] * xj
            total_budget += c_unit[j] * xj

        # 赋值目标函数
        f[i] = total_cost

        # 赋值不等式约束 (g <= 0)
        g[i, 0] = total_volume - v_max
        g[i, 1] = total_budget - b_max

    return f, g, None


@njit(fastmath=True)
def _fast_calc_vessel(x, P_int, R, L, S):
    """
    Problem 18 (Corrected): Pressure Vessel Design (Constrained)
    严格对齐公式 (3-18)：计算高压容器的总金属体积，并评估最大环向应力约束。

    Args:
        x: (ps, D) 种群矩阵，D 为管壁分段数 N，x_i 为第 i 段管壁的厚度 Th
        P_int: (float) 内部设计压力 P_{int}
        R: (float) 容器半径 R
        L: (float) 每段容器的长度 L (原代码遗漏项)
        S: (float) 材料最大许用屈服应力 S_{max}

    Returns:
        f: (ps,) 金属总材质体积 (Material Volume)
        g: (ps, 1) 应力约束 (Max_Stress - S_max <= 0)
        h: None (无等式约束)
    """
    ps = x.shape[0]
    D = x.shape[1]

    f = np.zeros(ps)
    g = np.zeros((ps, 1))

    for i in range(ps):
        vol_metal = 0.0
        max_stress = -1e20

        for k in range(D):
            Th = x[i, k]  # 第 k 段的壁厚 x_i

            # 【修复点 1】：目标函数计算真实总金属体积，补上遗漏的段长 L
            vol_metal += 2.0 * np.pi * R * Th * L

            # 约束：计算第 k 段的环向应力 (Hoop stress)
            stress = (P_int * R) / Th

            # 动态更新整条管道的最大应力 (木桶效应)
            if stress > max_stress:
                max_stress = stress

        # 赋值目标函数 f(x)
        f[i] = vol_metal

        # 赋值不等式约束 g(x) <= 0
        g[i, 0] = max_stress - S

    return f, g, None

@njit(fastmath=True)
def _fast_calc_spring(x, K_req, N_c, G, D_coil):
    """
    Problem 19: Series Spring System Design (Constrained)
    对齐公式 (3-19) 并优化了底层计算性能。

    Returns:
        f: (ps,) 线径平方和 (Mass proxy)
        g: None (无不等式约束)
        h: (ps, 1) 刚度等式约束 (K_eq - K_req = 0)
    """
    ps = x.shape[0]
    D = x.shape[1]

    f = np.zeros(ps)
    h = np.zeros((ps, 1))

    # 【核心提速点】：提前计算与决策变量线径无关的系统柔度常数（物理意义：材料与几何固有柔性）
    # 将原本在 D 次内循环里重复计算的常数剥离，时间复杂度骤降
    flexibility_const = (8.0 * D_coil * D_coil * D_coil * N_c) / G

    for i in range(ps):
        sum_sq = 0.0
        sum_inv_k = 0.0

        for k in range(D):
            d = x[i, k]  # 第 k 段弹簧的线径
            sum_sq += d * d

            # 直接使用预存的常数除以 d^4，累加单根弹簧的柔度 (1/k_i)
            d4 = d * d * d * d
            sum_inv_k += flexibility_const / d4

        # 赋值目标函数
        f[i] = sum_sq

        # 赋值等式约束：总刚度 (柔度之和的倒数) 减去 目标刚度
        k_eq = 1.0 / sum_inv_k
        h[i, 0] = k_eq - K_req

    return f, None, h


@njit(fastmath=True)
def _fast_calc_rocket(x, H_tgt, g_g, m, dt):
    """
    Problem 20: Rocket Dynamics (Constrained)

    Returns:
        f: 推力平方和 (Fuel Consumption)
        h: 最终高度约束 (y_final - Target = 0)
    """
    ps = x.shape[0]
    D = x.shape[1]
    f = np.zeros(ps)
    h = np.zeros((ps, 1))

    for i in range(ps):
        thrust_sq = 0.0
        v = 0.0
        y = 0.0

        # Simple Euler Integration
        for k in range(D):
            th = x[i, k]  # Thrust at step k
            thrust_sq += th * th

            acc = (th / m) - g_g
            v += acc * dt
            y += v * dt

        f[i] = thrust_sq
        h[i, 0] = y - H_tgt
    return f, None, h
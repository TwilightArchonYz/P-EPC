import os
import pickle
import argparse
import multiprocessing
import numpy as np
from tqdm import tqdm
from evorl.problems.scalable_problem import ScalableProblem
from evorl.problems.params_def import get_raw_params  # 修改点：导入已修正的参数生成逻辑


# ==============================================================================
# Parameter Generation Logic
# Defines how each problem instance is randomized.
# ==============================================================================

def get_problem_params(prob_k: int, D: int, rng: np.random.RandomState) -> dict:
    """
    Generate specific parameters for a problem instance.
    Refactored from original generate_data.py to be stateless.

    [修改点] 直接代理给 params_def.get_raw_params，
    确保离线生成的 benchmark 数据与物理 JIT 内核的最新参数需求严格咬合。
    """
    return get_raw_params(prob_k, D, rng)


# ==============================================================================
# Worker Process
# ==============================================================================

def process_single_instance(args):
    """
    Worker function to generate one problem instance.
    Includes PF1/PF2 calculation (Process 2.3).
    """
    prob_k, dim, inst_id, sample_size = args

    # 1. Deterministic Seed Generation
    # Ensure reproducibility: Seed depends on ProbID, Dim, and InstID
    # Formula: ProbID * 100000 + Dim * 1000 + InstID
    seed = prob_k * 100000 + dim * 1000 + inst_id
    rng = np.random.RandomState(seed)

    # 2. Generate Parameters
    # (Process 2.2)
    par = get_problem_params(prob_k, dim, rng)

    # 3. Generate Coordinate Transforms (Shift/Rotation)
    # Using a temporary ScalableProblem to access bounds logic
    # We pass empty params initially just to get bounds
    temp_prob = ScalableProblem(prob_k, dim, par)
    lb, ub = temp_prob.lb, temp_prob.ub
    actual_dim = temp_prob.dim

    if prob_k <= 10:
        # Math problems: Random Shift & Rotation
        shift = lb + (ub - lb) * rng.rand(actual_dim)
        H_mat = rng.randn(actual_dim, actual_dim)
        Q, _ = np.linalg.qr(H_mat)
        matrix = Q
    else:
        # Physical problems: No shift/rot
        shift = np.zeros(actual_dim)
        matrix = np.eye(actual_dim)

    # Add to params
    par['shift'] = shift
    par['matrix'] = matrix

    # 4. Calculate Penalty Factors (PF1, PF2)
    # (Process 2.3)
    # Re-instantiate with full params to use evaluate logic
    # Note: PF1/PF2 are 0.0 initially for calculation
    prob_for_calc = ScalableProblem(prob_k, dim, par, pf1=0.0, pf2=0.0)

    X_sample = lb + rng.rand(sample_size, actual_dim) * (ub - lb)
    _, f_vals, cv_vals = prob_for_calc.evaluate(X_sample)

    max_abs_f = np.max(np.abs(f_vals))
    if max_abs_f == 0: max_abs_f = 1.0

    pf1 = 0.0
    pf2 = 0.0

    # Logic: if any constraint violation exists, calculate penalties
    if np.max(cv_vals) > 1e-9:
        # Target order of magnitude logic
        target_order = 10 ** (np.ceil(np.log10(max_abs_f)) + 1)
        pf1 = target_order

        nonzero_cv = cv_vals[cv_vals > 1e-9]
        min_cv = np.min(nonzero_cv) if len(nonzero_cv) > 0 else 1e-4
        pf2 = target_order / min_cv

    # 5. Pack Result
    # We store the raw dictionary. ScalableProblem can reconstruct from this.
    data_entry = {
        'id': (prob_k, dim, inst_id),
        'params': par,
        'pf1': pf1,
        'pf2': pf2,
        'seed': seed  # Save seed for traceability
    }

    return (prob_k, dim, inst_id), data_entry


# ==============================================================================
# Main Entry Point
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(description="Generate Benchmark Data (Process 2.1-2.3)")
    parser.add_argument('--dims', type=int, nargs='+', default=[30, 40, 50], help='Dimensions to generate')
    parser.add_argument('--n_train', type=int, default=80, help='Number of training instances per problem')
    parser.add_argument('--n_test', type=int, default=20, help='Number of testing instances per problem')
    parser.add_argument('--sample_size', type=int, default=100000, help='Sample size for penalty calculation')
    parser.add_argument('--cores', type=int, default=4, help='Number of parallel cores')
    parser.add_argument('--save_dir', type=str, default='../data/benchmarks', help='Output directory')

    args = parser.parse_args()

    # 1. Setup Directory
    save_dir = os.path.join(os.path.dirname(__file__), args.save_dir)
    os.makedirs(save_dir, exist_ok=True)

    total_inst = args.n_train + args.n_test
    print(f"==================================================")
    print(f"Generating Benchmarks")
    print(f"Dimensions: {args.dims}")
    print(f"Instances : {args.n_train} (Train) + {args.n_test} (Test) = {total_inst}")
    print(f"Problems  : 20")
    print(f"Cores     : {args.cores}")
    print(f"Output    : {save_dir}")
    print(f"==================================================")

    # 2. Build Task List
    # We group by dimension to save separate files
    for d in args.dims:
        tasks = []
        for k in range(1, 21):  # Problems 1 to 20
            for i in range(1, total_inst + 1):
                # Task: (prob_k, dim, inst_id, sample_size)
                tasks.append((k, d, i, args.sample_size))

        print(f"\nProcessing Dimension {d} ({len(tasks)} tasks)...")

        # 3. Parallel Execution
        results_dict = {}
        with multiprocessing.Pool(processes=args.cores) as pool:
            for key, data in tqdm(pool.imap_unordered(process_single_instance, tasks), total=len(tasks)):
                results_dict[key] = data

        # 4. Save to Disk
        # Format: benchmarks_30d.pkl
        filename = f"benchmarks_{d}d.pkl"
        filepath = os.path.join(save_dir, filename)

        # Add metadata about train/test split
        save_obj = {
            'metadata': {
                'dim': d,
                'n_train': args.n_train,
                'n_test': args.n_test,
                'total_inst': total_inst,
                'train_ids': list(range(1, args.n_train + 1)),
                'test_ids': list(range(args.n_train + 1, total_inst + 1))
            },
            'data': results_dict
        }

        with open(filepath, 'wb') as f:
            pickle.dump(save_obj, f)

        print(f"[Saved] {filepath}")

    print("\nAll Done.")


if __name__ == "__main__":
    main()
import os
import pickle
import argparse
import multiprocessing
import numpy as np
from tqdm import tqdm
from evorl.problems.scalable_problem import ScalableProblem


# ==============================================================================
# Parameter Generation Logic
# Defines how each problem instance is randomized.
# ==============================================================================

def get_problem_params(prob_k: int, D: int, rng: np.random.RandomState) -> dict:
    """
    Generate specific parameters for a problem instance.
    Refactored from original generate_data.py to be stateless.
    """
    par = {}

    # Specific logic for each problem type
    if prob_k == 1:  # LJ
        par['sigma'] = 1.0 + 0.1 * (rng.rand() - 0.5)
        par['epsilon'] = 1.0 + 0.1 * (rng.rand() - 0.5)
        par['N_atoms'] = int(np.floor(D / 3))
    elif prob_k == 2:  # Morse
        par['rho'] = 14.0 + 1.0 * (rng.rand() - 0.5)
        par['N_atoms'] = int(np.floor(D / 3))
    elif prob_k == 3:  # Antenna
        shift = 30 * (rng.rand() - 0.5) * np.pi / 180
        width = 60 * np.pi / 180
        par['phi_sll'] = np.linspace(20 * np.pi / 180 + shift, 20 * np.pi / 180 + shift + width, 20)
        par['N'] = D
    elif prob_k == 4:  # Radar
        par['phase_bias'] = 2 * np.pi * rng.rand(D)
    elif prob_k == 5:  # Protein
        ratio = 0.6
        base = (rng.rand(D) < ratio).astype(float)
        par['full_seq'] = np.concatenate([[0, 1], base])
    elif prob_k == 6:  # Robot
        max_reach = D
        target_dist = max_reach * (0.8 + 0.15 * rng.rand())
        vec = rng.randn(3)
        par['Target'] = (vec / np.linalg.norm(vec)) * target_dist
    elif prob_k == 7:  # NN
        par['inputs'] = np.arange(-1, 1.1, 0.1)
        shift = 0.5 * (rng.rand() - 0.5)
        scale = 2.0 + 0.5 * (rng.rand() - 0.5)
        par['targets'] = scale * (par['inputs'] + shift) ** 2
        H = int(np.floor((D - 1) / 3))
        valid_D = 3 * H + 1
        # Correction logic from original code
        if valid_D > D:
            valid_D = D
            H = int(np.floor((D - 1) / 3))
        par['H'] = H
        par['valid_D'] = valid_D
    elif prob_k == 8:  # FM Synth
        t = np.arange(0, 2 * np.pi + 0.05, 0.1)
        par['t'] = t
        clean_sig = np.sin(t + 2 * np.pi * rng.rand())
        noise = 0.1 * rng.randn(len(t))
        par['y_tgt'] = clean_sig + noise
        par['H_harm'] = int(np.floor(D / 2))
    elif prob_k == 9:  # WSN
        par['Anchors'] = np.zeros((4, 2))
        par['Anchors'][0] = [0, 2 + 8 * rng.rand()]
        par['Anchors'][1] = [10, 2 + 8 * rng.rand()]
        par['Anchors'][2] = [2 + 8 * rng.rand(), 0]
        par['Anchors'][3] = [2 + 8 * rng.rand(), 10]
        par['N_sens'] = int(np.floor(D / 2))
        True_P = rng.rand(par['N_sens'], 2) * 10
        Dist_A = np.zeros((par['N_sens'], 4))
        for s in range(par['N_sens']):
            for a in range(4):
                Dist_A[s, a] = np.linalg.norm(True_P[s] - par['Anchors'][a])
        par['Dist_A'] = Dist_A
    elif prob_k == 10:  # K-Means
        par['K'] = int(np.floor(D / 2))
        shift = 0.5 * rng.randn(2)
        # Fix: Ensure Data is float
        Data = np.vstack([rng.randn(50, 2) + 1, rng.randn(50, 2) - 1])
        par['Data'] = Data + shift
    elif prob_k == 11:  # ELD
        max_cap = 200 * D
        load_ratio = 0.85 + 0.07 * rng.rand()
        par['Load'] = max_cap * load_ratio
        reps = int(np.ceil(D / 3))
        a_base = np.array([0.008, 0.02, 0.005])
        b_base = np.array([7, 10, 5])
        c_base = np.array([200, 100, 300])
        a_rep = np.tile(a_base, reps) * (1 + 0.1 * rng.randn(reps * 3))
        b_rep = np.tile(b_base, reps)
        c_rep = np.tile(c_base, reps)
        par['a'] = a_rep[:D]
        par['b'] = b_rep[:D]
        par['c'] = c_rep[:D]
    elif prob_k == 12:  # Portfolio
        par['Ret'] = 0.02 + 0.15 * rng.rand(D)
        base = rng.randn(D, D)
        market = rng.rand(D, 1)
        par['Cov'] = base @ base.T + 0.5 * (market @ market.T)
        par['Risk_Max'] = np.mean(np.diag(par['Cov'])) * 0.9
    elif prob_k == 13:  # Hydro
        t_idx = np.arange(D)
        season = 5 * np.sin(2 * np.pi * t_idx / D)
        par['Inflow'] = 10 + season + 2 * rng.rand(D)
        par['Vol_0'] = 100.0
        par['Vol_min'] = 50.0
        par['Vol_max'] = 150.0
    elif prob_k == 14:  # Beam
        par['L'] = 100 / D
        par['P'] = 1000 * (1 + 0.2 * rng.randn())
        par['E'] = 2e5
        par['Wi'] = 5 * np.ones(D)
    elif prob_k == 15:  # Dynamic Dispatch
        Ramp = 10.0
        par['Ramp'] = Ramp
        current_d = 50 + 10 * rng.randn()
        demand_curve = []
        for t in range(D):
            delta = (rng.rand() - 0.5) * 2 * (0.8 * Ramp)
            trend = 2.0 * np.sin(2 * np.pi * t / D)
            step = np.clip(delta + trend, -0.9 * Ramp, 0.9 * Ramp)
            current_d += step
            current_d = np.clip(current_d, 15, 95)
            demand_curve.append(current_d)
        par['Demand'] = np.array(demand_curve)
    elif prob_k == 16:  # IIR Filter
        par['limit'] = 2.0
    elif prob_k == 17:  # Gearbox
        base_ratio = 1.2 + 0.1 * rng.rand()
        par['Target'] = base_ratio ** D
    elif prob_k == 18:  # Pressure Vessel
        par['P_int'] = 15 * (1 + 0.1 * rng.randn())
        par['R'] = 50.0
        par['S_all'] = 200.0
    elif prob_k == 19:  # Spring
        base_k = 150.0
        par['K_req'] = (base_k / D) * (0.8 + 0.2 * rng.rand())
        par['N_coils'] = 10.0
        par['G'] = 80e9
        par['D_coil'] = 0.1
    elif prob_k == 20:  # Rocket
        par['mass'] = 15.0
        par['g'] = 9.8
        par['dt'] = 1.0
        par['H_target'] = (D ** 2) * 0.8 * (1 + 0.1 * rng.randn())

    return par


# ==============================================================================
# Worker Process
# ==============================================================================

def process_single_instance(args):
    """
    Worker function to generate one problem instance.
    Includes PF1/PF2 calculation (Process 2.3).
    """
    prob_k, dim, inst_id, sample_size = args

    # 1. Deterministic Seed Generation
    # Ensure reproducibility: Seed depends on ProbID, Dim, and InstID
    # Formula: ProbID * 100000 + Dim * 1000 + InstID
    seed = prob_k * 100000 + dim * 1000 + inst_id
    rng = np.random.RandomState(seed)

    # 2. Generate Parameters
    # (Process 2.2)
    par = get_problem_params(prob_k, dim, rng)

    # 3. Generate Coordinate Transforms (Shift/Rotation)
    # Using a temporary ScalableProblem to access bounds logic
    # We pass empty params initially just to get bounds
    temp_prob = ScalableProblem(prob_k, dim, par)
    lb, ub = temp_prob.lb, temp_prob.ub
    actual_dim = temp_prob.dim

    if prob_k <= 10:
        # Math problems: Random Shift & Rotation
        shift = lb + (ub - lb) * rng.rand(actual_dim)
        H_mat = rng.randn(actual_dim, actual_dim)
        Q, _ = np.linalg.qr(H_mat)
        matrix = Q
    else:
        # Physical problems: No shift/rot
        shift = np.zeros(actual_dim)
        matrix = np.eye(actual_dim)

    # Add to params
    par['shift'] = shift
    par['matrix'] = matrix

    # 4. Calculate Penalty Factors (PF1, PF2)
    # (Process 2.3)
    # Re-instantiate with full params to use evaluate logic
    # Note: PF1/PF2 are 0.0 initially for calculation
    prob_for_calc = ScalableProblem(prob_k, dim, par, pf1=0.0, pf2=0.0)

    X_sample = lb + rng.rand(sample_size, actual_dim) * (ub - lb)
    _, f_vals, cv_vals = prob_for_calc.evaluate(X_sample)

    max_abs_f = np.max(np.abs(f_vals))
    if max_abs_f == 0: max_abs_f = 1.0

    pf1 = 0.0
    pf2 = 0.0

    # Logic: if any constraint violation exists, calculate penalties
    if np.max(cv_vals) > 1e-9:
        # Target order of magnitude logic
        target_order = 10 ** (np.ceil(np.log10(max_abs_f)) + 1)
        pf1 = target_order

        nonzero_cv = cv_vals[cv_vals > 1e-9]
        min_cv = np.min(nonzero_cv) if len(nonzero_cv) > 0 else 1e-4
        pf2 = target_order / min_cv

    # 5. Pack Result
    # We store the raw dictionary. ScalableProblem can reconstruct from this.
    data_entry = {
        'id': (prob_k, dim, inst_id),
        'params': par,
        'pf1': pf1,
        'pf2': pf2,
        'seed': seed  # Save seed for traceability
    }

    return (prob_k, dim, inst_id), data_entry


# ==============================================================================
# Main Entry Point
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(description="Generate Benchmark Data (Process 2.1-2.3)")
    parser.add_argument('--dims', type=int, nargs='+', default=[10, 30, 50], help='Dimensions to generate')
    parser.add_argument('--n_train', type=int, default=80, help='Number of training instances per problem')
    parser.add_argument('--n_test', type=int, default=20, help='Number of testing instances per problem')
    parser.add_argument('--sample_size', type=int, default=100000, help='Sample size for penalty calculation')
    parser.add_argument('--cores', type=int, default=4, help='Number of parallel cores')
    parser.add_argument('--save_dir', type=str, default='../data/benchmarks', help='Output directory')

    args = parser.parse_args()

    # 1. Setup Directory
    save_dir = os.path.join(os.path.dirname(__file__), args.save_dir)
    os.makedirs(save_dir, exist_ok=True)

    total_inst = args.n_train + args.n_test
    print(f"==================================================")
    print(f"Generating Benchmarks")
    print(f"Dimensions: {args.dims}")
    print(f"Instances : {args.n_train} (Train) + {args.n_test} (Test) = {total_inst}")
    print(f"Problems  : 20")
    print(f"Cores     : {args.cores}")
    print(f"Output    : {save_dir}")
    print(f"==================================================")

    # 2. Build Task List
    # We group by dimension to save separate files
    for d in args.dims:
        tasks = []
        for k in range(1, 21):  # Problems 1 to 20
            for i in range(1, total_inst + 1):
                # Task: (prob_k, dim, inst_id, sample_size)
                tasks.append((k, d, i, args.sample_size))

        print(f"\nProcessing Dimension {d} ({len(tasks)} tasks)...")

        # 3. Parallel Execution
        results_dict = {}
        with multiprocessing.Pool(processes=args.cores) as pool:
            for key, data in tqdm(pool.imap_unordered(process_single_instance, tasks), total=len(tasks)):
                results_dict[key] = data

        # 4. Save to Disk
        # Format: benchmarks_30d.pkl
        filename = f"benchmarks_{d}d.pkl"
        filepath = os.path.join(save_dir, filename)

        # Add metadata about train/test split
        save_obj = {
            'metadata': {
                'dim': d,
                'n_train': args.n_train,
                'n_test': args.n_test,
                'total_inst': total_inst,
                'train_ids': list(range(1, args.n_train + 1)),
                'test_ids': list(range(args.n_train + 1, total_inst + 1))
            },
            'data': results_dict
        }

        with open(filepath, 'wb') as f:
            pickle.dump(save_obj, f)

        print(f"[Saved] {filepath}")

    print("\nAll Done.")


if __name__ == "__main__":
    main()
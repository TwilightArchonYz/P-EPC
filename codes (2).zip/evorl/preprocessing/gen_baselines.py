import os
import csv
import json
import pickle
import numpy as np
from joblib import Parallel, delayed
from evorl.factory import AlgorithmFactory
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def
# 引入核心奖励计算器，用于后续的奖励回填
from evorl.core.reward_def import TrajectoryRewardCalculator
from evorl.utils.naming import PathManager
from evorl.core import state_def


# ==============================================================================
# 0. 配置指纹提取工具 (Config Fingerprint Utils)
# ==============================================================================
def _get_config_fingerprint(cfg):
    """
    提取决定数据集内容的关键配置参数，用于一致性校验。
    不包含任何 try-except，如果配置缺失直接报错。
    """
    if 'gen_instances' in cfg:
        instances = cfg['gen_instances']
    else:
        instances = cfg.get('train_instances', []) + cfg.get('test_instances', [])

    if isinstance(instances, list):
        instances = sorted(list(set(instances)))

    problems = cfg.get('train_problems', [cfg.get('prob_id', 1)])
    if isinstance(problems, list):
        problems = sorted(problems)

    target_dims = cfg['target_dims']
    if isinstance(target_dims, list):
        target_dims = sorted(target_dims)

    seeds = cfg['seed_pool']
    if isinstance(seeds, list):
        seeds = sorted(seeds)

    use_features = cfg.get('use_features')
    if isinstance(use_features, list):
        use_features = sorted(use_features)
    else:
        use_features = None

    return {
        'structure_version': 'v4_decoupled_fes_lpsr',  # [Updated] 版本标识更新
        'ea_name': cfg['ea_name'],
        'train_problems': problems,
        'target_dims': target_dims,
        'gen_instances': instances,
        'seed_pool': seeds,
        'pop_size_factor': cfg.get('pop_size_factor', 18),
        'max_fes_factor': cfg.get('max_fes_factor', 10000),
        'dim_norm_factor': cfg.get('dim_norm_factor', 100.0),
        'head_padding_ratio': cfg.get('head_padding_ratio', 0.2),
        'evo_long_ratio': cfg.get('evo_long_ratio', 0.1),
        'evo_short_ratio': cfg.get('evo_short_ratio', 0.05),
        'use_features': use_features
    }


# ==============================================================================
# 1. 数据收集包装器 (Data Collector Wrapper)
class DataCollectorWrapper:
    def __init__(self, solver, dim_norm_factor=100.0, collect_transitions=True,
                 time_horizon_ratios=None, use_features=None, target_fes=None):
        self.solver = solver
        self.dim_norm_factor = dim_norm_factor
        self.time_horizon_ratios = time_horizon_ratios
        self.use_features = use_features
        self.collect_transitions = collect_transitions
        self.transitions = []
        # 新增：接收 2 倍的 FES 目标
        self.target_fes = target_fes

        if not hasattr(self.solver, 'stagnation_counter'):
            self.solver.stagnation_counter = 0

    def get_state_vector(self):
        return state_def.get_state_vector(
            self.solver,
            self.dim_norm_factor,
            time_horizon_ratios=self.time_horizon_ratios,
            use_features=self.use_features
        )

    def extract_raw_action(self):
        """
        [Modified] 适配字典化的参数提取，按键名排序保证维度顺序一致
        """
        # 1. 此时获取到的是一个字典，例如 {'w': 0.7, 'c1': 1.5, 'c2': 1.5}
        params_dict = state_def.extract_solver_params(self.solver)

        # 2. 如果字典为空，给个兜底的数组防止崩溃
        if not params_dict:
            return np.array([0.5, 0.5], dtype=np.float32)

        # 3. 对键名进行字母排序，保证每次提取出来的维度顺序绝对一致 (如 c1, c2, w)
        sorted_keys = sorted(params_dict.keys())

        # 4. 按排序好的键名提取出对应的值
        ordered_values = [params_dict[k] for k in sorted_keys]

        # 5. 最后转换为 numpy 数组返回
        return np.array(ordered_values, dtype=np.float32)

    def solve(self):
        # 初始化求解器
        self.solver.initialize()

        # 获取初始最差适应度，用于头部填充 (Padding)
        # 直接假设 solver 初始化后一定有 history 或 fitness，不处理异常
        if hasattr(self.solver, 'fitness') and self.solver.fitness is not None:
            initial_worst = np.max(self.solver.fitness)
        else:
            initial_worst = self.solver.history[0][1]

        self.transitions = []

        # 确定实际的运行寿命限制
        run_limit = self.target_fes if getattr(self, 'target_fes', None) is not None else self.solver.max_nfes

        # 主进化循环
        while self.solver.fes < run_limit:
            # 1. 采集当前状态 (State) 并强制拼接缺失的动作维度
            if self.collect_transitions:
                state = self.get_state_vector()
                if self.use_features and len(state) < len(self.use_features):
                    current_params = self.extract_raw_action()
                    pad_len = len(self.use_features) - len(state)
                    state = np.concatenate([state, current_params[:pad_len]])

            # 2. 执行一步进化
            self.solver.evolve()

            # 3. 采集转移数据 (Next State, Action) 并强制拼接缺失的动作维度
            if self.collect_transitions:
                next_state = self.get_state_vector()
                raw_action = self.extract_raw_action()

                if self.use_features and len(next_state) < len(self.use_features):
                    pad_len = len(self.use_features) - len(next_state)
                    next_state = np.concatenate([next_state, raw_action[:pad_len]])

                # 奖励占位：设为 0.0，后续统一使用 RewardCalculator 回填
                reward = 0.0

                # 存储 Transition 元组
                self.transitions.append((state, raw_action, reward, next_state))

        # 返回完整历史曲线、Transition 列表和初始最差值
        final_transitions = self.transitions if self.collect_transitions else None
        return self.solver.history, final_transitions, initial_worst


# ==============================================================================
# 2. 工作进程任务 (Worker Task)
# ==============================================================================
def worker_task(args):
    """
    单次优化任务执行函数。
    """
    pid, dim, inst, seed, config, save_traj = args

    param_dict, pf1, pf2 = params_def.generate_instance_config(pid, dim, inst)
    problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)

    max_fes_factor = config.get('max_fes_factor', 10000)

    # [Updated] 核心修改：解耦数学寿命与物理寿命
    # 1. base_max_nfes 是 1 倍寿命，传给底层用来初始化算法（保证 LSHADE 递减斜率不变）
    base_max_nfes = max_fes_factor * dim

    # 2. target_run_fes 是 2 倍寿命，传给 Wrapper 强制延长实际执行时间
    target_run_fes = base_max_nfes * 1.5

    pop_size_factor = config.get('pop_size_factor', 18)
    pop_size = pop_size_factor * dim

    # [Updated] 创建求解器：传入 base_max_nfes (1倍)
    solver = AlgorithmFactory.create_solver(
        problem=problem,
        ea_name=config['ea_name'],
        pop_size=pop_size,
        max_nfes=base_max_nfes,
        seed=seed
    )

    norm_factor = config.get('dim_norm_factor', 100.0)
    time_horizon_ratios = {
        'long': config.get('evo_long_ratio', 0.1),
        'short': config.get('evo_short_ratio', 0.05)
    }
    use_features = config.get('use_features', None)

    # [Updated] 实例化 Wrapper：传入 target_run_fes (2倍)，让 Wrapper 强制多跑
    collector = DataCollectorWrapper(
        solver,
        dim_norm_factor=norm_factor,
        collect_transitions=save_traj,
        time_horizon_ratios=time_horizon_ratios,
        use_features=use_features,
        target_fes=target_run_fes
    )

    curve, transitions, initial_worst = collector.solve()

    # [Updated] 头部填充逻辑：计算总代数时使用 target_run_fes
    padding_ratio = config.get('head_padding_ratio', 0.2)
    total_generations = target_run_fes / max(1, pop_size)
    k_pad = int(total_generations * padding_ratio)
    k_pad = max(2, k_pad)

    start_fes = curve[0][0]
    start_fit = curve[0][1]

    virtual_fits = np.linspace(initial_worst, start_fit, k_pad + 1)[:-1]
    step_fes = max(1, int(start_fes))

    virtual_prefix = []
    for i, fit in enumerate(virtual_fits):
        fes = start_fes - (k_pad - i) * step_fes
        virtual_prefix.append([fes, fit])

    curve = virtual_prefix + list(curve)
    curve_np = np.array(curve, dtype=np.float64)

    best_fitness = solver.gbest_val
    key = (pid, dim, inst, seed)

    return key, curve_np, transitions, best_fitness


# ==============================================================================
# 3. 辅助函数：计算平均曲线
# ==============================================================================
def _compute_mean_curve(curves):
    """
    对一组基准曲线进行插值并计算平均值。
    """
    min_fes = min(c[0, 0] for c in curves)
    max_fes = max(c[-1, 0] for c in curves)

    mean_len = int(np.mean([len(c) for c in curves]))
    num_samples = mean_len

    common_fes = np.linspace(min_fes, max_fes, num_samples)

    interp_fits = []
    for c in curves:
        fes = c[:, 0]
        fit = c[:, 1]
        y = np.interp(common_fes, fes, fit)
        interp_fits.append(y)

    mean_fits = np.mean(interp_fits, axis=0)
    mean_curve = np.column_stack((common_fes, mean_fits))

    return mean_curve.astype(np.float64)


# ==============================================================================
# 4. 主入口函数 (Main Entry Point)
# ==============================================================================
def generate_dataset(cfg, experiment_dir=None, check_consistency=True):
    """
    主流程：生成基准数据 -> 计算均值 -> 生成专家轨迹 -> 回填奖励。
    """
    ea_name = cfg['ea_name']
    print(f"=== [Generator] Starting Data Generation for {ea_name} ===")

    paths = PathManager.get_paths(cfg, experiment_dir)
    baseline_path = paths['baseline_pkl']
    expert_path = paths['expert_pkl']
    csv_path = paths.get('baseline_report_csv')
    baseline_config_path = baseline_path + '.json'

    if check_consistency:
        current_fingerprint = _get_config_fingerprint(cfg)
        if os.path.exists(baseline_path) and os.path.exists(baseline_config_path):
            with open(baseline_config_path, 'r') as f:
                saved_fingerprint = json.load(f)

            if saved_fingerprint == current_fingerprint:
                print(f"[Generator] VALID baseline data found. Skipping generation.")
                return
            else:
                print(f"[Generator] Config MISMATCH. Forcing regeneration...")
        else:
            print(f"[Generator] No existing data found. Starting generation...")

    target_dims = cfg['target_dims']
    problems = cfg.get('train_problems', [cfg.get('prob_id', 1)])
    instances = cfg.get('gen_instances', cfg['train_instances'] + cfg.get('test_instances', []))
    instances = sorted(list(set(instances)))
    train_instances_set = set(cfg.get('train_instances', []))
    seeds = cfg['seed_pool']
    n_cores = cfg['n_cores']

    tasks = []
    for pid in problems:
        for dim in target_dims:
            for inst in instances:
                for seed in seeds:
                    task_cfg = {
                        'ea_name': cfg['ea_name'],
                        'max_fes_factor': cfg.get('max_fes_factor', 10000),
                        'pop_size_factor': cfg.get('pop_size_factor', 18),
                        'dim_norm_factor': cfg['dim_norm_factor'],
                        'head_padding_ratio': cfg.get('head_padding_ratio', 0.2),
                        'evo_long_ratio': cfg.get('evo_long_ratio', 0.1),
                        'evo_short_ratio': cfg.get('evo_short_ratio', 0.05),
                        'use_features': cfg.get('use_features')
                    }
                    save_traj = (inst in train_instances_set)
                    tasks.append((pid, dim, inst, seed, task_cfg, save_traj))

    if n_cores > 1:
        print(f"[Generator] Parallel execution with joblib (n_jobs={n_cores})...")
        results = Parallel(n_jobs=n_cores, verbose=5)(
            delayed(worker_task)(task) for task in tasks
        )
    else:
        results = [worker_task(task) for task in tasks]

    baseline_seeds = {}
    instance_groups = {}
    expert_data = []
    report_rows = []

    for key, curve, trans, best_fit in results:
        baseline_seeds[key] = curve

        group_key = (key[0], key[1], key[2])
        if group_key not in instance_groups:
            instance_groups[group_key] = []
        instance_groups[group_key].append(curve)

        if trans is not None:
            expert_data.append({'key': key, 'transitions': trans})

        report_rows.append(list(key) + [best_fit])

    print(f"[Generator] Computing mean curves for {len(instance_groups)} instances...")
    baseline_means = {}
    for group_key, curves in instance_groups.items():
        baseline_means[group_key] = _compute_mean_curve(curves)

    print(f"[Generator] Phase 2: Back-propagating rewards for {len(expert_data)} expert trajectories...")

    refilled_count = 0
    for entry in expert_data:
        key = entry['key']
        group_key = (key[0], key[1], key[2])

        seed_bl = baseline_seeds[key]
        mean_bl = baseline_means[group_key]

        calculator = TrajectoryRewardCalculator(
            seed_baseline=seed_bl,
            mean_baseline=mean_bl,
            weight_seed=1.0,
            weight_mean=1.0
        )

        history_fitness = seed_bl[:, 1]
        full_rewards = calculator.compute_rewards(history_fitness)

        n_trans = len(entry['transitions'])
        relevant_rewards = full_rewards[-n_trans:]

        new_transitions = []
        original_trans = entry['transitions']

        for i in range(n_trans):
            s, a, _, sn = original_trans[i]
            r = float(relevant_rewards[i])
            new_transitions.append((s, a, r, sn))

        entry['transitions'] = new_transitions
        refilled_count += 1

    print(f"[Generator] Successfully refilled rewards for {refilled_count} trajectories.")

    final_baseline_data = {
        'seeds': baseline_seeds,
        'means': baseline_means
    }

    os.makedirs(os.path.dirname(baseline_path), exist_ok=True)

    with open(baseline_path, 'wb') as f:
        pickle.dump(final_baseline_data, f)
    print(f"[Generator] Saved Dual-Deck data to {baseline_path}")

    with open(expert_path, 'wb') as f:
        pickle.dump(expert_data, f)
    print(f"[Generator] Saved expert trajectories to {expert_path}")

    fingerprint = _get_config_fingerprint(cfg)
    with open(baseline_config_path, 'w') as f:
        json.dump(fingerprint, f, indent=4)

    if csv_path:
        with open(csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['ProbID', 'Dim', 'InstID', 'Seed', 'BestFitness'])
            writer.writerows(report_rows)


if __name__ == "__main__":
    default_config = {
        'ea_name': 'SHADE',
        'train_problems': [1],
        'target_dims': [10],
        'gen_instances': [1],
        'seed_pool': [1, 2, 3],
        'n_cores': 4,
        'dim_norm_factor': 100.0,
        'max_fes_factor': 10000,
        'pop_size_factor': 18,
        'head_padding_ratio': 0.2,
        'evo_long_ratio': 0.1,
        'evo_short_ratio': 0.05,
        'use_features': None
    }
    generate_dataset(default_config)
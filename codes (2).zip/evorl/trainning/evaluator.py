import numpy as np
import pickle
import os
import torch
import traceback
from multiprocessing.shared_memory import SharedMemory
from joblib import Parallel, delayed
from evorl.factory import AlgorithmFactory
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def
from evorl.utils.naming import PathManager
from evorl.utils.agent_adapter import AgentAdapter


# ==============================================================================
# 1. 核心业务逻辑 (隔离作用域)
# ==============================================================================

def _core_eval_task(task_args, q_table_buffer, visits_buffer):
    """
    内部评估逻辑。
    作用：将 Agent 和 Solver 的生命周期限制在这个函数内。
    当此函数返回时，Agent 和 Solver 的局部变量会被自动销毁，
    从而释放对 SharedMemory Buffer 的引用。
    """
    (pid, dim, inst, seeds, agent_name, agent_state_data, ea_name, config) = task_args

    # 1. 实例化问题
    param_dict, pf1, pf2 = params_def.generate_instance_config(pid, dim, inst)
    problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)

    # 2. 实例化 Agent
    # 注意：这里直接使用传入的 buffer (memoryview)
    agent = AlgorithmFactory.create_agent(
        agent_name,
        state_dim=config.get('state_dim', 6),
        action_dim=config.get('action_dim', 72),
        lr=config.get('lr', 1e-4),
        gamma=config.get('gamma', 0.99),
        batch_size=config.get('batch_size', 128),
        buffer_size=config.get('buffer_size', 100000),
        hidden_dim=config.get('hidden_dim', 128),
        stream_hidden_dim=config.get('stream_hidden_dim', 64),
        state_bins=config.get('state_bins', [5, 4, 4, 4, 4]),
        f_opts=config.get('f_opts'),
        cr_opts=config.get('cr_opts'),
        algo_params=config.get('algo_params'),
        dim_norm_factor=config.get('dim_norm_factor', 100.0),
        device='cpu',
        shared_memory=q_table_buffer,  # 传入 Buffer
        shared_visits=visits_buffer,  # 传入 Buffer
        target_dims=config.get('target_dims'),
        inference_only=True
    )

    # 加载状态 (如果是共享内存模式，这里只会加载元数据，不会覆盖 Q 表)
    if agent_state_data is not None:
        AgentAdapter.load_state(agent, agent_state_data)

    # 3. 准备 Solver 参数
    max_fes_factor = config.get('max_fes_factor', 10000)
    max_nfes = max_fes_factor * dim
    pop_size_factor = config.get('pop_size_factor', 18)
    pop_size = pop_size_factor * dim

    results_list = []

    # 4. 循环评估
    for seed in seeds:
        solver = AlgorithmFactory.create_solver(
            problem=problem,
            ea_name=ea_name,
            agent=agent,
            pop_size=pop_size,
            max_nfes=max_nfes,
            seed=seed,
            mode='test',
            baseline_seed_curve=None,
            baseline_mean_curve=None,
            use_features=config.get('use_features'),
            reward_window_long=config.get('reward_window_long_ratio', 0.5),
            reward_window_short=config.get('reward_window_short_ratio', 0.05)
        )
        res = solver.solve()
        results_list.append(res['best_fitness'])

    return results_list


# ==============================================================================
# 2. 评估工作进程入口 (Evaluation Worker)
# ==============================================================================

def eval_worker(args):
    """
    并行评估工作单元。
    负责：资源连接 -> 调用核心逻辑 -> 资源释放。
    """
    # 解包参数
    q_table_source = args[-2]
    shared_visits_buffer = args[-1]
    task_args = args[:-2]

    # --- 资源管理 ---
    shm_q_handle = None
    shm_v_handle = None
    q_buf = None
    v_buf = None

    try:
        # 1. 连接 Q-Table 共享内存
        if q_table_source is not None:
            if isinstance(q_table_source, dict):
                shm_name = q_table_source.get('name')
                if shm_name:
                    shm_q_handle = SharedMemory(name=shm_name)
                    q_buf = shm_q_handle.buf
            elif hasattr(q_table_source, 'data'):
                # Legacy 模式 (直接传递数组)
                q_buf = q_table_source.data

        # 2. 连接 Visits 共享内存
        if shared_visits_buffer is not None:
            if isinstance(shared_visits_buffer, dict):
                shm_name = shared_visits_buffer.get('name')
                if shm_name:
                    shm_v_handle = SharedMemory(name=shm_name)
                    v_buf = shm_v_handle.buf
            elif hasattr(shared_visits_buffer, 'data'):
                v_buf = shared_visits_buffer.data
            elif hasattr(shared_visits_buffer, 'base'):
                v_buf = shared_visits_buffer

        # 3. [关键] 调用隔离的核心逻辑
        # 当 _core_eval_task 返回时，它内部的所有局部变量（包括 Agent）都会被销毁。
        # 因此，q_buf 和 v_buf 的引用计数会自动归零。
        results = _core_eval_task(task_args, q_buf, v_buf)
        return results

    finally:
        # 4. 安全关闭句柄 (捕获并打印 BufferError)
        if shm_q_handle is not None:
            try:
                shm_q_handle.close()
            except Exception as e:
                # [Retained Log] 保留此日志以便观察 BufferError
                print(f"[Cleanup Error] Q-Handle Close Failed: {e}")

        if shm_v_handle is not None:
            try:
                shm_v_handle.close()
            except Exception:
                pass


class Evaluator:
    """
    评估器 (Evaluator)
    """

    def __init__(self, config, monitor=None):
        self.cfg = config
        self.monitor = monitor
        self.seeds = config.get('seed_pool', [42, 43, 44])
        self.train_instances = set(config.get('train_instances', []))
        self.val_instances = set(config.get('validation_instances', []))
        self.test_instances = set(config.get('test_instances', []))
        self.all_instances = sorted(list(self.train_instances | self.val_instances))
        self.problems = config.get('train_problems', [1])
        self.target_dims = config.get('target_dims', [10, 30])
        self.n_cores = config.get('n_cores', 1)
        self.paths = PathManager.get_paths(config)
        self.baselines_lookup = self._load_baselines()
        self.global_best_improvement = -float('inf')

    def _load_baselines(self):
        """
        加载基准数据，并根据当前训练的 MaxFES 进行对齐截断。
        解决"长基准"导致的评估不公平问题。
        """
        path = self.paths.get('baseline_pkl')
        lookup = {}

        # [Fix] 获取当前训练配置的 MaxFES 限制
        # 注意：Config 中的 max_fes_factor 是 5000，而基准生成时用了 10000
        # 我们需要用 5000 * dim 来截断基准
        train_fes_factor = self.cfg.get('max_fes_factor', 5000)

        if path and os.path.exists(path):
            try:
                print(f"[Evaluator] Loading baseline from: {path}")
                print(f"[Evaluator] Aligning baselines to Training Budget (Factor={train_fes_factor})...")

                with open(path, 'rb') as f:
                    data = pickle.load(f)

                source_data = data
                if isinstance(data, dict) and 'seeds' in data:
                    source_data = data['seeds']

                for key, curve in source_data.items():
                    # key = (pid, dim, inst, seed)
                    dim = key[1]
                    target_limit = train_fes_factor * dim

                    if len(curve) > 0:
                        # 1. 提取 FES 和 Fitness 列
                        fes_col = curve[:, 0]
                        fit_col = curve[:, 1]

                        # 2. 查找 target_limit 对应的索引
                        # 找到第一个大于等于限制的点的索引
                        idx = np.searchsorted(fes_col, target_limit)

                        if idx < len(fes_col):
                            # 如果找到了精确点或刚好跨过的点
                            # 简单起见，取该点的 Fitness
                            # 更精确的做法是插值，但对于评估通常直接取最近点即可
                            val = fit_col[idx]
                        else:
                            # 如果基准数据比训练预算还短（理论不应发生），取最后一点
                            val = fit_col[-1]

                        # 确保转换为浮点数
                        if isinstance(val, (list, np.ndarray, tuple)):
                            try:
                                val = float(val[-1])
                            except:
                                val = float(val)
                        else:
                            val = float(val)

                        lookup[key] = val

            except Exception as e:
                print(f"[Evaluator Error] {e}")
                traceback.print_exc()
        return lookup

    def run(self, epoch, agent, ea_name, shm_q_info=None, shm_v_info=None):
        print(f"[Evaluator] Running Epoch {epoch} Evaluation (Train & Val)...")
        tasks = []

        # 共享内存协议
        use_shared_q = False
        q_table_ref = None
        shared_visits_ref = None

        if shm_q_info is not None:
            use_shared_q = True
            q_table_ref = shm_q_info
        elif hasattr(agent, 'q_table') and isinstance(agent.q_table, np.ndarray):
            use_shared_q = True
            q_table_ref = agent.q_table

        if shm_v_info is not None:
            shared_visits_ref = shm_v_info
        else:
            shared_visits_ref = AgentAdapter.get_shared_visits(agent)

        worker_state_data = AgentAdapter.prepare_state_for_worker(agent, use_shared_q=use_shared_q)

        # [FIX] 激进序列化过滤 - 解决 PicklingError (WinError 87)
        # 强制移除所有可能导致序列化体积过大的数组对象
        if isinstance(worker_state_data, dict):
            keys_to_remove = [
                'q_table', 'q_table_tensor',
                'q_table_target', 'q_table_target_tensor',
                'visits', 'visits_tensor',
                'state_memory', 'next_state_memory',
                'action_memory', 'reward_memory'
            ]
            for k in keys_to_remove:
                if k in worker_state_data:
                    del worker_state_data[k]

        # 任务生成
        for pid in self.problems:
            for dim in self.target_dims:
                for inst in self.all_instances:
                    task = (pid, dim, inst, self.seeds,
                            self.cfg['agent_name'], worker_state_data,
                            ea_name, self.cfg)
                    tasks.append(task)

        if not tasks:
            return False, []

        joblib_tasks = [(*t, q_table_ref, shared_visits_ref) for t in tasks]

        torch.set_num_threads(1)
        nested_results = Parallel(n_jobs=self.n_cores, verbose=10, batch_size='auto')(
            delayed(eval_worker)(t) for t in joblib_tasks
        )

        fitness_values = [val for sublist in nested_results for val in sublist]

        # 统计逻辑保持不变
        train_fits = []
        val_fits = []
        group_imps_train = []
        group_imps_val = []
        detailed_stats = {}
        idx = 0

        for pid in self.problems:
            for dim in self.target_dims:
                for inst in self.all_instances:
                    for seed in self.seeds:
                        rl_fit = fitness_values[idx]
                        idx += 1

                        set_type = "Train" if inst in self.train_instances else "Val"
                        group_key = (pid, dim, set_type)
                        if group_key not in detailed_stats:
                            detailed_stats[group_key] = {'base': [], 'rl': [], 'details': []}

                        key = (pid, dim, inst, seed)
                        base_fit = self.baselines_lookup.get(key)

                        if base_fit is not None:
                            detailed_stats[group_key]['base'].append(base_fit)
                            detailed_stats[group_key]['rl'].append(rl_fit)
                            denom = abs(base_fit) + 1e-9
                            single_imp = (base_fit - rl_fit) / denom
                            detailed_stats[group_key]['details'].append({'imp': single_imp, 'seed': seed, 'inst': inst})

                            if set_type == "Train":
                                train_fits.append(rl_fit)
                            elif set_type == "Val":
                                val_fits.append(rl_fit)

        # 打印统计
        print("\n" + "=" * 155)
        print(
            f"{'Prob':<5} | {'Dim':<5} | {'Set':<6} | {'Mean Base':<12} | {'Mean RL':<12} | {'Count':<5} | {'Mean Imp':<10} | {'Std':<8} | {'Fail':<6} | {'Worst Case':<35}")
        print("-" * 155)

        weak_tasks_train_count = 0
        weak_tasks_val_count = 0
        weak_tasks_scheduler = []
        weak_records = []

        sorted_keys = sorted(detailed_stats.keys(), key=lambda x: (x[0], x[1], 0 if x[2] == 'Train' else 1))

        for (pid, dim, stype) in sorted_keys:
            stats = detailed_stats[(pid, dim, stype)]
            m_base = np.mean(stats['base']) if stats['base'] else float('nan')
            m_rl = np.mean(stats['rl']) if stats['rl'] else float('nan')
            count = len(stats['rl'])

            mean_imp = 0.0
            if not np.isnan(m_base) and not np.isnan(m_rl):
                denom = abs(m_base) + 1e-9
                mean_imp = (m_base - m_rl) / denom

            imp_list = [d['imp'] for d in stats['details']]
            if imp_list:
                std_imp = np.std(imp_list)
                fail_count = sum(1 for x in imp_list if x < 0)
                worst_record = min(stats['details'], key=lambda x: x['imp'])
                worst_info = f"{worst_record['imp'] * 100:.1f}% @ S{worst_record['seed']}/I{worst_record['inst']}"
            else:
                std_imp = 0.0
                fail_count = 0
                worst_info = "N/A"

            if stype == "Train":
                group_imps_train.append(mean_imp)
            elif stype == "Val":
                group_imps_val.append(mean_imp)

            print(
                f"{pid:<5} | {dim:<5} | {stype:<6} | {m_base:<12.2e} | {m_rl:<12.2e} | {count:<5} | {mean_imp * 100:<9.2f}% | {std_imp * 100:<7.2f}% | {fail_count}/{count:<5} | {worst_info:<35}")

            if mean_imp < 0.0:
                weak_records.append({'pid': pid, 'dim': dim, 'stype': stype, 'imp': mean_imp})
                if stype == "Train":
                    weak_tasks_train_count += 1
                elif stype == "Val":
                    weak_tasks_val_count += 1
                    weak_tasks_scheduler.append((pid, dim))

        print("=" * 155 + "\n")

        mean_train_fit = np.mean(train_fits) if train_fits else 0.0
        mean_val_fit = np.mean(val_fits) if val_fits else 0.0

        mean_train_imp = np.mean(group_imps_train) if group_imps_train else 0.0
        mean_val_imp = np.mean(group_imps_val) if group_imps_val else 0.0
        print(f"     [Eval Summary] Train Imp: {mean_train_imp * 100:.2f}% | Val Imp: {mean_val_imp * 100:.2f}%")

        if weak_records:
            print(f"\n     [Weakness Report] Found {len(weak_records)} weak tasks:")
            for i, rec in enumerate(weak_records, 1):
                print(
                    f"        {i}. Prob {rec['pid']:<2} | Dim {rec['dim']:<2} | {rec['stype']:<5} | Imp: {rec['imp'] * 100:.2f}%")
        print("")

        if self.monitor:
            self.monitor.log_eval(
                epoch,
                mean_train_fit, mean_train_imp,
                mean_val_fit, mean_val_imp,
                0.0, 0.0,
                weak_train=weak_tasks_train_count,
                weak_val=weak_tasks_val_count,
                weak_test=0
            )

        is_best = False
        if mean_val_imp > self.global_best_improvement:
            self.global_best_improvement = mean_val_imp
            is_best = True

        return is_best, weak_tasks_scheduler
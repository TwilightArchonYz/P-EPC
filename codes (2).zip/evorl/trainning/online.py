import multiprocessing
import numpy as np
import os
import pickle
import functools
import torch
import time
import sys
import gc
from multiprocessing.shared_memory import SharedMemory
from joblib import Parallel, delayed
from evorl.factory import AlgorithmFactory
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def
from evorl.utils.naming import PathManager
from evorl.utils.agent_adapter import AgentAdapter
from evorl.utils.task_scheduler import TaskScheduler


# ==============================================================================
# 1. 核心训练逻辑 (隔离作用域)
# ==============================================================================

def _core_train_task(task_args, q_buf, v_buf, v_lock, seed_buf, mean_buf, seed_shape, mean_shape, seed_dtype,
                     mean_dtype):
    """
    内部训练逻辑。
    作用：将 Agent 和 Solver 的生命周期限制在这个函数内。
    函数返回时，Agent 和 Solver 销毁，自动释放 Buffer 引用。
    """
    (prob_id, dim, inst_id, seed,
     agent_name, agent_state_data,
     ea_name, config,
     curve_index, _) = task_args

    # --- 1. 恢复基准数据 (从 Buffer 重建) ---
    baseline_seed = None
    baseline_mean = None

    # Reconstruct Seed Curve
    if seed_buf is not None:
        try:
            full_arr = np.ndarray(seed_shape, dtype=seed_dtype, buffer=seed_buf)
            data = full_arr[curve_index].copy()
            if not np.all(np.isnan(data)):
                baseline_seed = data
        except Exception:
            pass

    # Reconstruct Mean Curve
    if mean_buf is not None:
        try:
            full_arr = np.ndarray(mean_shape, dtype=mean_dtype, buffer=mean_buf)
            data = full_arr[curve_index].copy()
            if not np.all(np.isnan(data)):
                baseline_mean = data
        except Exception:
            pass

    # --- 2. 实例化问题 ---
    param_dict, pf1, pf2 = params_def.generate_instance_config(prob_id, dim, inst_id)
    problem = ScalableProblem(prob_id, dim, param_dict, pf1=pf1, pf2=pf2)

    # --- 3. 实例化 Agent ---
    agent = AlgorithmFactory.create_agent(
        agent_name,
        state_dim=config.get('state_dim', 6),
        action_dim=config.get('action_dim', 72),
        lr=config.get('lr', 1e-4),
        gamma=config.get('gamma', 0.99),
        batch_size=config.get('batch_size', 128),
        buffer_size=config.get('buffer_size', 100000),
        hidden_dim=config.get('hidden_dim', 128),
        stream_hidden_dim=config.get('stream_hidden_dim', 64),
        state_bins=config.get('state_bins', [5, 4, 4, 4, 4]),
        f_opts=config.get('f_opts'),
        cr_opts=config.get('cr_opts'),
        algo_params=config.get('algo_params'),
        state_spec=config.get('state_spec'),
        context_spec=config.get('context_spec'),
        dim_norm_factor=config.get('dim_norm_factor', 100.0),
        device='cpu',
        shared_memory=q_buf,  # 传入 Buffer
        shared_visits=v_buf,  # 传入 Buffer
        visits_lock=v_lock,
        target_dims=config.get('target_dims'),
        inference_only=True  # [Fix] 显式开启推断模式，禁止 Worker 分配 TargetNet 和 Buffer
    )

    # 加载状态
    if agent_state_data is not None:
        AgentAdapter.load_state(agent, agent_state_data)

    # --- 4. 实例化 Solver ---
    max_fes_factor = config.get('max_fes_factor', 10000)
    max_nfes = max_fes_factor * dim
    pop_size_factor = config.get('pop_size_factor', 18)
    pop_size = pop_size_factor * dim

    solver = AlgorithmFactory.create_solver(
        problem=problem,
        ea_name=ea_name,
        agent=agent,
        pop_size=pop_size,
        max_nfes=max_nfes,
        seed=seed,
        mode='train',
        baseline_seed_curve=baseline_seed,
        baseline_mean_curve=baseline_mean,
        reward_window_long=config.get('reward_window_long_ratio', 0.5),
        reward_window_short=config.get('reward_window_short_ratio', 0.05),
        use_features=config.get('use_features')  # [修复]: 严格透传特征配置，保持状态空间对齐
    )

    # --- 5. 执行优化 ---
    res = solver.solve()

    return res['best_fitness'], res['transitions']


# ==============================================================================
# 2. 训练工作进程入口 (Train Worker)
# ==============================================================================

def train_worker(args):
    """
    并行训练工作单元。
    负责：资源连接 -> 调用核心逻辑 -> 资源释放。
    """
    t_abs_start = time.time()

    # 环境设置
    os.environ["OMP_NUM_THREADS"] = "1"
    torch.set_num_threads(1)

    # 解包参数
    batch_mean_info = args[-1]
    batch_seed_info = args[-2]
    visits_lock = args[-3]
    shared_visits_buffer = args[-4]
    q_table_source = args[-5]
    task_args = args[:-5]

    # 解包 Task Args 以获取 key
    (prob_id, dim, inst_id, _, _, _, _, _, _, _) = task_args
    task_key = (prob_id, dim, inst_id)

    # --- 资源句柄 ---
    shm_q = None
    shm_v = None
    shm_seed = None
    shm_mean = None

    # --- Buffer 引用 ---
    q_buf = None
    v_buf = None
    seed_buf = None
    mean_buf = None

    # --- 辅助变量 ---
    seed_shape, mean_shape = None, None
    seed_dtype, mean_dtype = None, None

    try:
        # 1. 连接 Q-Table
        if q_table_source is not None:
            if isinstance(q_table_source, dict):
                shm_q = SharedMemory(name=q_table_source['name'])
                q_buf = shm_q.buf
            elif hasattr(q_table_source, 'data'):
                q_buf = q_table_source.data

        # 2. 连接 Visits
        if shared_visits_buffer is not None:
            if isinstance(shared_visits_buffer, dict):
                shm_v = SharedMemory(name=shared_visits_buffer['name'])
                v_buf = shm_v.buf
            elif hasattr(shared_visits_buffer, 'data'):
                v_buf = shared_visits_buffer.data  # legacy
            elif hasattr(shared_visits_buffer, 'base'):
                v_buf = shared_visits_buffer

        # 3. 连接 Baselines (Seed)
        if isinstance(batch_seed_info, dict):
            shm_seed = SharedMemory(name=batch_seed_info['name'])
            seed_buf = shm_seed.buf
            seed_shape = batch_seed_info['shape']
            seed_dtype = batch_seed_info['dtype']
        elif isinstance(batch_seed_info, np.ndarray):
            # Legacy non-SHM mode (unlikely in new arch, but kept for safety)
            # 这种情况下无法传递 buffer 给 _core，需特殊处理或在 _core 中兼容
            pass

            # 4. 连接 Baselines (Mean)
        if isinstance(batch_mean_info, dict):
            shm_mean = SharedMemory(name=batch_mean_info['name'])
            mean_buf = shm_mean.buf
            mean_shape = batch_mean_info['shape']
            mean_dtype = batch_mean_info['dtype']

        # 5. [关键] 调用隔离的核心逻辑
        best_fitness, raw_transitions = _core_train_task(
            task_args, q_buf, v_buf, visits_lock,
            seed_buf, mean_buf, seed_shape, mean_shape, seed_dtype, mean_dtype
        )

        t_abs_end = time.time()
        d_solve = t_abs_end - t_abs_start

        # 向量化返回数据
        numpy_transitions = None
        if raw_transitions and len(raw_transitions) > 0:
            unzipped = list(zip(*raw_transitions))
            numpy_transitions = [np.array(col) for col in unzipped]

        return best_fitness, numpy_transitions, d_solve, task_key, t_abs_start, t_abs_end

    finally:
        # 6. 安全关闭句柄
        # 此时 Agent 和 Solver 已销毁，引用计数归零

        if shm_q is not None:
            try:
                shm_q.close()
            except Exception as e:
                print(f"[Worker] Close Q Failed: {e}")

        if shm_v is not None:
            try:
                shm_v.close()
            except Exception:
                pass

        if shm_seed is not None:
            try:
                shm_seed.close()
            except Exception:
                pass

        if shm_mean is not None:
            try:
                shm_mean.close()
            except Exception:
                pass


# ==============================================================================
# 3. 在线训练器类 (OnlineTrainer)
# ==============================================================================

class OnlineTrainer:
    """
    在线训练器 (OnlineTrainer)
    """

    def __init__(self, config, agent, evaluator=None, monitor=None, experiment_dir=None):
        self.cfg = config
        self.agent = agent
        self.evaluator = evaluator
        self.monitor = monitor
        self.exp_dir = experiment_dir

        self.paths = PathManager.get_paths(config, experiment_dir)
        self.model_dir = os.path.dirname(self.paths.get('model_best', '.'))
        self.n_cores = config['n_cores']
        self.epochs = config['epochs']
        self.scheduler = TaskScheduler(config)
        self.baselines = self._load_baselines()

        # [Wait] Visits Base 会在 _setup_persistent_q 中动态更新
        self.shared_visits_base = AgentAdapter.get_shared_visits(self.agent)

        self.mp_manager = multiprocessing.Manager()
        self.visits_lock = self.mp_manager.Lock()
        self.task_costs = {}

        # 持久化共享内存句柄
        self.persistent_q_shm = None
        self.persistent_v_shm = None
        self.persistent_q_info = None
        self.persistent_v_info = None

    def _load_baselines(self):
        path = self.paths.get('baseline_pkl')
        if path and os.path.exists(path):
            try:
                with open(path, 'rb') as f:
                    data = pickle.load(f)
                print(f"[Online] 已加载基准数据: {path}")
                return data
            except Exception as e:
                print(f"[Online] 警告: 加载基准数据失败 {path}: {e}")
                return {}
        else:
            print(f"[Online] 警告: 未找到基准数据文件 {path}")
            return {}

    def _store_transitions_batch(self, np_transitions):
        """
        批量存储 Worker 返回的转换数据。
        """
        if np_transitions is None: return 0
        s_batch, a_batch, r_batch, sn_batch = np_transitions

        # [Cleaned] 移除了高频 Reward 打印，保持日志清洁

        n_samples = len(s_batch)
        if hasattr(self.agent, 'store_transitions_batch'):
            self.agent.store_transitions_batch(s_batch, a_batch, r_batch, sn_batch)
        else:
            for i in range(n_samples):
                self.agent.store_transition(s_batch[i], a_batch[i], r_batch[i], sn_batch[i])
        return n_samples

    def _pack_baselines_to_numpy(self, tasks):
        """生成基准数据 NumPy 数组 (本地)"""
        seed_curves_list = []
        mean_curves_list = []

        for t in tasks:
            pid, dim, inst, seed = t[0], t[1], t[2], t[3]
            s_data = self.baselines.get('seeds', {}).get((pid, dim, inst, seed))
            m_data = self.baselines.get('means', {}).get((pid, dim, inst))
            seed_curves_list.append(s_data)
            mean_curves_list.append(m_data)

        def pad_and_stack(data_list):
            processed_list = []
            for d in data_list:
                if d is None or len(d) == 0:
                    processed_list.append(None)
                    continue
                arr = np.array(d)
                if arr.ndim == 1:
                    dummy_fes = np.arange(len(arr))
                    arr = np.column_stack((dummy_fes, arr))
                elif arr.ndim > 2:
                    arr = arr[:, -2:]
                processed_list.append(arr)

            valid_data = [d for d in processed_list if d is not None and len(d) > 0]
            if not valid_data:
                return None

            max_len = max(len(d) for d in valid_data)
            n_samples = len(data_list)
            arr = np.full((n_samples, max_len, 2), np.nan, dtype=np.float64)

            for i, d in enumerate(processed_list):
                if d is not None and len(d) > 0:
                    length = len(d)
                    if length > max_len:
                        d = d[:max_len, :]
                        length = max_len
                    arr[i, :length, :] = d
                    if length < max_len:
                        arr[i, length:, :] = d[-1, :]
            return arr

        batch_seed = pad_and_stack(seed_curves_list)
        batch_mean = pad_and_stack(mean_curves_list)
        return batch_seed, batch_mean

    def _create_shm_from_array(self, array):
        """创建 SharedMemory 并写入 NumPy 数组"""
        if array is None:
            return None, None

        try:
            shm = SharedMemory(create=True, size=array.nbytes)
            shm_arr = np.ndarray(array.shape, dtype=array.dtype, buffer=shm.buf)
            shm_arr[:] = array[:]

            info = {
                'name': shm.name,
                'shape': array.shape,
                'dtype': array.dtype
            }
            return shm, info
        except Exception as e:
            print(f"[Online] SharedMemory creation failed: {e}")
            return None, None

    def _setup_persistent_q(self):
        """初始化 Q-Table 和 Visits 的持久化共享内存"""
        # 1. Setup Q-Table Shared Memory
        if hasattr(self.agent, 'q_table') and isinstance(self.agent.q_table, np.ndarray):
            print(f"[Online] 检测到 Q-Table ({self.agent.q_table.nbytes / (1024 ** 3):.2f} GB)，正在挂载共享内存...")

            try:
                self.persistent_q_shm = SharedMemory(create=True, size=self.agent.q_table.nbytes)
                shm_q_arr = np.ndarray(self.agent.q_table.shape, dtype=self.agent.q_table.dtype,
                                       buffer=self.persistent_q_shm.buf)
                shm_q_arr[:] = self.agent.q_table[:]

                self.agent.q_table = shm_q_arr

                if hasattr(self.agent, 'q_table_tensor') and self.agent.q_table_tensor is not None:
                    print("[Online] [Fix] Re-binding Q-Table Tensor to Shared Memory...")
                    self.agent.q_table_tensor = torch.from_numpy(self.agent.q_table)

                self.persistent_q_info = {
                    'name': self.persistent_q_shm.name,
                    'shape': self.agent.q_table.shape,
                    'dtype': self.agent.q_table.dtype
                }
            except Exception as e:
                print(f"[Online] Q-Table SHM 初始化失败: {e}")
                if self.persistent_q_shm:
                    self.persistent_q_shm.close()
                    self.persistent_q_shm.unlink()
                    self.persistent_q_shm = None

        # 2. Setup Visits Shared Memory
        if hasattr(self.agent, 'visits') and isinstance(self.agent.visits, np.ndarray):
            print(f"[Online] 检测到 Visits Table，正在挂载共享内存...")
            try:
                self.persistent_v_shm = SharedMemory(create=True, size=self.agent.visits.nbytes)
                shm_v_arr = np.ndarray(self.agent.visits.shape, dtype=self.agent.visits.dtype,
                                       buffer=self.persistent_v_shm.buf)
                shm_v_arr[:] = self.agent.visits[:]

                self.agent.visits = shm_v_arr

                if hasattr(self.agent, 'visits_tensor') and self.agent.visits_tensor is not None:
                    print("[Online] [Fix] Re-binding Visits Tensor to Shared Memory...")
                    self.agent.visits_tensor = torch.from_numpy(self.agent.visits)

                self.persistent_v_info = {
                    'name': self.persistent_v_shm.name,
                    'shape': self.agent.visits.shape,
                    'dtype': self.agent.visits.dtype
                }
                self.shared_visits_base = AgentAdapter.get_shared_visits(self.agent)

            except Exception as e:
                print(f"[Online] Visits SHM 初始化失败: {e}")
                if self.persistent_v_shm:
                    self.persistent_v_shm.close()
                    self.persistent_v_shm.unlink()
                    self.persistent_v_shm = None

    def train(self):
        print(f"[Online] 开始在线训练 (模式: {self.cfg.get('train_mode')})...")
        print(f"    模型保存路径: {self.model_dir}")

        best_model_path = self.paths['model_best']
        latest_model_path = self.paths['model_latest']
        enable_perf_log = self.cfg.get('enable_perf_log', True)
        warmup_epochs = self.cfg.get('warmup_epochs', 0)

        # [Step 0] 训练前初始化持久化共享内存
        self._setup_persistent_q()

        if self.evaluator:
            print("[Online] 正在运行 Epoch 0 评估 (Baseline)...")
            self.evaluator.run(0, self.agent, self.cfg['ea_name'],
                               shm_q_info=self.persistent_q_info,
                               shm_v_info=self.persistent_v_info)

        try:
            for epoch in range(1, self.epochs + 1):
                use_shared_q = False
                if self.persistent_q_info is not None:
                    use_shared_q = True

                clean_state_data = AgentAdapter.prepare_state_for_worker(self.agent, use_shared_q=use_shared_q)
                raw_tasks = self.scheduler.generate_tasks(epoch, clean_state_data, {})

                def get_task_cost(t):
                    key = (t[0], t[1], t[2])
                    return self.task_costs.get(key, t[1])

                raw_tasks.sort(key=get_task_cost, reverse=True)

                # 2. 准备 Baselines (Local Numpy)
                batch_seed_np, batch_mean_np = self._pack_baselines_to_numpy(raw_tasks)

                shm_seed_obj = None
                shm_mean_obj = None
                seed_info = None
                mean_info = None

                try:
                    # 3. 写入临时 SharedMemory
                    shm_seed_obj, seed_info = self._create_shm_from_array(batch_seed_np)
                    shm_mean_obj, mean_info = self._create_shm_from_array(batch_mean_np)

                    # 4. 构造 Joblib 任务
                    joblib_tasks = []
                    for i, t in enumerate(raw_tasks):
                        t_base = t[:-1]
                        task_args = (*t_base, i, None)

                        # [Fix] 安全获取 q_table，深度强化学习 Agent 可能没有该属性
                        if use_shared_q:
                            q_source = self.persistent_q_info
                        else:
                            q_source = getattr(self.agent, 'q_table', None)

                        v_source = self.persistent_v_info if use_shared_q else self.shared_visits_base
                        joblib_tasks.append(
                            (*task_args, q_source, v_source, self.visits_lock, seed_info, mean_info))

                    # Phase 1: Rollout
                    t_start_rollout = time.time()
                    torch.set_num_threads(1)

                    results = Parallel(n_jobs=self.n_cores, batch_size='auto')(
                        delayed(train_worker)(t) for t in joblib_tasks
                    )

                    t_end_rollout = time.time()

                finally:
                    # 清理临时的 Baseline SHM
                    if shm_seed_obj:
                        shm_seed_obj.close()
                        shm_seed_obj.unlink()
                    if shm_mean_obj:
                        shm_mean_obj.close()
                        shm_mean_obj.unlink()

                # Phase 2: IO
                t_start_io = time.time()
                epoch_fits = []
                total_transitions = 0
                task_stats = []

                for fit, np_transitions, cost, task_key, t_start, t_end in results:
                    epoch_fits.append(fit)
                    task_stats.append({
                        'key': f"{task_key[0]}-{task_key[1]}",
                        'cost': cost,
                        'start': t_start, 'end': t_end
                    })
                    self.task_costs[task_key] = cost
                    n_added = self._store_transitions_batch(np_transitions)
                    total_transitions += n_added

                t_end_io = time.time()

                # Phase 3: Learn
                t_start_learn = time.time()
                torch.set_num_threads(self.n_cores)
                steps_per_epoch = self.cfg.get('train_steps_per_epoch', 50)
                loss_list = []
                for _ in range(steps_per_epoch):
                    loss = self.agent.learn()
                    if loss is not None: loss_list.append(loss)
                torch.set_num_threads(1)
                t_end_learn = time.time()

                # Phase 4: Log
                if epoch % self.cfg.get('target_update_interval', 10) == 0:
                    if hasattr(self.agent, 'update_target_network'):
                        self.agent.update_target_network()

                current_mode = getattr(self.scheduler, 'mode', self.cfg['train_mode'])
                if current_mode == 'dynamic' and getattr(self.scheduler, 'focus_tasks', None):
                    current_mode = 'dynamic-focus'

                mean_fit = np.mean(epoch_fits) if epoch_fits else 0.0
                mean_loss = np.mean(loss_list) if loss_list else 0.0

                dur_rollout = t_end_rollout - t_start_rollout
                dur_io = t_end_io - t_start_io
                dur_learn = t_end_learn - t_start_learn
                dur_total = dur_rollout + dur_io + dur_learn

                task_stats.sort(key=lambda x: x['end'], reverse=True)
                top_late = task_stats[:3]
                task_stats.sort(key=lambda x: x['start'])
                first_start = task_stats[0]['start']
                launch_lag = first_start - t_start_rollout
                worker_costs = [t['cost'] for t in task_stats]
                worker_max = max(worker_costs) if worker_costs else 0.0
                worker_mean = np.mean(worker_costs) if worker_costs else 0.0
                overhead = max(0.0, dur_rollout - worker_max)
                tps = total_transitions / dur_total if dur_total > 0 else 0

                print(f"    Epoch {epoch:04d} | Fit: {mean_fit:.2e} | Loss: {mean_loss:.4f} | Mode: {current_mode}")

                if enable_perf_log:
                    print(
                        f"      [Time] Total: {dur_total:.2f}s | Rollout: {dur_rollout:.2f}s ({dur_rollout / dur_total * 100:.1f}%) "
                        f"| DataIO: {dur_io:.2f}s | Learn: {dur_learn:.2f}s")
                    print(
                        f"      [Perf] Overhead: {overhead:.2f}s | Workers: Avg {worker_mean:.2f}s / Max {worker_max:.2f}s | TPS: {int(tps)}")
                    print(f"      [Diag] Launch Lag: {launch_lag:.3f}s")
                    print(f"      [Diag] Top Late Tasks:")
                    for t in top_late:
                        end_lag = t_end_rollout - t['end']
                        start_lag = t['start'] - t_start_rollout
                        print(
                            f"         -> {t['key']}: Cost={t['cost']:.2f}s | StartLag={start_lag:.2f}s | EndLag={end_lag:.2f}s")

                if self.monitor:
                    self.monitor.log_train(epoch, current_mode, self.cfg['base_seed'], mean_fit, mean_loss,
                                           total_transitions)

                if self.evaluator and (epoch % self.cfg.get('eval_interval', 10) == 0):
                    is_best, weak_tasks = self.evaluator.run(epoch, self.agent, self.cfg['ea_name'],
                                                             shm_q_info=self.persistent_q_info,
                                                             shm_v_info=self.persistent_v_info)
                    if is_best:
                        self.agent.save(best_model_path)
                    if self.cfg.get('train_mode') == 'dynamic' and epoch > warmup_epochs:
                        self.scheduler.set_focus_tasks(weak_tasks if weak_tasks else None)

                if epoch % self.cfg.get('save_interval', 50) == 0:
                    self.agent.save(latest_model_path)

        finally:
            if self.persistent_q_shm is not None:
                print("[Online] 正在清理持久化 Q-Table 共享内存...")
                self.persistent_q_shm.close()
                self.persistent_q_shm.unlink()
                self.persistent_q_shm = None

            if self.persistent_v_shm is not None:
                print("[Online] 正在清理持久化 Visits 共享内存...")
                self.persistent_v_shm.close()
                self.persistent_v_shm.unlink()
                self.persistent_v_shm = None

        print("[Online] 训练完成。")
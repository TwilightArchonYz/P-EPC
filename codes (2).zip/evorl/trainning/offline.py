import os
import pickle
import numpy as np
import torch
import random
from joblib import Parallel, delayed
from evorl.utils.monitor import Monitor
from evorl.utils.naming import PathManager
# [New] 导入外部数据质量诊断模块
from check.data_quality import diagnose_rewards


# ==============================================================================
# [Helper] 独立计算函数 (纯数学逻辑，无对象依赖)
# ==============================================================================
def _calculate_closest_action(action_params, param_grids, action_strides):
    """
    [Optimization] 从 Agent 中剥离出的独立动作映射逻辑。
    无需反序列化整个 Agent 即可计算动作索引。
    逻辑必须与 QLearningAgent.get_closest_action 完全保持一致。
    """
    flat_idx = 0
    for i, val in enumerate(action_params):
        if i >= len(param_grids): break
        grid = param_grids[i]
        stride = action_strides[i]

        # 找到网格中最近的值
        best_val = min(grid, key=lambda x: abs(x - val))
        idx = grid.index(best_val)

        # 累加扁平化索引
        flat_idx += idx * stride
    return flat_idx


# ==============================================================================
# [Helper] 独立的数据处理函数 (供 joblib 并行调用)
# ==============================================================================
def _process_expert_entry(entry, param_grids, action_strides):
    """
    单条专家轨迹的处理逻辑。
    [Optimization]
    1. 移除 'agent' 参数，改为接收轻量级的 'param_grids' 和 'action_strides'。
    2. 彻底消除并行过程中的 Pickle 序列化瓶颈。
    3. [Fix] 支持连续动作空间 (param_grids is None)。
    """
    # [Safety] 强制 Worker 进程只使用单线程
    torch.set_num_threads(1)
    os.environ["OMP_NUM_THREADS"] = "1"

    # 加载轨迹
    raw_transitions = entry['transitions']
    processed_transitions = []

    for t in raw_transitions:
        # 解包数据：状态、原始动作参数、奖励、下一状态
        state, raw_action, reward, next_state = t

        # [动作空间映射]
        if param_grids is not None and action_strides is not None:
            # [Discrete/Grid] 使用独立的静态函数进行计算
            action_idx = _calculate_closest_action(raw_action, param_grids, action_strides)
        else:
            # [Continuous] 连续动作空间 (如 DDPG)，直接使用原始动作向量
            # DDPG Agent 会将此列表/数组转换为 Tensor
            action_idx = raw_action

        processed_transitions.append((state, action_idx, reward, next_state))

    return processed_transitions


class OfflineTrainer:
    """
    离线训练器 (Offline Trainer) - 阶段 1
    --------------------------------------------------
    功能：利用生成的专家数据 (Expert Data) 对 RL Agent 进行预训练。
    方法：行为克隆 (Behavior Cloning, BC)，即监督学习模式。
    目标：为在线训练提供一个良好的初始策略，缩短冷启动时间。
    优化：
    1. [Manual Mode] 数据加载与动作映射并行化 (Joblib)。
    2. [Auto Mode] 训练阶段动态释放 PyTorch 算力。
    3. [Pre-filtering] 主进程预先过滤数据，减少 IPC 开销。
    4. [Debug] 增加内存数据检查机制，排查梯度爆炸原因。
    5. [Adaptive] 自动探测 Agent 能力，支持 SAC 的纯 BC 模式。
    6. [Compatibility] 兼容链表式 Buffer (deque) 和矩阵式 Buffer (NumPy)。
    7. [Super Batch] 支持超大 Batch Size 以饱和高性能 CPU。
    """

    def __init__(self, config, agent, monitor=None, experiment_dir=None):
        self.cfg = config
        self.agent = agent
        self.monitor = monitor
        self.exp_dir = experiment_dir

        # 路径解析：优先使用 PathManager 管理的路径
        self.paths = PathManager.get_paths(config, experiment_dir)
        self.data_path = self.paths.get('expert_pkl',
                                        config.get('expert_data_path', 'data/precomputed/expert_data.pkl'))
        # 预训练轮数
        self.epochs = config.get('pretrain_epochs', 50)

        # [New] 获取核心数配置，用于控制并行度
        self.n_cores = config.get('n_cores', 1)

        # 数据过滤配置
        # 使用 set 数据结构提高成员检查效率 (O(1))
        # 目的：确保只加载训练集实例，防止测试集数据泄漏 (Data Leakage)
        self.train_instances = set(config.get('train_instances', []))
        self.seed_pool = set(config.get('seed_pool', []))

    def _get_buffer_size(self):
        """
        [Helper] 获取当前 Buffer 大小，兼容不同类型的 Agent。
        """
        # 情况 1: 矩阵化 Buffer (Matrix-based)
        if hasattr(self.agent, 'mem_cntr'):
            return min(self.agent.mem_cntr, self.agent.buffer_capacity)
        # 情况 2: 链表化 Buffer (Deque-based)
        elif hasattr(self.agent, 'memory'):
            return len(self.agent.memory)
        return 0

    def inspect_memory(self):
        """
        [Debug] 检查内存中的数据分布，用于排查梯度爆炸问题。
        统计 State 和 Reward 的 Min/Max/Mean。
        """
        buffer_size = self._get_buffer_size()
        if buffer_size == 0:
            print("[Debug] Memory is empty.")
            return

        print("-" * 60)
        print(f"[Debug] Inspecting Replay Buffer (Total: {buffer_size})")

        sample_size = min(1000, buffer_size)

        # [Compatibility] 根据 Agent 类型获取采样数据
        if hasattr(self.agent, 'state_memory'):
            # 矩阵化 Agent: 直接切片采样 (O(1))
            indices = np.random.randint(0, buffer_size, size=sample_size)
            states = self.agent.state_memory[indices]
            rewards = self.agent.reward_memory[indices]
        else:
            # 链表化 Agent: 随机采样 (O(N))
            samples = random.sample(self.agent.memory, sample_size)
            states = np.array([s[0] for s in samples])
            rewards = np.array([s[2] for s in samples])

        # 统计 State
        print(f"   > State Shape: {states.shape}")
        print(f"   > State Min:  {np.min(states):.4f}")
        print(f"   > State Max:  {np.max(states):.4f}")
        print(f"   > State Mean: {np.mean(states):.4f}")
        print(f"   > State Std:  {np.std(states):.4f}")

        # 如果 Max State 非常大，打印每一列的 Max
        if np.max(states) > 100.0:
            print(f"     [Alert] Large State Value Detected! Max per dim: {np.max(states, axis=0)}")

        # 统计 Reward
        print(f"   > Reward Min:  {np.min(rewards):.4f}")
        print(f"   > Reward Max:  {np.max(rewards):.4f}")
        print(f"   > Reward Mean: {np.mean(rewards):.4f}")
        print("-" * 60)

    def load_and_populate_buffer(self):
        """
        加载专家数据并填充到 Agent 的经验回放池 (Replay Buffer)。
        [Refactor] 主进程预过滤 + Joblib 并行映射 (参数解耦版)。
        """
        if not os.path.exists(self.data_path):
            print(f"[Offline] 错误: 找不到数据文件 {self.data_path}")
            return False

        print(f"[Offline] 正在加载专家数据: {self.data_path}...")
        try:
            with open(self.data_path, 'rb') as f:
                expert_data = pickle.load(f)
        except Exception as e:
            print(f"[Offline] 数据加载失败: {e}")
            return False

        if not expert_data:
            print("[Offline] 数据为空。")
            return False

        # [Optimization] 1. 主进程预过滤 (Pre-filtering)
        # 在序列化分发任务之前，先剔除无关数据，避免无效的 IPC 通信开销
        print(f"[Offline] 正在执行主进程预过滤...")
        valid_tasks = []
        for entry in expert_data:
            pid, dim, inst, seed = entry['key']

            # 仅保留训练集且在种子池中的数据
            if inst in self.train_instances and seed in self.seed_pool:
                valid_tasks.append(entry)

        print(f"[Offline] 原始条目: {len(expert_data)} -> 有效训练条目: {len(valid_tasks)}")
        print(f"[Offline] 正在并行执行动作空间映射 (n_jobs={self.n_cores})...")

        if not valid_tasks:
            print(f"[Offline] 警告: 没有匹配的有效数据。")
            return False

        # [Optimization] 2. 提取轻量级参数
        # 避免将整个 Agent (含巨大 Memory Buffer) 传入子进程
        # [Fix] 兼容连续动作空间 (DDPG 没有 param_grids)
        agent_param_grids = getattr(self.agent, 'param_grids', None)
        agent_action_strides = getattr(self.agent, 'action_strides', None)

        if agent_param_grids is None:
            print("[Offline] 检测到连续动作空间 (无 param_grids)。Worker 将跳过网格映射。")

        # [Manual Parallel Mode]
        # 使用 joblib 并行处理有效数据
        # 传入解耦后的参数: param_grids, action_strides
        results = Parallel(n_jobs=self.n_cores, verbose=10, batch_size='auto')(
            delayed(_process_expert_entry)(entry, agent_param_grids, agent_action_strides)
            for entry in valid_tasks
        )

        count = 0
        loaded_trajs = 0

        # 将并行处理的结果汇总存入 Buffer (主进程操作，线程安全)
        for res_list in results:
            if res_list is None:
                continue

            loaded_trajs += 1
            for trans in res_list:
                state, action_idx, reward, next_state = trans
                self.agent.store_transition(state, action_idx, reward, next_state)
                count += 1

        print(f"[Offline] 已处理有效轨迹数: {loaded_trajs} (仅限训练集)。")
        print(f"[Offline] 已填充经验池样本数: {count}。")

        # [Debug] 执行内存体检
        self.inspect_memory()

        # [New] 执行深度数据质量诊断并绘图
        # 如果 exp_dir 存在，则保存到 plots 子目录；否则使用默认 plots 目录
        plot_dir = os.path.join(self.exp_dir, 'plots') if self.exp_dir else 'plots'
        diagnose_rewards(self.agent, save_dir=plot_dir, tag="Offline_Expert_Load")

        return count > 0

    def train(self):
        """
        执行离线预训练的主循环。
        [Architecture Fix] 实现自动并行模式 (Auto Parallel Mode)。
        """
        print("=" * 60)
        print(f"[Offline] 开始阶段 1: 行为克隆 (Behavior Cloning)")

        # [Auto Parallel Mode Start]
        # 动态释放 CPU 算力，允许 PyTorch 使用多核进行矩阵运算
        # 由于 Main 现在默认已是 Unclamped，这步是保险措施，确保不超过配置的 N_CORES
        torch.set_num_threads(self.n_cores)
        print(f"[Offline] [Compute Boost] CPU 线程数配置为 {torch.get_num_threads()} 用于加速训练。")
        print("=" * 60)

        # 1. 填充数据
        success = self.load_and_populate_buffer()
        if not success:
            print("[Offline] 由于数据问题，跳过预训练。")
            return

        # 2. 检查数据量是否满足最小批次要求
        current_buffer_size = self._get_buffer_size()
        if current_buffer_size < self.agent.batch_size:
            print(f"[Offline] 经验池样本 ({current_buffer_size}) 不足一个 Batch ({self.agent.batch_size})。跳过。")
            return

        # [Strategy A: Super Batch Calculation]
        # 针对 16核+ 高性能 CPU，设定极大的 Batch Size 以饱和算力
        TARGET_BATCH_SIZE = 65536  # 2^16

        # 确保 Batch Size 不超过实际数据量
        offline_batch_size = min(current_buffer_size, TARGET_BATCH_SIZE)
        # 确保至少不小于默认 Batch Size
        offline_batch_size = max(offline_batch_size, self.agent.batch_size)

        # ======================================================================
        # [New] Q-Learning 快速通道: 直接修改 Q 表，不进行梯度迭代
        # ======================================================================
        if self.agent.__class__.__name__ == 'QLearningAgent':
            print(f"[Offline] 检测到 QLearningAgent。执行直接 Q 表初始化 (无迭代)...")

            if hasattr(self.agent, 'learn_behavior_cloning'):
                # 调用一次 BC 逻辑，传入 Batch Size (视具体实现可能用到也可能忽略)
                self.agent.learn_behavior_cloning(batch_size=offline_batch_size)
            else:
                print("[Offline] 警告: QLearningAgent 缺少 learn_behavior_cloning 方法！")

            # 保存并退出
            save_path = self.paths.get('model_pretrained')
            if save_path:
                self.agent.save(save_path)
                print(f"[Offline] 预训练模型已保存至 {save_path}")
            print("[Offline] Q-Learning 预训练完成。")
            return

        # ======================================================================
        # Deep Learning 训练循环 (DQN, SAC, etc.)
        # ======================================================================
        print(f"[Offline] 开始训练，共 {self.epochs} 轮...")
        print(f"[Offline] [Super Batch] 启用大批量吞吐模式: Batch Size = {offline_batch_size}")

        # 3. 计算每轮步数
        # 由于 Batch Size 变大了，为了保证遍历数据的覆盖率一致，Steps 需要相应减少
        # Epoch 定义: 过一遍所有数据
        steps_per_epoch = current_buffer_size // offline_batch_size
        steps_per_epoch = max(1, steps_per_epoch)
        print(f"[Offline] [Super Batch] 每轮步数 (Steps/Epoch): {steps_per_epoch}")

        # 4. 训练循环
        for epoch in range(1, self.epochs + 1):
            loss_list = []
            for _ in range(steps_per_epoch):
                # [Adaptive Learning]
                # 优先使用行为克隆 (BC) 接口，并传入 Super Batch Size
                if hasattr(self.agent, 'learn_behavior_cloning'):
                    loss = self.agent.learn_behavior_cloning(batch_size=offline_batch_size)
                else:
                    # Fallback 到普通学习 (不推荐用于 Offline，且通常不接受 batch_size 参数)
                    loss = self.agent.learn()

                if loss is not None:
                    loss_list.append(loss)

            # 计算平均损失
            mean_loss = np.mean(loss_list) if loss_list else 0.0

            # 日志输出 (每 10 轮或第 1 轮)
            if epoch % 10 == 0 or epoch == 1:
                print(f"     [Offline] Epoch {epoch:03d} | Loss: {mean_loss:.4f}")

            # 监控记录
            if self.monitor:
                self.monitor.log_train(epoch, "Offline", 0, 0.0, mean_loss, 0)

        # 5. 保存预训练模型
        save_path = self.paths.get('model_pretrained')
        if save_path:
            self.agent.save(save_path)
            print(f"[Offline] 预训练模型已保存至 {save_path}")

        print(f"[Offline] [Status] 预训练结束。保持主进程多核状态，等待进入 Online 阶段。")
        print("[Offline] 预训练完成。")
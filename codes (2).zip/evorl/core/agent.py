import abc
import numpy as np

class Agent(abc.ABC):
    """
    Abstract Base Class for Reinforcement Learning Agents.
    Standardizes interaction between Solvers and Algorithms (Q-Learning, PPO, etc.).
    """

    @abc.abstractmethod
    def choose_action(self, state, mode='train'):
        """
        Choose an action based on the current state.
        Args:
            state: Raw state vector [progress, diversity, stagnation] or processed state.
            mode: 'train' or 'test'.
        Returns:
            Action (index or continuous vector).
        """
        pass

    @abc.abstractmethod
    def learn(self, state, action, reward, next_state):
        """
        Update agent policy based on experience transition.
        """
        pass

    @abc.abstractmethod
    def get_action_params(self, action):
        """
        Convert agent's action output to EA parameters (e.g., F, CR).
        Args:
            action: Output from choose_action.
        Returns:
            tuple: (F, CR) or other parameters.
        """
        pass

    @abc.abstractmethod
    def save(self, filename):
        pass

    @abc.abstractmethod
    def load(self, filename):
        pass
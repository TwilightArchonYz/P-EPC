import numpy as np
from evorl.core.reward_def import TrajectoryRewardCalculator
from evorl.core import state_def


class RLSolverMixin:
    """
    RL Solver Mixin
    --------------------------------------------------
    为演化算法提供通用的 RL 交互能力。
    该 Mixin 负责管理：
    1. Agent 的持有与调用
    2. 状态 (State) 的构建与更新
    3. 奖励 (Reward) 的计算 (即时步奖励 + 轨迹回溯奖励)
    4. 轨迹数据 (Transitions) 的记录
    5. [New] 种群参数的生成 (Generation) 与 历史存档 (Memory)

    使用该 Mixin 的 Solver 必须：
    1. 在 __init__ 或 initialize 中调用 setup_rl(...)
    2. 在 evolve 循环中调用 generate_population_params(...) 生成参数
    3. 在 evolve 循环中调用 update_parameter_memory(...) 更新存档
    4. 在 evolve 循环中调用 interact_rl_step(...) 执行 RL 交互
    5. 在 solve 结束时调用 finalize_rl_trajectory()
    """

    def setup_rl(self, agent, mode='train',
                 baseline_seed_curve=None,
                 baseline_mean_curve=None,
                 ucb_beta=1.0,
                 param_dim=None,  # [New] 受控参数的维度 (如 PSO=3, JADE=2)
                 memory_size=100,  # [New] 参数记忆库大小
                 **kwargs):
        """
        初始化 RL 组件。
        """
        self.agent = agent
        self.mode = mode
        self.ucb_beta = ucb_beta

        # 双轨基准数据
        self.baseline_seed = baseline_seed_curve
        self.baseline_mean = baseline_mean_curve

        # 状态特征参数
        self.evo_long_ratio = kwargs.get('evo_long_ratio', 0.1)
        self.evo_short_ratio = kwargs.get('evo_short_ratio', 0.05)
        self.use_features = kwargs.get('use_features', None)

        # 轨迹与状态容器
        self.transitions = []
        self.fit_history = []
        self.state = None
        self.action_idx = None
        self.last_best_fit = float('inf')

        # [New] 通用参数记忆库
        # 替代具体算法中的 M_cr, M_f 等，统一存储 normalized parameters
        self.param_dim = param_dim
        self.memory_size = memory_size
        if self.param_dim is not None:
            self.memory = np.full((self.memory_size, self.param_dim), 0.5)
            self.k_mem = 0

        # 如果 Solver 尚未初始化 fit_history，则初始化
        if not hasattr(self, 'fit_history') or self.fit_history is None:
            self.fit_history = []

        # 记录初始代适应度
        if len(self.fit_history) == 0:
            self.fit_history.append(self.gbest_val)

        self.last_best_fit = self.gbest_val

        # 1. 获取初始状态
        self.state = self._get_state_vector()

        # === [DEBUG LOG] 检查 State 具体数值 ===
        #print(f"[DEBUG] Mixin.setup_rl 获取初始 State:")
        #print(f"  > State Shape: {self.state.shape}")
        #print(f"  > State Values: {self.state}")

        if np.isnan(self.state).any():
            print(f"  > [ALARM] State 中包含 NaN! 索引位置: {np.where(np.isnan(self.state))[0]}")
        # =======================================

        # 2. RL 选择初始动作
        self.action_idx = self.agent.choose_action(self.state, mode=self.mode, beta=self.ucb_beta)

    def _get_state_vector(self):
        """
        获取当前进化状态向量。
        调用 evorl.core.state_def，统一处理维度归一化与特征参数。
        """
        norm = getattr(self.agent, 'dim_norm_factor', 100.0)

        time_horizon_ratios = {
            'long': self.evo_long_ratio,
            'short': self.evo_short_ratio
        }

        return state_def.get_state_vector(
            self,
            dim_norm_factor=norm,
            time_horizon_ratios=time_horizon_ratios,
            use_features=self.use_features
        )

    def generate_population_params(self, action_means, pop_size, distributions, scales=0.1):
        """
        [New] 根据 RL 输出的均值动作，为种群生成具体的个体参数。

        参数:
            action_means: (list or np.array) RL 输出的参数均值，长度应等于 self.param_dim。
            pop_size: (int) 种群大小。
            distributions: (list of str) 每维参数的分布类型，支持 'normal', 'cauchy'。
            scales: (float or list) 分布的标准差或尺度参数，默认 0.1。

        返回:
            params: (np.array) 形状为 (pop_size, param_dim) 的参数矩阵，范围限制在 [0, 1]。
        """
        if self.param_dim is None:
            raise ValueError("RL param_dim is not set. Call setup_rl with param_dim first.")

        params = np.zeros((pop_size, self.param_dim))

        # 统一 scale 格式
        if np.isscalar(scales):
            scales = [scales] * self.param_dim

        for i in range(self.param_dim):
            mu = action_means[i]
            dist_type = distributions[i]
            scale = scales[i]

            if dist_type == 'normal':
                # Normal Distribution
                col = np.random.normal(mu, scale, pop_size)
            elif dist_type == 'cauchy':
                # Cauchy Distribution using tan trick
                # C(loc, scale) = loc + scale * tan(pi * (rand - 0.5))
                col = mu + scale * np.tan(np.pi * (np.random.rand(pop_size) - 0.5))

                # Cauchy 特殊处理: <= 0 重生成 (仅针对正值参数场景)
                # 这里假设参数通常在 [0, 1] 之间
                retry_mask = col <= 0
                while np.any(retry_mask):
                    n_retry = np.sum(retry_mask)
                    col[retry_mask] = mu + scale * np.tan(np.pi * (np.random.rand(n_retry) - 0.5))
                    retry_mask = col <= 0
            else:
                raise ValueError(f"Unsupported distribution type: {dist_type}")

            # 统一截断到 [0, 1] (假设 RL 输出和所需参数都是归一化的)
            col = np.clip(col, 0.0, 1.0)
            params[:, i] = col

        return params

    def update_parameter_memory(self, success_params, fitness_diffs, mean_types):
        """
        [New] 更新通用参数记忆库。

        参数:
            success_params: (np.array) 成功个体的参数矩阵，形状 (N_success, param_dim)。
            fitness_diffs: (np.array) 适应度改进量，用于加权。
            mean_types: (list of str) 每维参数的平均方式，支持 'arithmetic', 'lehmer'。
        """
        if self.param_dim is None or len(success_params) == 0:
            return

        # 计算权重
        weights = fitness_diffs / (np.sum(fitness_diffs) + 1e-15)

        for i in range(self.param_dim):
            param_col = success_params[:, i]
            m_type = mean_types[i]

            val = 0.5
            if m_type == 'arithmetic':
                val = np.sum(weights * param_col)
            elif m_type == 'lehmer':
                # Lehmer Mean: sum(w * x^2) / sum(w * x)
                numerator = np.sum(weights * (param_col ** 2))
                denominator = np.sum(weights * param_col) + 1e-15
                val = numerator / denominator
            else:
                # 默认算术平均
                val = np.mean(param_col)

            self.memory[self.k_mem, i] = val

        # 移动指针
        self.k_mem = (self.k_mem + 1) % self.memory_size

    def interact_rl_step(self):
        """
        执行 RL 的单步交互逻辑。
        """
        # 准备基准数据 (优先 Seed, 其次 Mean)
        base_curve = self.baseline_seed if self.baseline_seed is not None else self.baseline_mean
        r_self = 0.0

        if base_curve is not None:
            base_fits = base_curve
            if hasattr(base_curve, 'ndim') and base_curve.ndim > 1:
                base_fits = base_curve[:, 1]

            # 估算归一化因子
            est_gens = self.max_nfes / max(1, self.pop_size)
            norm = max(1.0, est_gens * 0.2)

            current_t = len(self.fit_history)
            last_t = current_t - 1

            # 调用静态方法计算单步奖励
            r_self = TrajectoryRewardCalculator.calc_step_reward(
                self.gbest_val, self.last_best_fit,
                current_t, last_t,
                base_fits, norm
            )

        # 获取下一状态
        next_state = self._get_state_vector()

        # 如果是训练模式，存储状态转换 (s, a, r, s')
        if self.mode == 'train':
            self.transitions.append([self.state, self.action_idx, r_self, next_state])

        # 更新状态追踪变量
        self.last_best_fit = self.gbest_val
        self.state = next_state

        # 选择下一代的动作
        self.action_idx = self.agent.choose_action(self.state, mode=self.mode, beta=self.ucb_beta)

    def finalize_rl_trajectory(self):
        """
        回合结束后的奖励回溯计算。
        """
        if self.mode != 'train' or (self.baseline_seed is None and self.baseline_mean is None):
            return

        # 1. 实例化计算器
        calculator = TrajectoryRewardCalculator(
            seed_baseline=self.baseline_seed,
            mean_baseline=self.baseline_mean,
            weight_seed=1.0,
            weight_mean=1.0
        )

        # 2. 执行计算
        future_rewards = calculator.compute_rewards(self.fit_history)

        if future_rewards is None:
            return

        # 3. 回填奖励
        n_trans = len(self.transitions)
        n_rewards = len(future_rewards)

        if n_rewards >= n_trans:
            relevant_rewards = future_rewards[-n_trans:]
        else:
            relevant_rewards = np.pad(future_rewards, (n_trans - n_rewards, 0), 'constant')

        for i in range(n_trans):
            self.transitions[i][2] = relevant_rewards[i]
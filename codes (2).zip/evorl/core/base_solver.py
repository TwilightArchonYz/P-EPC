import numpy as np
from abc import ABC, abstractmethod


class BaseSolver(ABC):
    """
    所有优化算法的基类 (DRL Ready)
    支持传统运行 (solve) 和 强化学习步进 (step_drl)
    """

    def __init__(self, problem, pop_size=100, max_nfes=100000, seed=None):
        """
        :param problem: ScalableProblem 实例 (来自 problems.py)
        :param pop_size: 种群大小
        :param max_nfes: 最大评估次数
        :param seed: 随机种子 (int) 或 随机数生成器 (np.random.RandomState)
        """
        self.problem = problem
        self.pop_size = pop_size
        self.max_nfes = max_nfes
        self.seed = seed

        # === 修改点: 支持传入统一的 RNG 实例 ===
        if isinstance(seed, np.random.RandomState):
            self.rng = seed
        else:
            self.rng = np.random.RandomState(seed)

        self.dim = problem.dim
        self.lb = problem.lb
        self.ub = problem.ub

        # 状态追踪
        self.X = None
        self.fitness = None  # 罚函数后的适应度
        self.raw_f = None  # 原始目标值
        self.cv = None  # 约束违反度

        self.gbest_val = float('inf')
        self.gbest_X = None
        self.gbest_raw = float('inf')
        self.gbest_cv = float('inf')

        self.fes = 0
        self.history = []  # 记录 [FES, BestFit]

        # DRL 状态特征
        self.stagnation_counter = 0
        self.diversity = 0.0

    def initialize(self):
        """初始化种群"""
        # 使用 self.rng 进行随机初始化
        self.X = self.lb + (self.ub - self.lb) * self.rng.rand(self.pop_size, self.dim)

        # 评估
        self.fitness, self.raw_f, self.cv = self.problem.evaluate(self.X)
        self.fes += self.pop_size

        # 更新全局最优
        self._update_gbest()

    def _update_gbest(self):
        """更新全局最优解"""
        min_idx = np.argmin(self.fitness)
        min_fit = self.fitness[min_idx]

        if min_fit < self.gbest_val:
            self.gbest_val = min_fit
            self.gbest_X = self.X[min_idx].copy()
            self.gbest_raw = self.raw_f[min_idx]
            self.gbest_cv = self.cv[min_idx]
            self.stagnation_counter = 0
        else:
            self.stagnation_counter += 1

        self.history.append([self.fes, self.gbest_val])

    @abstractmethod
    def evolve(self):
        """
        [子类实现] 执行一代进化
        """
        pass

    # ==========================================
    # DRL Interface
    # ==========================================

    def get_state(self):
        """
        获取 DRL 状态向量 (State)
        返回: [Progress, Diversity, Stagnation_Ratio]
        """
        # 1. 进度
        progress = self.fes / self.max_nfes

        # 2. 多样性 (平均距离 / 搜索空间对角线)
        center = np.mean(self.X, axis=0)
        dists = np.sqrt(np.sum((self.X - center) ** 2, axis=1))

        # 计算对角线长度
        diag = np.linalg.norm(self.ub - self.lb)
        if diag == 0: diag = 1e-9  # 防止除零

        diversity = np.mean(dists) / diag
        self.diversity = diversity

        # 3. 停滞率 (停滞代数 / 最大代数估计)
        # 假设平均一代消耗 pop_size
        max_gens = self.max_nfes / self.pop_size
        if max_gens == 0: max_gens = 1
        stag_ratio = self.stagnation_counter / max_gens

        return np.array([progress, diversity, stag_ratio], dtype=np.float32)

    @abstractmethod
    def update_params(self, action):
        """[子类实现] 根据 DRL 动作更新参数 (如 F, CR, w)"""
        pass

    def step_drl(self, action):
        """
        执行一步 DRL 交互
        :param action: Agent 输出的参数控制动作
        :return: (next_state, reward, done, info)
        """
        # 1. 应用动作
        self.update_params(action)

        prev_best = self.gbest_val

        # 2. 进化一代
        self.evolve()

        # 3. 计算奖励 (适应度提升量)
        if self.gbest_val < prev_best:
            # 简单的归一化提升奖励
            reward = (prev_best - self.gbest_val) / (np.abs(prev_best) + 1e-9)
        else:
            reward = 0.0

        # 4. 状态与结束
        next_state = self.get_state()
        done = self.fes >= self.max_nfes

        return next_state, reward, done, {}

    # ==========================================
    # Traditional Run
    # ==========================================

    def solve(self):
        """传统模式一键运行"""
        self.initialize()
        while self.fes < self.max_nfes:
            self.evolve()

        # 结果打包
        return {
            'best_x': self.gbest_X,
            'best_fitness': self.gbest_val,
            'best_obj': self.gbest_raw,
            'best_cv': self.gbest_cv,
            'history': np.array(self.history)
        }
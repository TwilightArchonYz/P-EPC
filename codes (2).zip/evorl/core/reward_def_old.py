import numpy as np


class TrajectoryRewardCalculator:
    """
    双轨轨迹奖励计算器 (Dual-Track Trajectory Reward Calculator).

    核心算法: 双指针线性扫描 (Two-Pointer Linear Scan).
    利用基准曲线 "严格单调递减" 的特性，通过线性追赶计算 Agent 的相对领先优势。

    物理定义 (完全基于索引/代数，不依赖 FES):
    1. 进度 (Progress): 基准数组的索引 (Index) 代表标准进度。
    2. 领先 (Lead): Agent 当前适应度对应的基准索引 - Agent 实际消耗步数。
       Lead_t = Index_base(fit_t) - t
    3. 奖励 (Reward): 领先优势的增量。
       Reward_t = Lead_t - Lead_{t-1}
    4. 归一化 (Normalization): 奖励除以 (当前轨迹长度 * 0.2)。
    """

    def __init__(self, seed_baseline, mean_baseline,
                 weight_seed=1.0, weight_mean=1.0):
        """
        初始化计算器。

        Args:
            seed_baseline: (np.ndarray) 种子基准曲线。
                           可以是 [Fit] (1D) 或 [FES, Fit] (2D)。
                           必须保证 Fitness 是严格单调递减的。
            mean_baseline: (np.ndarray) 均值基准曲线。同上。
            weight_seed: (float) 种子基准奖励权重。
            weight_mean: (float) 均值基准奖励权重。
        """
        # 预处理: 提取 Fitness 列并展平为 1D 数组
        self.seed_baseline = self._extract_fitness(seed_baseline)
        self.mean_baseline = self._extract_fitness(mean_baseline)

        self.w_seed = weight_seed
        self.w_mean = weight_mean

    def _extract_fitness(self, baseline):
        """辅助函数: 提取适应度列"""
        if baseline is None or len(baseline) == 0:
            return None
        baseline = np.array(baseline, dtype=np.float64)
        if baseline.ndim > 1:
            # 假设第 1 列是 Fitness (第 0 列是 FES/Step)
            return baseline[:, 1]
        return baseline

    def compute_rewards(self, agent_history):
        """
        批量计算整条轨迹的即时奖励序列。

        Args:
            agent_history: (list/np.array) Agent 的适应度历史 [f0, f1, ..., f_end]。
                           应为 Best-so-far 曲线 (单调非增)。

        Returns:
            np.ndarray: 即时奖励数组 [r0, r1, ..., r_end]。
        """
        # 1. 数据准备
        ag_fit = np.array(agent_history, dtype=np.float64).flatten()
        n_steps = len(ag_fit)

        if n_steps < 2:
            return np.zeros(n_steps)

        # 2. 计算动态归一化因子
        # 规则: Fixed to 20% maxIter (maxIter 以输入轨迹长度为准)
        # 加上 1.0 防止极短轨迹除以 0
        norm_factor = max(1.0, n_steps * 0.2)

        # 3. 轨道 A: 种子基准奖励
        r_seed = np.zeros(n_steps)
        if self.seed_baseline is not None:
            r_seed = self._calc_track_reward_linear(self.seed_baseline, ag_fit)

        # 4. 轨道 B: 均值基准奖励
        r_mean = np.zeros(n_steps)
        if self.mean_baseline is not None:
            r_mean = self._calc_track_reward_linear(self.mean_baseline, ag_fit)

        # 5. 加权融合并归一化
        total_reward = (self.w_seed * r_seed + self.w_mean * r_mean) / norm_factor

        return total_reward

    def _calc_track_reward_linear(self, baseline, agent_fits):
        """
        使用双指针算法计算单轨奖励 (Raw Reward without Normalization).
        时间复杂度: O(N + M)
        """
        n = len(agent_fits)
        m = len(baseline)
        leads = np.zeros(n, dtype=np.float64)

        # 指针初始化 (base_ptr)
        ptr = 0

        # 线性扫描 (Linear Scan)
        for t in range(n):
            fit = agent_fits[t]

            # 向后推进指针 (Chasing)
            # 只要 Baseline 当前位置比 Agent 差 (数值更大)，就继续往后找。
            # "永不回头": ptr 在整个循环中只增不减。
            # 假设 baseline 是严格单调递减的
            while ptr < m and baseline[ptr] > fit:
                ptr += 1

            # 此时 ptr 指向的是第一个 <= fit 的位置。
            # 这代表了 Agent 当前表现等效于 Baseline 走到了第 ptr 步。
            # 如果 Agent 表现没有进步 (fit 不变)，ptr 也会停在原地。

            # 计算相对领先 (Lead)
            # Lead = (等效基准步数) - (实际消耗步数)
            leads[t] = ptr - t

        # 计算增量奖励 (Diff)
        # Reward_t = Lead_t - Lead_{t-1}
        # 使用 prepend=leads[0] 使得第 0 步的奖励为 0 (初始状态无增量)
        raw_rewards = np.diff(leads, prepend=leads[0])

        return raw_rewards

    @staticmethod
    def calc_step_reward(current_fit, last_fit, current_step_idx, last_step_idx,
                         baseline_fits, normalization_factor):
        """
        [Static Tool] 单步奖励计算函数。

        用于 Online 模式下的单步计算。
        由于无法维护有状态的指针，此处使用二分查找 (Binary Search) 模拟定位。

        Args:
            current_fit: 当前适应度
            last_fit: 上一步适应度
            current_step_idx: 当前步数 (t)
            last_step_idx: 上一步步数 (t-1)
            baseline_fits: 1D 基准适应度数组 (必须严格单调递减)
            normalization_factor: 归一化因子 (通常是预估总代数的 20%)

        Returns:
            float: 单步即时奖励
        """
        if baseline_fits is None or len(baseline_fits) == 0:
            return 0.0

        # 辅助函数: 查找等效索引
        # 使用 searchsorted 配合负号映射，处理降序数组
        # 查找 -val 在 -baseline 中的插入位置 (第一个 >= -val 的位置 -> 第一个 <= val 的位置)
        def get_equiv_idx(val):
            # 注意: baseline_fits 必须是 1D array
            # 这里假定调用方已经处理好了 baseline_fits
            idx = np.searchsorted(-baseline_fits, -val, side='left')
            # 边界保护
            return min(idx, len(baseline_fits) - 1)

        # 1. 计算上一步的 Lead
        ptr_prev = get_equiv_idx(last_fit)
        lead_prev = ptr_prev - last_step_idx

        # 2. 计算当前的 Lead
        ptr_curr = get_equiv_idx(current_fit)
        lead_curr = ptr_curr - current_step_idx

        # 3. 计算增量
        delta = lead_curr - lead_prev

        # 4. 归一化
        return delta / float(normalization_factor)
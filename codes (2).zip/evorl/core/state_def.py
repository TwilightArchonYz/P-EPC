import numpy as np


def calc_diversity(population, lb, ub):
    """
    计算种群多样性 (Diversity)。
    公式: 种群在各维度标准差的均值 / 搜索空间边界的均值
    """
    if population is None or len(population) == 0:
        return 0.0

    std_per_dim = np.std(population, axis=0)
    mean_std = np.mean(std_per_dim)

    # 处理标量边界或向量边界
    if np.isscalar(lb) and np.isscalar(ub):
        mean_bound = ub - lb
    else:
        bounds = ub - lb
        mean_bound = np.mean(bounds)

    div = mean_std / (mean_bound + 1e-9)
    # 确保返回值在 [0, 1] 之间
    return min(1.0, div) if np.isfinite(div) else 0.0


def calc_fitness_distribution(fitness_values):
    """
    计算适应度分布比 (Fitness Gap Ratio)。
    公式: (Mean - Best) / (Worst - Best)
    反映种群是聚集在平底(接近0)还是悬崖边缘(接近1)。
    """
    if fitness_values is None or len(fitness_values) == 0:
        return 0.0

    # 假设最小化问题
    # np.min/mean/max 可以自动处理 [[val], [val]] 这种二维数组的情况，返回标量
    f_best = np.min(fitness_values)
    f_mean = np.mean(fitness_values)
    f_worst = np.max(fitness_values)

    numerator = f_mean - f_best
    # 添加 epsilon 防止除零
    denominator = f_worst - f_best + 1e-9

    dist = numerator / denominator
    return min(1.0, max(0.0, dist))


def calc_evolution_rate(solver, ratio_long=0.1, ratio_short=0.05):
    """
    计算进化速率 (Evolution Rate) - 动态比例版。
    逻辑: 计算前 K_short 个周期的下降量 / 前 K_long 个周期的下降量。
    K 值根据 MaxFES 和 PopSize 动态计算，适应不同维度的任务。

    Args:
        solver: 求解器实例
        ratio_long: 长周期占总代数的比例 (默认 10%)
        ratio_short: 短周期占总代数的比例 (默认 5%)
    """
    # 1. 动态计算窗口长度 K
    # 估算总代数
    pop_size = max(1, solver.pop_size)
    total_generations = solver.max_nfes / pop_size

    # 计算 K值，至少为 2 以保证差分计算有效
    k1 = max(2, int(total_generations * ratio_long))
    k2 = max(2, int(total_generations * ratio_short))

    # 确保 k2 < k1，防止逻辑倒置
    if k2 >= k1:
        k2 = max(1, k1 // 4)

    # 2. 获取历史最优适应度曲线
    history_data = []
    if hasattr(solver, 'fit_history'):
        history_data = solver.fit_history
    elif hasattr(solver, 'history'):
        # 兼容 solver.history 存储格式 [[fes, fit], ...]
        history_data = [x[1] for x in solver.history]

    # 扁平化处理，防止 [[val]] 格式
    history = np.array(history_data).flatten()

    if len(history) == 0:
        return 0.0

    # 3. 初始最差值注入 (Initial Worst Injection)
    if not hasattr(solver, 'initial_worst'):
        if hasattr(solver, 'fitness') and solver.fitness is not None:
            solver.initial_worst = np.max(solver.fitness)
        else:
            solver.initial_worst = history[0] if len(history) > 0 else 1e9

    initial_worst = float(solver.initial_worst)
    history_start = float(history[0])

    # 4. 头部补全 (Head Padding)
    virtual_prefix = np.linspace(initial_worst, history_start, k1 + 1)[:-1]

    # 拼接完整历史
    full_history = np.concatenate([virtual_prefix, history])

    # 5. 计算下降比率
    current_idx = len(full_history) - 1

    f_curr = full_history[current_idx]
    f_k2 = full_history[current_idx - k2]  # 前 k2 代
    f_k1 = full_history[current_idx - k1]  # 前 k1 代

    # 计算下降量 (Drop)
    drop_k2 = f_k2 - f_curr
    drop_k1 = f_k1 - f_curr

    # 6. 计算比率
    rate = drop_k2 / (drop_k1 + 1e-9)

    return np.clip(rate, 0.0, 1.0)


def extract_solver_params(solver):
    """
    [Refactored] 通用辅助函数：从任意 Solver 实例中提取控制参数。
    强制约定：所有返回值必须是一个字典 (Dictionary)，以支持基于键值的安全特征提取。
    """
    # 1. 接口优先原则: 如果 Solver 显式定义了参数获取接口，直接返回（期望其返回字典）
    if hasattr(solver, 'get_current_params'):
        return solver.get_current_params()

    # 2. 启发式检测 (Duck Typing): 针对尚未接入 rl_mixin 的旧版 EA 算法
    params = {}

    # -- PSO 检测 (w, c1, c2) --
    if hasattr(solver, 'w') and hasattr(solver, 'c1'):
        params['w'] = float(solver.w)
        params['c1'] = float(solver.c1)
        if hasattr(solver, 'c2'):
            params['c2'] = float(solver.c2)
        return params

    # -- SHADE / DE 检测 (F, CR) --
    has_mf = hasattr(solver, 'M_f') and solver.M_f is not None
    has_mcr = hasattr(solver, 'M_cr') and solver.M_cr is not None
    has_f = hasattr(solver, 'F')
    has_cr = hasattr(solver, 'CR')

    if has_mf or has_f:
        if has_mf:
            params['F'] = float(np.mean(solver.M_f))
        else:
            params['F'] = float(solver.F)

        if has_mcr:
            params['CR'] = float(np.mean(solver.M_cr))
        elif has_cr:
            params['CR'] = float(solver.CR)
        return params

    # -- GA 检测 (pm, pc) --
    if hasattr(solver, 'pm') or hasattr(solver, 'pc'):
        if hasattr(solver, 'pm'): params['pm'] = float(solver.pm)
        if hasattr(solver, 'pc'): params['pc'] = float(solver.pc)
        return params

    # 3. 兜底策略: 无法识别参数时，返回空字典
    return params


def get_state_vector(solver, dim_norm_factor=100.0, time_horizon_ratios=None, use_features=None):
    """
    [Refactored] 为演化强化学习 (EvoRL) 提取通用的状态向量。
    移除了对具体参数名 (F, CR, w, c1) 的硬编码，通过统一字典接口实现动态映射。

    Args:
        solver: 优化器实例
        dim_norm_factor: 维度归一化因子
        time_horizon_ratios: 包含 'long' 和 'short' 比例的字典。
        use_features: (List[str]) 需要计算并返回的特征名称列表。
    """
    # 默认特征 (保持向后兼容)
    if use_features is None:
        use_features = ['Progress', 'Diversity', 'Stagnation', 'FitDist', 'EvoRate', 'NormDim', 'Params']

    features = []

    # 缓存参数字典，避免在一个步长内重复提取
    _cached_params = None

    def _get_params_cached():
        nonlocal _cached_params
        if _cached_params is None:
            _cached_params = extract_solver_params(solver)
        return _cached_params

    # 遍历并组装状态
    for key in use_features:

        # --- 基础元特征 ---
        if key == 'Progress':
            features.append(solver.fes / solver.max_nfes)

        elif key == 'Diversity':
            if hasattr(solver, 'X'):
                div = calc_diversity(solver.X, solver.problem.lb, solver.problem.ub)
                features.append(div)
            else:
                features.append(0.0)

        elif key == 'Stagnation':
            stagnation_counter = getattr(solver, 'stagnation_counter', 0)
            if time_horizon_ratios is None:
                r_long = 0.1
            else:
                r_long = time_horizon_ratios.get('evo_long_ratio', time_horizon_ratios.get('long', 0.1))

            max_gens = solver.max_nfes / max(1, solver.pop_size)
            window_long = max(1.0, max_gens * r_long)
            stag = min(1.0, stagnation_counter / window_long)
            features.append(stag)

        elif key == 'FitDist':
            fitness_values = getattr(solver, 'Y', getattr(solver, 'fitness', None))
            features.append(calc_fitness_distribution(fitness_values))

        elif key == 'EvoRate':
            if time_horizon_ratios is None:
                r_long, r_short = 0.1, 0.05
            else:
                r_long = time_horizon_ratios.get('evo_long_ratio', time_horizon_ratios.get('long', 0.1))
                r_short = time_horizon_ratios.get('evo_short_ratio', time_horizon_ratios.get('short', 0.05))
            features.append(calc_evolution_rate(solver, ratio_long=r_long, ratio_short=r_short))

        elif key == 'NormDim':
            features.append(solver.dim / dim_norm_factor)

        # --- 算法参数动态映射 ---
        elif key == 'Params':
            # 兼容老版行为：把探测到的所有参数拼接到状态中
            p_dict = _get_params_cached()
            if p_dict:
                # 必须对键名排序，以确保 RL 代理每次观测到的维度顺序一致
                sorted_keys = sorted(p_dict.keys())
                for k in sorted_keys:
                    features.append(p_dict[k])
            else:
                # 兜底：防止因空字典导致状态维度不匹配
                features.extend([0.5, 0.5])

        else:
            # 动态查字典：自动处理所有具体的参数名请求 (如 'F', 'CR', 'w', 'c1', 'c2')
            p_dict = _get_params_cached()
            # 从字典中安全获取。如果没有找到该键，返回默认值 0.5
            val = p_dict.get(key, 0.5)
            features.append(val)

    return np.array(features, dtype=np.float32)
import abc
import numpy as np

class Problem(abc.ABC):
    """
    Optimization Problem Interface.
    All benchmark problems must inherit from this class.
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Name of the problem."""
        pass

    @property
    @abc.abstractmethod
    def dim(self) -> int:
        """Dimension of the problem."""
        pass

    @property
    @abc.abstractmethod
    def lb(self) -> np.ndarray:
        """Lower bound of the search space."""
        pass

    @property
    @abc.abstractmethod
    def ub(self) -> np.ndarray:
        """Upper bound of the search space."""
        pass

    @abc.abstractmethod
    def evaluate(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Evaluate the population.

        Args:
            x (np.ndarray): Population, shape (pop_size, dim).

        Returns:
            tuple:
                - fitness (np.ndarray): Final fitness values (with penalty applied).
                - raw_cost (np.ndarray): Raw objective function values (f).
                - cv (np.ndarray): Constraint violation values (cv).
        """
        pass
import numpy as np


class TrajectoryRewardCalculator:
    """
    双轨轨迹奖励计算器 (Dual-Track Trajectory Reward Calculator).

    核心算法: 双指针线性扫描 (Two-Pointer Linear Scan).

    物理定义:
    1. 种子轨道 (Seed Track):
       - 领先 (Lead): 虚拟时间与物理时间的差值 (绝对优势)。
       - Lead_t = tau_t - t
       - 奖励: 绝对优势的增量 (速度增益)。

    2. 均值轨道 (Mean Track):
       - 领先 (Lead): 当前虚拟时间与上一时刻虚拟时间的差值 (相对进步)。
       - Lead_t = tau_t - tau_{t-1}
       - 奖励: 相对进步的增量 (加速度/动量)。
    """

    def __init__(self, seed_baseline, mean_baseline,
                 weight_seed=1.0, weight_mean=1.0):
        """
        初始化计算器。

        Args:
            seed_baseline: (np.ndarray) 种子基准曲线 [Fit] (1D) 或 [FES, Fit] (2D)。
            mean_baseline: (np.ndarray) 均值基准曲线。
            weight_seed: (float) 种子基准奖励权重。
            weight_mean: (float) 均值基准奖励权重。
        """
        self.seed_baseline = self._extract_fitness(seed_baseline)
        self.mean_baseline = self._extract_fitness(mean_baseline)

        self.w_seed = weight_seed
        self.w_mean = weight_mean

    def _extract_fitness(self, baseline):
        """辅助函数: 提取适应度列"""
        if baseline is None or len(baseline) == 0:
            return None
        baseline = np.array(baseline, dtype=np.float64)
        if baseline.ndim > 1:
            return baseline[:, 1]
        return baseline

    def compute_rewards(self, agent_history):
        """
        批量计算整条轨迹的即时奖励序列。

        Args:
            agent_history: (list/np.array) Agent 的适应度历史 [f0, f1, ..., f_end]。

        Returns:
            np.ndarray: 即时奖励数组。
        """
        # 1. 数据准备
        ag_fit = np.array(agent_history, dtype=np.float64).flatten()
        n_steps = len(ag_fit)

        if n_steps < 2:
            return np.zeros(n_steps)

        # 2. 计算动态归一化因子
        norm_factor = max(1.0, n_steps * 0.2)

        # 3. 轨道 A: 种子基准奖励 (使用绝对领先逻辑 [Logic-1])
        r_seed = np.zeros(n_steps)
        if self.seed_baseline is not None:
            r_seed = self._calc_track_reward_linear(
                self.seed_baseline, ag_fit, is_seed_track=True
            )

        # 4. 轨道 B: 均值基准奖励 (使用相对领先逻辑 [Logic-2])
        r_mean = np.zeros(n_steps)
        if self.mean_baseline is not None:
            r_mean = self._calc_track_reward_linear(
                self.mean_baseline, ag_fit, is_seed_track=False
            )

        # 5. 加权融合并归一化
        total_reward = (self.w_seed * r_seed + self.w_mean * r_mean) / norm_factor

        return total_reward

    def _calc_track_reward_linear(self, baseline, agent_fits, is_seed_track=True):
        """
        使用双指针算法计算单轨奖励。

        Args:
            baseline: 基准适应度数组。
            agent_fits: Agent 适应度数组。
            is_seed_track: (bool)
                - True: 计算绝对领先 (tau - t) -> 种子轨道
                - False: 计算相对领先 (tau_t - tau_{t-1}) -> 均值轨道
        """
        n = len(agent_fits)
        m = len(baseline)
        leads = np.zeros(n, dtype=np.float64)

        # 指针初始化
        ptr = 0
        prev_ptr = 0  # 记录上一时刻的虚拟时间 (tau_{t-1})

        # 线性扫描 (Linear Scan)
        for t in range(n):
            fit = agent_fits[t]

            # 双指针追赶 (Chasing)
            while ptr < m and baseline[ptr] > fit:
                ptr += 1

            # ptr 即为当前虚拟时间 tau(f_t)

            # --- 核心逻辑分流 ---
            if is_seed_track:
                # [Logic-1] 种子轨道: 绝对领先
                # Lead = 虚拟时间 - 物理时间
                leads[t] = ptr - t
            else:
                # [Logic-2] 均值轨道: 相对领先
                # Lead = 当前虚拟时间 - 上一时刻虚拟时间 (即单步速度)
                # 注意: 这种定义的差分 (Diff) 物理意义为加速度
                leads[t] = ptr - prev_ptr

            # 更新 prev_ptr 供下一步使用
            prev_ptr = ptr

        # 计算奖励: 领先状态的增量 (Diff)
        # Reward_t = Lead_t - Lead_{t-1}
        raw_rewards = np.diff(leads, prepend=leads[0])

        return raw_rewards

    @staticmethod
    def calc_step_reward(current_fit, last_fit, current_step_idx, last_step_idx,
                         baseline_fits, normalization_factor):
        """
        [Static Tool] 单步奖励计算函数 (主要用于种子轨道逻辑/通用逻辑)。

        注意: 此函数仅支持 [Logic-1] 绝对领先的差分计算。
        由于接口限制 (仅输入两步状态)，无法支持需要三步历史的 [Logic-2] 加速度计算。
        """
        if baseline_fits is None or len(baseline_fits) == 0:
            return 0.0

        def get_equiv_idx(val):
            idx = np.searchsorted(-baseline_fits, -val, side='left')
            return min(idx, len(baseline_fits) - 1)

        # 1. 计算上一步的 Lead (绝对定义: tau - t)
        ptr_prev = get_equiv_idx(last_fit)
        lead_prev = ptr_prev - last_step_idx

        # 2. 计算当前的 Lead (绝对定义: tau - t)
        ptr_curr = get_equiv_idx(current_fit)
        lead_curr = ptr_curr - current_step_idx

        # 3. 计算增量
        delta = lead_curr - lead_prev

        # 4. 归一化
        return delta / float(normalization_factor)
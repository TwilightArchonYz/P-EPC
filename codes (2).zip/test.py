import pickle
import numpy as np

# 请替换为你确定的那个路径
file_path = 'data/precomputed/baselines_ljade.pkl'

with open(file_path, 'rb') as f:
    data = pickle.load(f)

# 取 Problem 1, Dim 30, Instance 1, Seed 1 的曲线
print(list(data['seeds'].keys())[:5])
curve = data['seeds'][(1, 30, 1, 1)]
fes_col = curve[:, 0]
fit_col = curve[:, 1]

target_limit = 5000 * 30
idx = np.searchsorted(fes_col, target_limit)

print("曲线总点数:", len(curve))
print("曲线最大 FES:", fes_col[-1])
print(f"FES={target_limit} 时的 Fitness:", fit_col[idx])
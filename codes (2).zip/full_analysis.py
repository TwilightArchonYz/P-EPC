import os
import pandas as pd

# 导入封装好的 analysis 模块
from analysis import loader, runner, reporter

# ==============================================================================
# 1. 全局配置 (Global Configuration)
# ==============================================================================
# 获取当前脚本所在目录作为项目根目录，避免相对路径失效
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

TARGET_DIR = os.path.join(PROJECT_ROOT, 'R1')  # 实验数据根目录

# [Fix] 根据 check_structure.py 的输出，data 文件夹在根目录下
BASELINE_DIR = os.path.join(PROJECT_ROOT, 'data', 'precomputed')

SAVE_DIR = os.path.join(TARGET_DIR, 'analysis_results')  # 结果保存目录

N_EVAL_EPISODES = 30  # 每个数据集(Train/Val/Test)回测的独立运行次数
DEVICE = 'cpu'  # 评估通常使用 CPU

# 确保保存目录存在
os.makedirs(SAVE_DIR, exist_ok=True)


# ==============================================================================
# 2. 主流程 (Main Workflow)
# ==============================================================================

def main():
    print(f"Starting Full Analysis Pipeline...")
    print(f"Project Root:       {PROJECT_ROOT}")
    print(f"Target Directory:   {TARGET_DIR}")
    print(f"Baseline Directory: {BASELINE_DIR}")
    print(f"Save Directory:     {SAVE_DIR}")

    # --------------------------------------------------------------------------
    # Step 1: 巡检配置 (Configuration Inspection)
    # --------------------------------------------------------------------------
    valid_configs = loader.inspect_configurations(TARGET_DIR)

    if valid_configs == 0:
        print("[Error] No valid configurations found to evaluate. Exiting.")
        return

    # --------------------------------------------------------------------------
    # Step 1.5: 训练过程分析与模型选择 (Training Analysis & Model Selection)
    # --------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("TRAINING PROCESS ANALYSIS (Comparative Plots & Model Selection)")
    print("=" * 80)

    # 1. 实验分组 (按 Algo_Config 聚合不同 Seeds)
    exp_groups = loader.group_experiment_folders(TARGET_DIR)

    full_training_list = []  # 用于存储所有组的日志，供对比绘图
    best_seeds_registry = {}  # 用于存储 {Group_Name: Best_Seed_ID}
    selection_report = []  # 文本报告

    for group_name, folder_list in exp_groups.items():
        print(f"\n[Analysis] Processing Group: {group_name} ({len(folder_list)} seeds)")

        # 2. 加载该组所有 Seed 的日志
        group_logs = loader.load_training_logs(folder_list)

        if group_logs.empty:
            print(f"    [Warn] No training logs found for {group_name}.")
            continue

        # 3. 标记算法名称 (用于后续绘图区分颜色)
        group_logs['Algorithm'] = group_name
        full_training_list.append(group_logs)

        # 4. 模型选择: 根据 Validation Fitness 选最佳 Seed
        best_seed, best_val, best_epoch = reporter.get_best_seed_by_validation(group_logs)

        if best_seed is not None:
            best_seeds_registry[group_name] = best_seed

            line = f"Algo: {group_name:<40} | Best Seed: {best_seed:<3} | Val Fit: {best_val:.4e} (Ep {best_epoch})"
            selection_report.append(line)
            print(f"    -> Selected Best Model: Seed {best_seed} (Val: {best_val:.4e})")
        else:
            print(f"    [Warn] Could not select best seed for {group_name} (Missing Val data?)")

    # 5. 生成对比图 (9张大图)
    if full_training_list:
        full_training_df = pd.concat(full_training_list, ignore_index=True)
        reporter.plot_training_comparison(full_training_df, SAVE_DIR)
    else:
        print("[Warn] No training data available for plotting.")

    # 6. 保存最佳模型推荐报告
    if selection_report:
        rec_file = os.path.join(SAVE_DIR, 'best_seeds_recommendation.txt')
        with open(rec_file, 'w') as f:
            f.write("Model Selection Report (Based on Minimum Validation Fitness)\n")
            f.write("=" * 80 + "\n")
            f.write("\n".join(selection_report))
        print(f"\n[Info] Best seed registry saved to {rec_file}")

    # --------------------------------------------------------------------------
    # Step 2: 数据收集 (Data Collection - Inference Phase)
    # --------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("DATA COLLECTION PHASE (Inference/Testing on Best Models)")
    print("=" * 80)

    # 2.1 收集实验数据 (Agents)
    # [Critical Update] 传入 best_seeds_registry，只跑最佳模型
    print(f"[Info] Starting evaluation loop. Using Best Seeds Registry with {len(best_seeds_registry)} entries.")

    exp_df = runner.collect_data(
        TARGET_DIR,
        n_eval_episodes=N_EVAL_EPISODES,
        device=DEVICE,
        best_seeds_registry=best_seeds_registry  # 传递筛选器
    )

    # 2.2 收集基准数据 (Baselines)
    print("\n[Info] Loading Baseline Data (loader)...")

    if os.path.exists(BASELINE_DIR):
        base_df = loader.load_baseline_dataframes(BASELINE_DIR)
    else:
        print(f"\n{'!' * 80}")
        print(f"[ERROR] BASELINE DIRECTORY NOT FOUND: {BASELINE_DIR}")
        print(f"{'!' * 80}\n")
        base_df = pd.DataFrame()

    # 2.3 数据合并
    dfs_to_merge = []
    if not exp_df.empty:
        dfs_to_merge.append(exp_df)
    else:
        print("[Warn] No experimental data collected.")

    if not base_df.empty:
        dfs_to_merge.append(base_df)
    else:
        print("[Warn] No baseline data collected.")

    if not dfs_to_merge:
        print("[Error] No data available (neither Experiment nor Baseline). Exiting.")
        return

    df = pd.concat(dfs_to_merge, ignore_index=True)

    # 数据审计
    print("\n" + "=" * 40)
    print("DATA AUDIT (Rows per Algo & Problem)")
    print("=" * 40)
    if not df.empty:
        df['Problem'] = df['Problem'].astype(str)
        audit = df.groupby(['Problem', 'Dimension', 'SetType', 'Algorithm']).size()
        print(audit)
    print("=" * 40 + "\n")

    # 保存合并数据
    data_file = os.path.join(SAVE_DIR, 'combined_data.csv')
    df.to_csv(data_file, index=False)
    print(f"[Info] Data saved to {data_file}")

    # --------------------------------------------------------------------------
    # Step 3: 统计与报告 (Reporting - Inference Phase)
    # --------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("REPORTING PHASE (Convergence & Stats)")
    print("=" * 80)

    # 3.1 绘制收敛曲线对比图 (含基准)
    reporter.plot_convergence_curves(df, SAVE_DIR)

    # 3.2 基础统计检验 + 排名计算 + 全局排名箱型图
    reporter.perform_statistical_test_and_plot(df, SAVE_DIR)

    # 3.3 胜负统计 (Win/Loss Summary)
    reporter.generate_win_loss_report(df)

    # 3.4 打印全局摘要表 (Global Summary)
    print("\n" + "=" * 80)
    print("FINAL GLOBAL SUMMARY (Mean Fitness per Problem & Dimension & Set)")
    print("=" * 80)

    if not df.empty:
        summary = df.groupby(['Problem', 'Dimension', 'SetType', 'Algorithm'])['Fitness'].agg(
            ['mean', 'std']).reset_index()

        pd.set_option('display.max_rows', None)
        print(summary.to_string(index=False))

    print(f"\n[Done] Analysis complete. Detailed results in {SAVE_DIR}")


if __name__ == "__main__":
    main()
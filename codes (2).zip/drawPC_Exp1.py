import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import matplotlib.ticker as ticker
import warnings

warnings.filterwarnings('ignore')  # 忽略作图或统计检验中的除零警告

# ==============================================================================
# 1. 配置与映射 (Configuration & Mappings)
# ==============================================================================

PATH_BASELINES = 'experiments/benchmarks/benchmark_results_5000D_30_40_50.pkl'
PATH_RL_SPECIALIST = 'experiments/benchmarks/rl_specialist_results.pkl'
OUTPUT_DIR = 'experiments/benchmarks/analysis_final_paper'

DIMS = [30, 40, 50]
PROBLEMS = list(range(1, 21))
MAX_FES_FACTOR = 5000

SPLITS_INFO = {
    'Train': {1, 2, 3},
    'Val': {4, 5, 6},
    'Test': {7, 8, 9}
}

# 1. 原始键名 1v1 对比配置 (底层物理数据)
PAIRS_1V1_RAW = [
    ('Q_Learning_JADE-Specialist', 'JADE'),
    ('Q_Learning_LJADE-Specialist', 'L-SHADE'),  # IJADE/LJADE 对齐 L-SHADE
    ('Q_Learning_PSO-Specialist', 'IPSO')
]

# 2. 论文标准命名映射 (LaTeX Safe, 替换下划线，精简长度)
PAPER_NAMES_MAP = {
    'Q_Learning_JADE-Specialist': 'QL-JADE',
    'Q_Learning_LJADE-Specialist': 'QL-IJADE',
    'Q_Learning_PSO-Specialist': 'QL-PSO',
    'JADE': 'JADE',
    'IPSO': 'IPSO',
    'L-SHADE': 'L-SHADE',
    'jSO': 'jSO',
    'IMODE': 'IMODE',
    'SHADE': 'SHADE'
}

SOTA_ALGOS_RAW = ['L-SHADE', 'jSO', 'IMODE']

# 颜色映射 (直接绑定给清洗后的名字)
ALGO_COLORS = {
    'QL-JADE': '#d62728', 'QL-IJADE': '#ff7f0e', 'QL-PSO': '#1f77b4',
    'JADE': '#ff9896', 'IPSO': '#aec7e8',
    'L-SHADE': '#2ca02c', 'jSO': '#9467bd', 'IMODE': '#8c564b', 'SHADE': '#7f7f7f'
}

# 论文双栏排版尺寸设定 (英寸)
FIG_SIZE_SINGLE = (3.5, 3.2)  # 单栏图尺寸 (适合散点图、箱型图)
FIG_SIZE_DOUBLE = (7.5, 3.0)  # 双栏宽图尺寸 (适合 20 个问题的柱状图)

# 全局字号设定
plt.rcParams.update({
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 11,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
})


# ==============================================================================
# 2. 数据加载机制 (Data Loading)
# ==============================================================================

def load_and_merge_data():
    print("=" * 80)
    print("[1/4] Loading and Merging Data...")
    structured_data = {dim: {pid: {} for pid in PROBLEMS} for dim in DIMS}

    def _merge(raw_dict, tag):
        count = 0
        for key, val in raw_dict.items():
            try:
                algo, pid, dim, inst = key[0], key[1], key[2], key[3]
            except Exception:
                continue
            if dim not in DIMS or pid not in PROBLEMS: continue

            if algo not in structured_data[dim][pid]:
                structured_data[dim][pid][algo] = {'histories': [], 'instances': []}

            if val.get('history') is not None:
                structured_data[dim][pid][algo]['histories'].append(val['history'])
                structured_data[dim][pid][algo]['instances'].append(inst)
                count += 1
        print(f"   > Merged {count} instances from {tag}.")

    if os.path.exists(PATH_BASELINES):
        with open(PATH_BASELINES, 'rb') as f: _merge(pickle.load(f), "Baselines")
    if os.path.exists(PATH_RL_SPECIALIST):
        with open(PATH_RL_SPECIALIST, 'rb') as f: _merge(pickle.load(f), "RL-Specialist")

    return structured_data


def get_aligned_fitness(histories, instances, target_instances, max_fes):
    """提取对齐到特定 FES 的最终适应度数组"""
    fit_list = []
    for hist, inst in zip(histories, instances):
        if inst in target_instances:
            hist = np.array(hist)
            if hist.ndim == 2 and hist.shape[1] == 2:
                valid_idx = np.where(hist[:, 0] <= max_fes)[0]
                if len(valid_idx) > 0:
                    fit_list.append(hist[valid_idx[-1], 1])
    return np.array(fit_list)


# ==============================================================================
# 3. 核心统计计算与 CSV 导出 (Stats & CSV Export)
# ==============================================================================

def analyze_and_export_stats(data):
    print("\n[2/4] Calculating W/T/L, RPD, Ranks for All Splits...")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    plot_data_pack = {'Test': {}}

    for split_name, inst_set in SPLITS_INFO.items():
        wtl_rows = []
        rank_rows = []

        if split_name == 'Test':
            plot_data_pack['Test'] = {'dim_stats': {dim: {} for dim in DIMS}}

        for dim in DIMS:
            max_fes = MAX_FES_FACTOR * dim

            # --- A. 1v1 W/T/L & RPD 分析 ---
            for rl_raw, base_raw in PAIRS_1V1_RAW:
                rl_clean = PAPER_NAMES_MAP.get(rl_raw, rl_raw)
                base_clean = PAPER_NAMES_MAP.get(base_raw, base_raw)

                wins, ties, losses = 0, 0, 0
                rpd_list = []

                if split_name == 'Test':
                    if rl_clean not in plot_data_pack['Test']['dim_stats'][dim]:
                        plot_data_pack['Test']['dim_stats'][dim][rl_clean] = {'scatter': {'rl': [], 'base': []},
                                                                              'rpd': [], 'base_target': base_clean}

                for pid in PROBLEMS:
                    rl_fit = get_aligned_fitness(data[dim][pid].get(rl_raw, {}).get('histories', []),
                                                 data[dim][pid].get(rl_raw, {}).get('instances', []), inst_set, max_fes)
                    base_fit = get_aligned_fitness(data[dim][pid].get(base_raw, {}).get('histories', []),
                                                   data[dim][pid].get(base_raw, {}).get('instances', []), inst_set,
                                                   max_fes)

                    if len(rl_fit) >= 3 and len(base_fit) >= 3:
                        mean_rl, mean_base = np.mean(rl_fit), np.mean(base_fit)

                        if split_name == 'Test':
                            plot_data_pack['Test']['dim_stats'][dim][rl_clean]['scatter']['rl'].append(mean_rl)
                            plot_data_pack['Test']['dim_stats'][dim][rl_clean]['scatter']['base'].append(mean_base)

                        # [修正]: 对称相对提升率 (Symmetric RPD)，严格限制在 [-100%, +100%]，防止 Excel 数值爆炸
                        denominator = max(abs(mean_base), abs(mean_rl), 1e-8)
                        rpd = ((mean_base - mean_rl) / denominator) * 100
                        rpd_list.append(rpd)

                        if split_name == 'Test':
                            plot_data_pack['Test']['dim_stats'][dim][rl_clean]['rpd'].append(rpd)

                        stat, p_val = stats.mannwhitneyu(rl_fit, base_fit, alternative='two-sided')
                        if p_val < 0.05:
                            if mean_rl < mean_base:
                                wins += 1
                            else:
                                losses += 1
                        else:
                            ties += 1
                    else:
                        ties += 1

                avg_rpd = np.mean(rpd_list) if rpd_list else 0
                # [修正]: W/T/L 字母后缀，彻底绝杀 Excel 的日期自动格式化
                wtl_rows.append({'Dimension': f"{dim}D", 'Pair': f"{rl_clean} vs {base_clean}",
                                 'W/T/L': f"{wins}W / {ties}T / {losses}L", 'RPD(%)': f"{avg_rpd:+.1f}%"})

            # --- B. 全局 Friedman Ranking 与 热力图判定 ---
            all_algos_raw = [p[0] for p in PAIRS_1V1_RAW] + SOTA_ALGOS_RAW + [p[1] for p in PAIRS_1V1_RAW]
            all_algos_raw = list(dict.fromkeys(all_algos_raw))
            all_algos_raw = [a for a in all_algos_raw if any(a in data[dim][pid] for pid in PROBLEMS)]

            problem_ranks = {PAPER_NAMES_MAP.get(a, a): [] for a in all_algos_raw}
            heatmap_matrix = {PAPER_NAMES_MAP.get(p[0], p[0]): {PAPER_NAMES_MAP.get(s, s): [] for s in SOTA_ALGOS_RAW}
                              for p in PAIRS_1V1_RAW}

            for pid in PROBLEMS:
                pid_means = {}
                for algo_raw in all_algos_raw:
                    fit = get_aligned_fitness(data[dim][pid].get(algo_raw, {}).get('histories', []),
                                              data[dim][pid].get(algo_raw, {}).get('instances', []), inst_set, max_fes)
                    if len(fit) > 0:
                        pid_means[PAPER_NAMES_MAP.get(algo_raw, algo_raw)] = np.mean(fit)

                valid_algos_clean = list(pid_means.keys())
                if valid_algos_clean:
                    vals = [pid_means[a] for a in valid_algos_clean]
                    ranks = stats.rankdata(vals)
                    for a, r in zip(valid_algos_clean, ranks):
                        problem_ranks[a].append(r)

                if split_name == 'Test':
                    for rl_raw in [p[0] for p in PAIRS_1V1_RAW]:
                        rl_clean = PAPER_NAMES_MAP.get(rl_raw, rl_raw)
                        rl_fit = get_aligned_fitness(data[dim][pid].get(rl_raw, {}).get('histories', []),
                                                     data[dim][pid].get(rl_raw, {}).get('instances', []), inst_set,
                                                     max_fes)
                        for sota_raw in SOTA_ALGOS_RAW:
                            sota_clean = PAPER_NAMES_MAP.get(sota_raw, sota_raw)
                            sota_fit = get_aligned_fitness(data[dim][pid].get(sota_raw, {}).get('histories', []),
                                                           data[dim][pid].get(sota_raw, {}).get('instances', []),
                                                           inst_set, max_fes)

                            if len(rl_fit) >= 3 and len(sota_fit) >= 3:
                                _, p_val = stats.mannwhitneyu(rl_fit, sota_fit, alternative='two-sided')
                                if p_val < 0.05:
                                    score = 1 if np.mean(rl_fit) < np.mean(sota_fit) else -1
                                else:
                                    score = 0
                            else:
                                score = 0
                            heatmap_matrix[rl_clean][sota_clean].append(score)

            for algo_clean, r_list in problem_ranks.items():
                avg_r = np.mean(r_list) if r_list else np.nan
                rank_rows.append({'Dimension': f"{dim}D", 'Algorithm': algo_clean, 'Avg_Rank': avg_r})

            if split_name == 'Test':
                plot_data_pack['Test']['dim_stats'][dim]['ranks_raw'] = problem_ranks
                plot_data_pack['Test']['dim_stats'][dim]['heatmap_raw'] = heatmap_matrix

        df_wtl = pd.DataFrame(wtl_rows)
        df_wtl.to_csv(os.path.join(OUTPUT_DIR, f'WTL_RPD_{split_name}.csv'), index=False)

        df_rank = pd.DataFrame(rank_rows).pivot(index='Algorithm', columns='Dimension', values='Avg_Rank')
        df_rank.to_csv(os.path.join(OUTPUT_DIR, f'Avg_Rank_{split_name}.csv'))

    return plot_data_pack


# ==============================================================================
# 4. 图表绘制: 散件输出, 适配 LaTeX 双栏排版 (For TEST Set)
# ==============================================================================

def draw_plots_for_test_set(plot_pack):
    print("\n[3/4] Generating Individual LaTeX-ready Figures (Single & Double Column)...")

    # FES K单位格式化器
    def fes_formatter(x, pos):
        return f'{int(x / 1000)}k' if x >= 1000 else f'{int(x)}'

    for dim in DIMS:
        print(f"   > Drawing figures for {dim}D...")
        pack_dim = plot_pack['Test']['dim_stats'][dim]

        # --- 图 A: 对角线散点图 (分别输出单图) ---
        for rl_clean in [PAPER_NAMES_MAP.get(p[0]) for p in PAIRS_1V1_RAW]:
            if rl_clean not in pack_dim: continue

            base_clean = pack_dim[rl_clean]['base_target']
            rl_vals = np.array(pack_dim[rl_clean]['scatter']['rl'])
            base_vals = np.array(pack_dim[rl_clean]['scatter']['base'])

            if len(rl_vals) == 0: continue

            rl_vals = np.clip(rl_vals, 1e-12, None)
            base_vals = np.clip(base_vals, 1e-12, None)

            fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
            ax.scatter(base_vals, rl_vals, alpha=0.8, c=ALGO_COLORS.get(rl_clean, 'red'), edgecolors='white', s=40)

            min_val = min(np.min(rl_vals), np.min(base_vals)) * 0.1
            max_val = max(np.max(rl_vals), np.max(base_vals)) * 10
            ax.plot([min_val, max_val], [min_val, max_val], 'k--', alpha=0.5)

            ax.set_aspect('equal')
            ax.set_xscale('log')
            ax.set_yscale('log')
            ax.set_xlim(min_val, max_val)
            ax.set_ylim(min_val, max_val)

            ax.set_xlabel(f'{base_clean}')
            ax.set_ylabel(f'{rl_clean}')
            ax.set_title(f'{rl_clean} vs {base_clean} ({dim}D)')
            ax.grid(True, which="both", ls="--", alpha=0.2)

            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Scatter_{rl_clean}_vs_{base_clean}_{dim}D.pdf'), dpi=300)
            plt.close()

        # --- 图 B: 逐算例相对提升率 (双栏宽图) ---
        fig, axes = plt.subplots(len(PAIRS_1V1_RAW), 1, figsize=(7.5, 2.5 * len(PAIRS_1V1_RAW)), sharex=True)
        # 如果只有一个pair，包装成列表防止迭代报错
        if len(PAIRS_1V1_RAW) == 1: axes = [axes]

        x_labels = [f"P{i}" for i in PROBLEMS]
        x_pos = np.arange(len(PROBLEMS))

        for idx, rl_raw in enumerate([p[0] for p in PAIRS_1V1_RAW]):
            rl_clean = PAPER_NAMES_MAP.get(rl_raw)
            ax = axes[idx]
            rpds = pack_dim.get(rl_clean, {}).get('rpd', [])
            if len(rpds) == 0: continue

            colors = ['#2ca02c' if v > 0 else '#d62728' for v in rpds]
            ax.bar(x_pos, rpds, color=colors, alpha=0.8, width=0.6)
            ax.axhline(0, color='k', linewidth=0.8)
            ax.set_ylabel('RPD (%)')
            ax.set_title(f'{rl_clean} over {pack_dim[rl_clean]["base_target"]}')
            ax.grid(axis='y', alpha=0.3)

        axes[-1].set_xticks(x_pos)
        axes[-1].set_xticklabels(x_labels, rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, f'RPD_BarChart_All_{dim}D.pdf'), dpi=300)
        plt.close()

        # --- 图 C: 排名的箱型图 (单栏图) ---
        fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)
        box_df = pd.DataFrame(pack_dim['ranks_raw'])

        # 确定排序，RL 优先
        order_raw = [p[0] for p in PAIRS_1V1_RAW] + SOTA_ALGOS_RAW + [p[1] for p in PAIRS_1V1_RAW]
        order_clean = list(dict.fromkeys([PAPER_NAMES_MAP.get(o, o) for o in order_raw]))
        order_clean = [o for o in order_clean if o in box_df.columns and not box_df[o].isnull().all()]

        if not box_df.empty and order_clean:
            sns.boxplot(data=box_df[order_clean], ax=ax, palette=[ALGO_COLORS.get(x, '#cccccc') for x in order_clean],
                        width=0.5)
            ax.invert_yaxis()
            ax.set_ylabel('Rank (Lower is Better)')
            ax.set_title(f'Rank Distribution ({dim}D)')
            ax.set_xticklabels(order_clean, rotation=45, ha='right')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Rank_Boxplot_{dim}D.pdf'), dpi=300)
        plt.close()

        # --- 图 D: 优势热力图 (分别输出单图) ---
        for rl_clean in [PAPER_NAMES_MAP.get(p[0]) for p in PAIRS_1V1_RAW]:
            sota_heat = pack_dim['heatmap_raw'].get(rl_clean, {})
            if not sota_heat or all(len(v) == 0 for v in sota_heat.values()): continue

            df_heat = pd.DataFrame(sota_heat, index=[f"P{i}" for i in PROBLEMS])
            fig, ax = plt.subplots(figsize=(3.5, 4.0))  # 热力图高一点
            cmap = sns.color_palette("vlag", as_cmap=True)
            sns.heatmap(df_heat, cmap=cmap, center=0, cbar=False, annot=False, linewidths=.5, ax=ax)
            ax.set_title(f'{rl_clean} vs SOTA ({dim}D)')
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'Heatmap_{rl_clean}_{dim}D.pdf'), dpi=300)
            plt.close()


def draw_early_convergence_split(raw_data):
    print("\n[4/4] Generating Individual Early-Stage Convergence Figures...")
    test_insts = SPLITS_INFO['Test']

    SELECTED_PROBS = [1, 7, 13, 19]
    dim = 50
    max_fes = MAX_FES_FACTOR * dim
    cutoff_fes = max_fes * 0.10

    # 提取所有要对比的算法 (使用原始名字去 data 里取)
    algos_raw = [p[0] for p in PAIRS_1V1_RAW] + ['JADE', 'IPSO', 'L-SHADE']

    for pid in SELECTED_PROBS:
        fig, ax = plt.subplots(figsize=FIG_SIZE_SINGLE)  # 单图输出

        for algo_raw in algos_raw:
            histories = raw_data[dim][pid].get(algo_raw, {}).get('histories', [])
            instances = raw_data[dim][pid].get(algo_raw, {}).get('instances', [])

            interp_ys = []
            common_x = np.linspace(0, cutoff_fes, 200)
            for hist, inst in zip(histories, instances):
                if inst in test_insts:
                    h = np.array(hist)
                    if h.ndim == 2:
                        valid = h[:, 0] <= cutoff_fes
                        if np.sum(valid) > 2:
                            x, y = h[valid, 0], h[valid, 1]
                            y_interp = np.interp(common_x, x, y)
                            interp_ys.append(y_interp)

            if interp_ys:
                mean_y = np.mean(interp_ys, axis=0)
                algo_clean = PAPER_NAMES_MAP.get(algo_raw, algo_raw)
                ax.plot(common_x, mean_y, label=algo_clean, color=ALGO_COLORS.get(algo_clean, 'black'), lw=1.5)

        ax.set_title(f'P{pid} (Early Stage, {dim}D)')
        ax.set_xlabel('FES')
        ax.set_ylabel('Fitness')  # 去掉 SymLog 废话
        ax.set_yscale('symlog', linthresh=1e-2)
        ax.xaxis.set_major_formatter(
            ticker.FuncFormatter(lambda x, pos: f'{int(x / 1000)}k' if x >= 1000 else f'{int(x)}'))
        ax.legend(framealpha=0.6, loc='best')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, f'Early_Convergence_P{pid}_{dim}D.pdf'), dpi=300)
        plt.close()


# ==============================================================================
# Main
# ==============================================================================
if __name__ == "__main__":
    data = load_and_merge_data()
    if data:
        plot_pack = analyze_and_export_stats(data)
        draw_plots_for_test_set(plot_pack)
        draw_early_convergence_split(data)

        print("\n[Success] All tasks completed! LaTeX-ready files are in:")
        print(f"      -> {OUTPUT_DIR}")
    else:
        print("[Error] Initialization failed.")
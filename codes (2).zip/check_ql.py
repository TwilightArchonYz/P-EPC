import sys
import os
import numpy as np

# [Setup] 确保可以导入当前目录下的模块
sys.path.append(os.getcwd())

 # 1. 导入待测试的奖励计算器类
from evorl.core.reward_def import TrajectoryRewardCalculator
# 2. 导入现有的均值计算逻辑 (确保逻辑一致性)
# 注意: gen_baselines.py 必须在同一目录下
from evorl.preprocessing.gen_baselines import _compute_mean_curve



def run_check():
    print("=== [Check] TrajectoryRewardCalculator 逻辑验证 ===")

    # ==========================================================================
    # 1. 构造合成数据 (Mock Data)
    # ==========================================================================
    print("\n[Step 1] 生成合成种子曲线 (包含头部补全的负数刻度)...")

    # 模拟时间轴: 从 -200 (补全头部) 到 500 (正式演化)
    fes = np.array([-200, -100, 0, 100, 200, 300, 400, 500], dtype=float)

    # Seed A (优胜者):
    # 前期平台期 (100), 在 T=200 发生突变 (Drop to 10), 之后保持优势
    fit_a = np.array([100, 100, 100, 100, 10, 10, 10, 10], dtype=float)

    # Seed B (平庸者): 线性下降
    fit_b = np.array([100, 90, 80, 70, 60, 50, 40, 30], dtype=float)

    # Seed C (落后者): 缓慢下降
    fit_c = np.array([100, 95, 95, 90, 90, 85, 85, 80], dtype=float)

    # 组合成 (FES, Fitness) 格式
    curve_a = np.column_stack((fes, fit_a))
    curve_b = np.column_stack((fes, fit_b))
    curve_c = np.column_stack((fes, fit_c))

    # ==========================================================================
    # 2. 计算均值基准 (Real Calculation)
    # ==========================================================================
    print("[Step 2] 使用 gen_baselines._compute_mean_curve 计算均值基准...")
    mean_curve = _compute_mean_curve([curve_a, curve_b, curve_c])

    # 验证插值点 (T=200 时, A=10, B=60, C=90. Mean 约 (10+60+90)/3 = 53.3)
    val_at_200 = np.interp(200, mean_curve[:, 0], mean_curve[:, 1])
    print(f"   > FES=200 处的均值插值: {val_at_200:.2f} (预期约 53.33)")

    # ==========================================================================
    # 3. 验证自我对齐 (Self-Check)
    # ==========================================================================
    print("\n[Step 3] 验证自我对齐特性 (Seed A vs Seed A)...")
    # 仅启用 Seed Track (Weight=1.0), 禁用 Mean Track
    calc_self = TrajectoryRewardCalculator(
        seed_baseline=curve_a,
        mean_baseline=None,
        max_nfes=10000,
        gamma=0.99,
        weight_seed=1.0,
        weight_mean=0.0
    )

    # 计算奖励
    rewards_self = calc_self.compute_rewards(fit_a, fes)
    max_abs_r = np.max(np.abs(rewards_self))

    print(f"   > 最大绝对奖励值: {max_abs_r:.6f}")
    if max_abs_r > 1e-9:
        print("     [Note] 非零奖励是预期的。物理含义：'不进则退'。")
        print("     即使 Fitness 不变，但时间在流逝，相对于最早达到该 Fitness 的基准时刻，")
        print("     Agent 的时间优势 (Lead) 在减小，导致产生微小的负 Delta。")
    else:
        print("     [Pass] 奖励严格为 0。")

    # ==========================================================================
    # 4. 验证折扣回传 (Forward Propagation)
    # ==========================================================================
    print("\n[Step 4] 验证折扣回传逻辑 (Seed A vs Mean)...")
    # Seed A 在 T=200 取得了对 Mean 的巨大优势 (10 vs 53)。
    # 这个优势产生的正奖励应该回传给 T=100, 0, -100...

    calc_prop = TrajectoryRewardCalculator(
        seed_baseline=None,
        mean_baseline=mean_curve,
        max_nfes=10000,
        gamma=0.90,  # 使用 0.90 以便肉眼观察衰减 (1.0 -> 0.9 -> 0.81)
        weight_seed=0.0,
        weight_mean=1.0
    )

    rewards_prop = calc_prop.compute_rewards(fit_a, fes)

    print("   > 逐帧奖励分析:")
    for i in range(len(fes)):
        r_val = rewards_prop[i]
        f_val = fit_a[i]
        t_val = fes[i]
        print(f"     Idx {i} | FES {t_val:>4.0f} | Fit {f_val:>3.0f} | Reward={r_val:.6f}")

    # 逻辑断言
    r3 = rewards_prop[3]  # FES 100
    r4 = rewards_prop[4]  # FES 200 (突变点)

    print(f"\n   > 关键帧检查 (Gamma=0.90):")
    print(f"     R[3] (FES 100) = {r3:.6f}")
    print(f"     R[4] (FES 200) = {r4:.6f}")

    # R[3] 应该是正的，虽然在 FES 100 时 A(100) 比 Mean(70) 差。
    # 因为 R[4] 的巨大正值回传了回来： R[3] = Delta[3] + 0.9 * R[4]
    if r3 > 0 and r4 > r3:
        print("     [PASS] 成功回传！尽管当前表现不佳，未来的收益成功拉高了当前价值。")
    else:
        print("     [FAIL] 回传逻辑未生效或数值异常。")

    # ==========================================================================
    # 5. 验证刻度对齐 (Scale Alignment)
    # ==========================================================================
    print("\n[Step 5] 验证负数刻度对齐...")
    # 检查 FES -200 处是否有计算结果
    if rewards_prop[0] != 0.0:
        print(f"     [PASS] 负数时间轴 (FES -200) 计算正常，奖励值: {rewards_prop[0]:.6f}")
    else:
        print("     [WARN] FES -200 奖励为 0。可能是恰好 Delta 为 0，需人工确认。")


if __name__ == "__main__":
    run_check()
import numpy as np
import matplotlib.pyplot as plt

# 设置绘图风格
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['mathtext.fontset'] = 'cm'


def plot_final_v6():
    # 1. 定义时间轴
    t_full = np.linspace(-30, 150, 800)

    # 2. 定义基线函数 (全局统一延伸)
    def get_baseline(t_arr, a, b):
        y = np.zeros_like(t_arr)
        mask_main = t_arr >= 0
        y[mask_main] = a * np.exp(-b * t_arr[mask_main])
        mask_front = t_arr < 0
        y[mask_front] = a - (a * b) * t_arr[mask_front]
        return y

    # 3. 生成曲线数据
    f_mean = get_baseline(t_full, 20, 0.04)
    f_seed = get_baseline(t_full, 35, 0.02)

    t_agent_end = 100
    t_agent = np.linspace(0, t_agent_end, 400)
    f_agent = 28 * np.exp(-0.03 * t_agent)

    # 4. 选取演示点
    t_prev = 30
    t_curr = 45
    f_ag_prev = 28 * np.exp(-0.03 * t_prev)
    f_ag_curr = 28 * np.exp(-0.03 * t_curr)

    # 5. 计算投影点
    idx_mean_prev = np.argmin(np.abs(f_mean - f_ag_prev))
    tau_mean_prev = t_full[idx_mean_prev]

    idx_mean_curr = np.argmin(np.abs(f_mean - f_ag_curr))
    tau_mean_curr = t_full[idx_mean_curr]

    idx_seed_curr = np.argmin(np.abs(f_seed - f_ag_curr))
    tau_seed_curr = t_full[idx_seed_curr]

    # 6. 绘图
    fig, ax = plt.subplots(figsize=(12, 7))
    FONT_LABEL = 14
    FONT_TEXT = 12
    FONT_LEGEND = 12
    Y_MIN = 0.5

    # --- 绘制区域背景 ---
    ax.axvspan(-30, 0, color='gray', alpha=0.1)
    ax.text(-15, 0.8, "Front Padding", ha='center', va='bottom', color='gray', fontsize=FONT_TEXT)
    ax.axvspan(100, 150, color='gray', alpha=0.1)
    ax.text(125, 0.8, "Back Padding", ha='center', va='bottom', color='gray', fontsize=FONT_TEXT)

    # --- 绘制曲线 ---
    ax.plot(t_full, f_seed, color='#1f77b4', linestyle='--', linewidth=2.5, label='Specific Baseline ($B_{seed}$)')
    ax.plot(t_full, f_mean, color='#2ca02c', linestyle='-.', linewidth=2.5, label='Mean Baseline ($B_{mean}$)')
    ax.plot(t_agent, f_agent, color='#d62728', linestyle='-', linewidth=3.5, label='Agent (Actual Run)')

    # --- 绘制实体物理状态点 (实心红圆) ---
    ax.plot(t_prev, f_ag_prev, 'o', color='#d62728', markersize=8, zorder=5)
    ax.plot([t_prev, t_curr], [f_ag_prev, f_ag_curr], '-', color='#d62728', linewidth=2)
    ax.plot(t_curr, f_ag_curr, 'o', color='#d62728', markersize=13, zorder=5)

    # 贯穿红色虚线
    ax.plot([t_curr, t_curr], [Y_MIN, f_ag_curr], color='#d62728', linestyle='--', linewidth=2.5)

    ax.text(t_prev, f_ag_prev + 1.5, '$t-1$', color='#d62728', ha='center', fontsize=FONT_TEXT)
    ax.text(t_curr + 2, f_ag_curr + 1.5, '$t$ (Current)', color='#d62728', ha='left', fontweight='bold',
            fontsize=FONT_TEXT)

    # --- 绘制投影点 (虚拟映射状态 - 边缘异色，内部留白空心) ---
    # 1. t-1 在 Mean 上的投影
    ax.plot(tau_mean_prev, f_mean[idx_mean_prev], 'o', markeredgecolor='#2ca02c', markerfacecolor='white', markersize=8,
            markeredgewidth=2.5, zorder=6)
    # 2. t 在 Mean 上的投影
    ax.plot(tau_mean_curr, f_mean[idx_mean_curr], 'o', markeredgecolor='#2ca02c', markerfacecolor='white', markersize=8,
            markeredgewidth=2.5, zorder=6)
    # 3. t 在 Seed 上的投影
    ax.plot(tau_seed_curr, f_seed[idx_seed_curr], 'o', markeredgecolor='#1f77b4', markerfacecolor='white', markersize=8,
            markeredgewidth=2.5, zorder=6)

    # --- 可视化 1: 相对领先 (基于 Mean Baseline) ---
    ax.vlines(x=tau_mean_prev, ymin=Y_MIN, ymax=f_mean[idx_mean_prev], colors='#2ca02c', linestyles=':', alpha=0.5,
              linewidth=1.5)
    ax.vlines(x=tau_mean_curr, ymin=Y_MIN, ymax=f_mean[idx_mean_curr], colors='#2ca02c', linestyles=':', alpha=0.5,
              linewidth=1.5)
    ax.hlines(y=f_ag_prev, xmin=tau_mean_prev, xmax=t_prev, colors='#2ca02c', linestyles=':', alpha=0.5, linewidth=1.5)
    ax.hlines(y=f_ag_curr, xmin=tau_mean_curr, xmax=t_curr, colors='#2ca02c', linestyles=':', alpha=0.5, linewidth=1.5)

    y_rel_arrow = 3.0
    y_rel_text = 2.0
    ax.annotate('', xy=(tau_mean_prev, y_rel_arrow), xytext=(tau_mean_curr, y_rel_arrow),
                arrowprops=dict(arrowstyle='<|-|>', color='#2ca02c', linewidth=2.5))
    ax.text((tau_mean_prev + tau_mean_curr) / 2, y_rel_text,
            r'$\bf{Relative\ Gain}$' + '\n' + r'($\Delta \tau$ on Mean Curve)',
            color='#2ca02c', ha='center', va='top', fontsize=FONT_TEXT)

    # --- 可视化 2: 绝对领先 (基于 Specific Baseline) ---
    ax.vlines(x=tau_seed_curr, ymin=Y_MIN, ymax=f_seed[idx_seed_curr], colors='#1f77b4', linestyles=':', alpha=0.5,
              linewidth=1.5)
    ax.hlines(y=f_ag_curr, xmin=t_curr, xmax=tau_seed_curr, colors='#1f77b4', linestyles=':', alpha=0.5, linewidth=1.5)

    y_abs_arrow = 22.0
    y_abs_text = 24.5
    ax.annotate('', xy=(t_curr, y_abs_arrow), xytext=(tau_seed_curr, y_abs_arrow),
                arrowprops=dict(arrowstyle='<|-|>', color='#1f77b4', linewidth=2.5))
    ax.text((t_curr + tau_seed_curr) / 2, y_abs_text,
            r'$\bf{Absolute\ Lead}$' + '\n' + r'(Total Distance on Specific Curve)',
            color='#1f77b4', ha='center', va='bottom', fontsize=FONT_TEXT)

    ax.plot([t_curr, t_curr], [f_ag_curr, y_abs_arrow], ':', color='gray', alpha=0.4, linewidth=1.5)
    ax.plot([tau_seed_curr, tau_seed_curr], [f_seed[idx_seed_curr], y_abs_arrow], ':', color='gray', alpha=0.4,
            linewidth=1.5)

    # --- 装饰与坐标轴 ---
    ax.set_yscale('log')
    ax.set_xlim(-30, 150)
    ax.set_ylim(Y_MIN, 55)

    ax.axvline(0, color='k', linewidth=1.0)
    ax.axvline(100, color='k', linestyle='--', linewidth=1.0)

    # 彻底接管X轴，只保留概念标签
    ax.set_xticks([0, t_prev, t_curr, 100])
    ax.set_xticklabels(['Start', '$t-1$', '$t$', '$G_{max}$'])

    # 将 t 时刻的标签标红加粗
    for tick_label, loc in zip(ax.get_xticklabels(), ax.get_xticks()):
        if loc == t_curr:
            tick_label.set_color('#d62728')
            tick_label.set_fontweight('bold')
            tick_label.set_fontsize(FONT_TEXT + 4)
        else:
            tick_label.set_fontsize(FONT_TEXT + 2)

    ax.set_xlabel('Evolutionary Generations (Virtual Time)', fontsize=FONT_LABEL)
    ax.set_ylabel('Objective Value (Log Scale)', fontsize=FONT_LABEL)

    ax.legend(loc='upper right', fontsize=FONT_LEGEND, frameon=True)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    plt.savefig('final_plot_v6.png', dpi=300, bbox_inches='tight')
    plt.show()


plot_final_v6()
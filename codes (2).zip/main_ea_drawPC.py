import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ==============================================================================
# 1. 配置与参数 (Configuration)
# ==============================================================================

# 输入文件路径 (必须与 main_benchmark_baselines.py 输出一致)
INPUT_PATH = 'experiments/benchmarks/benchmark_results_5000D_30_40_50.pkl'

# 输出目录
OUTPUT_DIR = 'experiments/baselines_results'

# 实验参数
DIMS = [30, 40, 50]
PROBLEMS = list(range(1, 21))
ALGOS = ['SHADE', 'L-SHADE', 'jSO', 'JADE', 'IMODE', 'IPSO']
MAX_FES_FACTOR = 5000  # MaxFES = 5000 * D

# [新增] 数据集显式切分规则
TRAIN_INSTS = [1, 2, 3, 4]
VAL_INSTS = [5, 6, 7, 8]
TEST_INSTS = [9, 10, 11, 12]

# 绘图配置
ALGO_COLORS = {
    'SHADE': '#1f77b4',
    'L-SHADE': '#ff7f0e',
    'jSO': '#2ca02c',
    'JADE': '#d62728',
    'IMODE': '#9467bd',
    'IPSO': '#8c564b'
}

# 收敛曲线插值点数
INTERP_POINTS = 500


# ==============================================================================
# 2. 数据加载与预处理 (Data Processing)
# ==============================================================================

def load_and_structure_data():
    """
    加载 PKL 并重组为层级字典:
    data[dim][pid][algo][dataset_type] = {histories, finals, runtimes}
    dataset_type 包含: 'all', 'train', 'val', 'test'
    """
    print(f"[Analysis] Loading data from {INPUT_PATH}...")
    if not os.path.exists(INPUT_PATH):
        print(f"[Error] File not found: {INPUT_PATH}")
        return {}

    with open(INPUT_PATH, 'rb') as f:
        raw_data = pickle.load(f)

    structured_data = {}

    # 预初始化四路分支结构
    for dim in DIMS:
        structured_data[dim] = {}
        for pid in PROBLEMS:
            structured_data[dim][pid] = {}
            for algo in ALGOS:
                structured_data[dim][pid][algo] = {
                    'all': {'histories': [], 'finals': [], 'runtimes': []},
                    'train': {'histories': [], 'finals': [], 'runtimes': []},
                    'val': {'histories': [], 'finals': [], 'runtimes': []},
                    'test': {'histories': [], 'finals': [], 'runtimes': []}
                }

    # 填充数据
    count = 0
    for key, val in raw_data.items():
        algo, pid, dim, inst, seed = key

        if dim not in DIMS or pid not in PROBLEMS or algo not in ALGOS:
            continue

        # 1. 无差别塞入 'all' 分支 (保留旧逻辑)
        structured_data[dim][pid][algo]['all']['histories'].append(val['history'])
        structured_data[dim][pid][algo]['all']['finals'].append(val['final_fitness'])
        structured_data[dim][pid][algo]['all']['runtimes'].append(val.get('runtime', 0))

        # 2. 精准路由到 'train', 'val', 'test' 分支
        if inst in TRAIN_INSTS:
            target_set = 'train'
        elif inst in VAL_INSTS:
            target_set = 'val'
        elif inst in TEST_INSTS:
            target_set = 'test'
        else:
            continue  # 未知算例跳过

        structured_data[dim][pid][algo][target_set]['histories'].append(val['history'])
        structured_data[dim][pid][algo][target_set]['finals'].append(val['final_fitness'])
        structured_data[dim][pid][algo][target_set]['runtimes'].append(val.get('runtime', 0))

        count += 1

    print(f"[Analysis] Loaded {count} runs and splitted into train/val/test.")
    return structured_data


def get_interpolated_curves(histories, max_fes):
    """
    将不同长度的历史记录插值到公共 X 轴。
    """
    common_x = np.linspace(0, max_fes, INTERP_POINTS)
    interp_y_list = []

    for hist in histories:
        fes = hist[:, 0]
        fit = hist[:, 1]
        y_interp = np.interp(common_x, fes, fit)
        interp_y_list.append(y_interp)

    if not interp_y_list:
        return common_x, np.zeros_like(common_x), np.zeros_like(common_x)

    interp_matrix = np.array(interp_y_list)
    mean_curve = np.mean(interp_matrix, axis=0)
    std_curve = np.std(interp_matrix, axis=0)

    return common_x, mean_curve, std_curve


# ==============================================================================
# 3. 绘图：收敛曲线 (默认只画 'all')
# ==============================================================================

def plot_convergence(structured_data):
    """
    为每个维度生成一个 PDF。目前默认使用 'all' 数据集画图，避免线条过多。
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    for dim in DIMS:
        print(f"[Analysis] Plotting convergence curves for Dim {dim} (using 'all' data)...")
        max_fes = MAX_FES_FACTOR * dim

        fig, axes = plt.subplots(4, 5, figsize=(25, 18))
        axes = axes.flatten()

        for i, pid in enumerate(PROBLEMS):
            ax = axes[i]

            for algo in ALGOS:
                # [修改] 提取 'all' 分支的历史数据
                histories = structured_data[dim][pid][algo]['all']['histories']

                if not histories:
                    continue

                x, mean, std = get_interpolated_curves(histories, max_fes)
                color = ALGO_COLORS.get(algo, 'black')

                ax.plot(x, mean, label=algo, color=color, linewidth=1.5, alpha=0.9)
                upper = mean + 0.2 * std
                lower = mean - 0.2 * std
                ax.fill_between(x, lower, upper, color=color, alpha=0.1)

            ax.set_title(f"Problem {pid} (D={dim})", fontsize=11, fontweight='bold')
            ax.set_yscale('symlog', linthresh=1e-5)
            ax.grid(True, which="both", ls="-", alpha=0.3)
            ax.legend(fontsize=7, loc='best', framealpha=0.5)

            if i >= 15:
                ax.set_xlabel("FES")
            if i % 5 == 0:
                ax.set_ylabel("Fitness (SymLog)")

        plt.tight_layout()
        save_file = os.path.join(OUTPUT_DIR, f'ea_curves_{dim}D.pdf')
        plt.savefig(save_file, dpi=300)
        plt.close()
        print(f"   -> Saved: {save_file}")


# ==============================================================================
# 4. 统计表格：四路输出 (Statistical Tables)
# ==============================================================================

def generate_tables(structured_data):
    """
    生成 Mean (Std) 表格 CSV。按维度和数据集类型（all, train, val, test）分别输出。
    """
    dataset_types = ['all', 'train', 'val', 'test']

    for dim in DIMS:
        for d_type in dataset_types:
            print(f"[Analysis] Generating statistical table for Dim {dim} ({d_type} set)...")

            rows = []
            for pid in PROBLEMS:
                row_data = {'Problem': pid}
                best_mean = float('inf')

                algo_stats = {}
                for algo in ALGOS:
                    # [修改] 提取对应分支的 finals 列表
                    finals = structured_data[dim][pid][algo][d_type]['finals']

                    if not finals:
                        mean, std = np.nan, np.nan
                    else:
                        mean = np.mean(finals)
                        std = np.std(finals)

                    algo_stats[algo] = (mean, std)

                    if not np.isnan(mean) and mean < best_mean:
                        best_mean = mean

                for algo in ALGOS:
                    mean, std = algo_stats[algo]
                    if np.isnan(mean):
                        row_data[algo] = "N/A"
                    else:
                        str_val = f"{mean:.2e} (±{std:.1e})"
                        if abs(mean - best_mean) < 1e-15:
                            str_val = f"*{str_val}*"
                        row_data[algo] = str_val

                rows.append(row_data)

            df = pd.DataFrame(rows)
            cols = ['Problem'] + ALGOS
            df = df[cols]

            # [修改] 文件名加上数据集类型后缀
            save_file = os.path.join(OUTPUT_DIR, f'ea_stats_{dim}D_{d_type}.csv')
            df.to_csv(save_file, index=False)
            print(f"   -> Saved: {save_file}")


# ==============================================================================
# 5. 运行时间分析 (默认只画 'all')
# ==============================================================================

def plot_runtime(structured_data):
    """
    绘制运行时间箱线图 (使用 'all' 数据)
    """
    print(f"[Analysis] Plotting runtime comparison (using 'all' data)...")

    plot_data = []
    for dim in DIMS:
        for algo in ALGOS:
            times = []
            for pid in PROBLEMS:
                # [修改] 提取 'all' 分支的运行时间
                times.extend(structured_data[dim][pid][algo]['all']['runtimes'])

            for t in times:
                plot_data.append({'Dimension': str(dim), 'Algorithm': algo, 'Time(s)': t})

    if not plot_data:
        print("[Warning] No runtime data found.")
        return

    df = pd.DataFrame(plot_data)

    plt.figure(figsize=(12, 6))
    sns.boxplot(x='Dimension', y='Time(s)', hue='Algorithm', data=df, palette=ALGO_COLORS)
    plt.title("Runtime Distribution by Dimension (All Problems)", fontsize=14)
    plt.grid(True, axis='y', alpha=0.3)
    plt.yscale('log')
    plt.ylabel("Time (s) - Log Scale")

    save_file = os.path.join(OUTPUT_DIR, 'ea_runtime_comparison.png')
    plt.savefig(save_file, dpi=300)
    plt.close()
    print(f"   -> Saved: {save_file}")


# ==============================================================================
# Main
# ==============================================================================

if __name__ == "__main__":
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 1. 加载数据并进行四路分发
    data = load_and_structure_data()

    if data:
        # 2. 生成收敛曲线 (默认 'all')
        plot_convergence(data)

        # 3. 生成四组统计表格 (all, train, val, test)
        generate_tables(data)

        # 4. 生成时间对比 (默认 'all')
        plot_runtime(data)

        print("\n[Analysis] All Baseline analysis tasks completed.")
    else:
        print("[Analysis] No data loaded. Exiting.")
import os
import sys
import json
import torch
import pickle
import numpy as np
import time
from tqdm import tqdm
import glob  # [Modified] 新增 glob 模块，用于跨文件夹递归搜索和通配符匹配
import traceback  # [Added] 用于打印完整的错误堆栈信息

# [System] 导入核心模块
try:
    from evorl.factory import AlgorithmFactory
    from evorl.problems import ScalableProblem
    import evorl.problems.params_def as params_def
    # 如果有 AgentAdapter 需求可以导入，但通常 checkpoint加载不需要
except ImportError as e:
    print(f"[Error] Failed to import evorl modules: {e}")
    sys.exit(1)

# ==============================================================================
# 配置区域 (Configuration)
# ==============================================================================

# 输入：实验根目录 (单问题专用模型)
INPUT_ROOT = 'experiments_single'

# 输出：结果保存路径
OUTPUT_DIR = 'experiments/benchmarks'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'rl_specialist_results.pkl')

# 推理配置
TARGET_DIMS = [30, 40, 50]  # 测试维度
# FES 计算公式: MAX_FES_FACTOR * D
MAX_FES_FACTOR = 5000
# 强制覆盖测试实例 (如果为None则读取config['test_instances'])
TEST_INSTANCES_FORCE = list(range(1, 10))  # 建议与 benchmark 保持一致


# ==============================================================================
# 核心逻辑 (Core Logic)
# ==============================================================================

def load_specialist_agent(folder_path, device):
    """
    加载 Agent 和 Config。
    严格检查是否为 Specialist 模型 (只训练了一个问题)。
    """
    # 1. [Modified] 精确定位 Config 文件 (直接在实验根目录下寻找 config.json)
    config_path = os.path.join(folder_path, 'config.json')
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"No config file found at {config_path}")

    # 2. [Modified] 递归向下定位模型权重 (寻找任何以 _best.pth 结尾的文件)
    best_models = glob.glob(os.path.join(folder_path, '**', '*_best.pth'), recursive=True)
    # 备用方案：如果没有 _best.pth，则寻找 _pretrained.pth
    pretrained_models = glob.glob(os.path.join(folder_path, '**', '*_pretrained.pth'), recursive=True)

    if best_models:
        model_path = best_models[0]
    elif pretrained_models:
        model_path = pretrained_models[0]
    else:
        raise FileNotFoundError(
            f"No checkpoint (*_best.pth or *_pretrained.pth) found in {folder_path} or its subdirectories.")

    # 3. 加载配置
    with open(config_path, 'r') as f:
        config = json.load(f)

    # [Logic Audit] 严格过滤：必须是 Specialist
    train_probs = config.get('train_problems', [])
    if len(train_probs) > 1:
        raise ValueError(f"Detected Generalist Model (Training on {len(train_probs)} problems). Skipping.")
    if len(train_probs) == 0:
        # 兼容旧版 config 可能用 prob_id 的情况
        if 'prob_id' not in config:
            raise ValueError("Invalid Config: No train_problems or prob_id found.")

    # 4. 重建 Agent
    # 提取构造参数
    agent_name = config['agent_name']
    algo_params = config.get('algo_params', [])
    spec_params = config.get('special_params', {})

    # 修正：部分 config 可能没有 context_spec (兼容性处理)
    context_spec = config.get('context_spec', None)

    agent = AlgorithmFactory.create_agent(
        agent_name,
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config.get('lr', 3e-4),
        gamma=config.get('gamma', 0.99),
        batch_size=config.get('batch_size', 256),
        buffer_size=config.get('buffer_size', 1000000),
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config.get('stream_hidden_dim', 64),
        state_spec=config.get('state_spec'),
        context_spec=context_spec,
        state_bins=config.get('state_bins', []),
        algo_params=algo_params,
        dim_norm_factor=config.get('dim_norm_factor', 50),
        device=device,
        target_dims=config.get('target_dims', [30]),
        inference_only=True,  # [Key] 标记为推理模式，不初始化优化器等
        **spec_params
    )

    # 5. [Final Fix] 加载权重 (兼容深度网络与纯 Numpy 强化学习)
    if hasattr(agent, 'load') and agent_name == "Q_Learning":
        # 如果是 Q-Learning，直接把 .pth 文件路径传给它自己的 load 方法
        try:
            agent.load(model_path)
            # print(f"[System] Successfully loaded Q-Table from {model_path}")
        except Exception as e:
            raise RuntimeError(f"Q-Learning agent failed to load {model_path}: {e}")
    else:
        # 如果是其他标准的 PyTorch 深度网络 (SAC, PPO, DQN 等)
        try:
            # 必须加上 weights_only=False 绕过 PyTorch 2.6 的安全限制
            checkpoint = torch.load(model_path, map_location=device, weights_only=False)

            # 兼容处理：有些 checkpoint 直接存 state_dict，有些存整个 dict
            if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
                state_dict = checkpoint['model_state_dict']
            else:
                state_dict = checkpoint

            agent.load_state_dict(state_dict)
        except Exception as e:
            raise RuntimeError(f"Failed to load standard PyTorch weights from {model_path}: {e}")

    # 6. [Modified] 安全切换到评估模式 (Q-Learning 没有 eval 方法，需加保护壳)
    if hasattr(agent, 'eval'):
        agent.eval()

    return agent, config


def run_solver_inference(agent, config, target_prob_id, dim, instance_id, device):
    """
    通过 AlgorithmFactory 创建 Solver 并执行推理循环。
    """
    # 1. 准备问题环境
    try:
        param_dict, pf1, pf2 = params_def.generate_instance_config(target_prob_id, dim, instance_id)
        problem = ScalableProblem(target_prob_id, dim, param_dict, pf1=pf1, pf2=pf2)
    except Exception as e:
        print(f"[Error] Problem Init Failed P{target_prob_id}-D{dim}-I{instance_id}: {e}")
        return None, None, None

    # 2. 准备 Solver
    ea_name = config.get('ea_name', 'JADE')
    max_nfes = MAX_FES_FACTOR * dim
    pop_size = config.get('pop_size_factor', 20) * dim

    try:
        solver = AlgorithmFactory.create_solver(
            problem=problem,
            ea_name=ea_name,
            agent=agent,
            pop_size=pop_size,
            max_nfes=max_nfes,
            seed=config.get('base_seed', 2024),
            mode='test'
        )
    except Exception as e:
        print(f"[Error] Solver Create Failed ({ea_name}): {e}")
        return None, None, None

    # 3. 执行推理循环
    start_time = time.time()
    history = []

    try:
        # 对应你 JADE_RL 里的 initialize()
        solver.initialize()

        # [Critical Fix] 参照你 JADE_RL.solve() 的逻辑进行延迟初始化
        if hasattr(solver, '_rl_init_params'):
            solver.setup_rl(**solver._rl_init_params)
            del solver._rl_init_params

        # 记录初始状态
        history.append([float(solver.fes), float(solver.gbest_val)])

        # [Correct Logic] 直接读取属性判断，不再调用不存在的 is_stop()
        while solver.fes < solver.max_nfes:
            solver.evolve()
            history.append([float(solver.fes), float(solver.gbest_val)])

    except Exception as e:
        print(f"\n[Error] Inference Loop Failed: {e}")
        traceback.print_exc()  # [Added] 打印完整堆栈以精确定位 None - float 发生的位置
        return None, None, None

    runtime = time.time() - start_time
    return np.array(history), float(solver.gbest_val), runtime


def main_specialist_export():
    print("=" * 80)
    print(f"[Pipeline] Starting RL Specialist Export (Solver-Based)")
    print(f"   > Input: {INPUT_ROOT}")
    print(f"   > Output: {OUTPUT_FILE}")
    print("=" * 80)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    combined_results = {}

    # 1. 扫描文件夹
    if not os.path.exists(INPUT_ROOT):
        print(f"[Error] Input root not found: {INPUT_ROOT}")
        return

    subdirs = [d for d in os.listdir(INPUT_ROOT) if os.path.isdir(os.path.join(INPUT_ROOT, d))]

    # [Modified] 过滤条件从 '_seed' 修改为 '_S'
    candidate_folders = [d for d in subdirs if '_P' in d and '_S' in d]

    print(f"[System] Found {len(candidate_folders)} candidate folders. Filtering...")

    valid_count = 0
    skipped_count = 0

    for folder_name in tqdm(candidate_folders, desc="Processing Models"):
        folder_path = os.path.join(INPUT_ROOT, folder_name)

        # 2. 加载模型
        try:
            agent, config = load_specialist_agent(folder_path, device)
        except ValueError as ve:
            # 这是一个预期的跳过 (例如遇到通用模型)
            skipped_count += 1
            continue
        except Exception as e:
            print(f"\n[Warning] Error loading {folder_name}: {e}")
            skipped_count += 1
            continue

        valid_count += 1

        # 3. 提取元数据 [Modified] 组合 RL 和 EA 算法名称防止键冲突
        rl_algo = config.get('agent_name', 'UnknownRL')
        ea_algo = config.get('ea_name', 'JADE')  # 如果 config 没存 EA 名字，默认给 JADE
        algo_name_key = f"{rl_algo}_{ea_algo}-Specialist"

        seed = config.get('base_seed')

        # 获取专用模型绑定的唯一问题 ID
        train_probs = config.get('train_problems', [])
        if not train_probs:
            target_prob_id = config.get('prob_id')  # Fallback
        else:
            target_prob_id = train_probs[0]

        # 4. 确定测试实例
        test_instances = TEST_INSTANCES_FORCE if TEST_INSTANCES_FORCE else config.get('test_instances', [])

        # 5. 执行推理 (Prob ID 必须匹配)
        for dim in TARGET_DIMS:
            for inst_id in test_instances:
                # Key: (Algo-Specialist, ProbID, Dim, Instance, Seed)
                key = (algo_name_key, target_prob_id, dim, inst_id, seed)

                # 如果结果已存在，是否跳过？(当前逻辑：覆盖)
                history, final_fit, runtime = run_solver_inference(
                    agent, config, target_prob_id, dim, inst_id, device
                )

                if history is not None:
                    combined_results[key] = {
                        'history': history,
                        'final_fitness': final_fit,
                        'runtime': runtime
                    }

    # 6. 保存结果
    print("-" * 80)
    print(f"[Summary] Processed: {valid_count} | Skipped: {skipped_count}")
    print(f"[System] Saving {len(combined_results)} entries to {OUTPUT_FILE}...")

    with open(OUTPUT_FILE, 'wb') as f:
        pickle.dump(combined_results, f)

    print("[System] Done.")


if __name__ == "__main__":
    main_specialist_export()
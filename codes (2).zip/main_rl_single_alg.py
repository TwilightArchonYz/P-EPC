import os

# [Architecture - Step 1] 移除全局环境钳制
# 原有的 os.environ 设置已被移除，允许主进程默认使用所有核心。
# 这确保了 Offline 阶段和 Online 的 Learn 阶段能跑满 CPU。
# os.environ["OMP_NUM_THREADS"] = "1" ... (Removed)

import torch
import numpy as np
import random
import json
import datetime
import multiprocessing
import copy
import time
import sys

# 导入自定义模块
from evorl.trainning.online import OnlineTrainer
from evorl.trainning.evaluator import Evaluator
from evorl.trainning.offline import OfflineTrainer
from evorl.factory import AlgorithmFactory
from evorl.utils.monitor import Monitor
from evorl.utils.naming import PathManager
from evorl.preprocessing import gen_baselines

# ==============================================================================
# PART 1: 用户全局配置 (User Global Configuration)
# ==============================================================================
# 按照功能逻辑分为 6 组，请在此区域调整实验参数。
# ==============================================================================

# ------------------------------------------------------------------------------
# Group 1: 基础设施与复现 (Infrastructure & Reproducibility)
# ------------------------------------------------------------------------------
N_CORES = 30  # [System] 允许使用的最大 CPU 核心数 (建议预留 1-2 核给系统)
N_REPEATS = 20  # [Exp] 每个 RL 算法在同一问题上的重复实验次数 (独立种子)
SEED_START = 1  # [Exp] 随机种子起始值
SEED_POOL = list(range(SEED_START, 21))  # 种子池 (供数据生成和训练使用)
BASE_SEEDS = list(range(1, N_REPEATS + 1))  # 实际参与对比实验的种子列表

# ------------------------------------------------------------------------------
# Group 2: 问题定义与数据 (Problem & Data)
# ------------------------------------------------------------------------------
TRAIN_PROBLEMS = list(range(2, 21))  # 参与训练的函数 ID 列表
TARGET_DIMS = [30, 40, 50]  # 问题维度
GEN_INSTANCES = list(range(1, 13))  # [Instance] 原始生成的实例总列表 (用于后续划分)

# ------------------------------------------------------------------------------
# Group 3: 特征工程与动作空间 (Feature & Action Space)
# ------------------------------------------------------------------------------
# [Action] 动作参数生成 (F 和 CR 的取值范围)
# 生成 0.02 到 1.00，步长 0.02 的列表
options_list = [round(x * 0.02, 2) for x in range(1, 51)]

ALGO_PARAMS = [
    {'name': 'F', 'options': options_list},
    {'name': 'CR', 'options': options_list}
]

# [Feature] 特征注册表 (定义所有可用特征的物理规格)
FEATURE_REGISTRY = {
    'Progress': {'bins': 5, 'min': 0.0, 'max': 1.0},  # 进化进度
    'Diversity': {'bins': 5, 'min': 0.0, 'max': 1.0},  # 种群多样性
    'Stagnation': {'bins': 5, 'min': 0.0, 'max': 1.0},  # 停滞代数指标
    'FitDist': {'bins': 5, 'min': 0.0, 'max': 1.0},  # 适应度分布
    'EvoRate': {'bins': 5, 'min': 0.0, 'max': 1.0},  # 进化速率 (已 Clip)
    'NormDim': {'bins': 5, 'min': 0.0, 'max': 1.0},  # 归一化维度
}

# [User Selection] 当前实验启用的特征列表
SELECTED_FEATURES = [
    'Progress',
    'Diversity',
    'Stagnation',
    'FitDist',
    'EvoRate',
    'NormDim',
    'F',
    'CR'
]

# ------------------------------------------------------------------------------
# Group 4: 神经网络与强化学习核心 (Network & RL Core)
# ------------------------------------------------------------------------------
HIDDEN_DIM = 256  # [Net] 主干网络隐层维度
STREAM_HIDDEN_DIM = 64  # [Net] Dueling 架构的分支隐层维度
RL_LR = 3e-4  # [RL] 默认学习率 (可被 Algo Registry 覆盖)
RL_GAMMA = 0.99  # [RL] 折扣因子
UCB_BETA = 1.0  # [Exploration] UCB 探索系数

# ------------------------------------------------------------------------------
# Group 5: 训练流程与动态调整 (Training Flow & Dynamics)
# ------------------------------------------------------------------------------
TRAIN_MODE = 'dynamic'  # [Flow] 训练模式: 'dynamic' (推荐) | 'standard'
TOTAL_EPOCHS = 200  # [Flow] 总训练 Epoch 数
PRETRAIN_EPOCHS = 100  # [Flow] 离线预训练 Epoch 数 (0 表示不预训练)
STEPS_PER_EPOCH = 10  # [Flow] 每个 Epoch 包含的 Step 数
EVAL_N_CYCLES = 1  # [Eval] 评估周期数

# [Dynamic Window] 动态时间窗口配置 (用于特征提取)
HEAD_PADDING_RATIO = 0.2  # 头部补全比例 (20% 基准)
EVO_LONG_RATIO = 0.1  # 长周期特征比例 (10%)
EVO_SHORT_RATIO = 0.05  # 短周期特征比例 (5%)

# [Reward Shaping] 奖励函数权重与窗口
REWARD_WINDOW_LONG_RATIO = 0.5  # 长期收益窗口 (战略定力)
REWARD_WINDOW_SHORT_RATIO = 0.2  # 短期收益窗口 (战术敏捷)
REWARD_WEIGHT_SEED = 1.0  # 种子基准权重
REWARD_WEIGHT_MEAN = 1.0  # 均值基准权重

# ------------------------------------------------------------------------------
# Group 6: 路径与存储 (Paths & Storage)
# ------------------------------------------------------------------------------
PATH_BASELINE = 'data/precomputed/baselines_jade.pkl'  # 基准数据路径
PATH_EXPERT = 'data/precomputed/expert_data_jade.pkl'  # 专家数据路径
SAVE_INTERVAL = 1000  # 模型保存间隔 (Epochs)
TARGET_UPDATE_INTERVAL = 10  # 目标网络更新间隔

# ==============================================================================
# PART 2: 衍生配置与逻辑处理 (Derived Configuration & Logic)
# ==============================================================================
# 基于上述用户配置自动计算得出的参数，通常无需手动修改。
# ==============================================================================

# 2.1 数据集切分 (Split Dataset)
# 默认按 1:1:1 比例切分 (Train/Val/Test)
_n_total = len(GEN_INSTANCES)
_chunk = _n_total // 3
TRAIN_INSTANCES = GEN_INSTANCES[:_chunk]
VAL_INSTANCES = GEN_INSTANCES[_chunk:2 * _chunk]
TEST_INSTANCES = GEN_INSTANCES[2 * _chunk:]

# 2.2 状态空间构建 (State Space Construction)
RL_STATE_SPEC = []
_idx_counter = 0

for feat_name in SELECTED_FEATURES:
    spec = {}
    # 处理通用特征
    if feat_name in FEATURE_REGISTRY:
        spec = FEATURE_REGISTRY[feat_name].copy()
        spec['name'] = feat_name
        spec['idx'] = _idx_counter
        RL_STATE_SPEC.append(spec)
        _idx_counter += 1
    # 处理算法参数特征 (F, CR)
    elif feat_name in [p['name'] for p in ALGO_PARAMS]:
        spec = {
            'idx': _idx_counter,
            'bins': 5,
            'min': 0.0,
            'max': 1.0,
            'name': feat_name
        }
        RL_STATE_SPEC.append(spec)
        _idx_counter += 1

CALC_STATE_DIM = len(RL_STATE_SPEC)

# 2.3 上下文感知配置 (Context Spec)
# 自动查找 NormDim 索引
norm_dim_idx = -1
for spec in RL_STATE_SPEC:
    if spec['name'] == 'NormDim':
        norm_dim_idx = spec['idx']
        break

RL_CONTEXT_SPEC = {
    'idx': norm_dim_idx,  # 动态索引
    'norm_factor': 50.0,  # 归一化因子
    'name': 'NormDim'
}

# 2.4 构建通用配置字典 (Common Config)
# 将所有散落参数打包，供 Trainer 使用
COMMON_CONFIG = {
    # --- 系统 ---
    'n_cores': N_CORES,
    'baseline_path': PATH_BASELINE,
    'expert_data_path': PATH_EXPERT,

    # --- 调试 ---
    'enable_perf_log': False,

    # --- 流程 ---
    'train_mode': TRAIN_MODE,
    'generate_data': True,
    'pretrain_epochs': PRETRAIN_EPOCHS,
    'epochs': TOTAL_EPOCHS,
    'steps_per_epoch': STEPS_PER_EPOCH,
    'save_interval': SAVE_INTERVAL,
    'target_update_interval': TARGET_UPDATE_INTERVAL,
    'seeds_per_instance': min(len(SEED_POOL), N_CORES),

    # --- 问题与数据 ---
    'prob_id': 1,  # 默认值，运行时会覆盖
    'train_problems': TRAIN_PROBLEMS,
    'target_dims': TARGET_DIMS,
    'train_instances': TRAIN_INSTANCES,
    'validation_instances': VAL_INSTANCES,
    'test_instances': TEST_INSTANCES,
    'gen_instances': GEN_INSTANCES,
    'seed_pool': SEED_POOL,

    # --- 网络与参数 ---
    'hidden_dim': HIDDEN_DIM,
    'stream_hidden_dim': STREAM_HIDDEN_DIM,
    'lr': RL_LR,
    'gamma': RL_GAMMA,
    'ucb_beta': UCB_BETA,
    'state_spec': RL_STATE_SPEC,
    'context_spec': RL_CONTEXT_SPEC,
    'use_features': SELECTED_FEATURES,

    # --- 兼容性旧参数 ---
    'state_bins': [spec['bins'] for spec in RL_STATE_SPEC],
    'dim_norm_factor': RL_CONTEXT_SPEC['norm_factor'],

    # --- EA 环境参数 ---
    'ea_name': 'JADE',
    'pop_size_factor': 10,
    'max_fes_factor': 5000,

    # --- 动态窗口参数 ---
    'head_padding_ratio': HEAD_PADDING_RATIO,
    'evo_long_ratio': EVO_LONG_RATIO,
    'evo_short_ratio': EVO_SHORT_RATIO,

    # --- 奖励函数参数 ---
    'reward_window_long_ratio': REWARD_WINDOW_LONG_RATIO,
    'reward_window_short_ratio': REWARD_WINDOW_SHORT_RATIO,
    'reward_weight_seed': REWARD_WEIGHT_SEED,
    'reward_weight_mean': REWARD_WEIGHT_MEAN
}

# 动态注入 Evaluation 参数
if TRAIN_MODE == 'dynamic':
    COMMON_CONFIG['dynamic_review_ratio'] = 0.2
    COMMON_CONFIG['warmup_epochs'] = int(TOTAL_EPOCHS * 0.1)
    COMMON_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)
elif TRAIN_MODE == 'standard':
    COMMON_CONFIG['eval_interval'] = EVAL_N_CYCLES * len(SEED_POOL)
else:
    COMMON_CONFIG['eval_interval'] = 10

# ==============================================================================
# PART 3: 算法注册表 (Algorithm Registry)
# ==============================================================================
# 定义每个算法的特异性参数 (动作空间类型、Buffer大小、特殊超参)
# ==============================================================================

ALGO_REGISTRY = {
    # --- Continuous Action Space Algorithms ---
    'SAC': {
        'type': 'continuous',
        'batch_size': 256,
        'buffer_size': 1000000,
        'lr': 1e-4,
        'special_params': {
            'alpha': 0.2,
            'tau': 0.005,
            'auto_entropy_tuning': True
        }
    },
    'DDPG': {
        'type': 'continuous',
        'batch_size': 256,
        'buffer_size': 1000000,
        'lr': 1e-4,
        'special_params': {}
    },
    'PPO': {
        'type': 'continuous',
        'batch_size': 256,
        'buffer_size': 2048,  # [Exception] On-Policy 特性
        'lr': 1e-4,
        'special_params': {
            'clip_param': 0.2,
            'ppo_epoch': 10,
            'value_coef': 0.5,
            'entropy_coef': 0.01,
            'grad_clip': 0.5
        }
    },

    # --- Discrete Action Space Algorithms ---
    'DQN': {
        'type': 'discrete',
        'batch_size': 256,
        'buffer_size': 1000000,
        'lr': 1e-4,
        'special_params': {}
    },
    'DuelingDQN': {
        'type': 'discrete',
        'batch_size': 256,
        'buffer_size': 1000000,
        'lr': 1e-4,
        'special_params': {}
    },
    'Q_Learning': {
        'type': 'discrete',
        # [Performance Tuning] 增大 Batch Size 以适配向量化 Agent
        # 对于 Ryzen 7950X，4096 能更好地触发 MKL 并行计算，提高 CPU 利用率
        'batch_size': 4096,
        'buffer_size': 1000000,
        'lr': 1e-4,
        'special_params': {
            'diffusion_decay': 0.5  # [Config] 初始扩散衰减率 (配合动态扩散逻辑)
        }
    }
}

# ==============================================================================
# PART 4: 执行序列控制 (Execution Sequence)
# ==============================================================================
# 定义需要参与对比的算法列表及顺序
ALGO_SEQUENCE = [
    # 'SAC',
    # 'PPO',
    # 'DDPG',
    # 'DQN',
    # 'DuelingDQN',
     'Q_Learning'
]


# ==============================================================================
# PART 5: 核心工具函数 (Core Utilities)
# ==============================================================================

def setup_seed(seed):
    """设置全局随机种子"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    # print(f"[System] Global seed set to: {seed}")


def setup_experiment(config):
    """
    创建实验目录并保存配置
    [Modified] 采用极简路径格式: {Algo}_{EA}_P{Prob}_S{Seed}_{Time}
    解决 Windows 路径过长导致的 WinError 433
    """
    # 1. 算法简称映射
    algo_map = {
        'Q_Learning': 'QL',
        'DuelingDQN': 'DDQN',
        'DQN': 'DQN',
        'PPO': 'PPO',
        'SAC': 'SAC',
        'DDPG': 'DDPG'
    }

    # 获取各个组件名称
    algo_full = config['agent_name']
    algo_short = algo_map.get(algo_full, algo_full[:4]) # 如果未定义映射，截取前4位

    ea_name = config.get('ea_name', 'EA')
    prob_id = config.get('prob_id', 'All')
    seed_val = config.get('base_seed', 0)

    # 2. 生成时间戳 (MMDD_HHMM)
    timestamp = datetime.datetime.now().strftime("%m%d_%H%M")

    # 3. 构造目录名: QL_JADE_P1_S1_0214_2245
    dir_name = f"{algo_short}_{ea_name}_P{prob_id}_S{seed_val}_{timestamp}"

    # 4. 创建目录 (使用 experiments_single 作为根)
    # [Critical Fix] 使用绝对路径以进一步规避路径解析问题
    current_file_dir = os.path.dirname(os.path.abspath(__file__))
    exp_root = os.path.join(current_file_dir, 'experiments_single')
    exp_dir = os.path.join(exp_root, dir_name)

    os.makedirs(exp_dir, exist_ok=True)

    # 5. 保存配置 (简化的文件名)
    config_path = os.path.join(exp_dir, "config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)

    return exp_dir


def _run_single_execution(config):
    """
    执行单次完整训练 (Single Seed)
    """
    current_seed = config['base_seed']
    setup_seed(current_seed)

    print("-" * 60)
    print(f"[Run] Agent: {config['agent_name']} | Seed: {current_seed}")
    print(f"[Run] Problem: {config.get('prob_id', 'All')} (Single Mode)")
    print(f"[Run] Type: {ALGO_REGISTRY[config['agent_name']]['type']} | Action Dim: {config['action_dim']}")
    print("-" * 60)

    # 1. 实验目录初始化
    experiment_dir = setup_experiment(config)

    # 2. 自动数据生成 (包含一致性检查)
    # [CRITICAL FIX] 基准倍增策略
    # 为了解决"钳位效应"，我们强制生成 2倍 长度的基准数据。
    # 这样当 Agent 在 1.0x 预算内运行时，可以查找到未来更优的 FES 成绩。
    if config.get('generate_data', True):
        # 创建生成专用的配置副本
        gen_config = copy.deepcopy(config)

        # 获取原始因子 (默认为 5000)
        original_factor = gen_config.get('max_fes_factor', 5000)
        gen_config['max_fes_factor'] = original_factor

        print(f"[System] Generating Extended Baseline Data...")

        # 使用加长版配置生成数据
        gen_baselines.generate_dataset(gen_config, experiment_dir=experiment_dir, check_consistency=True)

    # 3. 监控器
    monitor = Monitor(config, experiment_dir=experiment_dir)
    monitor.report_baseline()

    # 4. 初始化 Agent
    # 提取特有参数
    spec_params = ALGO_REGISTRY[config['agent_name']].get('special_params', {})

    agent = AlgorithmFactory.create_agent(
        config['agent_name'],
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config['lr'],
        gamma=config['gamma'],
        batch_size=config['batch_size'],
        buffer_size=config['buffer_size'],
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config['stream_hidden_dim'],
        # [Modified] 传递新定义的 Spec
        state_spec=config['state_spec'],
        context_spec=config['context_spec'],
        # 保持旧参数以防万一
        state_bins=config['state_bins'],
        algo_params=ALGO_PARAMS,
        dim_norm_factor=config['dim_norm_factor'],
        device='cuda' if torch.cuda.is_available() else 'cpu',
        target_dims=config['target_dims'],
        **spec_params  # 动态解包特有参数 (如 PPO clip_param, SAC alpha)
    )

    # 5. 阶段 1: 离线预训练
    # 此时主进程 MKL/Torch 处于默认全核模式，计算速度最快。
    pretrain_epochs = config.get('pretrain_epochs', 0)
    if pretrain_epochs > 0:
        print(f"[Run] Starting Offline Pre-training ({pretrain_epochs} epochs)...")
        offline_trainer = OfflineTrainer(config, agent, monitor, experiment_dir=experiment_dir)
        offline_trainer.train()

    # [Architecture - Step 2] 进程环境毒化 (Environment Poisoning)
    # 在 Online 阶段启动前，设置环境变量。
    # 关键点：这对当前运行的主进程（已经初始化了 MKL/NumPy）无效！主进程依然保持快速度。
    # 但是，接下来由 joblib/multiprocessing 孵化出的子进程会继承这个 "1"。
    # 从而实现：主进程快（学习），子进程慢且不争抢（采样）。
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"

    # 6. 阶段 2: 在线微调
    # 注意：OnlineTrainer 使用的是原始 config (1.0x budget)，这正是我们想要的
    evaluator = Evaluator(config, monitor)
    online_trainer = OnlineTrainer(config, agent, evaluator, monitor, experiment_dir=experiment_dir)
    online_trainer.train()

    print(f"[Run] Finished: {config['agent_name']} (Prob {config.get('prob_id', 'Unknown')} Seed {current_seed})\n")


def run_pipeline():
    """
    主训练管道：三层循环
    Outer Loop: Algorithms
    Middle Loop: Problems (1-20) [New]
    Inner Loop: Seeds
    """
    total_algos = len(ALGO_SEQUENCE)
    seeds = BASE_SEEDS

    # [Modified] Explicitly defining the problem list to iterate
    # This uses the global configuration list
    problem_list = TRAIN_PROBLEMS

    print("=" * 80)
    print(f"MAIN BENCHMARK PIPELINE STARTED (SINGLE PROBLEM MODE)")
    print(f"Algorithms: {ALGO_SEQUENCE}")
    print(f"Problems: {problem_list}")
    print(f"Seeds: {seeds}")
    print(f"Output Root: experiments_single/")
    print("=" * 80 + "\n")

    for i, algo_name in enumerate(ALGO_SEQUENCE):
        print(">" * 80)
        print(f">>> STARTING ALGORITHM {i + 1}/{total_algos}: {algo_name}")
        print(">" * 80 + "\n")

        # 1. 加载并合并配置
        algo_spec = ALGO_REGISTRY.get(algo_name)
        if not algo_spec:
            print(f"[Error] Algorithm {algo_name} not found in Registry! Skipping.")
            continue

        # 构造当前算法的基础配置
        current_config = copy.deepcopy(COMMON_CONFIG)
        current_config['agent_name'] = algo_name

        # 注入 Registry 中的差异化参数
        current_config['batch_size'] = algo_spec['batch_size']
        current_config['buffer_size'] = algo_spec['buffer_size']
        current_config['lr'] = algo_spec.get('lr', 3e-4)
        current_config['algo_params'] = ALGO_PARAMS
        current_config['state_dim'] = CALC_STATE_DIM

        # 2. 动态计算 Action Dim
        if algo_spec['type'] == 'continuous':
            current_config['action_dim'] = len(ALGO_PARAMS)  # 2
        else:
            # Discrete: product of options (9*8=72)
            dim = 1
            for p in ALGO_PARAMS:
                dim *= len(p['options'])
            current_config['action_dim'] = dim

        # [New] Loop 2: Iterate over each problem independently
        for prob_id in problem_list:
            print("*" * 60)
            print(f"*** Processing Problem ID: {prob_id} ***")
            print("*" * 60)

            # 3. 遍历种子执行
            for seed in seeds:
                # 注入当前种子和问题配置
                seed_config = copy.deepcopy(current_config)
                seed_config['base_seed'] = seed

                # [Critical Modification] Override problem configuration
                seed_config['prob_id'] = prob_id
                seed_config['train_problems'] = [prob_id]  # Force single problem in list

                try:
                    _run_single_execution(seed_config)
                except Exception as e:
                    print(f"[Error] Failed execution for {algo_name} (Prob {prob_id}, Seed {seed}): {e}")
                    import traceback
                    traceback.print_exc()
                    print("[Main] Continuing to next seed/algorithm...")

        print(f"\n<<< COMPLETED ALGORITHM: {algo_name}\n")
        time.sleep(2)  # 缓冲时间

    print("=" * 80)
    print("ALL BENCHMARKS COMPLETED.")
    print("=" * 80)


if __name__ == "__main__":
    # [Architecture Log] 打印并行架构状态日志
    print("=" * 80)
    print(f"[System] Parallel Architecture Check")
    print(f"   > Detected CPUs: {multiprocessing.cpu_count()}")
    print(f"   > Configured N_CORES: {N_CORES}")
    print("-" * 40)
    # 此时应该显示 Not Set，因为我们移除了顶部的限制
    print(f"   > Env: OMP_NUM_THREADS = {os.environ.get('OMP_NUM_THREADS', 'Not Set (Correct)')}")
    print(f"   > Torch: Initial Num Threads = {torch.get_num_threads()} (Should be > 1 for Main Process)")
    print("-" * 40)

    if torch.get_num_threads() == 1:
        print("[Warning] Torch threads are 1! Main process might be slow.")
    else:
        print("[OK] Main Process is Unclamped (Full Speed).")
    print("=" * 80)

    # 启动主流程
    run_pipeline()
import os
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import itertools


# ==============================================================================
# 模块: Reporter (统计与绘图 - 智能刻度版)
# ==============================================================================

# ------------------------------------------------------------------------------
# Part 1: 训练过程分析 (Training Process - Comparison & Selection)
# ------------------------------------------------------------------------------

def get_best_seed_by_validation(group_df):
    """
    [New] 基于验证集表现选择最佳 Seed。
    """
    if group_df.empty or 'Val_Fitness' not in group_df.columns:
        return None, float('inf'), -1

    if 'Seed' in group_df.columns:
        group_df['Seed'] = group_df['Seed'].astype(int)

    # 1. 找到每个 Seed 的历史最优
    best_indices = group_df.groupby('Seed')['Val_Fitness'].idxmin()
    best_rows = group_df.loc[best_indices]

    # 2. 在这些 Seed 的最优解中，选一个全局最优
    global_best_idx = best_rows['Val_Fitness'].idxmin()
    global_best_row = group_df.loc[global_best_idx]

    best_seed = int(global_best_row['Seed'])
    best_fit = float(global_best_row['Val_Fitness'])
    best_epoch = int(global_best_row['Epoch'])

    return best_seed, best_fit, best_epoch


def plot_training_comparison(full_df, save_dir):
    """
    [New] 绘制训练过程的聚合对比图 (9 张图)。
    [Fix] 增加数据范围检测，智能切换 symlog/log，防止负数导致空图。
    """
    if full_df.empty:
        print("[Reporter] No training data available for comparison plotting.")
        return

    print(f"\n[Plotting] Generating Training Comparison Plots (9 Metrics)...")

    comp_dir = os.path.join(save_dir, 'training_comparison')
    os.makedirs(comp_dir, exist_ok=True)

    # (Metric Column, Label, Scale Type, Filename Suffix)
    plot_configs = [
        # --- Fitness (Log/SymLog) ---
        ('Train_Fitness', 'Train Fitness', 'log', 'Fitness_Train'),
        ('Val_Fitness', 'Validation Fitness', 'log', 'Fitness_Val'),
        ('Test_Fitness', 'Test Fitness', 'log', 'Fitness_Test'),

        # --- Improvement (Linear) ---
        ('Train_Imp', 'Train Improvement (%)', 'linear', 'Imp_Train'),
        ('Val_Imp', 'Validation Improvement (%)', 'linear', 'Imp_Val'),
        ('Test_Imp', 'Test Improvement (%)', 'linear', 'Imp_Test'),

        # --- Weak Count (Linear) ---
        ('Weak_Train', 'Weak Count (Train)', 'linear', 'Weak_Train'),
        ('Weak_Val', 'Weak Count (Validation)', 'linear', 'Weak_Val'),
        ('Weak_Test', 'Weak Count (Test)', 'linear', 'Weak_Test')
    ]

    sns.set_style("whitegrid")

    algos = sorted(full_df['Algorithm'].unique())
    palette = sns.color_palette("tab10", n_colors=len(algos))

    for col, label, scale, suffix in plot_configs:
        if col not in full_df.columns:
            continue

        # 排除 NaN
        valid_data = full_df[col].dropna()
        if valid_data.empty:
            print(f"    [Skip] {label}: All data is NaN.")
            continue

        # [Audit] 打印数据范围，拒绝猜测
        data_min = valid_data.min()
        data_max = valid_data.max()
        print(f"    -> Plotting {label:<25} | Range: [{data_min:.4e}, {data_max:.4e}]")

        plt.figure(figsize=(10, 6))

        try:
            sns.lineplot(
                data=full_df,
                x='Epoch',
                y=col,
                hue='Algorithm',
                hue_order=algos,
                palette=palette,
                errorbar='sd',
                linewidth=2,
                alpha=0.8
            )
        except Exception as e:
            print(f"       [Error] Seaborn plot failed: {e}")
            plt.close()
            continue

        plt.title(f'Training Comparison - {label}')
        plt.xlabel('Epochs')
        plt.ylabel(label)

        # [Fix] 智能刻度逻辑
        if scale == 'log':
            if data_min <= 0:
                # 如果有负数或零，必须用 symlog (Symmetrical Log)
                # linthresh 决定了 0 附近的线性区域大小，防止趋近 0 时爆炸
                plt.yscale('symlog', linthresh=1e-5)
            else:
                # 只有全正数才用 log
                plt.yscale('log')

        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()

        out_path = os.path.join(comp_dir, f'Compare_{suffix}.png')
        plt.savefig(out_path, dpi=300)
        plt.close()
        # print(f"       Saved: {out_path}")


# ------------------------------------------------------------------------------
# Part 2: 推理阶段分析 (Inference Phase - Convergence & Stats)
# ------------------------------------------------------------------------------

def plot_convergence_curves(df, save_dir):
    """
    绘制推理阶段的收敛曲线对比图 (Mean ± Std)。
    [Fix] 同样增加 symlog 支持和数据范围打印。
    """
    print("\n[Plotting] Generating Convergence Curves (Inference Phase)...")

    if 'History' not in df.columns:
        print("    [Error] 'History' column missing. Skipping plots.")
        return

    # 解析 History 数据
    valid_rows = []
    for idx, row in df.iterrows():
        hist_val = row['History']

        if isinstance(hist_val, str):
            try:
                hist_list = json.loads(hist_val)
            except json.JSONDecodeError:
                continue
        elif isinstance(hist_val, (list, np.ndarray)):
            hist_list = hist_val
        else:
            continue

        valid_rows.append({
            'Problem': str(row['Problem']),
            'Dimension': str(row['Dimension']),
            'SetType': row['SetType'],
            'Algorithm': row['Algorithm'],
            'History': np.array(hist_list, dtype=np.float64) if len(hist_list) > 0 else np.array([])
        })

    if not valid_rows:
        print("    [Warn] No valid history data found.")
        return

    plot_df = pd.DataFrame(valid_rows)
    groups = plot_df.groupby(['Problem', 'Dimension', 'SetType'])

    for (prob, dim, set_type), group_df in groups:
        label = f"P{prob}_D{dim}_{set_type}"
        # print(f"    -> Processing: {label}")

        plt.figure(figsize=(10, 6))
        sns.set_style("whitegrid")

        algos = group_df['Algorithm'].unique()
        colors = sns.color_palette("Set1", n_colors=len(algos))

        has_plotted_any = False
        global_min_val = float('inf')
        global_max_val = -float('inf')

        for i, algo in enumerate(algos):
            algo_data = group_df[group_df['Algorithm'] == algo]
            raw_histories = algo_data['History'].values
            valid_histories = [h for h in raw_histories if len(h) > 0]

            if len(valid_histories) == 0: continue

            min_len = min(len(h) for h in valid_histories)
            if min_len < 1: continue

            stacked_hist = np.vstack([h[:min_len] for h in valid_histories])
            mean_curve = np.mean(stacked_hist, axis=0)
            std_curve = np.std(stacked_hist, axis=0)
            x_axis = np.arange(len(mean_curve))

            # 更新全局范围统计
            curr_min = np.min(mean_curve)
            curr_max = np.max(mean_curve)
            if curr_min < global_min_val: global_min_val = curr_min
            if curr_max > global_max_val: global_max_val = curr_max

            plt.plot(x_axis, mean_curve, label=algo, color=colors[i], linewidth=2)
            plt.fill_between(x_axis, mean_curve - std_curve, mean_curve + std_curve,
                             color=colors[i], alpha=0.15)
            has_plotted_any = True

        if not has_plotted_any:
            plt.close()
            continue

        # [Audit] 打印范围
        print(f"    -> Plotting {label:<20} | Range: [{global_min_val:.4e}, {global_max_val:.4e}]")

        plt.title(f'Convergence Curve - {label}')
        plt.xlabel('Evaluations')
        plt.ylabel('Best Fitness')

        # [Fix] 智能刻度
        if global_min_val <= 0:
            plt.yscale('symlog', linthresh=1e-5)
        else:
            plt.yscale('log')

        plt.legend()
        plt.tight_layout()

        save_path = os.path.join(save_dir, f'Convergence_{label}.png')
        plt.savefig(save_path, dpi=300)
        plt.close()


def perform_statistical_test_and_plot(df, save_dir):
    """
    执行统计检验 (Inference Phase)。
    包含去重逻辑。
    """
    df['Problem'] = df['Problem'].astype(str)
    df['Dimension'] = df['Dimension'].astype(str)

    groups = df.groupby(['Problem', 'Dimension', 'SetType'])

    for (prob, dim, set_type), group_df in groups:
        label = f"P{prob}_D{dim}_{set_type}"

        if group_df.duplicated(subset=['RunID', 'Algorithm']).any():
            group_df = group_df.drop_duplicates(subset=['RunID', 'Algorithm'], keep='last')

        pivot_df = group_df.pivot(index='RunID', columns='Algorithm', values='Fitness')
        if pivot_df.isnull().values.any():
            pivot_df = pivot_df.dropna()

        if pivot_df.shape[1] < 2:
            continue

        algos = pivot_df.columns.tolist()
        data_arrays = [pivot_df[algo].values for algo in algos]

        stats_output = []
        stats_output.append(f"Statistical Analysis for {label}\n")
        stats_output.append("=" * 50 + "\n")

        if len(algos) >= 3:
            try:
                f_stat, f_p = stats.friedmanchisquare(*data_arrays)
                stats_output.append(f"Friedman Test: stat={f_stat:.4f}, p={f_p:.4e}\n\n")
            except ValueError:
                stats_output.append("Friedman Test: Failed (Insufficient data)\n")

        stats_output.append("Pairwise Wilcoxon:\n")
        pairs = list(itertools.combinations(algos, 2))
        for (a, b) in pairs:
            try:
                w_stat, w_p = stats.wilcoxon(pivot_df[a], pivot_df[b])
                stats_output.append(f"{a} vs {b}: p={w_p:.4e}\n")
            except ValueError:
                stats_output.append(f"{a} vs {b}: N/A\n")

        with open(os.path.join(save_dir, f'stats_{label}.txt'), 'w') as f:
            f.writelines(stats_output)

    # 绘制全局排名箱型图
    df['Rank'] = df.groupby(['Problem', 'Dimension', 'Instance', 'SetType', 'RunID'])['Fitness'].rank(ascending=True,
                                                                                                      method='min')

    for set_type in ['Train', 'Validation', 'Test']:
        subset_df = df[df['SetType'] == set_type]
        if subset_df.empty: continue

        plt.figure(figsize=(12, 8))
        sns.set_style("whitegrid")

        mean_ranks = subset_df.groupby('Algorithm')['Rank'].mean().sort_values()
        sorted_algos = mean_ranks.index.tolist()

        sns.boxplot(x='Algorithm', y='Rank', hue='Algorithm', data=subset_df,
                    order=sorted_algos, palette="viridis", legend=False,
                    showmeans=True,
                    meanprops={"marker": "o", "markerfacecolor": "white", "markeredgecolor": "black"})

        plt.title(f'Global Algorithm Ranking ({set_type})', fontsize=14)
        plt.ylabel('Rank')
        plt.xlabel('Algorithm')
        plt.xticks(rotation=45)
        plt.tight_layout()

        plot_path = os.path.join(save_dir, f'Global_Rank_Boxplot_{set_type}.png')
        plt.savefig(plot_path, dpi=300)
        plt.close()


def generate_win_loss_report(df):
    """
    胜负统计 (Inference Phase)。
    包含去重逻辑。
    """
    print("\n" + "=" * 80)
    print("CALCULATING WIN/LOSS/TIE SUMMARY")
    print("=" * 80)

    wl_stats = {}
    all_sets = df['SetType'].unique()
    all_algos = df['Algorithm'].unique()

    for st in all_sets:
        wl_stats[st] = {}
        for algo in all_algos:
            wl_stats[st][algo] = {'W': 0, 'L': 0, 'T': 0}

    groups = df.groupby(['Problem', 'Dimension', 'SetType'])

    for (prob, dim, set_type), group_df in groups:
        if set_type not in wl_stats: continue

        if group_df.duplicated(subset=['RunID', 'Algorithm']).any():
            group_df = group_df.drop_duplicates(subset=['RunID', 'Algorithm'], keep='last')

        pivot_df = group_df.pivot(index='RunID', columns='Algorithm', values='Fitness')
        pivot_df = pivot_df.dropna()
        algos = pivot_df.columns.tolist()

        if len(algos) < 2: continue

        means = pivot_df.mean()
        pairs = list(itertools.combinations(algos, 2))

        for (a, b) in pairs:
            try:
                _, p_val = stats.wilcoxon(pivot_df[a], pivot_df[b])
                if p_val >= 0.05:
                    wl_stats[set_type][a]['T'] += 1
                    wl_stats[set_type][b]['T'] += 1
                else:
                    if means[a] < means[b]:
                        wl_stats[set_type][a]['W'] += 1
                        wl_stats[set_type][b]['L'] += 1
                    else:
                        wl_stats[set_type][b]['W'] += 1
                        wl_stats[set_type][a]['L'] += 1
            except ValueError:
                wl_stats[set_type][a]['T'] += 1
                wl_stats[set_type][b]['T'] += 1

    ordered_sets = [s for s in ['Train', 'Validation', 'Test'] if s in wl_stats]
    for set_type in ordered_sets:
        print(f"\n>>> SUMMARY FOR: {set_type.upper()} SET")
        print(f"{'Algorithm':<20} | {'Wins':<5} | {'Losses':<6} | {'Ties':<5} | {'Win Rate (%)':<12}")
        print("-" * 60)
        sorted_stats = sorted(wl_stats[set_type].items(), key=lambda x: x[1]['W'], reverse=True)
        for algo, s in sorted_stats:
            total = s['W'] + s['L'] + s['T']
            rate = (s['W'] / total * 100) if total > 0 else 0.0
            print(f"{algo:<20} | {s['W']:<5} | {s['L']:<6} | {s['T']:<5} | {rate:<12.1f}")
import os
import glob
import json
import torch
import pickle
import pandas as pd
import numpy as np
import re


# ==============================================================================
# 模块: Loader (IO 与 资源加载) - 聚合修复版
# ==============================================================================

def get_experiment_params(config):
    """
    从 config 中提取关键参数
    [Preserved] 保留验证集提取逻辑
    """
    problems = config.get('test_problems')
    if not problems:
        problems = config.get('train_problems', [])

    dims = config.get('test_dims')
    if not dims:
        dims = config.get('target_dims')
    if not dims:
        dims = config.get('train_dims', [])

    train_insts = config.get('train_instances', [])
    val_insts = config.get('validation_instances', [])
    test_insts = config.get('test_instances', [])

    # 排序去重
    if train_insts: train_insts = sorted(list(set(train_insts)))
    if val_insts: val_insts = sorted(list(set(val_insts)))
    if test_insts: test_insts = sorted(list(set(test_insts)))

    seeds = config.get('seed_pool')
    if not seeds:
        seeds = config.get('seeds', [])

    return problems, dims, train_insts, val_insts, test_insts, seeds


def inspect_configurations(target_dir):
    """检查配置"""
    print("\n" + "=" * 130)
    print(f"{'EXPERIMENT CONFIGURATION INSPECTION REPORT':^130}")
    print("=" * 130)
    header = f"{'Experiment Name':<40} | {'Probs':<8} | {'Dims':<8} | {'Train':<8} | {'Val':<8} | {'Test':<8} | {'Seeds':<6}"
    print(header)
    print("-" * 130)

    if not os.path.exists(target_dir):
        print(f"[Error] Target directory not found: {target_dir}")
        return 0

    subfolders = [f for f in os.listdir(target_dir) if os.path.isdir(os.path.join(target_dir, f))]
    subfolders = [f for f in subfolders if f != 'analysis_results']

    valid_count = 0

    for folder in subfolders:
        exp_path = os.path.join(target_dir, folder)

        # 查找 config
        config_path = os.path.join(exp_path, 'plots', os.path.basename(exp_path) + '_config.json')
        if not os.path.exists(config_path):
            candidates = glob.glob(os.path.join(exp_path, '**', '*_config.json'), recursive=True)
            if candidates:
                config_path = candidates[0]
            else:
                print(f"{folder:<40} | {'[Missing Config]':<80}")
                continue

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)

            probs, dims, tr_insts, val_insts, te_insts, seeds = get_experiment_params(config)

            tr_str = str(len(tr_insts)) if tr_insts else "0"
            val_str = str(len(val_insts)) if val_insts else "0"
            te_str = str(len(te_insts)) if te_insts else "0"
            seed_str = str(len(seeds)) if seeds else "0"

            print(
                f"{folder:<40} | {str(probs):<8} | {str(dims):<8} | {tr_str:<8} | {val_str:<8} | {te_str:<8} | {seed_str:<6}")
            valid_count += 1

        except Exception as e:
            print(f"{folder:<40} | {'[Error Reading Config]':<80}")

    print("-" * 130)
    print(f"Total Valid Experiments Found: {valid_count}")
    print("=" * 130 + "\n")
    return valid_count


def load_config_and_state(exp_path, device='cpu'):
    """加载配置和模型状态"""
    # 1. 查找 Config
    config_path = os.path.join(exp_path, 'plots', os.path.basename(exp_path) + '_config.json')
    if not os.path.exists(config_path):
        candidates = glob.glob(os.path.join(exp_path, '**', '*_config.json'), recursive=True)
        if candidates:
            config_path = candidates[0]
        else:
            return None, None

    with open(config_path, 'r') as f:
        config = json.load(f)

    # 2. 查找 Model
    model_candidates = glob.glob(os.path.join(exp_path, 'models', '*_best.pth'))
    if not model_candidates:
        model_candidates = glob.glob(os.path.join(exp_path, 'models', '*_latest.pth'))

    if not model_candidates:
        print(f"[Warn] No model found in {os.path.join(exp_path, 'models')}")
        return config, None

    model_path = model_candidates[0]
    agent_state_data = None

    try:
        data = torch.load(model_path, map_location=device, weights_only=False)
        if isinstance(data, dict) and 'model_state_dict' in data:
            agent_state_data = data['model_state_dict']
        else:
            agent_state_data = data
    except Exception:
        with open(model_path, 'rb') as f:
            data = pickle.load(f)
        if isinstance(data, dict) and 'model_state_dict' in data:
            agent_state_data = data['model_state_dict']
        else:
            agent_state_data = data

    return config, agent_state_data


def load_baseline_dataframes(data_root):
    """
    加载基准数据
    """
    if not os.path.exists(data_root):
        raise FileNotFoundError(f"Baseline data directory not found: {data_root}")

    pattern = os.path.join(data_root, 'baselines_*.pkl')
    baseline_files = glob.glob(pattern)

    if not baseline_files:
        print(f"[Info] No baseline files found in {data_root}")
        return pd.DataFrame()

    all_rows = []
    print(f"[Loader] Found {len(baseline_files)} baseline file(s). Loading...")

    for b_file in baseline_files:
        filename = os.path.basename(b_file)
        ea_name_raw = filename.replace('baselines_', '').replace('.pkl', '')
        algo_name = f"Baseline ({ea_name_raw.upper()})"

        print(f"    -> Reading: {filename} ...")
        with open(b_file, 'rb') as f:
            data_dict = pickle.load(f)

        if not data_dict:
            continue

        count = 0
        for (pid, dim, inst, seed), history in data_dict.items():
            if not isinstance(history, list) or len(history) == 0:
                continue

            raw_last = history[-1]
            pure_fitness_history = []
            final_fitness = float('inf')

            is_nested_format = isinstance(raw_last, (list, tuple, np.ndarray)) and len(raw_last) == 2

            if is_nested_format:
                final_fitness = raw_last[1]
                pure_fitness_history = [row[1] for row in history]
            else:
                final_fitness = raw_last
                pure_fitness_history = history

            hist_str = json.dumps(pure_fitness_history)
            unique_run_id = f"{inst}_{seed}"

            for set_type in ['Train', 'Validation', 'Test']:
                all_rows.append({
                    'Problem': pid,
                    'Dimension': dim,
                    'Instance': inst,
                    'SetType': set_type,
                    'RunID': unique_run_id,
                    'Algorithm': algo_name,
                    'Fitness': final_fitness,
                    'History': hist_str
                })
            count += 1
        print(f"    -> Loaded {algo_name}: {count} runs")

    return pd.DataFrame(all_rows)


# ==============================================================================
# [Modified] 实验分组逻辑：忽略时间戳
# ==============================================================================

def group_experiment_folders(target_dir):
    """
    [Modified] 扫描目标目录，忽略时间戳，按 'Mode_Tag_seedX' 的规则聚合文件夹。
    """
    if not os.path.exists(target_dir):
        print(f"[Loader] Target directory not found: {target_dir}")
        return {}

    subfolders = [f for f in os.listdir(target_dir) if os.path.isdir(os.path.join(target_dir, f))]
    subfolders = [f for f in subfolders if f != 'analysis_results']

    groups = {}

    # 正则逻辑更新：
    # 格式：YYYYMMDD_HHMMSS_Mode_Tag_seedX
    # Group 1 (.*): Mode_Tag (中间部分)
    # Group 2 (\d+): Seed (尾部)
    full_pattern = re.compile(r'^\d{8}_\d{6}_(.*)_seed(\d+)$')

    # 兼容旧格式 (无时间戳): Mode_Tag_seedX
    legacy_pattern = re.compile(r'^(.*)_seed(\d+)$')

    for folder in subfolders:
        seed_val = 'unknown'
        base_name = folder  # Default

        # 尝试匹配完整格式 (带时间戳)
        match_full = full_pattern.match(folder)
        if match_full:
            base_name = match_full.group(1)
            seed_val = int(match_full.group(2))
        else:
            # 尝试匹配旧格式
            match_legacy = legacy_pattern.match(folder)
            if match_legacy:
                base_name = match_legacy.group(1)
                seed_val = int(match_legacy.group(2))

        if base_name not in groups:
            groups[base_name] = []

        groups[base_name].append({
            'path': os.path.join(target_dir, folder),
            'seed': seed_val,
            'folder_name': folder
        })

    # 排序
    for key in groups:
        groups[key].sort(key=lambda x: x['seed'] if isinstance(x['seed'], int) else 0)

    print(f"[Loader] Identified {len(groups)} unique experiment groups (aggregated by config).")
    return groups


def load_training_logs(folder_list):
    """
    [Preserved] 读取一组实验文件夹下的日志，合并为一个 DataFrame。
    """
    dfs = []

    # 定义列名映射
    col_mapping = {
        'TrainFit': 'Train_Fitness',
        'ValFit': 'Val_Fitness',
        'TestFit': 'Test_Fitness',
        'TrainImp': 'Train_Imp',
        'ValImp': 'Val_Imp',
        'TestImp': 'Test_Imp',
        # [New] 支持 Weak Count 映射
        'WeakTrain': 'Weak_Train',
        'WeakVal': 'Weak_Val',
        'WeakTest': 'Weak_Test'
    }

    for item in folder_list:
        path = item['path']
        seed = item['seed']

        log_dir = os.path.join(path, 'logs')
        pattern = os.path.join(log_dir, '*_eval_summary.csv')
        candidates = glob.glob(pattern)

        if not candidates:
            # Fallback
            fallback_path = os.path.join(path, 'train_log.csv')
            if os.path.exists(fallback_path):
                candidates = [fallback_path]
            else:
                # Silent skip for brevity, or warn if strictly needed
                continue

        log_path = candidates[0]

        try:
            df = pd.read_csv(log_path)
            df.rename(columns=col_mapping, inplace=True)
            df['Seed'] = seed
            dfs.append(df)
        except Exception as e:
            print(f"    [Error] Failed to read log in {os.path.basename(path)}: {e}")

    if not dfs:
        return pd.DataFrame()

    combined_df = pd.concat(dfs, ignore_index=True)
    return combined_df
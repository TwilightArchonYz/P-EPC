import os
import time
import json
import torch
import pandas as pd
import numpy as np
import re
from evorl.factory import AlgorithmFactory


# ==============================================================================
# 模块: Runner (执行评估循环 - 筛选版)
# ==============================================================================

def run_single_eval(pid, dim, inst, seed, agent_name, agent_state_data, config, device='cpu'):
    """
    运行单次评估任务。
    """
    # 1. 准备配置参数
    state_dim = 8  # SHADE/L-SHADE state vector length
    action_dim = config.get('action_dim')

    if action_dim is None:
        raise ValueError(f"[Runner] Config missing 'action_dim' for {agent_name}")

    # 清洗参数
    agent_kwargs = config.copy()
    conflict_keys = ['agent_name', 'state_dim', 'action_dim', 'algo_params']
    for key in conflict_keys:
        if key in agent_kwargs:
            agent_kwargs.pop(key)

    # 2. 实例化 Agent
    algo_params_list = config.get('algo_params')

    agent = AlgorithmFactory.create_agent(
        agent_name=agent_name,
        state_dim=state_dim,
        action_dim=action_dim,
        algo_params=algo_params_list,
        **agent_kwargs
    )

    # 3. 加载模型权重
    if agent_state_data is not None:
        if hasattr(agent, 'q_table'):
            if isinstance(agent_state_data, dict) and 'q_table' in agent_state_data:
                if agent.q_table.shape != agent_state_data['q_table'].shape:
                    raise ValueError(
                        f"[Runner] Q-Table shape mismatch: Agent {agent.q_table.shape} vs Data {agent_state_data['q_table'].shape}")

                agent.q_table[:] = agent_state_data['q_table'][:]
                if hasattr(agent, 'visits') and 'visits' in agent_state_data:
                    agent.visits[:] = agent_state_data['visits'][:]
            else:
                raise ValueError("[Runner] Invalid data for Q-Learning (expected dict with 'q_table')")
        else:
            target_net = None
            if hasattr(agent, 'actor'):
                target_net = agent.actor
            elif hasattr(agent, 'eval_net'):
                target_net = agent.eval_net
            elif hasattr(agent, 'load_state_dict'):
                target_net = agent

            if target_net is None:
                raise AttributeError(f"[Runner] Agent {agent_name} has no recognized network attribute to load.")

            weights_to_load = agent_state_data
            if isinstance(agent_state_data, dict) and 'actor' in agent_state_data:
                weights_to_load = agent_state_data['actor']

            target_net.load_state_dict(weights_to_load)

    if hasattr(agent, 'eval'):
        agent.eval()

    # 4. 实例化 Solver
    ea_name = config.get('ea_name', 'UnknownEA')
    max_nfes = config.get('max_fes_factor', 10000) * dim
    pop_size = config.get('pop_size_factor', 18) * dim

    from evorl.problems import ScalableProblem
    import evorl.problems.params_def as params_def

    param_dict, pf1, pf2 = params_def.generate_instance_config(pid, dim, inst)
    problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)

    solver = AlgorithmFactory.create_solver(
        problem=problem,
        ea_name=ea_name,
        pop_size=pop_size,
        max_nfes=max_nfes,
        seed=seed,
        agent=agent,
        mode='test',
        baseline_curve=None
    )

    # 5. 执行求解
    res = solver.solve()

    # 6. 提取结果
    history = res.get('global_best_fitness_history')
    if history is None:
        history = res.get('history', [])

    if hasattr(history, 'tolist'):
        history = history.tolist()

    # [Robustness] 同样增加对 Fitness 的标量提取保护
    best_fitness = res.get('best_fitness', float('inf'))
    if isinstance(best_fitness, (list, np.ndarray, tuple)):
        # 如果是数组，尝试取第一个元素，避免列表嵌套报错
        if len(best_fitness) > 0:
            best_fitness = best_fitness[0]

    return {
        'Fitness': best_fitness,
        'History': history
    }


def collect_data(target_dir, n_eval_episodes=30, device='cpu', target_probs=None, target_dims=None,
                 best_seeds_registry=None):
    """
    遍历实验目录，收集数据。
    [Update]
    1. 接收 best_seeds_registry 参数。
    2. 如果提供了 registry，只运行指定的最佳 Seed。
    """
    from analysis import loader

    all_results = []
    subfolders = [f for f in os.listdir(target_dir) if os.path.isdir(os.path.join(target_dir, f))]
    subfolders = [f for f in subfolders if f != 'analysis_results']

    # 正则表达式 (与 loader.py 保持一致)
    full_pattern = re.compile(r'^\d{8}_\d{6}_(.*)_seed(\d+)$')
    legacy_pattern = re.compile(r'^(.*)_seed(\d+)$')

    for folder in subfolders:
        exp_path = os.path.join(target_dir, folder)

        # ----------------------------------------------------------------------
        # [Filter Logic] 最佳模型筛选
        # ----------------------------------------------------------------------
        if best_seeds_registry is not None:
            # 解析当前文件夹信息
            match = full_pattern.match(folder)
            if not match:
                match = legacy_pattern.match(folder)

            should_run = False
            if match:
                group_name = match.group(1)
                seed_val = int(match.group(2))

                # 检查该组是否在注册表中
                if group_name in best_seeds_registry:
                    target_seed = best_seeds_registry[group_name]
                    if seed_val == target_seed:
                        print(f"\n[Processing] {folder} (MATCHED Best Model)", flush=True)
                        should_run = True
                    else:
                        # 是同一组但不是最佳 Seed -> 跳过
                        # print(f"[Skip] {folder} (Seed {seed_val} != Best {target_seed})")
                        continue
                else:
                    # 组名不在注册表中 (可能是旧数据或异常) -> 跳过
                    print(f"[Skip] {folder} (Group not in registry)")
                    continue
            else:
                print(f"[Skip] {folder} (Name parsing failed)")
                continue

            if not should_run:
                continue
        else:
            # 如果没有注册表，默认处理所有 (兼容旧模式)
            print(f"\n[Processing] {folder}", flush=True)
        # ----------------------------------------------------------------------

        # 加载配置
        config, agent_state = loader.load_config_and_state(exp_path, device)
        if config is None:
            print("  -> Skipping (Config missing)", flush=True)
            continue

        # 解析参数
        cfg_probs, cfg_dims, tr_insts, val_insts, te_insts, cfg_seeds = loader.get_experiment_params(config)
        agent_name = config.get('agent_name', 'UnknownAgent')

        # 过滤目标
        probs = [p for p in cfg_probs if p in target_probs] if target_probs else cfg_probs
        dims = [d for d in cfg_dims if d in target_dims] if target_dims else cfg_dims

        print(f"  -> Target Probs:{probs} Dims:{dims}", flush=True)

        if not probs or not dims:
            continue

        # 确定 Seeds
        # [Critical] 推理阶段使用全新的独立种子 (通常是 0-29)，而不是训练用的种子
        # 这确保了公平评估
        eval_seeds = list(range(n_eval_episodes))

        # 数据集
        datasets = {
            'Train': tr_insts,
            'Validation': val_insts,
            'Test': te_insts
        }

        for set_type, instances in datasets.items():
            if not instances:
                continue

            print(f"    -> Evaluating {set_type:<10} Set ({len(instances)} insts)...", flush=True)

            count_success = 0
            for pid in probs:
                for dim in dims:
                    for inst in instances:
                        for seed in eval_seeds:
                            # 运行评估
                            res_dict = run_single_eval(pid, dim, inst, seed, agent_name, agent_state, config, device)

                            unique_run_id = f"{inst}_{seed}"
                            all_results.append({
                                'Problem': pid,
                                'Dimension': dim,
                                'Instance': inst,
                                'SetType': set_type,
                                'RunID': unique_run_id,
                                'Algorithm': agent_name,
                                'Fitness': res_dict['Fitness'],
                                'History': json.dumps(res_dict['History'])
                            })
                            count_success += 1
            print(f"       > Completed {count_success} runs.", flush=True)

    return pd.DataFrame(all_results)
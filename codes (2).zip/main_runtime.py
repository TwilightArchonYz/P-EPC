import os
import sys
import time
import json
import glob
import math
import torch
import numpy as np
import pandas as pd
import traceback

# ==============================================================================
# 0. 强制环境钳制：绝对单核模式
# ==============================================================================
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
torch.set_num_threads(1)

from evorl.factory import AlgorithmFactory
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def

# 【请根据你实际的基准算法类名修改这里的导入】
from evorl.algorithms.ea.ipso import SolverIPSO
from evorl.algorithms.ea.jade import SolverJADE

try:
    from evorl.algorithms.ea.ljade import SolverLJADE
except ImportError:
    SolverLJADE = SolverJADE  # 降级占位

# ==============================================================================
# 1. 全局配置
# ==============================================================================
OUTPUT_DIR = 'experiments/benchmarks/analysis_runtime'
INPUT_ROOT = 'experiments_single'

PROBLEMS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
DIMS = [30, 40, 50]
INSTANCES = [1]
SEEDS = [1, 2, 3]

MAX_FES_FACTOR = 5000
UPDATE_INTERVAL_N = 10

TARGET_AGENTS = ['Q_Learning', 'SAC']
TARGET_EAS = ['PSO', 'JADE', 'LJADE']

BASE_EA_MAP = {
    'PSO': SolverIPSO,
    'JADE': SolverJADE,
    'LJADE': SolverLJADE
}


# ==============================================================================
# 2. 核心辅助函数
# ==============================================================================
def get_pop_size(ea_name, dim):
    return 18 * dim if ea_name == 'LJADE' else 10 * dim


def get_dynamic_agent_config(agent_name, ea_name, dim):
    """动态生成完美匹配的维度配置 (仅用于 Phase 3 的冷启动在线训练)"""
    if ea_name == 'PSO':
        options_list = [0.1, 0.3, 0.4, 0.5, 0.6, 0.7, 0.9]
        algo_params = [{'name': 'w', 'options': options_list}, {'name': 'c1', 'options': options_list},
                       {'name': 'c2', 'options': options_list}]
        selected_features = ['Progress', 'Diversity', 'Stagnation', 'FitDist', 'EvoRate', 'NormDim', 'w', 'c1', 'c2']
    else:
        options_list = [round(x * 0.02, 2) for x in range(1, 51)]
        algo_params = [{'name': 'F', 'options': options_list}, {'name': 'CR', 'options': options_list}]
        selected_features = ['Progress', 'Diversity', 'Stagnation', 'FitDist', 'EvoRate', 'NormDim', 'F', 'CR']

    state_dim = len(selected_features)
    state_bins = [5] * state_dim
    action_dim = len(algo_params) if agent_name in ['SAC', 'PPO', 'DDPG'] else np.prod(
        [len(p['options']) for p in algo_params])
    norm_dim_idx = selected_features.index('NormDim')

    return {
        'state_dim': state_dim, 'action_dim': action_dim, 'lr': 3e-4, 'gamma': 0.99,
        'batch_size': 256, 'buffer_size': 1000000, 'hidden_dim': 256, 'stream_hidden_dim': 64,
        'state_bins': state_bins, 'algo_params': algo_params,
        'context_spec': {'idx': norm_dim_idx, 'norm_factor': 50.0, 'name': 'NormDim'},
        'dim_norm_factor': 50.0, 'target_dims': [dim],
        'special_params': {'diffusion_decay': 0.5} if agent_name == 'Q_Learning' else {'alpha': 0.2, 'tau': 0.005,
                                                                                       'auto_entropy_tuning': True}
    }


def find_pretrained_folder(agent_name, ea_name, prob_id):
    """寻找预训练模型文件夹"""
    if not os.path.exists(INPUT_ROOT): return None
    candidate_folders = [d for d in os.listdir(INPUT_ROOT) if os.path.isdir(os.path.join(INPUT_ROOT, d))]
    for folder_name in candidate_folders:
        config_path = os.path.join(INPUT_ROOT, folder_name, 'config.json')
        if not os.path.exists(config_path): continue
        try:
            with open(config_path, 'r') as f:
                cfg = json.load(f)
            train_probs = cfg.get('train_problems', [])
            pid = train_probs[0] if train_probs else cfg.get('prob_id')
            if cfg.get('agent_name') == agent_name and cfg.get('ea_name') == ea_name and pid == prob_id:
                return os.path.join(INPUT_ROOT, folder_name)
        except Exception:
            pass
    return None


def load_specialist_agent(folder_path, device):
    """载入预训练智能体"""
    config_path = os.path.join(folder_path, 'config.json')
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"No config file found at {config_path}")

    best_models = glob.glob(os.path.join(folder_path, '**', '*_best.pth'), recursive=True)
    pretrained_models = glob.glob(os.path.join(folder_path, '**', '*_pretrained.pth'), recursive=True)

    if best_models:
        model_path = best_models[0]
    elif pretrained_models:
        model_path = pretrained_models[0]
    else:
        raise FileNotFoundError(f"No checkpoint found in {folder_path}")

    with open(config_path, 'r') as f:
        config = json.load(f)

    train_probs = config.get('train_problems', [])
    if len(train_probs) > 1:
        raise ValueError(f"Detected Generalist Model. Skipping.")
    if len(train_probs) == 0:
        if 'prob_id' not in config:
            raise ValueError("Invalid Config.")

    agent_name = config['agent_name']
    algo_params = config.get('algo_params', [])
    spec_params = config.get('special_params', {})
    context_spec = config.get('context_spec', None)

    agent = AlgorithmFactory.create_agent(
        agent_name,
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        lr=config.get('lr', 3e-4),
        gamma=config.get('gamma', 0.99),
        batch_size=config.get('batch_size', 256),
        buffer_size=config.get('buffer_size', 1000000),
        hidden_dim=config['hidden_dim'],
        stream_hidden_dim=config.get('stream_hidden_dim', 64),
        state_spec=config.get('state_spec'),
        context_spec=context_spec,
        state_bins=config.get('state_bins', []),
        algo_params=algo_params,
        dim_norm_factor=config.get('dim_norm_factor', 50),
        device=device,
        target_dims=config.get('target_dims', [30]),
        inference_only=True,
        **spec_params
    )

    if hasattr(agent, 'load') and agent_name == "Q_Learning":
        agent.load(model_path)
    else:
        checkpoint = torch.load(model_path, map_location=device, weights_only=False)
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            state_dict = checkpoint['model_state_dict']
        else:
            state_dict = checkpoint
        agent.load_state_dict(state_dict)

    if hasattr(agent, 'eval'):
        agent.eval()

    return agent, config


# ==============================================================================
# 3. 主流程
# ==============================================================================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    results_baseline = []
    results_inference = []
    results_online = []

    print("=" * 80)
    print("🚀 UNIFIED TIME COMPLEXITY BENCHMARK STARTING (DECOUPLED LOGGING)")
    print("=" * 80)

    # --------------------------------------------------------------------------
    # Phase 1: 测算基准 EA 时间，并独立归档入桶
    # --------------------------------------------------------------------------
    print("\n[Phase 1] Evaluating Pure Baseline EAs...")
    for ea_name in TARGET_EAS:
        SolverClass = BASE_EA_MAP[ea_name]
        for pid in PROBLEMS:
            for dim in DIMS:
                pop_size = get_pop_size(ea_name, dim)
                max_nfes = MAX_FES_FACTOR * dim
                for inst in INSTANCES:
                    for seed in SEEDS:
                        param_dict, pf1, pf2 = params_def.generate_instance_config(pid, dim, inst)
                        problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)
                        solver = SolverClass(problem=problem, pop_size=pop_size, max_nfes=max_nfes, seed=seed)

                        t0 = time.perf_counter()
                        solver.initialize()
                        while solver.fes < solver.max_nfes:
                            solver.evolve()
                        t1 = time.perf_counter()
                        t_base = t1 - t0

                        results_baseline.append({
                            'EA': ea_name, 'Problem': pid, 'Dim': dim, 'Instance': inst, 'Seed': seed,
                            'T_Run(s)': t_base
                        })

    # --------------------------------------------------------------------------
    # Phase 2 & 3: 测算预训练推理时间与冷启动伴随式学习时间
    # --------------------------------------------------------------------------
    print("\n[Phase 2 & 3] Evaluating Pre-trained Inference & Cold-Start Online...")
    for agent_name in TARGET_AGENTS:
        for ea_name in TARGET_EAS:
            print(f"\n>>> Profile Target: {ea_name} + {agent_name}")
            for pid in PROBLEMS:
                pt_folder = find_pretrained_folder(agent_name, ea_name, pid)
                pt_agent = None
                if pt_folder:
                    try:
                        pt_agent, _ = load_specialist_agent(pt_folder, 'cpu')
                    except Exception as e:
                        print(f"      [Warn] Pretrained load failed: {e}")

                for dim in DIMS:
                    pop_size = get_pop_size(ea_name, dim)
                    max_nfes = MAX_FES_FACTOR * dim

                    for inst in INSTANCES:
                        for seed in SEEDS:
                            param_dict, pf1, pf2 = params_def.generate_instance_config(pid, dim, inst)
                            problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)

                            # --- Phase 2: 测试预训练模型 (Inference Only) ---
                            if pt_agent:
                                try:
                                    pt_solver = AlgorithmFactory.create_solver(
                                        problem=problem, ea_name=ea_name, agent=pt_agent,
                                        pop_size=pop_size, max_nfes=max_nfes, seed=seed, mode='test'
                                    )
                                    t0 = time.perf_counter()
                                    pt_solver.initialize()
                                    if hasattr(pt_solver, '_rl_init_params'):
                                        pt_solver.setup_rl(**pt_solver._rl_init_params)
                                        del pt_solver._rl_init_params
                                    while pt_solver.fes < pt_solver.max_nfes:
                                        pt_solver.evolve()
                                    t_infer = time.perf_counter() - t0

                                    results_inference.append({
                                        'EA': ea_name, 'Agent': agent_name, 'Problem': pid, 'Dim': dim,
                                        'Instance': inst, 'Seed': seed,
                                        'T_Infer_Total(s)': t_infer
                                    })
                                    print(
                                        f"    [Infer] P{pid}-D{dim}-I{inst}-S{seed} | {ea_name}+{agent_name} | Time: {t_infer:.2f}s")
                                except Exception as e:
                                    print(f"      [Warn] Pretrained run failed: {e}")

                            # --- Phase 3: 测试冷启动伴随式学习 (Online Learning) ---
                            problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)

                            cfg = get_dynamic_agent_config(agent_name, ea_name, dim)
                            cs_agent = AlgorithmFactory.create_agent(
                                agent_name, state_dim=cfg['state_dim'], action_dim=cfg['action_dim'],
                                lr=cfg['lr'], gamma=cfg['gamma'], batch_size=cfg['batch_size'],
                                buffer_size=cfg['buffer_size'], hidden_dim=cfg['hidden_dim'],
                                stream_hidden_dim=cfg['stream_hidden_dim'], context_spec=cfg['context_spec'],
                                state_bins=cfg['state_bins'], algo_params=cfg['algo_params'],
                                dim_norm_factor=cfg['dim_norm_factor'], device='cpu', target_dims=[dim],
                                inference_only=False, **cfg['special_params']
                            )

                            cs_solver = AlgorithmFactory.create_solver(
                                problem=problem, ea_name=ea_name, agent=cs_agent,
                                pop_size=pop_size, max_nfes=max_nfes, seed=seed, mode='train'
                            )

                            # 先走完纯前向与交互收集数据
                            t0 = time.perf_counter()
                            res = cs_solver.solve()
                            t1 = time.perf_counter()
                            t_evolve_infer = t1 - t0

                            raw_transitions = res.get('transitions', [])
                            G_gens = len(raw_transitions)

                            if raw_transitions:
                                unzipped = list(zip(*raw_transitions))
                                s_batch, a_batch, r_batch, sn_batch = [np.array(col) for col in unzipped]
                                if hasattr(cs_agent, 'store_transitions_batch'):
                                    cs_agent.store_transitions_batch(s_batch, a_batch, r_batch, sn_batch)
                                else:
                                    for i in range(len(s_batch)):
                                        cs_agent.store_transition(s_batch[i], a_batch[i], r_batch[i], sn_batch[i])

                            # 开始测算学习时间
                            t2 = time.perf_counter()

                            # 1. 计算客观触发次数
                            num_triggers = max(1, G_gens // UPDATE_INTERVAL_N)

                            # 2. 区分算法：定义每次触发的基础迭代步数 (保障最少抽取100次进行10遍覆盖)
                            if agent_name == 'Q_Learning':
                                # 表格型：10条新数据 × 10次重演 = 100次单样本更新
                                base_steps_per_trigger = 100
                            elif agent_name in ['SAC', 'PPO', 'DDPG']:
                                # 深度型：10条新数据 × 10 (UTD比率) = 100次 Batch 梯度下降
                                base_steps_per_trigger = 100
                            else:
                                base_steps_per_trigger = 100

                            # 3. 引入 30 核并行算力折算真实物理耗时 (向上取整)
                            parallel_cores = 30
                            actual_steps_per_trigger = math.ceil(base_steps_per_trigger / parallel_cores)

                            # 4. 计算并集中执行总测试步数
                            total_learn_steps = num_triggers * actual_steps_per_trigger

                            for _ in range(total_learn_steps):
                                cs_agent.learn()

                            t3 = time.perf_counter()
                            t_learn = t3 - t2
                            t_online = t_evolve_infer + t_learn

                            results_online.append({
                                'EA': ea_name, 'Agent': agent_name, 'Problem': pid, 'Dim': dim, 'Instance': inst,
                                'Seed': seed, 'Generations': G_gens,
                                'Num_Triggers': num_triggers, 'Total_Learn_Steps': total_learn_steps,
                                'T_Evolve_Infer(s)': t_evolve_infer, 'T_Learn(s)': t_learn,
                                'T_Online_Total(s)': t_online
                            })
                            print(
                                f"    [Online] P{pid}-D{dim}-I{inst}-S{seed} | Rollout: {t_evolve_infer:.2f}s + Learn: {t_learn:.2f}s -> Total: {t_online:.2f}s")

    # ==============================================================================
    # 4. 解耦数据导出与透视汇总
    # ==============================================================================
    print("\n" + "=" * 90)
    print("📊 FINAL EXPORTING: DECOUPLED SUMMARIES")
    print("=" * 90)

    # (1) 基准 EA 汇总
    if results_baseline:
        df_base = pd.DataFrame(results_baseline)
        df_base.to_csv(os.path.join(OUTPUT_DIR, 'baseline_time_details.csv'), index=False)
        sum_base = df_base.groupby(['EA', 'Problem', 'Dim'])['T_Run(s)'].mean().reset_index()
        sum_base.to_csv(os.path.join(OUTPUT_DIR, 'baseline_time_summary.csv'), index=False)
        print("\n[Baseline EAs Time Summary (Averaged over instances & seeds)]")
        print(sum_base.to_string(index=False, float_format="%.3f"))

    # (2) 预训练推理汇总
    if results_inference:
        df_infer = pd.DataFrame(results_inference)
        df_infer.to_csv(os.path.join(OUTPUT_DIR, 'inference_time_details.csv'), index=False)
        sum_infer = df_infer.groupby(['EA', 'Agent', 'Problem', 'Dim'])['T_Infer_Total(s)'].mean().reset_index()
        sum_infer.to_csv(os.path.join(OUTPUT_DIR, 'inference_time_summary.csv'), index=False)
        print("\n[Pretrained Inference Time Summary (Averaged over instances & seeds)]")
        print(sum_infer.to_string(index=False, float_format="%.3f"))

    # (3) 冷启动伴随式汇总 (已同步更新字段)
    if results_online:
        df_online = pd.DataFrame(results_online)
        df_online.to_csv(os.path.join(OUTPUT_DIR, 'online_time_details.csv'), index=False)
        sum_online = df_online.groupby(['EA', 'Agent', 'Problem', 'Dim'])[
            ['Generations', 'Num_Triggers', 'Total_Learn_Steps', 'T_Evolve_Infer(s)', 'T_Learn(s)',
             'T_Online_Total(s)']].mean().reset_index()
        sum_online.to_csv(os.path.join(OUTPUT_DIR, 'online_time_summary.csv'), index=False)
        print("\n[Cold-Start Online Time Summary (Averaged over instances & seeds)]")
        print(sum_online.to_string(index=False, float_format="%.3f"))

    print("\n" + "=" * 90)
    print(f"✅ All decoupled files (details & summaries) saved to: {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
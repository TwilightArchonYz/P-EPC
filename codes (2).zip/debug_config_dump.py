import numpy as np
import torch
from evorl.factory import AlgorithmFactory
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def
from evorl.algorithms.hybrid.shade_rl import SHADE_RL
from evorl.algorithms.core.reward_def import calc_immediate_reward


def check_system_config():
    print("=" * 40)
    print("       SYSTEM CONFIGURATION CHECK")
    print("=" * 40)

    # 1. Check Problem Generation
    print("\n[1. Problem Consistency Check]")
    pid, dim_in, inst = 1, 10, 1
    params, pf1, pf2 = params_def.generate_instance_config(pid, dim_in, inst)
    prob = ScalableProblem(pid, dim_in, params, pf1=pf1, pf2=pf2)

    real_dim = prob.dim  # Get actual adjusted dimension (e.g. 9 for LJ)
    print(f"Problem ID {pid}, Input Dim {dim_in} -> Real Dim {real_dim}, Inst {inst}")
    print(f" -> Shift Vec [0]: {prob.shift_vec[0]:.6f}")
    print(f" -> Bounds: {prob.lb[0]} to {prob.ub[0]}")

    # 2. Check Agent Hyperparameters
    print("\n[2. Agent Configuration]")
    # Initialize with generic dims, just to check internal params
    agent = AlgorithmFactory.create_agent('DQN', state_dim=6, action_dim=72)
    print(f" -> Class: {agent.__class__.__name__}")
    print(f" -> Learning Rate: {agent.optimizer.param_groups[0]['lr']}")
    print(f" -> Gamma: {agent.gamma}")
    print(f" -> Batch Size: {agent.batch_size}")
    print(f" -> Buffer Capacity: {agent.buffer_capacity}")
    print(f" -> F Options: {agent.f_opts}")
    print(f" -> CR Options: {agent.cr_opts}")

    # 3. Check State Definition logic
    print("\n[3. State Vector Logic]")
    solver = SHADE_RL(prob, agent, pop_size=100, max_nfes=10000)
    solver.fes = 5000
    solver.stagnation_counter = 10
    solver.M_f = np.ones(100) * 0.5
    solver.M_cr = np.ones(100) * 0.5

    # [Fix] Use real_dim for initialization
    solver.X = np.random.rand(100, real_dim) * (prob.ub - prob.lb) + prob.lb

    state = solver.get_state_vector()
    print(f"Mock State Input (Progress=0.5):")
    print(f" -> Vector: {state}")
    print(f"    [0] Progress: {state[0]:.4f}")
    print(f"    [1] Diversity: {state[1]:.4f}")
    print(f"    [2] Stagnation: {state[2]:.4f}")
    print(f"    [3] Mean F: {state[3]:.4f}")
    print(f"    [4] Mean CR: {state[4]:.4f}")
    print(f"    [5] Norm Dim: {state[5]:.4f}")

    # 4. Check Reward Logic
    print("\n[4. Reward Logic]")
    r1 = calc_immediate_reward(100.0, 90.0)
    print(f" -> Reward (100->90): {r1:.6f}")
    r2 = calc_immediate_reward(100.0, 110.0)
    print(f" -> Reward (100->110): {r2:.6f}")
    print("=" * 40)


if __name__ == "__main__":
    check_system_config()
import os
import glob
import json
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# ==============================================================================
# 配置区 (Configuration)
# ==============================================================================
TARGET_DIR = 'R1'  # 自动扫描的目标文件夹名称
SMOOTH_WEIGHT = 0.8  # 平滑系数

# 定义可能的列名映射 (兼容不同版本的 Monitor)
# 优先级按列表顺序
CANDIDATES_TRAIN_LOSS = ['MeanLoss', 'loss', 'mean_loss', 'Loss']
CANDIDATES_TEST_FIT = ['TestFit', 'test_fit', 'mean_fitness', 'fitness', 'TestFitness']
CANDIDATES_EPOCH = ['Epoch', 'epoch', 'Step', 'step']


# ==============================================================================
# 工具函数
# ==============================================================================

def smooth_curve(scalars, weight=0.6):
    """
    使用指数移动平均 (EMA) 对曲线进行平滑处理。
    """
    if len(scalars) == 0:
        return np.array([])
    last = scalars[0]
    smoothed = []
    for point in scalars:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed.append(smoothed_val)
        last = smoothed_val
    return np.array(smoothed)


def get_experiment_label(exp_path, folder_name):
    """
    尝试从配置文件中提取算法名称作为图例标签。
    """
    config_files = glob.glob(os.path.join(exp_path, '*_config.json'))
    if config_files:
        try:
            with open(config_files[0], 'r') as f:
                config = json.load(f)
                agent_name = config.get('agent_name')
                if agent_name:
                    return agent_name
        except Exception as e:
            print(f"  [Warn] Config read error: {e}")
    return folder_name


def find_column(df, candidates):
    """
    在 DataFrame 中查找存在的列名。
    返回找到的第一个列名，如果没有找到则返回 None。
    """
    for col in candidates:
        if col in df.columns:
            return col
    return None


def load_data_smart(exp_path):
    """
    智能加载数据：递归扫描目录下所有 CSV 文件，
    根据表头判断是 Train Log 还是 Eval Log。
    """
    train_df = None
    eval_df = None
    train_col_map = {}  # 记录找到的列名映射
    eval_col_map = {}

    # [修复] 使用递归 glob 查找子文件夹 (如 logs/) 中的 CSV
    csv_files = glob.glob(os.path.join(exp_path, '**', '*.csv'), recursive=True)

    print(f"  [Scanning] Found {len(csv_files)} csv files in {os.path.basename(exp_path)} (recursive)")

    for csv_file in csv_files:
        try:
            # 读取数据
            df = pd.read_csv(csv_file)
            columns = df.columns.tolist()
            # 显示相对路径以便调试
            rel_filename = os.path.relpath(csv_file, exp_path)

            # [诊断] 打印列名
            print(f"    > File: {rel_filename:<40} | Columns: {columns}")

            # 1. 尝试识别为训练日志 (寻找 Loss)
            found_loss = find_column(df, CANDIDATES_TRAIN_LOSS)
            if found_loss:
                train_df = df
                train_col_map['loss'] = found_loss
                # print(f"      -> Identified as TRAIN LOG (Loss Column: {found_loss})")
                continue

                # 2. 尝试识别为评估日志 (寻找 Test Fit)
            found_fit = find_column(df, CANDIDATES_TEST_FIT)
            if found_fit:
                eval_df = df
                eval_col_map['fit'] = found_fit
                # 同时也找一下 Epoch 列
                found_epoch = find_column(df, CANDIDATES_EPOCH)
                if found_epoch:
                    eval_col_map['epoch'] = found_epoch
                else:
                    eval_col_map['epoch'] = None

                # print(f"      -> Identified as EVAL LOG (Fit Column: {found_fit})")
                continue

        except Exception as e:
            print(f"  [Warn] Failed to read {csv_file}: {e}")

    return train_df, eval_df, train_col_map, eval_col_map


def plot_comparison():
    """
    主绘图逻辑
    """
    if not os.path.exists(TARGET_DIR):
        print(f"[Fatal] Target directory '{TARGET_DIR}' not found.")
        return

    subfolders = [f for f in os.listdir(TARGET_DIR) if os.path.isdir(os.path.join(TARGET_DIR, f))]
    if not subfolders:
        print(f"[Warn] No subfolders in '{TARGET_DIR}'.")
        return

    # 准备绘图
    plt.style.use('seaborn-v0_8-darkgrid')
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

    summary_data = []
    label_counts = {}
    colors = plt.cm.tab10(np.linspace(0, 1, max(len(subfolders), 1)))

    for idx, folder_name in enumerate(subfolders):
        exp_path = os.path.join(TARGET_DIR, folder_name)

        # 标签处理
        base_label = get_experiment_label(exp_path, folder_name)
        if base_label not in label_counts:
            label_counts[base_label] = 0
            final_label = base_label
        else:
            label_counts[base_label] += 1
            final_label = f"{base_label}_{label_counts[base_label]}"

        print(f"\n[Processing] {final_label}")

        # 加载数据
        train_df, eval_df, train_cols, eval_cols = load_data_smart(exp_path)
        color = colors[idx]

        # --- 绘图 1: Training Loss ---
        if train_df is not None and 'loss' in train_cols:
            col_name = train_cols['loss']
            loss_data = train_df[col_name].replace([np.inf, -np.inf], np.nan).dropna()

            if len(loss_data) > 0:
                smoothed = smooth_curve(loss_data.values, SMOOTH_WEIGHT)
                steps = range(len(smoothed))
                ax1.plot(steps, loss_data.values[:len(steps)], color=color, alpha=0.15)
                ax1.plot(steps, smoothed, color=color, label=final_label, linewidth=2)
        else:
            print(f"  [Error] No valid Training Loss data found.")

        # --- 绘图 2: Evaluation Fitness ---
        if eval_df is not None and 'fit' in eval_cols:
            col_fit = eval_cols['fit']
            col_epoch = eval_cols['epoch']

            fitness = eval_df[col_fit]

            if col_epoch:
                epochs = eval_df[col_epoch]
            else:
                epochs = range(len(fitness))

            ax2.plot(epochs, fitness, color=color, label=final_label, marker='o', markersize=4, linewidth=2)

            if len(fitness) > 0:
                summary_data.append({
                    'Algorithm': final_label,
                    'Final Mean': fitness.tail(5).mean(),
                    'Final Std': fitness.tail(5).std()
                })
        else:
            print(f"  [Error] No valid Eval Fitness data found.")

    # 设置图表
    ax1.set_title(f'Training Loss (Smoothed: {SMOOTH_WEIGHT})', fontsize=14)
    ax1.set_xlabel('Steps', fontsize=12)
    ax1.set_ylabel('Loss', fontsize=12)
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)

    ax2.set_title('Evaluation Fitness', fontsize=14)
    ax2.set_xlabel('Epochs', fontsize=12)
    ax2.set_ylabel('Fitness', fontsize=12)
    ax2.set_yscale('symlog')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    # 打印统计
    if summary_data:
        summary_data.sort(key=lambda x: x['Final Mean'])
        print("\n" + "=" * 60)
        print(f"{'Algorithm':<20} | {'Final Fitness':<20} | {'Std':<10}")
        print("-" * 60)
        for item in summary_data:
            print(f"{item['Algorithm']:<20} | {item['Final Mean']:<20.4e} | {item['Final Std']:<10.4e}")
        print("=" * 60 + "\n")


if __name__ == "__main__":
    plot_comparison()
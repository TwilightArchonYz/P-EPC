from graphviz import Digraph

# ==========================================
# 图 1：传统框架
# ==========================================
dot1 = Digraph(name='Traditional_Framework', format='pdf')
dot1.attr(fontname='Times-Roman', fontsize='12', rankdir='TB')
dot1.attr(nodesep='0.6', ranksep='0.8')
dot1.attr('node', fontname='Times-Roman', shape='box', style='rounded,filled', fillcolor='white')
dot1.attr('edge', fontname='Times-Roman', fontsize='10')

with dot1.subgraph(name='cluster_traditional') as c_trad:
    c_trad.attr(label='Traditional In-situ Learning (Tabula Rasa)', style='dashed', color='gray')

    c_trad.node('T_Inst', 'New Isolated Instance\n(Start from scratch)', fillcolor='#f9f9f9')
    c_trad.node('T_Agent', 'RL Agent\n(Untrained Policy)', shape='ellipse', fillcolor='#ffe6e6')
    c_trad.node('T_Env', 'Evolutionary Environment', fillcolor='#e6f2ff')

    c_trad.edge('T_Inst', 'T_Agent')
    c_trad.edge('T_Agent', 'T_Env', label=' Action (Parameters)')
    c_trad.edge('T_Env', 'T_Agent', label=' Reward & State\n[Repetitive Gradient Updates]', color='red', fontcolor='red')

dot1.render('fig1_traditional_learning', view=True)

from graphviz import Digraph

# ==========================================
# 图 2：本文提出的框架 (精准对齐版)
# ==========================================
dot2 = Digraph(name='Proposed_Framework', format='pdf')
dot2.attr(newrank='true')  # 开启新排版引擎以支持跨框对齐

# 核心修改 1：加入 splines='ortho'，强制所有连线使用横平竖直的正交折线
dot2.attr(fontname='Times-Roman', fontsize='12', rankdir='TB', compound='true', splines='ortho')
dot2.attr(nodesep='0.8', ranksep='0.8')

# 核心修改 2：给所有节点设定一个统一的基础高度 (height='0.6')，防止多行文本撑导致框体变形
dot2.attr('node', fontname='Times-Roman', shape='box', style='rounded,filled', fillcolor='white', height='0.6')
dot2.attr('edge', fontname='Times-Roman', fontsize='10')

# 左半部分：Phase 1 离线预训练
with dot2.subgraph(name='cluster_phase1') as p1:
    p1.attr(label='Phase 1: Offline Pre-training', style='dotted', color='blue', penwidth='2')

    p1.node('P_Dist', 'Problem Class Distribution', shape='folder', fillcolor='#f9f9f9')
    p1.node('P_TrainInst', 'Massive Training Instances\n(Domain Randomization)', fillcolor='#e6ffe6')
    p1.node('P_Agent', 'RL Agent\n(Extracting Dynamics)', shape='ellipse', fillcolor='#ffe6e6')

    p1.edge('P_Dist', 'P_TrainInst')
    p1.edge('P_TrainInst', 'P_Agent', label=' Extensive Interaction\n& Gradient Updates')

# 右半部分：Phase 2 零样本推理
with dot2.subgraph(name='cluster_phase2') as p2:
    p2.attr(label='Phase 2: Online Zero-Shot Inference', style='dotted', color='green', penwidth='2')

    p2.node('P_TestInst', 'Unseen Test Instance', fillcolor='#f9f9f9')
    p2.node('P_Pretrained', 'Pre-trained Policy\n(Frozen Weights)', shape='ellipse', fillcolor='#e6ffe6')
    p2.node('P_Env', 'Evolutionary Environment', fillcolor='#e6f2ff')

    p2.edge('P_TestInst', 'P_Pretrained')
    p2.edge('P_Pretrained', 'P_Env', label=' Real-time Parameter Adaptation\n[Forward Inference Only]', color='green',
            fontcolor='green')

# ==========================================
# 核心修改 3：像“搭脚手架”一样，把左右两边的上、中、下三层节点两两绝对绑定！
# 这样不仅节点会对齐，外部的虚线大框也会被撑得一模一样大且绝对平齐。
# ==========================================
dot2.body.append('{ rank=same; "P_Dist"; "P_TestInst"; }')  # 锁死顶部高度
dot2.body.append('{ rank=same; "P_TrainInst"; "P_Pretrained"; }')  # 锁死中部高度
dot2.body.append('{ rank=same; "P_Agent"; "P_Env"; }')  # 锁死底部高度

# ==========================================
# 核心修改 4：规范跨框虚线的走线路由 (正交 + 锚点锁定)
# 从左下 Agent 的“正右侧(e)”出发，水平向右，直角向上拐入右中 Policy 的“正下方(s)”
# ==========================================
dot2.edge('P_Agent:e', 'P_Pretrained:s', label=' Transfer Policy', style='dashed', constraint='false', tailport='e',
          headport='s')

# 渲染图表
dot2.render('fig2_proposed_framework_aligned', view=True)
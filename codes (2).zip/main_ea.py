import os
import time

# [System] 强制单核模式，防止并行争抢资源
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import numpy as np
import pickle
import datetime
import multiprocessing
from joblib import Parallel, delayed

# 导入核心问题定义
from evorl.problems import ScalableProblem
import evorl.problems.params_def as params_def

# 导入算法类
from evorl.algorithms.ea.shade import SolverSHADE
from evorl.algorithms.ea.lshade import SolverLSHADE
from evorl.algorithms.ea.jso import SolverjSO
from evorl.algorithms.ea.jade import SolverJADE
from evorl.algorithms.ea.imode import SolverIMODE
from evorl.algorithms.ea.ipso import SolverIPSO

# ==============================================================================
# 1. 全局配置 (Configuration)
# ==============================================================================

# 并行核心数
N_CORES = 30

# 问题配置
PROBLEMS = list(range(1, 21))  # Problem 1-20
# [Update] 维度更新为 30, 40, 50
DIMS = [30, 40, 50]
INSTANCES = list(range(1, 13))  # Instances 1-12
SEEDS = list(range(1, 21))  # Seeds 1-20

# 评价预算
MAX_FES_FACTOR = 10000  # MaxFES = 10000 * D

# 种群规模配置
POP_SIZE_FACTOR_FIXED = 20  # 固定种群类: 10 * D

# 算法名单与分类
ALGOS_FIXED   = ['SHADE', 'JADE', 'IPSO']
ALGOS_DYNAMIC = ['L-SHADE', 'jSO', 'IMODE']

# 算法类映射
ALGO_MAP = {
    'SHADE': SolverSHADE,
    'L-SHADE': SolverLSHADE,
   'jSO': SolverjSO,
    'JADE': SolverJADE,
    'IMODE': SolverIMODE,
    'IPSO': SolverIPSO
}

# 输出路径
SAVE_PATH = 'experiments/benchmarks/benchmark_results_5000D_30_40_50.pkl'


# ==============================================================================
# 2. 工作进程 (Worker)
# ==============================================================================

def run_single_task(task_args):
    """
    执行单个 (Algo, Problem, Dim, Instance, Seed) 任务
    """
    algo_name, pid, dim, inst, seed = task_args

    # A. 初始化问题环境
    try:
        param_dict, pf1, pf2 = params_def.generate_instance_config(pid, dim, inst)
        problem = ScalableProblem(pid, dim, param_dict, pf1=pf1, pf2=pf2)
    except Exception as e:
        # 捕获问题初始化可能的错误
        return None

    # B. 确定超参
    max_nfes = MAX_FES_FACTOR * dim

    # [Fix] 显式计算种群大小，不再传递 None，修复 L-SHADE 报错
    if algo_name in ALGOS_FIXED:
        pop_size = POP_SIZE_FACTOR_FIXED * dim
    else:
        # 动态种群类 (L-SHADE, jSO, IMODE)
        # 显式传递标准初始值 18 * D，避免算法内部因 None 报错
        pop_size = 18 * dim

    # C. 实例化算法
    SolverClass = ALGO_MAP[algo_name]

    solver = SolverClass(
        problem=problem,
        pop_size=pop_size,
        max_nfes=max_nfes,
        seed=seed
    )

    # D. 执行优化 (Manual Loop)
    start_time = time.time()

    try:
        solver.initialize()

        # 历史记录: List of [fes, best_fitness]
        history = []
        # 记录初始状态
        history.append([float(solver.fes), float(solver.gbest_val)])

        while solver.fes < solver.max_nfes:
            solver.evolve()

            curr_fes = float(solver.fes)
            curr_fit = float(solver.gbest_val)
            history.append([curr_fes, curr_fit])

    except Exception as e:
        print(f"[Error] Execution Failed: {algo_name}-P{pid}-D{dim}-I{inst}-S{seed} | {e}")
        return None

    end_time = time.time()
    runtime = end_time - start_time

    # E. 整理结果
    final_fitness = float(solver.gbest_val)
    history_np = np.array(history, dtype=np.float32)

    # 构建唯一键
    key = (algo_name, pid, dim, inst, seed)

    return key, final_fitness, history_np, runtime


# ==============================================================================
# 3. 主流程 (Main)
# ==============================================================================

def main():
    print("=" * 60)
    print(f"BENCHMARK STARTING: {datetime.datetime.now()}")
    print(f"Cores: {N_CORES} (OMP_NUM_THREADS=1)")
    print(f"MaxFES: {MAX_FES_FACTOR} * D")
    print(f"Dims: {DIMS}")
    print(f"Algorithms: {list(ALGO_MAP.keys())}")
    print("=" * 60)

    # 1. 生成任务列表
    tasks = []
    for algo in ALGO_MAP.keys():
        for pid in PROBLEMS:
            for dim in DIMS:
                for inst in INSTANCES:
                    for seed in SEEDS:
                        tasks.append((algo, pid, dim, inst, seed))

    total_tasks = len(tasks)
    print(f"[System] Generated {total_tasks} tasks.")

    # 2. 并行执行
    results_list = Parallel(n_jobs=N_CORES, verbose=10)(
        delayed(run_single_task)(task) for task in tasks
    )

    # 3. 数据汇总
    print("[System] Aggregating results...")
    benchmark_data = {}

    success_count = 0
    fail_count = 0

    for res in results_list:
        if res is None:
            fail_count += 1
            continue

        key, final_fit, history, runtime = res
        benchmark_data[key] = {
            "final_fitness": final_fit,
            "history": history,
            "runtime": runtime
        }
        success_count += 1

    print(f"[System] Completed. Success: {success_count}, Failed: {fail_count}")

    # 4. 持久化保存
    os.makedirs(os.path.dirname(SAVE_PATH), exist_ok=True)
    with open(SAVE_PATH, 'wb') as f:
        pickle.dump(benchmark_data, f)

    print(f"[System] Saved results to: {SAVE_PATH}")
    print(f"BENCHMARK FINISHED: {datetime.datetime.now()}")


if __name__ == "__main__":
    main()
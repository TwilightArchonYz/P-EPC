from graphviz import Digraph

# ==========================================
# 保持原设置（完全未修改）
# ==========================================
dot = Digraph(name='MDP_Loop_Final', format='pdf')
dot.attr(rankdir='TB', nodesep='0.5', ranksep='0.1')
dot.attr('node', fontname='Arial', shape='box', style='rounded,filled', fillcolor='white')
dot.attr('edge', fontname='Arial', fontsize='10')

# ==========================================
# 1. 顶部 (北)：RL Agent
# ==========================================
dot.node('Agent', '<RL Agent<BR/>Policy <I>&pi;<SUB>&theta;</SUB></I>>', fillcolor='#ffe6e6', height='0.8', width='2.5')

# ==========================================
# 2. 中间层：左侧动作解码 (西) & 右侧状态感知 (东)
# 核心修改：去掉了正文加粗，给向量 a_t, h_t 加上了 <B> 加粗标签
# ==========================================
action_decoding_html = '''<
<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0" CELLPADDING="4">
    <TR><TD BGCOLOR="#e0e0e0">Action Decoding</TD></TR>
    <TR><TD BGCOLOR="#f9f9f9">Normalized Action <B><I>a<SUB>t</SUB></I></B> &isin; [0, 1]<SUP><I>d</I></SUP></TD></TR>
    <TR><TD BGCOLOR="#f9f9f9">Mapping Operator <I>&psi;</I></TD></TR>
    <TR><TD BGCOLOR="#e6ffe6">Physical Parameters <B><I>h<SUB>t</SUB></I></B></TD></TR>
</TABLE>>'''
dot.node('Decoding', label=action_decoding_html, shape='none', margin='0')

# 核心修改：去掉了正文加粗，给状态特征向量 o_env, o_pop, o_dyn, o_cfg 加上了 <B> 加粗标签
# (标量奖励 r_t 保持普通斜体)
state_reward_html = '''<
<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0" CELLPADDING="4">
    <TR><TD COLSPAN="4" BGCOLOR="#e0e0e0">State &amp; Reward Perception</TD></TR>
    <TR>
        <TD BGCOLOR="#fff2cc">Context<BR/><B><I>o<SUB>env</SUB></I></B></TD>
        <TD BGCOLOR="#d9ead3">Population<BR/><B><I>o<SUB>pop</SUB></I></B></TD>
        <TD BGCOLOR="#cfe2f3">Dynamics<BR/><B><I>o<SUB>dyn</SUB></I></B></TD>
        <TD BGCOLOR="#f4cccc">Config<BR/><B><I>o<SUB>cfg</SUB></I></B></TD>
    </TR>
    <TR><TD COLSPAN="4" BGCOLOR="#fff2cc">Relative Time Reward <I>r<SUB>t</SUB></I></TD></TR>
</TABLE>>'''
dot.node('Perception', label=state_reward_html, shape='none', margin='0')

# ==========================================
# 建立隐形十字脚手架 (维持居中，未修改)
# ==========================================
dot.node('Center', '', shape='point', width='0', height='0', style='invis')

with dot.subgraph() as s:
    s.attr(rank='same')
    s.node('Decoding')
    s.node('Center')
    s.node('Perception')
    s.edge('Decoding', 'Center', style='invis')
    s.edge('Center', 'Perception', style='invis')

# ==========================================
# 3. 底部 (南)：执行环境 (未修改)
# ==========================================
dot.node('Env', 'Evolutionary Environment\n(Population & Operators)', fillcolor='#e6f2ff', height='0.8', width='4.0')

# ==========================================
# 垂直中轴线 (未修改)
# ==========================================
dot.edge('Agent', 'Center', style='invis', weight='10')
dot.edge('Center', 'Env', style='invis', weight='10')

# ==========================================
# 4. 连线路由 (自然曲线，未修改)
# ==========================================
dot.edge('Agent:w', 'Decoding:n', label=' Action', tailport='w', headport='n')
dot.edge('Decoding:s', 'Env:w', label=' Apply to Ops', tailport='s', headport='w')
dot.edge('Env:e', 'Perception:s', label=' Extract Features', tailport='e', headport='s', constraint='false')
dot.edge('Perception:n', 'Agent:e', label=' State & Reward', tailport='n', headport='e', constraint='false')

# 渲染生成 PDF
dot.render('mdp_loop_perfect', view=True)
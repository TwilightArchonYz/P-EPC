from graphviz import Digraph

# 初始化有向图，设置自上而下布局 (TB) 和正交折线 (ortho)
dot = Digraph(name='Data_Isolation_Protocol_V2', format='pdf')
dot.attr(rankdir='TB', splines='ortho', nodesep='0.1', ranksep='0.3')
dot.attr('node', fontname='Arial', shape='box', style='rounded,filled', fillcolor='white')
dot.attr('edge', fontname='Arial', fontsize='10')

# ==========================================
# 第一层：顶层生成区
# ==========================================
dot.node('Base', 'Base Problem Class\n(Shared Mathematical Structure)', fillcolor='#e6f2ff', fontname='Arial Bold')

# 去掉具体操作细节，只保留分类和编号
dot.node('Unconstrained', 'Unconstrained (P1-P10)', fillcolor='#f9f9f9')
dot.node('Constrained', 'Constrained (P11-P20)', fillcolor='#f9f9f9')

# 强制锚点 (s=南, n=北)，使正交线条更像工程管线
dot.edge('Base:s', 'Unconstrained:n')
dot.edge('Base:s', 'Constrained:n')

# 领域随机化池
dot.node('Pool', 'Domain Randomization\nGenerates N Heterogeneous Instances', shape='cylinder', fillcolor='#e6ffe6',
         style='filled')
dot.edge('Unconstrained:s', 'Pool:n')
dot.edge('Constrained:s', 'Pool:n')

# ==========================================
# 第二层：中间分流区 (扁平化隔离器)
# ==========================================
dot.node('Splitter', 'Strict Instance-wise Isolation\n(Mutually Exclusive Partitioning)', fillcolor='#fff2cc', width='4.5',
         height='0.6')
dot.edge('Pool:s', 'Splitter:n', label=' Mutually Exclusive Split')

# ==========================================
# 第三层：底层功能区 (三大数据集，带图标和左对齐)
# ==========================================
with dot.subgraph() as s:
    s.attr(rank='same')

    # 训练集：删除了括号里的实例数量
    train_html = '''<
        <TABLE BORDER="0" CELLBORDER="0" CELLSPACING="2">
            <TR><TD ALIGN="CENTER"><B>Training Set</B></TD></TR>
            <TR><TD ALIGN="LEFT">⚙️ Policy Optimization</TD></TR>
            <TR><TD ALIGN="LEFT">🔄 Gradient Backpropagation</TD></TR>
        </TABLE>
    >'''
    s.node('Train', label=train_html, shape='box', fillcolor='#d9ead3', color='green', penwidth='2')

    # 验证集：删除了括号里的实例数量
    val_html = '''<
        <TABLE BORDER="0" CELLBORDER="0" CELLSPACING="2">
            <TR><TD ALIGN="CENTER"><B>Validation Set</B></TD></TR>
            <TR><TD ALIGN="LEFT">🔍 Model Selection</TD></TR>
            <TR><TD ALIGN="LEFT">💾 Save Best Checkpoint</TD></TR>
        </TABLE>
    >'''
    s.node('Val', label=val_html, shape='box', fillcolor='#fff2cc', color='orange', penwidth='2')

    # 测试集：删除了括号里的实例数量
    test_html = '''<
        <TABLE BORDER="0" CELLBORDER="0" CELLSPACING="2">
            <TR><TD ALIGN="CENTER"><B>Test Set</B></TD></TR>
            <TR><TD ALIGN="LEFT">🔒 Zero-Shot Evaluation</TD></TR>
            <TR><TD ALIGN="LEFT">🚫 Strictly Unseen (No Updates)</TD></TR>
        </TABLE>
    >'''
    s.node('Test', label=test_html, shape='box', fillcolor='#f4cccc', color='red', penwidth='2')

# 形成清晰的“三叉戟”正交分支
dot.edge('Splitter:s', 'Train:n')
dot.edge('Splitter:s', 'Val:n')
dot.edge('Splitter:s', 'Test:n')

# 渲染图表
dot.render('data_isolation_protocol_v2', view=True)